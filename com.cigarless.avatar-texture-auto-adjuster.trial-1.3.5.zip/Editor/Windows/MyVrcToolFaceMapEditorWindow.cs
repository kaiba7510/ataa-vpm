// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Windows/MyVrcToolFaceMapEditorWindow.cs
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディター（メイク基準作成画面、Issue #16）。購入したメイクテクスチャの基準位置（FaceMap）を、
    /// 数クリックのラフ配置で素早く作成・補正するユーティリティ。画面は UI案A（docs~/UI/facemap_editor_ui_proposal_a.html）を
    /// UI Toolkit で組んだもの（UXML/USS は Editor/Windows/UI/FaceMapEditorWindow.*）:
    /// 【上部ツールバー】[新規作成] [読込] [自動生成] [3D ビュー] [上書き保存] [別名保存] と、編集中のファイル名・必須の数
    /// 【左】テクスチャビュー（IMGUIContainer）: 左クリックで配置・選択・枠の移動・四隅で拡縮、中/右ドラッグでパン、ホイールでズーム。
    ///       上に倍率・全体表示・対称軸表示・選択中のパーツ、上と左に U/V の定規、テクスチャが無いときはドロップカード
    /// 【右】インスペクター: 顔パレット（線画シルエット）、選択中パーツの詳細、折りたたみ（対称軸・自動作成・情報）、「保存して完了」
    /// 【下】ステータスバー: 次にすべきことの案内（新規作成ウィザード: 鼻 → 左目 → 口）
    /// Ctrl+Z / Ctrl+Y で元に戻す・やり直し（§12.5）。
    /// </summary>
    public partial class MyVrcToolFaceMapEditorWindow : EditorWindow
    {

        private readonly FaceMapEditorViewModel _vm = new();

        // 同期の時点のスナップショット（表示に使う）
        private HashSet<string> _placedSnapshot = new HashSet<string>();
        private string _targetLabel;
        private string _targetText;
        private string _guideMessage;
        private int _placedRequired;
        private bool _panelBound;
        private bool _hasTexture;
        private float? _panelCenter;
        private bool _panelMirror;

        // 自動作成の要確認（§12.6）: 未確認の領域・選択中がそうか・次に案内する領域
        private HashSet<string> _activeChecks = new HashSet<string>();
        private bool _panelSelectedIsCheck;
        private string _panelNextCheck;
        private string _panelStyleText;

        private const float MinTexSize = 420f;
        private const float InspectorWidth = 320f;

        // ── UI Toolkit ──
        private bool _uiBuilt;
        private bool _uiDirty = true;
        private bool _hoverDirty;
        private bool _scrubbing;
        private bool _suppressUiEvents;
        private VisualElement _root;

        /// <summary>例外をログした区画（同じ区画の失敗は 1 回だけログする）。</summary>
        private readonly HashSet<string> _uiErrorsReported = new HashSet<string>();

        private static void LogUiSectionError(string section, System.Exception ex)
        {
            Debug.LogError($"[ATAA] FaceMap エディターの画面「{section}」でエラーが出ました（ほかの部分は動かし続けます）。UXML と C# の版が合っているか確認してください。");
            Debug.LogException(ex);
        }

        internal static void ShowWindow()
        {
            ShowOrFocusWindow();
        }

        private static MyVrcToolFaceMapEditorWindow ShowOrFocusWindow()
        {
            bool alreadyOpen = HasOpenInstances<MyVrcToolFaceMapEditorWindow>();
            var window = GetWindow<MyVrcToolFaceMapEditorWindow>("FaceMap エディター");
            window.minSize = new Vector2(MinTexSize + InspectorWidth + 40f, MinTexSize + 80f);

            if (!alreadyOpen)
            {
                Rect p = window.position;
                p.size = new Vector2(1180f, 780f);
                window.position = p;
            }
            return window;
        }

        /// <summary>
        /// 保存した FaceMap を開いて、目の線を合わせる状態にする（左の目を選び、3D ビューを開いて目に寄せる）。
        /// メイクフィックス画面の「アバター基準を自動生成」で目の線を決められなかったときに使う（§11.22）。
        /// </summary>
        internal static void OpenForEyeLineReview(string path, GameObject avatar, SkinnedMeshRenderer renderer, Texture2D faceTexture, string issue)
        {
            var window = ShowOrFocusWindow();
            if (window._vm.OpenForEyeLineReview(path, avatar, renderer, faceTexture, issue))
            {
                if (window._transientTexture != null && !ReferenceEquals(window._transientTexture, faceTexture))
                    window.DisposeTransientTexture();
                window.MarkUiDirty();
                if (window._uiBuilt) window.SyncAndRefreshUi();
                window.Repaint();
            }
        }

        /// <summary>メインウィンドウの「FaceMap エディターで微調整」: 選択中の FaceMap・アバター・顔メッシュ・顔テクスチャを引き継いで開く。</summary>
        internal static void OpenForRefinement(string path, GameObject avatar, SkinnedMeshRenderer renderer, Texture2D faceTexture)
        {
            var window = ShowOrFocusWindow();
            if (window._vm.OpenForRefinement(path, avatar, renderer, faceTexture))
            {
                if (window._transientTexture != null && !ReferenceEquals(window._transientTexture, faceTexture))
                    window.DisposeTransientTexture();
                window.MarkUiDirty();
                if (window._uiBuilt) window.SyncAndRefreshUi();
                window.Repaint();
            }
        }

        /// <summary>メインウィンドウの「この画像で手動作成」: メイクテクスチャを引き継いだ新規作成で開き、保存時に通知する。</summary>
        internal static void OpenForNewMakeup(Texture2D makeupTexture, System.Action<string> onSaved)
        {
            var window = ShowOrFocusWindow();
            if (window._vm.OpenForNewMakeup(makeupTexture, onSaved))
            {
                if (window._transientTexture != null && !ReferenceEquals(window._transientTexture, makeupTexture))
                    window.DisposeTransientTexture();
                window.ResetZoom();
                window.MarkUiDirty();
                if (window._uiBuilt)
                {
                    window.SyncAndRefreshUi();
                    window._viewImgui?.Focus();
                }
                window.Repaint();
            }
        }

        private Texture2D _transientTexture;

        private void DisposeTransientTexture()
        {
            if (_transientTexture != null)
            {
                DestroyImmediate(_transientTexture);
                _transientTexture = null;
            }
        }

        private void OnEnable()
        {
            wantsMouseMove = true;
            wantsMouseEnterLeaveWindow = true;
            saveChangesMessage = AtaaCore.Edition == CoreEdition.Trial
                ? "FaceMap に未保存の変更があります。一時保存しますか?（体験版はメモリに保存し、Unity を閉じると消えます）"
                : "FaceMap に未保存の変更があります。保存しますか?";
            EditorApplication.update += OnEditorUpdate;
            Undo.undoRedoPerformed += OnUndoRedo;
            _orbit = new FaceOrbitView();
            _vm.RequestFileName = AskFileName;
            _showAxis = EditorPrefs.GetBool(ShowAxisPrefsKey, true);
        }

        /// <summary>新規保存（別名保存・保存先が無いときの上書き保存）で、保存する名前を聞く。保存先は FaceMaps フォルダに決まっている。</summary>
        private static string AskFileName(string initial, string folder)
        {
            bool trial = AtaaCore.Edition == CoreEdition.Trial;
            string title = trial ? "別名で一時保存" : "別名保存";
            string prompt = trial
                ? "一時保存するメイク基準の名前を入れてください（体験版はメモリに保存し、Unity を閉じると消えます）。"
                : "保存するメイク基準のファイル名を入れてください（FaceMaps フォルダに保存します）。";
            return NameInputDialog.Show(title, prompt,
                initial, "保存",
                name =>
                {
                    string file = FaceMapSerializer.SanitizeFileName(name);
                    if (file.Length == 0) return new NameInputDialog.NameCheck { Error = "ファイル名に使える文字がありません。" };
                    bool exists = FaceMapStorage.Exists(System.IO.Path.Combine(folder, file + ".json"));
                    return new NameInputDialog.NameCheck
                    {
                        Note = exists ? $"{file}.json は既にあります（保存すると上書きの確認が出ます）。" : $"保存されるファイル: {file}.json"
                    };
                });
        }

        private void OnDisable()
        {
            EditorApplication.update -= OnEditorUpdate;
            Undo.undoRedoPerformed -= OnUndoRedo;
            _orbit?.Dispose();
            _orbit = null;
            DisposeTransientTexture();
            // 閉じる・再コンパイルで編集中のデータは消えるので、履歴も消す（§12.5）
            _vm.History.Dispose();
        }

        private void OnUndoRedo()
        {
            if (_vm.OnUndoRedo()) MarkUiDirty();
        }

        private void OnLostFocus()
        {
            _panning = false;
            _orbit?.CancelDrag();
            if (_vm.IsDraggingControlPoint) _vm.EndDrag();
            MarkUiDirty();
        }

        public override void SaveChanges()
        {
            // 保存に成功したときだけ base を呼び、未保存フラグを下ろす
            if (_vm.SaveOverwrite()) base.SaveChanges();
        }

        // ── UI Toolkit の組み立て ──

        private void CreateGUI()
        {
            _uiBuilt = false;
            rootVisualElement.Clear();

            string apiMismatch = CoreApiCompatibility.GetMismatchMessage();
            if (apiMismatch != null)
            {
                Debug.LogError("[ATAA] " + apiMismatch);
                var err = new Label(apiMismatch);
                err.style.whiteSpace = WhiteSpace.Normal;
                err.style.paddingLeft = 12;
                err.style.paddingRight = 12;
                err.style.paddingTop = 12;
                rootVisualElement.Add(err);
                return;
            }

            VisualTreeAsset uxml = UiAssets.Load<VisualTreeAsset>("FaceMapEditorWindow", ".uxml");
            StyleSheet uss = UiAssets.Load<StyleSheet>("FaceMapEditorWindow", ".uss");
            if (uss != null) rootVisualElement.styleSheets.Add(uss);
            if (uxml == null)
            {
                var err = new Label("FaceMapEditorWindow.uxml が見つかりませんでした。");
                err.style.paddingLeft = 12;
                err.style.paddingTop = 12;
                rootVisualElement.Add(err);
                return;
            }
            uxml.CloneTree(rootVisualElement);
            _root = rootVisualElement.Q<VisualElement>("fm-root");
            _root.style.flexGrow = 1;
            rootVisualElement.focusable = true;

            // 区画ごとに組み立てる。1 つが落ちても（UXML の要素が欠けているなど）残りは動かす。
            // 以前はインスペクターの Bind の例外で _uiBuilt が立たず、テクスチャを入れてもドロップカードが消えなかった
            _uiErrorsReported.Clear();
            UiSections.RunEach(_uiErrorsReported, LogUiSectionError,
                ("Bind:Toolbar", BindToolbarUi),
                ("Bind:Viewport", BindViewportUi),
                ("Bind:3D", Bind3DUi),
                ("Bind:Inspector", BindInspectorUi),
                ("Bind:Status", BindStatusUi));
            rootVisualElement.RegisterCallback<KeyDownEvent>(OnRootKeyDown, TrickleDown.TrickleDown);

            _uiBuilt = true;
            _uiDirty = true;
            SyncAndRefreshUi();
            _viewImgui?.Focus();
            rootVisualElement.schedule.Execute(() => { if (_uiBuilt) SyncAndRefreshUi(); });
        }

        /// <summary>状態が変わった。次の EditorApplication.update で画面を同期し、テクスチャビューを描き直す。</summary>
        private void MarkUiDirty()
        {
            _uiDirty = true;
            _viewImgui?.MarkDirtyRepaint();
            if (_show3D) _view3DImgui?.MarkDirtyRepaint();
        }

        private void OnEditorUpdate()
        {
            if (!_uiBuilt) return;
            if (_uiDirty)
            {
                SyncAndRefreshUi();
                return;
            }
            if (_hoverDirty)
            {
                _hoverDirty = false;
                RefreshStatusChip();
            }
            if (_rulersDirty) UpdateRulers();
        }

        private void SyncAndRefreshUi()
        {
            if (!_uiBuilt) return;
            _uiDirty = false;
            _hoverDirty = false;

            ConsumeRequests();
            UpdateSnapshot();
            hasUnsavedChanges = _vm.NeedsSavePrompt;

            _suppressUiEvents = true;
            try
            {
                // テクスチャビュー（ドロップカード）を先に。ほかの区画で例外が出ても止めない
                UiSections.RunEach(_uiErrorsReported, LogUiSectionError,
                    ("Refresh:Viewport", RefreshViewportUi),
                    ("Refresh:Toolbar", RefreshToolbarUi),
                    ("Refresh:Inspector", RefreshInspectorUi),
                    ("Refresh:Status", RefreshStatusUi));
            }
            finally
            {
                _suppressUiEvents = false;
            }

            _viewImgui?.MarkDirtyRepaint();
            if (_show3D) _view3DImgui?.MarkDirtyRepaint();
        }

        /// <summary>ViewModel からの依頼（要確認の領域を選んだ・目の線を合わせる案内）を受ける。</summary>
        private void ConsumeRequests()
        {
            if (_vm.AdjustFocusRequested)
            {
                // 要確認の領域を選択した直後: 入力欄のフォーカスを外して矢印キーをすぐ使えるようにし、詳細欄を先頭へ
                _vm.ConsumeAdjustFocus();
                _viewImgui?.Focus();
                if (_inspectorScroll != null) _inspectorScroll.scrollOffset = Vector2.zero;
                Focus();
            }
            if (_vm.EyeLineReviewRequested)
            {
                // 目の線を合わせる案内を受けた直後: 3D ビューを開いて目に寄せる
                _vm.ConsumeEyeLineReview();
                Set3DVisible(true);
                _focusEyesPending = true;
            }
        }

        private void UpdateSnapshot()
        {
            int count = _vm.State.Points.Count;
            if (_vm.SelectedPoint >= count) _vm.SelectPoint(count - 1);
            _vm.PanelSelected = _vm.SelectedPoint;

            _placedSnapshot = _vm.Service.PlacedLabels();
            _placedRequired = _vm.Service.PlacedRequiredCount();

            UpdateTarget();
            _guideMessage = _vm.GuideMessage();

            _panelBound = !string.IsNullOrEmpty(_vm.State.BoundPath);
            _panelCenter = _vm.State.CenterX;
            _panelMirror = _vm.MirrorEnabled;

            _activeChecks = _vm.ActiveCheckLabels();
            int selIdx = _vm.PanelSelected;
            string selLabel = selIdx >= 0 && selIdx < count ? _vm.State.Points[selIdx].Label : null;
            _panelSelectedIsCheck = selLabel != null && _activeChecks.Contains(selLabel);
            _panelNextCheck = _vm.NextCheckLabel(selLabel);
            _panelStyleText = _vm.AutoStyleText;
        }

        /// <summary>次に置くパーツ（テクスチャビューの案内にも使うので、ビューの描画からも呼ぶ）。</summary>
        private void UpdateTarget()
        {
            FaceTemplateEntry target = _vm.TargetEntry;
            _targetLabel = target?.Label;
            _targetText = target == null ? null : $"{FaceIllustrationPalette.ShortName(target.Label)}（{FaceTemplateText.Describe(target.Label)}）";
            _hasTexture = _vm.State.Texture != null;
        }

        // ── キーボード: 矢印キーで選択中の領域を動かす（微調整 PAD と同じ移動量。Alt で片側だけ）──

        private void OnRootKeyDown(KeyDownEvent evt)
        {
            Vector2? dir = FaceMapEditorUi.NudgeDirection(evt.keyCode);
            if (!dir.HasValue) return;
            int sel = _vm.SelectedPoint;
            if (!FaceMapEditorUi.AcceptsNudgeKey(evt.ctrlKey || evt.commandKey, IsTextInputFocused(),
                    _vm.IsDraggingControlPoint || _scrubbing || _panning, sel, _vm.State.Points.Count))
                return;

            _vm.Nudge(sel, dir.Value * NudgePad.CurrentStep(NudgePad.FaceMapEditorStepKey), evt.altKey);
            evt.StopPropagation();
            evt.PreventDefault();
            MarkUiDirty();
        }

        /// <summary>入力欄・スライダーにフォーカスがあるか（そのときの矢印キーは入力欄のもの）。IMGUI の状態は読まない。</summary>
        private bool IsTextInputFocused()
        {
            for (var e = rootVisualElement.focusController?.focusedElement as VisualElement; e != null; e = e.parent)
            {
                if (e is TextField || e is FloatField || e is IntegerField || e is BaseSlider<float> || e is DropdownField) return true;
            }
            return false;
        }

        /// <summary>保存したファイル名を、ビューの中央に大きく出す（数秒で消える）。</summary>
        private void NotifySaved()
        {
            if (string.IsNullOrEmpty(_vm.State.BoundPath)) return;
            ShowNotification(new GUIContent($"保存しました\n{System.IO.Path.GetFileName(_vm.State.BoundPath)}"), 3.0);
        }

        private void SaveOverwriteAndNotify()
        {
            if (_vm.SaveOverwrite()) NotifySaved();
            MarkUiDirty();
        }

        /// <summary>［自動生成］。アバターの準備ができていれば自動作成、無ければ指定するか標準位置に仮配置するかを選ぶ。</summary>
        private void OnAutoGenerateClicked()
        {
            _vm.RefreshAutoInputs();
            if (_vm.State.TargetAvatarObject != null && _vm.AutoRenderer != null && _vm.AutoBlink >= 0)
            {
                _vm.RunAutoGenerate();
                MarkUiDirty();
                return;
            }

            int choice = EditorUtility.DisplayDialogComplex("自動生成",
                "アバター（または顔のレンダラー・まばたきのブレンドシェイプ）が指定されていません。\n" +
                "アバターを指定すると、顔メッシュから目・鼻・口・頬の位置を推定できます。\n" +
                "テンプレートの標準位置に仮配置して、手で合わせることもできます。",
                "アバターを指定する", "キャンセル", "標準位置に仮配置");
            if (choice == 0)
            {
                OpenAutoFoldout();
                _vm.State.Warning = "右の「アバターから自動作成」でアバターを指定して、もう一度［自動生成］を押してください。";
                _vm.State.WarningType = MessageType.Info;
            }
            else if (choice == 2)
            {
                if (_vm.State.Points.Count > 0 &&
                    !EditorUtility.DisplayDialog("自動生成", "置いた領域を標準位置の仮配置で置き換えます。よろしいですか?\n（Ctrl+Z で元に戻せます）",
                        "置き換える", "キャンセル"))
                    return;
                _vm.PlaceTemplateDefaults();
            }
            MarkUiDirty();
        }
    }
}
