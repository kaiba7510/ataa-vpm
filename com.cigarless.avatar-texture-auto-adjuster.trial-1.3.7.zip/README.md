# Avatar Texture Auto Adjuster (ATAA)

あるアバター用に作られた顔のテクスチャ（メイク）を、別のアバターの顔に合わせて自動で変形・合成する Unity エディター拡張です。
目・まぶた・下まつ毛・鼻・口・頬の位置と形の違いに合わせてメイクを変形し、肌色をなじませて非破壊で顔テクスチャに合成します。

## 動作環境

- Unity 2022.3（VRChat 推奨バージョン）
- Newtonsoft Json（`com.unity.nuget.newtonsoft-json`）。VRChat SDK を導入済みのプロジェクトには含まれています（VPM 版は `com.vrchat.base >= 3.4.0` に依存します）。
- エディター専用です。アバターのビルド・アップロードには含まれません。

## 導入

次のどちらかの方法でプロジェクトに追加してください。

- **VCC（VRChat Creator Companion）**:
  1. VCC の「Settings → Packages → Add Repository」に、BOOTH の商品ページ（または購入時にダウンロードした案内ファイル）に記載のリポジトリ URL を追加します。
  2. 対象プロジェクトの「Manage Project」から `Avatar Texture Auto Adjuster`（体験版は `Avatar Texture Auto Adjuster（体験版）`）を追加します。
  3. 以後のアップデートも VCC から行えます。
- **`.unitypackage`**:
  1. 配布された `.unitypackage` を Unity プロジェクトにインポートします。
  2. `Assets/Cigarless/AvatarTextureAutoAdjuster/` に展開されます（フォルダは移動しても動作します）。

### エディションの併用とデータ保存先

- **体験版と製品版は同時に導入できません**。VCC で製品版を追加すると、体験版は自動で外れます。`.unitypackage` 版で入れ替える場合は、古い `Assets/Cigarless/AvatarTextureAutoAdjuster` フォルダを削除してから新しい版をインポートしてください。
- **ユーザーデータの保存先**: ツールが作るもの・出力するものは、すべてショップのフォルダの直下の `Assets/Cigarless/ATAA_Data/` に保存されます（製品版）。ツール本体のフォルダ（`Assets/Cigarless/AvatarTextureAutoAdjuster/`）とは別なので、ツールを入れ直す・更新するときも消えません。`Assets/Cigarless/ATAA_Data` は削除しないでください。

  | 場所 | 中身 |
  |---|---|
  | `ATAA_Data/FaceMaps/` | 作成・自動生成した FaceMap（`.json`） |
  | `ATAA_Data/FaceMaps/Adjustments/` | 組み合わせごとの微調整 |
  | `ATAA_Data/FaceMaps/Generated/<アバター>/<メイク>/` | メイク適用で書き出した合成テクスチャと複製マテリアル。**適用したアバターがこれを参照しているので、消すとアバターの見た目が元に戻らなくなります** |
  | `ATAA_Data/Makeups/` | プロジェクトの外から読み込んだメイク画像のコピー |

- `Assets/Cigarless/` ごと削除すると、このデータも消えます。ツールを入れ直すときは `Assets/Cigarless/AvatarTextureAutoAdjuster` だけを削除してください。
- **以前の版からの移行**: 1.3.5 までの版は `Assets/ATAA_Data/` に保存していました。製品版を開いたときに `Assets/Cigarless/ATAA_Data/` へ自動で移し、ダイアログでお知らせします（参照 GUID も保たれるので、適用済みのアバターはそのまま使えます）。同じ名前のファイルが両方にあるときは上書きせずに古い側に残し、ダイアログと Console に一覧を出します。さらに前の版でツールのフォルダ内（`AvatarTextureAutoAdjuster/FaceMaps/`）に保存していた FaceMap も、同じく自動で移します。

## 体験版と製品版の違い

| 機能 | 体験版 | 製品版 |
|---|---|---|
| アバター自動認識・FaceMap 作成・フィッティング調整 | ○ | ○ |
| 3D ビュー / 2D UV プレビュー・ライブプレビュー | ○ | ○ |
| プレビュー解像度 | 通常 512px（透かしなし）<br>右下の高画質ボタン長押し中のみ 2048px（透かし入り） | 最大 4096px（透かしなし） |
| メイク適用（テクスチャ・マテリアルの書き出し） | ×（ボタン無効） | ○（元の解像度・最大 8192px） |
| FaceMap・調整データの保存 | メモリ上に一時保存（Unity を閉じると消えます） | `Assets/Cigarless/ATAA_Data/FaceMaps/` にファイル保存 |

## 使い方の概要

詳しい画面説明・各機能・トラブルシューティングは、同梱の `USAGE.md` をご覧ください。
作業の前に、Unity プロジェクトのバックアップを取っておくことをおすすめします。

1. メニューの **Cigarless > ATAA** からウィンドウを開きます。
2. 左の **アバター管理** でシーン上の対象アバターを選びます（顔メッシュ・アバター基準・顔テクスチャが自動で認識されます）。
3. 右の **フィッティング調整 > メイク元** で、使いたいメイクテクスチャとメイク元の基準（FaceMap）を選びます。
4. 中央のプレビュー（3D ビュー / 2D UV）で仕上がりを確認・微調整し、右下の **メイク適用** を押します（体験版はプレビュー確認まで）。

## FaceMap と出力ファイルについて

- **市販アバターの FaceMap は同梱していません**: お手持ちのアバターから自動生成するか、FaceMap エディターで作成して使用してください。
- **出力されるファイル**: 合成したテクスチャ・マテリアルは `Assets/Cigarless/ATAA_Data/FaceMaps/Generated/<アバター>/<メイク>/` に出力されます。元のマテリアル・テクスチャは書き換えません（非破壊・Undo 対応）。
- **元素材の利用規約**: 生成したテクスチャには、元のアバター・メイク素材の利用規約が適用されます。メイク元のテクスチャを別アバターへ使用してよいか、事前に各素材の規約をご確認ください。
- **FaceMap・調整データの同梱配布**: 作成した FaceMap・調整データは、アバターやメイク素材などの商品に同梱して配布できます（有償・無償不問）。その場合は、商品ページに「本ツール用の FaceMap が含まれていること（ツール名と BOOTH の URL）」と「使うには本ツールが別途必要なこと」を必ず記載してください（詳細は `LICENSE.txt` の 3 を参照）。

## 更新・移行

- **VCC（VPM）版の更新**: VCC の「Manage Project」から新しいバージョンへ更新できます。
- **`.unitypackage` 版の通常の上書き更新**: 新しい版を同じ場所にインポートし直すと上書き更新できます。作成した FaceMap・調整データ・出力したファイルは `Assets/Cigarless/ATAA_Data/` にあるため、そのまま残ります。
- **旧 `.unitypackage` 版から VCC 版への移行**: VCC から追加すると、旧ツールフォルダ内のプログラム部分（`Core/` `Editor/` 等）が自動で削除され、`Packages/` 配下へ移行します。`Assets/Cigarless/ATAA_Data/` や旧フォルダ内の `FaceMaps` は消えずに引き継がれます。
- **旧単一 DLL 版（オープンβなど）からの移行**: 以前の版（`Editor/AvatarTextureAutoAdjuster.Editor.dll` が入っていた版）が残ったまま新しい `.unitypackage` を上書きすると、型が重複してコンパイルエラーになります。移行時は **`Assets/Cigarless/AvatarTextureAutoAdjuster` フォルダを一度削除してから**、新しい `.unitypackage` をインポートしてください（`Assets/Cigarless/ATAA_Data` は消さないでください）。
- **バージョン不一致の案内が出たとき**: 起動時に「コア DLL と UI スクリプトのバージョンが一致していません」と出た場合は、VCC 版なら VCC から一度削除して入れ直し、`.unitypackage` 版なら `Assets/Cigarless/AvatarTextureAutoAdjuster` を削除して再インポートしてください。
- 変更点は `CHANGELOG.md` をご覧ください。

## 安全性・DLL・完全オフライン動作について

- **完全オフライン・エディタ専用**: 外部通信やテレメトリ送信は一切行いません。また、エディタ専用のためアバターのビルド・アップロードには一切含まれません。
- **UI・ファイル操作はソースコード同梱**: ウィンドウ UI・ファイル読み書き・アセット操作・マテリアル適用などはすべて読める C# ソースコード（`Editor/*.cs`）で同梱しています。
- **計算コアのみ DLL 化（穏健な名前難読化）**: 独自に開発した計算アルゴリズム保護のため、純粋な計算コア（`Core/AvatarTextureAutoAdjuster.Core.dll`）のみを DLL 化（ASCII 名のシンプルな難読化）しています。ウイルス対策ソフトの誤検知や不審な挙動の原因になりやすいパッカー・暗号化・`SuppressIldasm` 属性は使用していません。
- **外部 API 参照の検証可能**: コア DLL はネットワーク・ファイル I/O・プロセス起動・`UnityEditor` API 等を一切参照していません（リリースビルド時に .NET メタデータ解析で自動検査しています）。

### コア DLL の外部 API 参照（許可リストと確認手順）

`Core/AvatarTextureAutoAdjuster.Core.dll` が参照してよい外部 API は、次の範囲だけに限定しています。

- **許可している参照**:
  - `UnityEngine.CoreModule` の純粋な数学・色型のみ（`Vector2` / `Vector3` / `Vector3Int` / `Rect` / `Color` / `Color32` / `Mathf` 等）
  - `netstandard` の純粋計算・コレクション・並列計算・経過時間計測（`Stopwatch`）・コンパイラ生成の非実行メタデータ属性のみ
- **参照していないもの（自動検査で禁止）**:
  - 外部通信（`System.Net*`、`UnityEngine.Networking*`、`Application.OpenURL`）
  - ファイル・OS・プロセス（`System.IO.File*` / `Directory*` / `FileStream`、`System.Diagnostics.Process*`、`System.Environment*`）
  - 動的実行リフレクション（`Type.GetType`、`Assembly.Load*`、`MethodInfo.Invoke`、`Reflection.Emit`）
  - ネイティブ呼び出し（`DllImport` / `ImplMap`、`Marshal`、`NativeLibrary`）
  - エディタ・端末情報・永続化（`UnityEditor*`、`UnityEngine.Application*`、`UnityEngine.SystemInfo*`、`UnityEngine.PlayerPrefs*`）

VCC で導入した場合、下のパスは次のように読み替えてください。
- 製品版: `Packages/com.cigarless.avatar-texture-auto-adjuster/Core/AvatarTextureAutoAdjuster.Core.dll`
- 体験版: `Packages/com.cigarless.avatar-texture-auto-adjuster.trial/Core/AvatarTextureAutoAdjuster.Core.dll`

#### 方法 1: Windows 標準の PowerShell で依存アセンブリを確認する（ツール導入・逆コンパイル不要）

Unity プロジェクトのルートで PowerShell を開き、次を実行します。

```powershell
$asm = [System.Reflection.Assembly]::ReflectionOnlyLoadFrom(
    (Resolve-Path "Assets/Cigarless/AvatarTextureAutoAdjuster/Core/AvatarTextureAutoAdjuster.Core.dll").Path
)
$asm.GetReferencedAssemblies() | ForEach-Object { $_.Name }
```

出力が `netstandard` と `UnityEngine.CoreModule` の 2 つだけであることを確認できます。

#### 方法 2: PowerShell 7（`pwsh`）で外部型参照・P/Invoke 一覧まで確認する（逆コンパイル不要）

PowerShell 7 が入っている環境では、.NET 標準の `System.Reflection.Metadata` で `AssemblyRef` / `TypeRef` / `ImplMap`（`DllImport`）をそのまま一覧できます。

```powershell
$dll = (Resolve-Path "Assets/Cigarless/AvatarTextureAutoAdjuster/Core/AvatarTextureAutoAdjuster.Core.dll").Path
$fs = [System.IO.File]::OpenRead($dll)
$pe = [System.Reflection.PortableExecutable.PEReader]::new($fs)
$md = $pe.GetMetadataReader()
"=== AssemblyRefs ==="
$md.AssemblyReferences | ForEach-Object { $md.GetString($md.GetAssemblyReference($_).Name) } | Sort-Object
"=== TypeRefs ==="
$md.TypeReferences | ForEach-Object {
    $tr = $md.GetTypeReference($_)
    "$($md.GetString($tr.Namespace)).$($md.GetString($tr.Name))"
} | Sort-Object -Unique
"=== ImplMaps (DllImport) ==="
$md.MethodDefinitions | ForEach-Object {
    $imp = $md.GetMethodDefinition($_).GetImport()
    if (-not $imp.Module.IsNil) { "$($md.GetString($md.GetModuleReference($imp.Module).Name))|$($md.GetString($imp.Name))" }
}
$pe.Dispose(); $fs.Dispose()
```

#### 方法 3: ILSpy で参照を確認する

1. ILSpy で `Core/AvatarTextureAutoAdjuster.Core.dll` を開きます。
2. アセンブリ直下の **References** を開き、`netstandard` と `UnityEngine.CoreModule` のみであることを確認します。

（※ `LICENSE.txt` の「4. プログラムの扱いと安全性確認」の通り、安全性確認のための依存アセンブリ・外部 API 参照メタデータの確認は許可されています。計算アルゴリズムの解析・抽出・再現は禁止です。）

## 利用規約

`LICENSE.txt` をご覧ください。

## 連絡先

不具合報告・ご質問は、BOOTH のメッセージ機能、または X の DM からお願いします。

- BOOTH: https://cigarless.booth.pm/
- X: [@Cigarless_VR](https://x.com/Cigarless_VR)

### 不具合報告のお願い

次の内容を書いて送っていただけると、原因を探しやすくなります。分かる範囲で大丈夫です。

```
・ツールのバージョン（CHANGELOG.md の一番上）:
・Unity のバージョン:
・対象アバター（とメイク元のアバター）の名前:
・どの手順で起きたか（例: アバター基準の自動生成、メイク適用）:
・画面に出たメッセージ（Console のエラーがあればその文面）:
・どうなったか / どうなってほしかったか:
```

- スクリーンショットを付けていただく場合は、アバターのテクスチャやモデルの規約に反しない範囲でお願いします。
- アバターのデータ（モデル・テクスチャ・FaceMap など）を送っていただく必要はありません。
