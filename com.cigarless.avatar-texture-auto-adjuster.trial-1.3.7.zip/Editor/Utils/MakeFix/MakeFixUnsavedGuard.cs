namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メインウィンドウの「未適用（未保存）」判定と、閉じる前・アバター切り替え前の確認メッセージ。
    /// </summary>
    public static class MakeFixUnsavedGuard
    {
        public const string SwitchDialogTitle = "アバターの切り替え";
        public const string SwitchApplyButton = "適用して切り替え";
        public const string SwitchCancelButton = "キャンセル";
        public const string SwitchDiscardButton = "適用せずに切り替え";

        /// <summary>現在のアバターに未適用のメイク表示（または適用後に変えた未反映の調整）があるか。</summary>
        public static bool IsUnsaved(bool isTrial, bool applying, bool allOk, bool liveAttached, bool isCurrentApplied)
        {
            if (isTrial || applying || !allOk || !liveAttached) return false;
            return !isCurrentApplied;
        }

        /// <summary>
        /// 別のアバターへ切り替える前に確認ダイアログを出すか。
        /// メイク元を選んだだけ（調整・濃さを何も変えていない）なら出さない。切り替えても失うものが無いため。
        /// 調整を変えていれば、ライブ表示の有無（プレビューを作り直している途中など）に関係なく出す
        /// （ライブ表示を条件にすると、作り直しのタイミングで出たり出なかったりした）。
        /// </summary>
        public static bool ShouldConfirmAvatarSwitch(
            bool isTrial,
            bool applying,
            bool isPlaying,
            bool hasCurrentAvatar,
            bool isDifferentAvatar,
            bool hasUserEdits,
            bool allOk,
            bool isCurrentApplied)
        {
            if (!hasCurrentAvatar || !isDifferentAvatar || isPlaying) return false;
            if (isTrial || applying || !allOk || !hasUserEdits) return false;
            return !isCurrentApplied;
        }

        /// <summary>
        /// 適用開始時の FaceMap パスを、適用完了後の指紋用に解決する。
        /// 適用中に一時データ（ドラフト）が実ファイルへ昇格された場合だけ、昇格後のパスを使う
        /// （パスが変わっただけで内容は同じため、適用直後に「変更あり」と誤判定しない）。
        /// </summary>
        public static string ResolveAppliedPath(string startPath, string currentPath, bool startWasDraft)
        {
            if (startWasDraft && !string.IsNullOrEmpty(currentPath)) return currentPath;
            return startPath ?? "";
        }

        public static string CloseDialogMessage(bool isStale)
        {
            return isStale
                ? "適用した後に変えた調整を、まだアバターに反映していません。\n" +
                  "閉じると、シーンのアバターは前に適用したメイクの見た目に戻ります（調整した値は残ります）。\n\n" +
                  "保存: 今の調整でメイクを適用し直してから閉じる\n保存しない: 反映せずに閉じる"
                : "メイクをまだアバターに適用していません。\n" +
                  "閉じると、シーンのアバターは元の見た目に戻ります（調整した値は残ります）。\n\n" +
                  "保存: メイクを適用してから閉じる\n保存しない: 適用せずに閉じる";
        }

        public static string SwitchDialogMessage(string avatarName, bool isStale)
        {
            string name = string.IsNullOrEmpty(avatarName) ? "現在のアバター" : $"「{avatarName}」";
            return isStale
                ? $"{name}は、適用した後に変えた調整をまだ反映していません。\n" +
                  "このまま切り替えると、シーンのアバターは前に適用したメイクの見た目に戻ります（調整した値は残ります）。\n\n" +
                  $"{SwitchApplyButton}: 今の調整でメイクを適用し直してから切り替える\n" +
                  $"{SwitchDiscardButton}: 反映せずに切り替える"
                : $"{name}は、メイクをまだ適用（保存）していません。\n" +
                  "このまま切り替えると、シーンのアバターは元の見た目に戻ります（調整した値は残ります）。\n\n" +
                  $"{SwitchApplyButton}: メイクを適用してから切り替える\n" +
                  $"{SwitchDiscardButton}: 適用せずに切り替える";
        }
    }

    /// <summary>
    /// ユーザーが調整・メイクの濃さを変えたか（アバター切り替えの確認に使う）。変えた組み合わせのキーを覚え、
    /// メイク元を選び直して別の組み合わせになったら「何も変えていない」扱いにする。
    /// キーは FaceMap のパスの組み合わせ（<see cref="Key"/>）。更新日時は含めない
    /// （FaceMap エディターで保存し直しても調整は残るので、変えた記録も残す）。
    /// 適用が済んだら、適用を始めるより前の変更だけを消す（適用の待ち中に変えた分は残す）。
    /// 再コンパイルでも消えないよう、ウィンドウのシリアライズ対象にする。
    /// </summary>
    [System.Serializable]
    public class MakeFixUserEdits
    {
        [UnityEngine.SerializeField] private string _pairKey;
        [UnityEngine.SerializeField] private int _mark;

        /// <summary>変更を記録するたびに増える番号（適用を始めた時点を覚えるのに使う）。</summary>
        public int Mark => _mark;

        /// <summary>記録に使う組み合わせのキー。どちらかが未選択なら null。</summary>
        public static string Key(string makeupFaceMapPath, string avatarFaceMapPath) =>
            MakeFixLiveOutput.Key(makeupFaceMapPath, avatarFaceMapPath);

        public void Record(string pairKey)
        {
            _pairKey = pairKey;
            _mark++;
        }

        // シリアライズを通ると null は "" になるので、空も「記録なし」として扱う
        public bool HasEdits(string currentPairKey) =>
            !string.IsNullOrEmpty(_pairKey) && !string.IsNullOrEmpty(currentPairKey) && _pairKey == currentPairKey;

        public void Clear() => _pairKey = null;

        /// <summary>mark を取ってから何も記録していなければ消す。</summary>
        public void ClearIfUnchangedSince(int mark)
        {
            if (_mark == mark) Clear();
        }
    }
}
