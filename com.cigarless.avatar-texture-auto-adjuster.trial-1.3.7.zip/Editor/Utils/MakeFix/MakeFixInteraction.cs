namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メイクフィックス画面が「操作中」か（ドラッグ・スクラブ中は低解像度プレビュー＆保存を遅らせる）。
    /// EditorApplication.update からも呼ぶので、GUIUtility.hotControl などの IMGUI の状態は読まない
    /// （IMGUI の外で読むと「the GUIStateObj is deleted, but is accessed」が毎フレーム出る）。
    /// </summary>
    public static class MakeFixInteraction
    {
        public static bool IsInteracting(bool previewDragging, bool panning, bool orbitDragging, bool uiScrubbing)
        {
            return previewDragging || panning || orbitDragging || uiScrubbing;
        }

        /// <summary>
        /// 中央ビューのヒントカード全体がポインターを受けるか。ボタンのあるカードだけ受け、ほかはクリック・ドラッグ・
        /// ホイールを背面のビューへ通す（詳細文があるだけのカードが受けると、カードの上で回転・ズームできなくなった）。
        /// </summary>
        public static bool HintReceivesPointer(bool hasAction) => hasAction;

        /// <summary>
        /// ヒントカードの左のアイコンがポインターを受けるか。UI Toolkit のツールチップはポインターを受ける要素にしか出ないので、
        /// 詳細文はアイコンに付け、詳細文があるときだけアイコンで受ける（小さいので背面のビューの操作をほとんど妨げない）。
        /// </summary>
        public static bool HintIconReceivesPointer(bool hasTooltip) => hasTooltip;
    }
}
