namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 右パネル上部の「ステップ N / 6」見出しと進捗バーの表示。UI の状態は読まない（値だけを受け取る）。
    /// </summary>
    public static class MakeFixStepProgress
    {
        public static string Kicker(int done, int total, bool allOk) =>
            allOk ? "準備完了" : $"ステップ {done} / {total}";

        /// <summary>進捗バーの幅（0〜100 %）。</summary>
        public static float FillPercent(int done, int total)
        {
            if (total <= 0) return 0f;
            float p = (float)done / total * 100f;
            return p < 0f ? 0f : p > 100f ? 100f : p;
        }

        /// <summary>押しても移動先のカードが無い項目（対応付けなど）のツールチップに足す案内。</summary>
        public const string NoJumpHint = "この項目は中央のビューの案内で確かめてください。";

        /// <summary>右下の「次: …」ボタン。移動先のカードがあるときだけ「›」を付ける。</summary>
        public static string NextStepLabel(string message, bool canJump) =>
            "次: " + message + (canJump ? " ›" : "");

        /// <summary>ヘッダーの「あと N ステップ」。移動先のカードがあるときだけ「›」を付ける。</summary>
        public static string RemainingLabel(int remaining, bool canJump) =>
            $"あと {remaining} ステップ" + (canJump ? " ›" : "");

        /// <summary>右下の「次: …」ボタンのツールチップ。移動先が無い項目は、どこで確かめるかの案内を足す。</summary>
        public static string NextStepTooltip(string detail, bool canJump)
        {
            if (canJump) return detail ?? "";
            return string.IsNullOrEmpty(detail) ? NoJumpHint : detail + "\n" + NoJumpHint;
        }

        /// <summary>ヘッダーの「あと N ステップ」のツールチップ。次の項目が無ければ空。</summary>
        public static string RemainingTooltip(string nextMessage, bool canJump)
        {
            if (nextMessage == null) return "";
            return canJump ? $"次: {nextMessage}\n押すとその項目へ移動します。" : $"次: {nextMessage}\n{NoJumpHint}";
        }
    }
}
