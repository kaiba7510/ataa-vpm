using System;
using System.Collections.Generic;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// UI Toolkit 画面の組み立て（Bind）・更新（Refresh）を区画ごとに分けて実行する。
    /// 1 つの区画で例外が出ても残りの区画は実行する（UXML の要素が欠けてインスペクターの Bind が落ちたとき、
    /// テクスチャビューのドロップカードまで更新されなくなった不具合への対策）。
    /// </summary>
    public static class UiSections
    {
        /// <param name="reported">ログを出した失敗（区画名・例外の型・メッセージ）。同じ失敗は 1 回だけログする（毎回の更新でログが溢れないように）。
        /// 同じ区画でも別の例外なら、別の不具合なのでログする。null なら毎回ログする。</param>
        /// <param name="log">区画名と例外を受け取る。</param>
        /// <returns>失敗した区画の数。</returns>
        public static int RunEach(HashSet<string> reported, Action<string, Exception> log, params (string Name, Action Run)[] sections)
        {
            int failed = 0;
            foreach ((string name, Action run) in sections)
            {
                try
                {
                    run();
                }
                catch (Exception ex)
                {
                    failed++;
                    if (reported == null || reported.Add(ReportKey(name, ex))) log?.Invoke(name, ex);
                }
            }
            return failed;
        }

        /// <summary>同じ失敗かを見分けるキー。</summary>
        public static string ReportKey(string name, Exception ex) =>
            name + "|" + ex?.GetType().FullName + "|" + ex?.Message;
    }
}
