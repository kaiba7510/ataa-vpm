using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine.UIElements;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// UI Toolkit の画面（UXML/USS）を読む。実際に入っている場所 → VPM（Packages/）→ 旧 Assets の順に探し（PackageLocation）、
    /// どこにも無ければ（フォルダを移したとき）名前で探す。
    /// UXML は、インポート結果がディスクのファイルより古ければ（配布 zip を入れ替えても Unity が読み直さなかったとき）、
    /// 強制的にインポートし直してから返す（EnsureFresh）。
    /// </summary>
    public static class UiAssets
    {
        /// <param name="assetName">拡張子なしの名前（例 MakeFixWindow）</param>
        /// <param name="extension">".uxml" / ".uss"</param>
        public static T Load<T>(string assetName, string extension) where T : UnityEngine.Object
        {
            T found = Find<T>(assetName, extension);
            if (found is VisualTreeAsset tree) return EnsureFresh(tree) as T;
            return found;
        }

        private static T Find<T>(string assetName, string extension) where T : UnityEngine.Object
        {
            foreach (string path in PackageLocation.UiAssetCandidates(assetName + extension, InstalledPackage.Root))
            {
                T direct = AssetDatabase.LoadAssetAtPath<T>(path);
                if (direct != null) return direct;
            }

            string typeFilter = typeof(T) == typeof(VisualTreeAsset) ? "t:VisualTreeAsset" : "t:StyleSheet";
            // Packages/ の下も探す（既定の FindAssets は Assets だけのことがある）
            foreach (string guid in AssetDatabase.FindAssets(assetName + " " + typeFilter, new[] { "Assets", "Packages" }))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (Path.GetFileNameWithoutExtension(path) == assetName)
                {
                    T loaded = AssetDatabase.LoadAssetAtPath<T>(path);
                    if (loaded != null) return loaded;
                }
            }
            return null;
        }

        /// <summary>
        /// ディスクの UXML にある要素（name）が、読み込んだ UXML から作った画面に無ければ、インポート結果が古い。
        /// そのときは強制的にインポートし直して読み直す（同じ UXML で古い画面が出て、新しい要素を探す Bind が落ちるのを防ぐ）。
        /// 読み直しても足りなければ、そのまま返す（呼び出し側の区画ごとの Bind がエラーをログする）。
        /// </summary>
        public static VisualTreeAsset EnsureFresh(VisualTreeAsset asset)
        {
            if (asset == null) return null;
            string path = AssetDatabase.GetAssetPath(asset);
            if (string.IsNullOrEmpty(path)) return asset;

            List<string> expected;
            try
            {
                string physical = FileUtil.GetPhysicalPath(path);
                if (!File.Exists(physical)) return asset;
                expected = UxmlElementNames(File.ReadAllText(physical));
            }
            catch (Exception)
            {
                return asset; // 読めなければ確かめない
            }
            if (expected.Count == 0 || MissingIn(asset, expected).Count == 0) return asset;

            UnityEngine.Debug.LogWarning($"[ATAA] {Path.GetFileName(path)} のインポート結果が古いため、インポートし直します。");
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);
            VisualTreeAsset reloaded = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(path);
            if (reloaded == null) return asset;

            List<string> stillMissing = MissingIn(reloaded, expected);
            if (stillMissing.Count > 0)
                UnityEngine.Debug.LogError($"[ATAA] {Path.GetFileName(path)} をインポートし直しても、次の要素がありません: {string.Join(", ", stillMissing)}");
            return reloaded;
        }

        private static List<string> MissingIn(VisualTreeAsset asset, List<string> expected)
        {
            TemplateContainer probe = asset.CloneTree();
            return MissingNames(expected, n => probe.Q(n) != null);
        }

        // name="..." / name='...'。属性名の前は空白（text="name=..." の中は拾わない）
        private static readonly Regex NameAttr = new Regex("\\sname\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", RegexOptions.CultureInvariant);

        private static readonly Regex Comment = new Regex("<!--.*?-->", RegexOptions.Singleline | RegexOptions.CultureInvariant);

        /// <summary>UXML の文字列にある要素の name（重複なし、出てきた順）。</summary>
        public static List<string> UxmlElementNames(string uxml)
        {
            var names = new List<string>();
            if (string.IsNullOrEmpty(uxml)) return names;
            var seen = new HashSet<string>(StringComparer.Ordinal);
            string body = Comment.Replace(uxml, ""); // コメントアウトした要素は画面に無い
            foreach (Match m in NameAttr.Matches(body))
            {
                string n = m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value;
                if (n.Length > 0 && seen.Add(n)) names.Add(n);
            }
            return names;
        }

        /// <summary>expected のうち、exists が false を返す name（順は保つ）。</summary>
        public static List<string> MissingNames(IEnumerable<string> expected, Func<string, bool> exists)
        {
            var missing = new List<string>();
            foreach (string n in expected)
            {
                if (!exists(n)) missing.Add(n);
            }
            return missing;
        }
    }
}
