using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メイクテクスチャ（および FaceMap エディターの顔テクスチャ）を OS ファイルダイアログや D&amp;D から読み込む共通窓口。
    /// プロジェクト内（Assets/）の画像ならそのまま読み込み、プロジェクト外の画像は
    /// 製品版では Assets/Cigarless/ATAA_Data/Makeups/ へ自動インポート、体験版（AtaaCore.Edition）ではメモリ上だけへ読み込む。
    /// </summary>
    internal static class MakeupTextureImporter
    {
        public const string MakeupsFolderName = "Makeups";
        public const string MakeupsAssetPath = FaceMapFolder.DataRoot + "/" + MakeupsFolderName;
        private const string LastDirPrefsKey = "ATAA.MakeFix.LastMakeupFileDir";

        private static readonly string[] FileFilters =
        {
            "画像", "png,psd,jpg,jpeg,tga,tif,tiff,bmp,exr",
            "すべて", "*"
        };

        public struct LoadResult
        {
            public Texture2D Texture { get; set; }
            /// <summary>製品版で外部ファイルをプロジェクト内へインポートしたか。</summary>
            public bool Imported { get; set; }
            /// <summary>体験版でファイル保存せずメモリ上に生成したテクスチャか（呼び出し側が破棄する）。</summary>
            public bool IsTransient { get; set; }
            public string AssetPath { get; set; }
            public string Error { get; set; }
            public bool Canceled { get; set; }
        }

        /// <summary>OS のファイル選択ダイアログを開き、選んだ画像を読み込む（必要なら自動インポート）。</summary>
        public static LoadResult OpenFileDialog(string title = "メイクテクスチャを選択")
        {
            string initialDir = EditorPrefs.GetString(LastDirPrefsKey, "");
            if (string.IsNullOrEmpty(initialDir) || !Directory.Exists(initialDir))
                initialDir = Application.dataPath;

            string abs = EditorUtility.OpenFilePanelWithFilters(title, initialDir, FileFilters);
            if (string.IsNullOrEmpty(abs)) return new LoadResult { Canceled = true };

            string parent = Path.GetDirectoryName(abs);
            if (!string.IsNullOrEmpty(parent) && Directory.Exists(parent))
                EditorPrefs.SetString(LastDirPrefsKey, parent);

            return ImportOrLoad(abs);
        }

        /// <summary>D&amp;D された外部ファイルパス群から、対応している最初の画像ファイルパスを返す。</summary>
        public static string FindDraggedImagePath(string[] paths)
        {
            if (paths == null) return null;
            for (int i = 0; i < paths.Length; i++)
            {
                string p = paths[i];
                if (string.IsNullOrEmpty(p) || !File.Exists(p)) continue;
                if (MakeFixMakeupSource.IsSupportedImageExtension(p)) return p;
            }
            return null;
        }

        /// <summary>指定パスの画像を読み込む。プロジェクト外なら製品版はインポート、体験版はメモリ読み込み。</summary>
        public static LoadResult ImportOrLoad(string absPath)
        {
            if (string.IsNullOrWhiteSpace(absPath) || !File.Exists(absPath))
                return new LoadResult { Error = "画像ファイルが見つかりません。" };

            if (!MakeFixMakeupSource.IsSupportedImageExtension(absPath))
                return new LoadResult { Error = "画像ファイル（PNG / PSD / JPG など）を選んでください。" };

            string fullPath;
            string fullAssets;
            try
            {
                fullPath = Path.GetFullPath(absPath);
                fullAssets = Path.GetFullPath(Application.dataPath);
            }
            catch (Exception ex)
            {
                return new LoadResult { Error = "ファイルパスを読み取れませんでした: " + ex.Message };
            }

            // プロジェクト内（Assets/ 配下）ならコピーせずそのままアセットとして読む
            if (MakeFixMakeupSource.IsUnderFolder(fullPath, fullAssets))
            {
                string rel = FileUtil.GetProjectRelativePath(fullPath.Replace('\\', '/'));
                Texture2D existing = string.IsNullOrEmpty(rel) ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(rel);
                if (existing != null)
                    return new LoadResult { Texture = existing, AssetPath = rel };
                return new LoadResult { Error = "プロジェクト内の画像をテクスチャとして読み込めませんでした。" };
            }

            return AtaaCore.Edition == CoreEdition.Trial
                ? LoadExternalInMemory(fullPath)
                : ImportExternalToProject(fullPath);
        }

        /// <summary>体験版: ファイルを書き込まず、PNG / JPG をメモリ上だけに読み込む。</summary>
        private static LoadResult LoadExternalInMemory(string fullPath)
        {
            if (!MakeFixMakeupSource.CanLoadInMemory(fullPath))
            {
                return new LoadResult
                {
                    Error = "体験版ではプロジェクト外の PNG / JPG のみ直接読み込めます。PSD 等は先に Unity の Project へ入れてから選んでください。"
                };
            }

            Texture2D tex = null;
            try
            {
                byte[] bytes = File.ReadAllBytes(fullPath);
                tex = new Texture2D(2, 2, TextureFormat.RGBA32, false, false)
                {
                    name = Path.GetFileNameWithoutExtension(fullPath),
                    hideFlags = HideFlags.HideAndDontSave,
                    wrapMode = TextureWrapMode.Clamp
                };
                if (!tex.LoadImage(bytes, false))
                {
                    UnityEngine.Object.DestroyImmediate(tex);
                    return new LoadResult { Error = "画像を読み込めませんでした（破損しているか非対応の形式です）。" };
                }
                return new LoadResult { Texture = tex, IsTransient = true };
            }
            catch (Exception ex)
            {
                if (tex != null) UnityEngine.Object.DestroyImmediate(tex);
                return new LoadResult { Error = "画像を読み込めませんでした: " + ex.Message };
            }
        }

        /// <summary>製品版: Assets/Cigarless/ATAA_Data/Makeups/ へコピーして自動インポートする。</summary>
        private static LoadResult ImportExternalToProject(string fullPath)
        {
            if (!TryEnsureMakeupsFolder(out string absFolder, out string folderError))
                return new LoadResult { Error = folderError };

            string desiredName = Path.GetFileName(fullPath);
            string sameNameAbs = Path.Combine(absFolder, desiredName);
            string sameNameAsset = MakeupsAssetPath + "/" + desiredName;

            // 同名ファイルが既にあって中身が完全一致していれば、重複コピーせず再利用する
            if (File.Exists(sameNameAbs) && FilesHaveSameContent(fullPath, sameNameAbs))
            {
                Texture2D reused = AssetDatabase.LoadAssetAtPath<Texture2D>(sameNameAsset);
                if (reused != null)
                    return new LoadResult { Texture = reused, AssetPath = sameNameAsset };
            }

            string targetName = MakeFixMakeupSource.NextAvailableFileName(
                desiredName,
                name => File.Exists(Path.Combine(absFolder, name)));
            string dstAbs = Path.Combine(absFolder, targetName);
            string dstAsset = MakeupsAssetPath + "/" + targetName;

            try
            {
                File.Copy(fullPath, dstAbs, false);
            }
            catch (Exception ex)
            {
                return new LoadResult { Error = "画像をプロジェクトへコピーできませんでした: " + ex.Message };
            }

            AssetDatabase.ImportAsset(dstAsset, ImportAssetOptions.ForceSynchronousImport);
            var importer = AssetImporter.GetAtPath(dstAsset) as TextureImporter;
            if (importer != null)
            {
                bool changed = false;
                if (importer.textureType != TextureImporterType.Default)
                {
                    importer.textureType = TextureImporterType.Default;
                    changed = true;
                }
                if (importer.alphaSource != TextureImporterAlphaSource.FromInput)
                {
                    importer.alphaSource = TextureImporterAlphaSource.FromInput;
                    changed = true;
                }
                if (!importer.alphaIsTransparency)
                {
                    importer.alphaIsTransparency = true;
                    changed = true;
                }
                if (importer.maxTextureSize < 4096)
                {
                    importer.maxTextureSize = 4096;
                    changed = true;
                }
                if (changed) importer.SaveAndReimport();
            }

            Texture2D imported = AssetDatabase.LoadAssetAtPath<Texture2D>(dstAsset);
            if (imported == null)
                return new LoadResult { Error = "インポートした画像をテクスチャとして読み込めませんでした: " + dstAsset };

            return new LoadResult { Texture = imported, Imported = true, AssetPath = dstAsset };
        }

        private static bool TryEnsureMakeupsFolder(out string absFolder, out string error)
        {
            absFolder = FaceMapFolder.ToAbsolute(MakeupsAssetPath);
            // 以前の場所（Assets/ATAA_Data）にデータがあれば先に移す。移す前に Makeups だけ作ると、移すときに混ぜることになる
            if (!FaceMapFolder.TryEnsureDataRoot(out error)) return false;
            return FaceMapFolder.TryEnsureFolder(MakeupsAssetPath, out error);
        }

        private static bool FilesHaveSameContent(string a, string b)
        {
            try
            {
                var ia = new FileInfo(a);
                var ib = new FileInfo(b);
                if (ia.Length != ib.Length) return false;
                byte[] ba = File.ReadAllBytes(a);
                byte[] bb = File.ReadAllBytes(b);
                if (ba.Length != bb.Length) return false;
                for (int i = 0; i < ba.Length; i++)
                {
                    if (ba[i] != bb[i]) return false;
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
