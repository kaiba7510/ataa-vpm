using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── 左ペイン (UI Toolkit) ──

        private ScrollView _leftScrollView;
        private Button _btnLeftRefresh;

        private VisualElement _cardAvatar;
        private VisualElement _dotAvatar;
        private Label _lblSceneAvatarCount;
        private ObjectField _fieldAvatar;
        private VisualElement _warnAvatarPrefab;
        private ScrollView _listSceneAvatars;

        private VisualElement _cardFaceMesh;
        private VisualElement _dotFaceMesh;
        private Label _lblFaceMeshLocked;
        private VisualElement _bodyFaceMesh;
        private ScrollView _listFaceMeshes;
        private Label _lblMeshHoverHint;

        private VisualElement _cardAvatarFaceMap;
        private VisualElement _dotAvatarFaceMap;
        private Label _badgeReadonly;
        private Label _lblAvatarFaceMapLocked;
        private VisualElement _bodyAvatarFaceMap;
        private DropdownField _dropdownAvatarFaceMap;
        private VisualElement _warnAvatarNotes;
        private Label _lblAvatarNotes;
        private VisualElement _infoAvatarFaceMapMissing;
        private Button _btnAutoGenerate;

        private VisualElement _cardAvatarTexture;
        private VisualElement _dotAvatarTexture;
        private Label _lblAvatarTexRes;
        private Label _lblAvatarTextureLocked;
        private VisualElement _bodyAvatarTexture;
        private Image _imgAvatarTex;
        private ObjectField _fieldAvatarTex;
        private Label _lblAvatarTexName;
        private Label _lblAvatarTexSub;
        private Button _btnPickAvatarTex;
        private VisualElement _warnAvatarTexSlot;
        private Label _lblAvatarTexSlot;

        private Label _lblFaceMapFolder;

        // 自動認識サマリー・②〜④のまとめ
        private Label _lblAutoProgress;
        private VisualElement _cardAutoSummary;
        private VisualElement _dotAutoSummary;
        private Label _lblSummaryState;
        private Image _imgSummaryTex;
        private Label _lblSummaryMesh;
        private Label _lblSummaryBase;
        private Label _lblSummaryTex;
        private Button _btnSummaryToggle;
        private VisualElement _manualCards;
        private VisualElement _infoMeshRegenOffer;
        private Button _btnOpenFaceMapEditor;

        private string _lastAvatarListSig;
        private string _lastMeshListSig;
        private string _lastAvatarMapChoicesSig;
        private readonly Dictionary<string, string> _avatarMapLabelToPath = new Dictionary<string, string>();

        private void BindLeftUi()
        {
            _leftScrollView = _root.Q<ScrollView>("left-scroll");
            _btnLeftRefresh = _root.Q<Button>("btn-left-refresh");
            _btnLeftRefresh.clicked += TriggerRefreshAll;

            // Card 1: Avatar
            _cardAvatar = _root.Q<VisualElement>("card-avatar");
            _dotAvatar = _root.Q<VisualElement>("dot-avatar");
            _lblSceneAvatarCount = _root.Q<Label>("lbl-scene-avatar-count");
            _fieldAvatar = _root.Q<ObjectField>("field-avatar");
            _warnAvatarPrefab = _root.Q<VisualElement>("warn-avatar-prefab");
            _listSceneAvatars = _root.Q<ScrollView>("list-scene-avatars");
            _cardElements[FocusCard.Avatar] = _cardAvatar;

            _fieldAvatar.objectType = typeof(GameObject);
            _fieldAvatar.allowSceneObjects = true;
            _fieldAvatar.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                SelectAvatar(evt.newValue as GameObject);
                MarkUiDirty();
            });

            // Card 2: Face Mesh
            _cardFaceMesh = _root.Q<VisualElement>("card-face-mesh");
            _dotFaceMesh = _root.Q<VisualElement>("dot-face-mesh");
            _lblFaceMeshLocked = _root.Q<Label>("lbl-face-mesh-locked");
            _bodyFaceMesh = _root.Q<VisualElement>("body-face-mesh");
            _listFaceMeshes = _root.Q<ScrollView>("list-face-meshes");
            _lblMeshHoverHint = _root.Q<Label>("lbl-mesh-hover-hint");

            _listFaceMeshes.RegisterCallback<PointerLeaveEvent>(_ =>
            {
                SetHoveredFaceRenderer(null);
                MarkUiDirty();
            });

            // Card 3: Avatar FaceMap
            _cardAvatarFaceMap = _root.Q<VisualElement>("card-avatar-facemap");
            _dotAvatarFaceMap = _root.Q<VisualElement>("dot-avatar-facemap");
            _badgeReadonly = _root.Q<Label>("badge-readonly");
            _lblAvatarFaceMapLocked = _root.Q<Label>("lbl-avatar-facemap-locked");
            _bodyAvatarFaceMap = _root.Q<VisualElement>("body-avatar-facemap");
            _dropdownAvatarFaceMap = _root.Q<DropdownField>("dropdown-avatar-facemap");
            _dropdownAvatarFaceMap.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _state.AvatarFaceMapPath = ResolveFaceMapPathByLabel(_avatarMapLabelToPath, evt.newValue);
                MarkUiDirty();
            });
            _warnAvatarNotes = _root.Q<VisualElement>("warn-avatar-notes");
            _lblAvatarNotes = _root.Q<Label>("lbl-avatar-notes");
            _infoAvatarFaceMapMissing = _root.Q<VisualElement>("info-avatar-facemap-missing");
            _btnAutoGenerate = _root.Q<Button>("btn-auto-generate");
            _cardElements[FocusCard.AvatarFaceMap] = _cardAvatarFaceMap;

            _btnAutoGenerate.tooltip = "顔メッシュのまばたき・口のブレンドシェイプから、目・鼻・口・頬の位置と目の線を推定して FaceMap を作ります。";
            _btnAutoGenerate.clicked += () =>
            {
                GenerateAvatarFaceMap();
                MarkUiDirty();
            };

            // Card 4: Avatar Texture
            _cardAvatarTexture = _root.Q<VisualElement>("card-avatar-texture");
            _dotAvatarTexture = _root.Q<VisualElement>("dot-avatar-texture");
            _lblAvatarTexRes = _root.Q<Label>("lbl-avatar-tex-res");
            _lblAvatarTextureLocked = _root.Q<Label>("lbl-avatar-texture-locked");
            _bodyAvatarTexture = _root.Q<VisualElement>("body-avatar-texture");
            _imgAvatarTex = _root.Q<Image>("img-avatar-tex");
            _fieldAvatarTex = _root.Q<ObjectField>("field-avatar-tex");
            _lblAvatarTexName = _root.Q<Label>("lbl-avatar-tex-name");
            _lblAvatarTexSub = _root.Q<Label>("lbl-avatar-tex-sub");
            _btnPickAvatarTex = _root.Q<Button>("btn-pick-avatar-tex");
            _warnAvatarTexSlot = _root.Q<VisualElement>("warn-avatar-tex-slot");
            _lblAvatarTexSlot = _root.Q<Label>("lbl-avatar-tex-slot");
            _cardElements[FocusCard.AvatarTexture] = _cardAvatarTexture;

            _fieldAvatarTex.objectType = typeof(Texture2D);
            _fieldAvatarTex.allowSceneObjects = false;
            _fieldAvatarTex.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _state.PreviewAvatarTexture = evt.newValue as Texture2D;
                MarkUiDirty();
            });

            _btnPickAvatarTex.tooltip = "対象アバターのマテリアルが使っているテクスチャを、画像を見て選びます。";
            _btnPickAvatarTex.clicked += () =>
            {
                Rect wb = _btnPickAvatarTex.worldBound;
                ShowAvatarTextureMenu(new Rect(wb.x, wb.y, wb.width, wb.height));
            };

            _lblFaceMapFolder = _root.Q<Label>("lbl-facemap-folder");

            // 自動認識サマリーと、②〜④のまとめ
            _lblAutoProgress = _root.Q<Label>("lbl-auto-progress");
            _cardAutoSummary = _root.Q<VisualElement>("card-auto-summary");
            _dotAutoSummary = _root.Q<VisualElement>("dot-auto-summary");
            _lblSummaryState = _root.Q<Label>("lbl-summary-state");
            _imgSummaryTex = _root.Q<Image>("img-summary-tex");
            _lblSummaryMesh = _root.Q<Label>("lbl-summary-mesh");
            _lblSummaryBase = _root.Q<Label>("lbl-summary-base");
            _lblSummaryTex = _root.Q<Label>("lbl-summary-tex");
            _btnSummaryToggle = _root.Q<Button>("btn-summary-toggle");
            _manualCards = _root.Q<VisualElement>("manual-cards");
            _infoMeshRegenOffer = _root.Q<VisualElement>("info-mesh-regen-offer");
            _btnOpenFaceMapEditor = _root.Q<Button>("btn-open-facemap-editor");
            _btnSummaryToggle.clicked += () =>
            {
                _manualCardsOpen = !_manualCardsOpen;
                MarkUiDirty();
            };
            _btnOpenFaceMapEditor.tooltip = "いまのアバター基準を FaceMap エディターで開いて、位置や目の線を合わせます。";
            _btnOpenFaceMapEditor.clicked += () =>
            {
                OpenFaceMapEditorForCurrent();
                MarkUiDirty();
            };

            _lastAvatarListSig = null;
            _lastMeshListSig = null;
            _lastAvatarMapChoicesSig = null;
        }

        private void RefreshLeftUi()
        {
            GameObject target = _state.TargetAvatar;
            bool avatarIsAsset = target != null && EditorUtility.IsPersistent(target);
            bool avatarOk = target != null && !avatarIsAsset;
            bool faceOk = avatarOk && _state.FaceRenderer != null;
            bool mapOk = _state.AvatarFaceMap != null && _state.AvatarFaceMap.IsValid;
            bool texOk = _state.PreviewAvatarTexture != null;

            // Card 1: Avatar
            SetStepDot(_dotAvatar, avatarIsAsset ? MakeFixGui.StepState.Problem : StepStateOf(FocusCard.Avatar, avatarOk));
            ApplyCardHighlight(FocusCard.Avatar, _cardAvatar);
            _lblSceneAvatarCount.text = $"シーン内 {_sceneAvatars.Count}体";
            _fieldAvatar.SetValueWithoutNotify(target);
            _warnAvatarPrefab.EnableInClassList("hidden", !avatarIsAsset);

            string avatarSig = string.Join("|", _sceneAvatars.Select(a => a != null ? a.GetInstanceID() + ":" + a.name + ":" + (int)AvatarStatusOf(a) : "null"))
                               + "#" + (target != null ? target.GetInstanceID() : 0);
            if (avatarSig != _lastAvatarListSig)
            {
                _lastAvatarListSig = avatarSig;
                RebuildSceneAvatarList(target);
            }

            // 自動認識の進行（左ペイン上部）
            string progress = AutoProgressText;
            _lblAutoProgress.text = progress;
            _lblAutoProgress.EnableInClassList("hidden", progress.Length == 0);

            // Locked state for cards 2-4
            _lblFaceMeshLocked.EnableInClassList("hidden", _avatarReady);
            _bodyFaceMesh.EnableInClassList("hidden", !_avatarReady);
            _lblAvatarFaceMapLocked.EnableInClassList("hidden", _avatarReady);
            _bodyAvatarFaceMap.EnableInClassList("hidden", !_avatarReady);
            _lblAvatarTextureLocked.EnableInClassList("hidden", _avatarReady);
            _bodyAvatarTexture.EnableInClassList("hidden", !_avatarReady);

            if (!_avatarReady)
            {
                _cardAutoSummary.AddToClassList("hidden");
                _manualCards.RemoveFromClassList("hidden");
                SetHoveredFaceRenderer(null);
                SetStepDot(_dotFaceMesh, MakeFixGui.StepState.Pending);
                SetStepDot(_dotAvatarFaceMap, MakeFixGui.StepState.Pending);
                SetStepDot(_dotAvatarTexture, MakeFixGui.StepState.Pending);
                // 前に「次にやる項目」だった③④の青枠を残さない
                ApplyCardHighlight(FocusCard.AvatarFaceMap, _cardAvatarFaceMap);
                ApplyCardHighlight(FocusCard.AvatarTexture, _cardAvatarTexture);
                _badgeReadonly.AddToClassList("hidden");
                _lblAvatarTexRes.text = "";
                RefreshLeftFooter();
                return;
            }

            RefreshAutoSummary();

            // Card 2: Face Mesh
            SetStepDot(_dotFaceMesh, faceOk ? MakeFixGui.StepState.Done : MakeFixGui.StepState.Pending);
            string meshSig = string.Join("|", _faceCandidates.Select(m => m != null ? m.GetInstanceID() + ":" + m.name + ":" + (m.sharedMesh != null ? m.sharedMesh.blendShapeCount : -1) : "null"))
                             + "#" + (_state.FaceRenderer != null ? _state.FaceRenderer.GetInstanceID() : 0);
            if (meshSig != _lastMeshListSig)
            {
                _lastMeshListSig = meshSig;
                RebuildFaceMeshList();
            }

            if (_hoveredFaceRenderer != null)
            {
                _lblMeshHoverHint.RemoveFromClassList("hidden");
                _lblMeshHoverHint.text = _centerMode == CenterMode.View3D
                    ? $"3D ビューに「{_hoveredFaceRenderer.name}」だけを映しています"
                    : "3D ビューに切り替えると、乗せたメッシュだけを映して確かめられます";
            }
            else
            {
                _lblMeshHoverHint.AddToClassList("hidden");
            }

            // Card 3: Avatar FaceMap
            SetStepDot(_dotAvatarFaceMap, StepStateOf(FocusCard.AvatarFaceMap, mapOk));
            ApplyCardHighlight(FocusCard.AvatarFaceMap, _cardAvatarFaceMap);
            _badgeReadonly.EnableInClassList("hidden", !mapOk);

            SyncFaceMapDropdown(_dropdownAvatarFaceMap, _avatarMapLabelToPath, ref _lastAvatarMapChoicesSig, _state.AvatarFaceMapPath);

            if (_avatarNotes.Count > 0)
            {
                _warnAvatarNotes.RemoveFromClassList("hidden");
                string more = _avatarNotes.Count > 1 ? $"（他 {_avatarNotes.Count - 1} 件）" : "";
                _lblAvatarNotes.text = "! " + _avatarNotes[0] + more;
                _warnAvatarNotes.tooltip = string.Join("\n", _avatarNotes);
            }
            else
            {
                _warnAvatarNotes.AddToClassList("hidden");
            }

            _infoAvatarFaceMapMissing.EnableInClassList("hidden", !(_state.AvatarFaceMap == null && !_state.IsScanning));
            _btnAutoGenerate.SetEnabled(avatarOk);
            _btnAutoGenerate.text = _state.AvatarFaceMap == null ? "アバター基準を自動生成"
                : MeshChangeOffer ? "このメッシュで自動生成し直す（上書き確認あり）"
                : "自動生成し直す（上書き確認あり）";
            _infoMeshRegenOffer.EnableInClassList("hidden", !MeshChangeOffer || _state.AvatarFaceMap == null);
            _btnOpenFaceMapEditor.SetEnabled(avatarOk && mapOk);

            // Card 4: Avatar Texture
            SetStepDot(_dotAvatarTexture, StepStateOf(FocusCard.AvatarTexture, texOk && ItemsOk(6)));
            ApplyCardHighlight(FocusCard.AvatarTexture, _cardAvatarTexture);

            Texture2D faceTex = _state.PreviewAvatarTexture;
            _imgAvatarTex.image = faceTex;
            _fieldAvatarTex.SetValueWithoutNotify(faceTex);
            _lblAvatarTexRes.text = faceTex != null ? $"{faceTex.width} × {faceTex.height}" : "";
            _lblAvatarTexName.text = faceTex != null ? faceTex.name : "未選択";
            _lblAvatarTexSub.text = faceTex != null ? $"{faceTex.format}" : "候補から選べます";
            _btnPickAvatarTex.SetEnabled(target != null);

            ReadinessItem slotProblem = avatarOk && texOk ? FirstFailedOf(6) : null;
            if (slotProblem != null)
            {
                _warnAvatarTexSlot.RemoveFromClassList("hidden");
                _lblAvatarTexSlot.text = "! アバターがこのテクスチャを使っていません";
                _warnAvatarTexSlot.tooltip = slotProblem.Detail;
            }
            else
            {
                _warnAvatarTexSlot.AddToClassList("hidden");
            }

            RefreshLeftFooter();
        }

        /// <summary>自動認識サマリーの更新と、②〜④カードの開閉（異常時は自動で開く）。</summary>
        private void RefreshAutoSummary()
        {
            MakeFixAutoSetup.CardState problem = ComputeProblemState();
            bool hasProblem = MakeFixAutoSetup.ShouldExpandCards(problem);
            MakeFixAutoSetup.CardState full = problem;
            full.ManualOpen = _manualCardsOpen;
            bool expand = MakeFixAutoSetup.ShouldExpandCards(full);

            _cardAutoSummary.RemoveFromClassList("hidden");
            _manualCards.EnableInClassList("hidden", !expand);

            FaceMapMeta map = _state.AvatarFaceMap;
            Texture2D tex = _state.PreviewAvatarTexture;
            _imgSummaryTex.image = tex;
            _lblSummaryMesh.text = "顔メッシュ: " + (_state.FaceRenderer != null ? _state.FaceRenderer.name : "未設定");
            _lblSummaryBase.text = "基準: " + (map != null
                ? MakeFixAutoSetup.DisplayLabel(map.DisplayName, FaceMapStorage.IsDraft(map.FilePath))
                : "未設定");
            _lblSummaryTex.text = "テクスチャ: " + (tex != null ? tex.name : "未設定");

            _lblSummaryState.text = hasProblem ? "要確認" : "OK";
            SetStepDot(_dotAutoSummary, hasProblem ? MakeFixGui.StepState.Problem : MakeFixGui.StepState.Done);

            // 異常で開いているときは閉じられない（直すまで開いたまま）。正常なときだけ手動で開閉できる
            _btnSummaryToggle.EnableInClassList("hidden", hasProblem);
            _btnSummaryToggle.text = _manualCardsOpen ? "閉じる ▴" : "おかしい場合は手動変更 ▾";
        }

        private void RefreshLeftFooter()
        {
            string folder = _state.IsScanning ? "FaceMap 読み込み中..." : (_state.FaceMapFolderPath ?? "");
            _lblFaceMapFolder.text = folder;
            _lblFaceMapFolder.tooltip = _state.FaceMapFolderPath ?? "";
        }

        private void RebuildSceneAvatarList(GameObject target)
        {
            _listSceneAvatars.Clear();
            if (_sceneAvatars.Count == 0)
            {
                var empty = new Label("アバターが見つかりません");
                empty.AddToClassList("list-empty-label");
                _listSceneAvatars.Add(empty);
                return;
            }

            foreach (GameObject avatar in _sceneAvatars)
            {
                if (avatar == null) continue;
                bool on = avatar == target;
                var row = new VisualElement();
                row.AddToClassList("list-row");
                if (on) row.AddToClassList("list-row--selected");
                row.tooltip = AvatarTooltip(avatar);

                var dot = new VisualElement();
                dot.AddToClassList("list-row-dot");
                MakeFixAutoSetup.AvatarStatus status = AvatarStatusOf(avatar);
                if (status == MakeFixAutoSetup.AvatarStatus.Ready) dot.AddToClassList("list-row-dot--ready");
                else if (status == MakeFixAutoSetup.AvatarStatus.NeedsCheck) dot.AddToClassList("list-row-dot--check");
                dot.tooltip = status == MakeFixAutoSetup.AvatarStatus.Ready ? "準備 OK"
                    : status == MakeFixAutoSetup.AvatarStatus.NeedsCheck ? "要確認" : "未解析";
                row.Add(dot);

                var lbl = new Label(on ? avatar.name + " (Active)" : avatar.name);
                lbl.AddToClassList("list-row-label");
                row.Add(lbl);

                string sceneName = avatar.scene.IsValid() ? avatar.scene.name : "";
                if (!string.IsNullOrEmpty(sceneName))
                {
                    var sub = new Label(sceneName);
                    sub.AddToClassList("list-row-sub");
                    row.Add(sub);
                }

                GameObject captured = avatar;
                row.RegisterCallback<MouseDownEvent>(evt =>
                {
                    if (evt.button != 0) return;
                    if (captured != _state.TargetAvatar)
                    {
                        SelectAvatar(captured);
                        MarkUiDirty();
                    }
                });

                _listSceneAvatars.Add(row);
            }
        }

        private void RebuildFaceMeshList()
        {
            if (_hoveredFaceRenderer != null && !_faceCandidates.Contains(_hoveredFaceRenderer))
                SetHoveredFaceRenderer(null);

            _listFaceMeshes.Clear();
            if (_faceCandidates.Count == 0)
            {
                var empty = new Label("SkinnedMeshRenderer がありません");
                empty.AddToClassList("list-empty-label");
                _listFaceMeshes.Add(empty);
                return;
            }

            foreach (SkinnedMeshRenderer smr in _faceCandidates)
            {
                if (smr == null) continue;
                bool on = smr == _state.FaceRenderer;
                Mesh m = smr.sharedMesh;
                var row = new VisualElement();
                row.AddToClassList("list-row");
                if (on) row.AddToClassList("list-row--selected");
                row.tooltip = $"メッシュ: {(m != null ? m.name : "-")}\nマウスを乗せている間、3D 顔ビューにこのメッシュだけを映します。";

                var lbl = new Label(smr.name);
                lbl.AddToClassList("list-row-label");
                row.Add(lbl);

                if (m != null)
                {
                    var sub = new Label($"BS {m.blendShapeCount}");
                    sub.AddToClassList("list-row-sub");
                    sub.AddToClassList("mono");
                    row.Add(sub);
                }

                SkinnedMeshRenderer captured = smr;
                row.RegisterCallback<MouseDownEvent>(evt =>
                {
                    if (evt.button != 0) return;
                    if (captured != _state.FaceRenderer)
                    {
                        SelectFaceRenderer(captured);
                        MarkUiDirty();
                    }
                });
                row.RegisterCallback<PointerEnterEvent>(_ =>
                {
                    SetHoveredFaceRenderer(captured);
                    MarkUiDirty();
                });

                _listFaceMeshes.Add(row);
            }
        }

        private static string ResolveFaceMapPathByLabel(Dictionary<string, string> map, string label)
        {
            if (map == null || string.IsNullOrEmpty(label)) return null;
            return map.TryGetValue(label, out string path) ? path : null;
        }

        private void SyncFaceMapDropdown(DropdownField dropdown, Dictionary<string, string> labelToPath, ref string lastSig, string currentPath)
        {
            if (dropdown == null) return;

            var choices = new List<string>(_validMaps.Count + 1) { "（未選択）" };
            int currentIdx = 0;
            labelToPath.Clear();
            for (int i = 0; i < _validMaps.Count; i++)
            {
                FaceMapMeta m = _validMaps[i];
                bool dup = _validMaps.Count(x => x.DisplayName == m.DisplayName) > 1;
                string shownName = MakeFixAutoSetup.DisplayLabel(m.DisplayName, FaceMapStorage.IsDraft(m.FilePath));
                string baseLabel = (dup ? $"{shownName} ({m.FileName})" : shownName).Replace('/', '／');
                string labelText = baseLabel;
                int suffix = 2;
                while (labelToPath.ContainsKey(labelText))
                {
                    labelText = $"{baseLabel} [{suffix++}]";
                }
                choices.Add(labelText);
                labelToPath[labelText] = m.FilePath;
                if (MakeFixMakeupSource.PathsEqual(m.FilePath, currentPath)) currentIdx = i + 1;
            }

            string sig = string.Join("|", choices);
            bool choicesChanged = sig != lastSig;
            if (choicesChanged)
            {
                lastSig = sig;
                dropdown.choices = choices;
            }

            string targetLabel = currentIdx >= 0 && currentIdx < choices.Count ? choices[currentIdx] : choices[0];
            if (choicesChanged || dropdown.value != targetLabel)
            {
                dropdown.SetValueWithoutNotify(targetLabel);
            }
        }
    }
}
