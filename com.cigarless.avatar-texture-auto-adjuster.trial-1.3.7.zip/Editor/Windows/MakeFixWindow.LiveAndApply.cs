using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── ライブプレビューの同期（§13.6）──

        /// <summary>表示する条件を満たしていれば付け（同じなら何もしない）、満たさなければ外す。</summary>
        private void SyncLive()
        {
            if (_live == null) return;
            bool wasAttached = _live.IsAttached;
            SyncLiveCore();
            if (wasAttached != _live.IsAttached) _orbit?.MarkDirty();
        }

        private void SyncLiveCore()
        {
            bool can = LiveEnabled && _liveOk && !_applying && _showPreview
                       && !EditorApplication.isPlayingOrWillChangePlaymode;
            Texture activeOutput = ActivePreviewOutput;
            bool ready = activeOutput != null;
            // 比較（メイク前）は「調整を表示」・準備チェックに関係なく出す。
            // OFF でも、適用済みならアバターのマテリアルはメイク後なので、メイク前を一時的に表示しないと比べられない
            GameObject avatar = _state.TargetAvatar;
            bool canCompare = _comparing && _showPreview && !_applying
                              && avatar != null && !EditorUtility.IsPersistent(avatar)
                              && !EditorApplication.isPlayingOrWillChangePlaymode;

            int shown = 0;
            if (canCompare)
            {
                // 比較中は、最初の顔テクスチャを表示する（適用済みでも、メイク前の見た目にする）
                shown = _live.Show(_state.TargetAvatar, _state.PreviewAvatarTexture, _state.PreviewAvatarTexture);
            }
            else if (can && ready && !_comparing)
            {
                shown = _live.Show(_state.TargetAvatar, _state.PreviewAvatarTexture, activeOutput);
            }
            else
            {
                _live.Detach();
            }

            // ON なのに表示できていないときの理由（ツールバーの状態表示のツールチップ）
            _liveReason =
                !LiveEnabled ? null
                : EditorApplication.isPlayingOrWillChangePlaymode ? "再生中は表示しません。"
                : _applying ? "適用中です。"
                : !_showPreview ? "メイク元とアバター基準の組み合わせがまだ選ばれていない（または使えない）ため、表示できません。"
                : !_liveOk ? "準備チェックに終わっていない項目があるため、表示できません（左のアバター管理の項目を確かめてください）。"
                : !_comparing && !ready ? "プレビューを作成中です。"
                : shown == 0 ? "シーンのアバターに、顔テクスチャを使うマテリアルが見つからないため、表示できません。"
                : null;
        }

        // 「調整を表示」が ON なのに表示できていない理由。表示できている・OFF なら null
        private string _liveReason;

        /// <summary>
        /// メイクを適用する。await の続きは EditorMainThreadContext（EditorApplication.update で回る）で受け取る。
        /// Unity 標準の同期コンテキストはエディターのアイドル中に回らないことがあり、適用が「適用中...」のまま終わらなかった。
        /// </summary>
        private void ApplyMakeup()
        {
            using (EditorMainThreadContext.Instance.Enter())
            {
                ApplyMakeupCore();
            }
        }

        private async void ApplyMakeupCore()
        {
            // 適用の前に外し、終わったら付け直す（適用後の複製マテリアルのスロットにも同じ規則で付ける）
            _applying = true;
            _live?.Detach();
            // 適用を始めた時点の結果を覚える（適用中に調整を変えたら「適用後に変更あり」になる）。
            // 一時データ（ドラフト）が適用中に実ファイルへ昇格した場合だけはパスを昇格後に揃える。
            int startRevision = _outputRevision;
            string startMakeupPath = _state.MakeupFaceMapPath;
            string startAvatarPath = _state.AvatarFaceMapPath;
            bool startMakeupDraft = FaceMapStorage.IsDraft(startMakeupPath);
            bool startAvatarDraft = FaceMapStorage.IsDraft(startAvatarPath);
            int startMakeupTexId = _state.PreviewMakeupTexture != null ? _state.PreviewMakeupTexture.GetInstanceID() : 0;
            int startAvatarTexId = _state.PreviewAvatarTexture != null ? _state.PreviewAvatarTexture.GetInstanceID() : 0;
            int startOpacityKey = Mathf.RoundToInt(_state.PreviewMakeupOpacity * 1000f);
            int avatarId = _state.TargetAvatar != null ? _state.TargetAvatar.GetInstanceID() : 0;
            int startEditMark = _userEdits.Mark;
            string generated = null;
            try
            {
                generated = await _toolService.ApplyMakeupAsync();
                if (generated != null)
                {
                    string appliedMakeupPath = MakeFixUnsavedGuard.ResolveAppliedPath(startMakeupPath, _state.MakeupFaceMapPath, startMakeupDraft);
                    string appliedAvatarPath = MakeFixUnsavedGuard.ResolveAppliedPath(startAvatarPath, _state.AvatarFaceMapPath, startAvatarDraft);
                    _appliedFingerprint = FormatOutputFingerprint(
                        startRevision, appliedMakeupPath, appliedAvatarPath,
                        startMakeupTexId, startAvatarTexId, startOpacityKey);
                    _appliedAvatarId = avatarId;
                    _appliedTexturePath = generated;
                    _userEdits.ClearIfUnchangedSince(startEditMark);
                    _historyBaselineClean = false; // 適用後は、履歴の起点へ戻しても適用した見た目とは違う
                }
            }
            finally
            {
                _applying = false;
                // 適用の待ち中にウィンドウが閉じられたら、破棄済みのウィンドウからプレビューを付け直さない
                if (this != null)
                {
                    _slotsDirty = true;
                    SyncLive();
                    if (generated != null) Notify("メイクを適用しました");
                    // 閉じる前の確認で「保存」を選んだ: 適用できたら閉じる（できなければ開いたまま、理由を見せる）
                    if (_closeAfterApply)
                    {
                        _closeAfterApply = false;
                        if (generated != null)
                        {
                            hasUnsavedChanges = false;
                            EditorApplication.delayCall += () => { if (this != null) Close(); };
                        }
                    }
                    // アバター切り替え前の確認で「適用して切り替え」を選んだ: 適用できたら切り替える
                    if (_switchAfterApply)
                    {
                        bool hadTarget = !ReferenceEquals(_pendingSwitchAvatar, null);
                        GameObject nextAvatar = _pendingSwitchAvatar;
                        _switchAfterApply = false;
                        _pendingSwitchAvatar = null;
                        if (generated != null && (!hadTarget || nextAvatar != null))
                        {
                            _state.TargetAvatar = nextAvatar;
                            GUI.FocusControl(null);
                        }
                    }
                    // UI Toolkit の表示（ボタン・状態表示・準備チェック）は MarkUiDirty で作り直す
                    MarkUiDirty();
                    Repaint();
                }
            }
        }

        /// <summary>
        /// 適用を解除。マテリアルを元に戻し、戻せたら「調整を表示」を OFF にして、シーンと 3D 顔ビューを元の見た目にする（§13.6）。
        /// ON のままだと、元のマテリアルのスロットにすぐ調整中のメイクが付け直され、見た目が何も変わらず「解除できない」ように見えた。
        /// </summary>
        private void RevertMakeup()
        {
            bool hadLivePreview = (_live != null && _live.IsAttached) || _showPreview;
            // 複製マテリアルのスロットに付けた一時表示を外してから戻す
            _live?.Detach();
            int reverted = _toolService.RevertMakeup();
            if (MakeFixLiveOutput.ShouldDisableLiveOnRevert(reverted, LiveEnabled, hadLivePreview))
            {
                LiveEnabled = false;
                _state.Warning += "\n「調整を表示」を OFF にしました（シーンは元の見た目です）。ON に戻すと、調整中のメイクをまた表示します。";
            }
            if (reverted > 0) Notify("適用を解除しました（元の見た目）");
            _appliedFingerprint = null;
            _appliedTexturePath = null;
            _slotsDirty = true;
            SyncLive();
            MarkUiDirty();
            Repaint();
        }

        /// <summary>生成したテクスチャを Project ウィンドウで選択し、押せたことをこのウィンドウにも知らせる。</summary>
        private void LocateAppliedTexture()
        {
            var asset = string.IsNullOrEmpty(_appliedTexturePath)
                ? null
                : AssetDatabase.LoadAssetAtPath<Texture2D>(_appliedTexturePath);
            if (asset != null)
            {
                EditorGUIUtility.PingObject(asset);
                Selection.activeObject = asset;
            }
            ShowNotification(new GUIContent(MakeFixLocateFeedback.Message(_appliedTexturePath, asset != null)), 2.5);
        }

        // ── 適用の状態 ──

        /// <summary>プレビューを作り直す印を付ける。結果が変わったので、適用済みとの比較用の番号も進める。</summary>
        private void InvalidatePreview()
        {
            _previewDirty = true;
            _outputRevision++;
            MarkUiDirty();
        }

        /// <summary>適用したときと今とで、結果が同じかを比べるための指紋（調整・組み合わせ・テクスチャ・メイクの濃さ）。</summary>
        private string OutputFingerprint()
        {
            Texture2D makeupTex = _state.PreviewMakeupTexture;
            Texture2D avatarTex = _state.PreviewAvatarTexture;
            return FormatOutputFingerprint(
                _outputRevision,
                _state.MakeupFaceMapPath ?? "",
                _state.AvatarFaceMapPath ?? "",
                makeupTex != null ? makeupTex.GetInstanceID() : 0,
                avatarTex != null ? avatarTex.GetInstanceID() : 0,
                Mathf.RoundToInt(_state.PreviewMakeupOpacity * 1000f));
        }

        private static string FormatOutputFingerprint(
            int revision, string makeupPath, string avatarPath, int makeupTexId, int avatarTexId, int opacityKey)
        {
            return string.Join("|", revision, makeupPath ?? "", avatarPath ?? "", makeupTexId, avatarTexId, opacityKey);
        }

        /// <summary>
        /// 対象アバターの適用の状態。このウィンドウを開く前に適用したもの（どの調整で適用したか分からない）は「適用済み」とみなす。
        /// </summary>
        private ApplyState CurrentApplyState()
        {
            if (!_hasAppliedSlots) return ApplyState.None;
            int avatarId = _state.TargetAvatar != null ? _state.TargetAvatar.GetInstanceID() : 0;
            if (_appliedFingerprint == null || avatarId != _appliedAvatarId) return ApplyState.Current;
            return _appliedFingerprint == OutputFingerprint() ? ApplyState.Current : ApplyState.Stale;
        }

        // ── 閉じる前の確認 ──
        // 「調整を表示」で映しているのは一時的な表示なので、ウィンドウを閉じると消える。未適用（または変更が未反映）のまま
        // 閉じようとしたら、Unity の「未保存の変更」の確認（FaceMap エディターと同じ仕組み）で知らせる。
        // 「保存」はメイク適用。適用は非同期なので、その場では閉じず（base.SaveChanges を呼ばない）、適用が済んだら閉じる。

        [System.NonSerialized] private bool _closeAfterApply;
        [System.NonSerialized] private bool _switchAfterApply;
        [System.NonSerialized] private GameObject _pendingSwitchAvatar;

        private bool ShouldConfirmAvatarSwitch(GameObject nextAvatar)
        {
            ApplyState state = CurrentApplyState();
            return MakeFixUnsavedGuard.ShouldConfirmAvatarSwitch(
                isTrial: AtaaCore.Edition == CoreEdition.Trial,
                applying: _applying,
                isPlaying: EditorApplication.isPlayingOrWillChangePlaymode,
                hasCurrentAvatar: _state.TargetAvatar != null,
                isDifferentAvatar: !ReferenceEquals(nextAvatar, _state.TargetAvatar),
                hasUserEdits: _userEdits.HasEdits(UserEditKey),
                allOk: _allOk,
                isCurrentApplied: state == ApplyState.Current);
        }

        /// <summary>閉じる前に確認するか（hasUnsavedChanges）と、その文面を今の状態に合わせる。UI 同期時に呼ぶ。</summary>
        private void UpdateUnsavedState()
        {
            ApplyState state = CurrentApplyState();
            bool unsaved = MakeFixUnsavedGuard.IsUnsaved(
                isTrial: AtaaCore.Edition == CoreEdition.Trial,
                applying: _applying,
                allOk: _allOk,
                liveAttached: _live != null && _live.IsAttached,
                isCurrentApplied: state == ApplyState.Current);
            if (unsaved)
                saveChangesMessage = MakeFixUnsavedGuard.CloseDialogMessage(state == ApplyState.Stale);
            hasUnsavedChanges = unsaved;
        }

        /// <summary>このウィンドウと Scene ビューに、大きな通知を数秒出す（適用・解除したことを見落とさないように）。</summary>
        private void Notify(string message)
        {
            var content = new GUIContent(message);
            ShowNotification(content, 2.5);
            SceneView.lastActiveSceneView?.ShowNotification(content, 2.5);
        }

        public override void SaveChanges()
        {
            // base を呼ばない（hasUnsavedChanges が残る）ので、ウィンドウは閉じない。適用が済んだら ApplyMakeup が閉じる
            if (_applying || !_allOk || EditorApplication.isPlayingOrWillChangePlaymode) return;
            _switchAfterApply = false;
            _pendingSwitchAvatar = null;
            _closeAfterApply = true;
            ApplyMakeup();
        }
    }
}
