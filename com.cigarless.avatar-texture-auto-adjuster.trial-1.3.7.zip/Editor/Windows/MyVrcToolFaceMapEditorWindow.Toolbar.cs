using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MyVrcToolFaceMapEditorWindow
    {
        // ── 上部ツールバー・通知帯・ステータスバー ──

        private Button _btnLoad;
        private Button _btn3D;
        private Button _btnSave;
        private Button _btnSaveAs;
        private Label _lblFile;
        private Label _lblRequired;

        private VisualElement _statusDot;
        private Label _lblStatusGuide;
        private Label _lblStatusWarning;
        private Label _lblStatusChip;

        private void BindToolbarUi()
        {
            var btnNew = _root.Q<Button>("btn-new");
            btnNew.tooltip = "新しいメイク基準 (FaceMap) を作ります。";
            btnNew.clicked += () =>
            {
                _vm.NewFaceMap();
                ResetZoom();
                MarkUiDirty();
            };

            _btnLoad = _root.Q<Button>("btn-load");
            _btnLoad.tooltip = AtaaCore.Edition == CoreEdition.Trial
                ? "一時保存した FaceMap、または FaceMaps フォルダの JSON を開きます。"
                : "FaceMaps フォルダの JSON を開きます。";
            _btnLoad.clicked += () => OnLoadClicked(_btnLoad);

            var btnAuto = _root.Q<Button>("btn-auto");
            btnAuto.tooltip = "右の「アバターから自動作成」でアバターを指定していれば、まばたき・口のブレンドシェイプから領域と目の線を置きます。" +
                              "指定が無ければ、テンプレートの標準位置に仮配置することもできます。どちらも枠を動かして直せます（Ctrl+Z で戻せます）。";
            btnAuto.clicked += OnAutoGenerateClicked;

            _btn3D = _root.Q<Button>("btn-3d");
            _btn3D.tooltip = "アバターの顔を 3D で表示し、目の線（黄）・目の下の線（緑）が顔のどこに当たるかを重ねて表示します。" +
                             "右の「アバターから自動作成」でアバターと顔のレンダラーを指定すると使えます。";
            _btn3D.clicked += () =>
            {
                Set3DVisible(!_show3D);
                MarkUiDirty();
            };

            _btnSave = _root.Q<Button>("btn-save");
            _btnSaveAs = _root.Q<Button>("btn-save-as");
            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                _btnSave.text = "一時保存";
                _btnSaveAs.text = "別名で一時保存";
            }
            _btnSave.clicked += SaveOverwriteAndNotify;
            _btnSaveAs.clicked += SaveAsAndNotify;

            _lblFile = _root.Q<Label>("lbl-file");
            _lblRequired = _root.Q<Label>("lbl-required");

            // オープンβ版・体験版だけの通知帯（新案の黄色い帯）。「非表示」で閉じる
            VisualElement banner = _root.Q<VisualElement>("fm-banner");
            string bannerText = null;
#if ATAA_DIAGNOSTICS
            bannerText = "オープンβ稼働中: 予期しない不具合が起きることがあります。利用する前にプロジェクトのバックアップを推奨します。";
#endif
            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                bannerText = (bannerText != null ? bannerText + "\n" : "") +
                             "体験版です。自動作成・調整・プレビューは製品版と同じように使えます（プレビューは通常 512・長押しで 2048 表示）。" +
                             "メイク適用（テクスチャの書き出し）とファイルへの保存は製品版のみです。" +
                             "作った FaceMap と調整はメモリに一時保存され、Unity を閉じると消えます。";
                banner.AddToClassList("fm-banner--trial");
            }
            if (bannerText != null)
            {
                _root.Q<Label>("lbl-banner").text = bannerText;
                banner.RemoveFromClassList("hidden");
            }
            _root.Q<Button>("btn-banner-hide").clicked += () => banner.AddToClassList("hidden");
        }

        private void OnLoadClicked(Button anchor)
        {
            if (!(AtaaCore.Edition == CoreEdition.Trial))
            {
                _vm.Load();
                MarkUiDirty();
                return;
            }

            // 体験版: 一時保存（メモリ）はファイルの選択画面に出ないので、メニューで選ぶ
            var menu = new GenericMenu();
            foreach (string p in TrialStore.FaceMapPaths())
            {
                string path = p;
                menu.AddItem(new GUIContent("一時保存/" + System.IO.Path.GetFileNameWithoutExtension(path)), false,
                    () => { if (_vm.LoadFromPath(path)) { ResetZoom(); MarkUiDirty(); } });
            }
            if (TrialStore.FaceMapPaths().Count == 0) menu.AddDisabledItem(new GUIContent("一時保存/（まだありません）"));
            menu.AddSeparator("");
            menu.AddItem(new GUIContent("ファイルから開く..."), false, () => { _vm.Load(); MarkUiDirty(); });
            menu.DropDown(anchor.worldBound);
        }

        private void RefreshToolbarUi()
        {
            int required = FaceMapEditorService.RequiredCount();
            bool canSave = FaceMapEditorUi.CanSave(_placedRequired, required);
            string saveTip = FaceMapEditorUi.SaveBlockedTip(_placedRequired, required);
            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                // 体験版: 保存先はメモリ（メイクフィックス画面のメイク基準・アバター基準に出る）。ファイルへの保存は製品版のみ
                const string trialNote = "\n体験版はメモリに一時保存します（メイクフィックス画面で選べます。Unity を閉じると消えます。ファイルへの保存は製品版のみ）。";
                _btnSave.tooltip = (_panelBound ? "開いている FaceMap に一時保存します。" : "名前を入力して一時保存します。") + saveTip + trialNote;
                _btnSaveAs.tooltip = "名前を入力して、新しい FaceMap として一時保存します。" + saveTip + trialNote;
            }
            else
            {
                _btnSave.tooltip = (_panelBound ? "開いているファイルに保存します。" : "まだ保存先が無いので、ファイル名を入力して新しいファイルに保存します。") + saveTip;
                _btnSaveAs.tooltip = "ファイル名を入力して、FaceMaps フォルダに新しいファイルとして保存します。" + saveTip;
            }
            _btnSave.SetEnabled(canSave);
            _btnSaveAs.SetEnabled(canSave);
            _btn3D.EnableInClassList("fm-tb-btn--on", _show3D);

            // 今どのメイク基準を編集しているかを常に表示する
            _lblFile.text = FaceMapEditorUi.FileLabel(_vm.State.BoundPath, _vm.State.Dirty);
            _lblFile.tooltip = _panelBound ? _vm.State.BoundPath : $"保存時のファイル名: {_vm.ResolveFileName()}.json";
            _lblFile.EnableInClassList("fm-chip-file--saved", _panelBound && !_vm.State.Dirty);

            _lblRequired.text = FaceMapEditorUi.RequiredPill(_placedRequired, required);
            _lblRequired.EnableInClassList("fm-pill--ok", canSave);
            _lblRequired.EnableInClassList("fm-pill--warn", !canSave);
        }

        // ── ステータスバー ──

        private void BindStatusUi()
        {
            _statusDot = _root.Q<VisualElement>("status-dot");
            _lblStatusGuide = _root.Q<Label>("lbl-status-guide");
            _lblStatusWarning = _root.Q<Label>("lbl-status-warning");
            _lblStatusChip = _root.Q<Label>("lbl-status-chip");
        }

        private void RefreshStatusUi()
        {
            // 次にすべきこと（ウィザードの指示・完了の案内）
            _lblStatusGuide.text = _guideMessage ?? "";
            _lblStatusGuide.tooltip = _guideMessage ?? "";

            // 操作の結果（保存・読み込み・自動生成など）
            string warning = _vm.State.Warning;
            bool hasWarning = !string.IsNullOrEmpty(warning);
            bool isError = hasWarning && _vm.State.WarningType == MessageType.Error;
            bool isWarn = hasWarning && _vm.State.WarningType == MessageType.Warning;
            _lblStatusWarning.EnableInClassList("hidden", !hasWarning);
            _lblStatusWarning.text = hasWarning ? (isWarn || isError ? "⚠ " : "") + warning.Split('\n')[0] : "";
            _lblStatusWarning.tooltip = warning ?? "";
            _lblStatusWarning.EnableInClassList("fm-status-warning--warn", isWarn);
            _lblStatusWarning.EnableInClassList("fm-status-warning--error", isError);

            _statusDot.EnableInClassList("fm-dot--emerald", !isWarn && !isError);
            _statusDot.EnableInClassList("fm-dot--warn", isWarn);
            _statusDot.EnableInClassList("fm-dot--error", isError);

            RefreshStatusChip();
        }

        /// <summary>右下のステータス（テクスチャの大きさ・マウス位置の UV）。マウスの移動のたびに呼ぶので軽くする。</summary>
        private void RefreshStatusChip()
        {
            if (_lblStatusChip == null) return;
            _lblStatusChip.text = FaceMapTextureRenderer.GetStatusText(_vm.State.Texture, _vm.IsHovering, _vm.HoverUV);
        }
    }
}
