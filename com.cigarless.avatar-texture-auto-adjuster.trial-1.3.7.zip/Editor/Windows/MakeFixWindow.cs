using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 3ペイン完結型メイクフィッティングツール（Issue #15）。作業の流れを左から右への一方向にまとめる:
    /// 【左】アバター管理（アバター・顔メッシュ・アバター基準 FaceMap・顔テクスチャ）
    /// 【中央】3D 顔ビュー（顔の中心をピボットにした独立 3D ビュー。2D UV 表示にも切り替え可）
    /// 【右】フィッティング調整（メイク元・パーツ選択・ドラッグスクラブ PAD・目の調整）
    /// 右ペイン下端に「メイク適用」（上部ツールバーには準備の状態だけ）。アバター基準データ（FaceMap）は Read-Only で、調整は .adjust.json にだけ保存する。
    /// 調整中の結果はシーン上のアバターにも一時表示する（ライブプレビュー、§13.6）。3D 顔ビューはそれを映す。
    /// </summary>
    public partial class MakeFixWindow : EditorWindow
    {
        internal MyVrcToolState _state = new MyVrcToolState();
        private ToolService _toolService;

        // 調整の元に戻す・やり直し（Ctrl+Z / Ctrl+Y）。履歴の起点にした組み合わせと調整を覚えておき、差し替わったら履歴を消す
        private readonly MakeFixHistory _history = new MakeFixHistory();
        private FaceMapAdjustment _historyAdjustment;
        private string _historyPairKey;

        // 履歴の起点が「読み込んだまま（ユーザーの変更を含まず、その後に適用もしていない）」状態か。
        // Undo でここへ戻ったら、変えた記録を消してよい
        private bool _historyBaselineClean;

        // ユーザーが調整・濃さを変えたか（メイク元を選んだだけのときは、アバター切り替えの確認を出さない）。
        // 調整値とライブ表示は再コンパイルを越えて残るので、この記録もシリアライズして残す
        [SerializeField] private MakeFixUserEdits _userEdits = new MakeFixUserEdits();

        /// <summary>変えた記録に使うキー（FaceMap のパスの組み合わせ。更新日時は含めない）。</summary>
        private string UserEditKey => MakeFixUserEdits.Key(_state.MakeupFaceMapPath, _state.AvatarFaceMapPath);

        // ── 大きさ（§13.2）──
        private static readonly Vector2 DefaultSize = new Vector2(1360f, 800f);
        private static readonly Vector2 MinSize = new Vector2(1050f, 650f);

        // ── 同期スナップショット ──
        private List<FaceMapMeta> _validMaps = new List<FaceMapMeta>();
        private List<FaceMapMeta> _invalidMaps = new List<FaceMapMeta>();
        private List<string> _makeupNotes = new List<string>();
        private List<string> _avatarNotes = new List<string>();
        private bool _showPreview;
        private List<string> _categories = new List<string>();
        private string _lowerLineNote;

        // メイク元が目の開いていない素体で、対象の目の開いた部分を残す組み合わせか（統合仕様書 §4.6）
        private bool _keepsAvatarEye;
        private bool _lowerLineAvatarMissing;
        private List<ReadinessItem> _readiness = new List<ReadinessItem>();
        private bool _setupOk;
        private bool _liveOk;
        private bool _allOk;

        /// <summary>シーン上のアバターを選んでいるか（②〜④のカードを開く条件）。</summary>
        private bool _avatarReady;

        /// <summary>次にやる項目のカード（枠を青くする）。</summary>
        private FocusCard _currentCard;
        private bool _showInvalidDetail;

        /// <summary>位置・拡大縮小を調整する対象のパーツ（分類）。null なら全体。</summary>
        private string _editTarget;

        // ── プレビュー（§13.5）──
        private readonly FaceMapPreview _preview = new FaceMapPreview();
        private bool _previewDirty = true;
        private string _previewPairKey;
        private float _previewOpacity = -1f;
        private string _previewError;
        private FaceMapPreview.Quality _requestedQuality = FaceMapPreview.Quality.Full;
        private FaceMapPreview.ViewMode _requestedView = FaceMapPreview.ViewMode.Result;
        private FaceMapPreview.ViewMode _viewMode = FaceMapPreview.ViewMode.Result;

        private const float MinZoom = 1f;
        private const float MaxZoom = 8f;
        private const float ZoomStep = 1.15f;
        private float _zoom = 1f;
        private Vector2 _pan;
        private bool _panning;

        private enum PreviewDrag
        {
            None,
            Move,
            Corner,

            /// <summary>対象アバターの目の線のつまみ（§13.4。この組み合わせの調整に保存する）。</summary>
            EyeLine,

            /// <summary>対象アバターの目の下の線のつまみ。</summary>
            EyeLowerLine
        }

        private PreviewDrag _previewDrag = PreviewDrag.None;

        /// <summary>目の線のつまみをドラッグしている目の領域（PairMatch.Regions の番号）。</summary>
        private int _lineDragRegion = -1;

        /// <summary>目の線のつまみを、目の領域の枠から横にどれだけ離して置くか（四隅のハンドルと重ならないように）。</summary>
        private const float LineKnobOffset = 16f;
        private Vector2 _dragStartMouseUv;
        private Vector2 _dragStartOffset;
        private Vector2 _dragFixedUv;

        // ── ライブプレビュー（§13.6）──
        private LiveFacePreview _live;
        private bool _comparing;
        private bool _trialHighResHeld;
        private string _requestedTrialHighKey;
        // 適用の非同期処理はドメインリロードで消えるので、フラグだけ持ち越さない（持ち越すと「適用中...」のまま戻らない）
        [System.NonSerialized] private bool _applying;

        // 「調整を表示」。保存せず、ウィンドウを開くたびに ON から始める（OFF にしても次回に持ち越さない）
        private static bool LiveEnabled { get; set; } = true;

        // ── 適用の状態（プレビュー中・適用済み・適用後に変更あり、を見分ける）──
        /// <summary>顔のスロットに、生成したマテリアルが入っているか（UpdateFaceSlots で数え直す）。</summary>
        private bool _hasAppliedSlots;
        /// <summary>結果が変わるたびに増やす（InvalidatePreview）。適用したときの値と比べて「適用後に変更あり」を出す。</summary>
        private int _outputRevision;
        /// <summary>このウィンドウで最後に適用したときの結果の指紋と、そのアバター・生成したテクスチャ。</summary>
        private string _appliedFingerprint;
        private int _appliedAvatarId;
        private string _appliedTexturePath;

        private enum ApplyState { None, Current, Stale }

        // ── 顔のスロットの有無（準備チェック 6）。アバター・テクスチャ・ヒエラルキーが変わったときだけ数え直す ──
        private int _slotsAvatarId;
        private int _slotsTextureId;
        private bool _slotsDirty = true;
        private bool _hasFaceSlots;

        // ── テクスチャの記憶（§13.9）──
        private string _memoryKey;
        private Texture2D _memAvatarTex;
        private Texture2D _memMakeupTex;

        /// <summary>前回 JSON に顔テクスチャを残そうとした「FaceMap のパス|GUID」（失敗時に書き直し続けないため）。</summary>
        private string _hintAttempt;

        private static MakeFixWindow _instance;

        private static GUIStyle _emptyViewStyle;

        // ── 中央ペイン（3D 顔ビュー / 2D UV）──
        private enum CenterMode
        {
            View3D,
            Uv2D
        }

        private const string CenterModeKey = "ATAA.MakeFix.CenterMode";
        private const string HideDecorationsKey = "ATAA.MakeFix.HideDecorations";
        private const string AuxLightKey = "ATAA.MakeFix.AuxLight";
        private const string BackgroundKey = "ATAA.MakeFix.ViewBackground";

        private FaceOrbitView _orbit;
        private CenterMode _centerMode = CenterMode.View3D;
        private bool _centerFocused;

        // ── 左ペイン（アバター管理）──
        private List<GameObject> _sceneAvatars = new List<GameObject>();
        private bool _avatarsDirty = true;
        private List<SkinnedMeshRenderer> _faceCandidates = new List<SkinnedMeshRenderer>();
        private GameObject _faceCandidatesFor;
        private bool _faceCandidatesDirty = true;
        private GameObject _lastAvatar;
        private List<Renderer> _faceSlotRenderers = new List<Renderer>();

        [MenuItem("Cigarless/ATAA")]
        public static void ShowWindow()
        {
            bool alreadyOpen = HasOpenInstances<MakeFixWindow>();
            var window = GetWindow<MakeFixWindow>("ATAA");
            window.minSize = MinSize;
            if (!alreadyOpen)
            {
                window.position = InitialRect();
            }
        }

        /// <summary>
        /// 最初に開くときの位置と大きさ。Unity のメインウィンドウの中央に置き、
        /// 画面より大きくならないように縮める（右側のパネルが画面外にはみ出さないように）。
        /// </summary>
        private static Rect InitialRect()
        {
            Rect main = EditorGUIUtility.GetMainWindowPosition();
            Vector2 size = new Vector2(
                Mathf.Max(MinSize.x, Mathf.Min(DefaultSize.x, main.width - 40f)),
                Mathf.Max(MinSize.y, Mathf.Min(DefaultSize.y, main.height - 80f)));
            Vector2 pos = new Vector2(
                main.x + Mathf.Max(0f, (main.width - size.x) * 0.5f),
                main.y + Mathf.Max(0f, (main.height - size.y) * 0.5f));
            return new Rect(pos, size);
        }

        public static MakeFixWindow GetMainInstance() => _instance;

        private void OnEnable()
        {
            minSize = MinSize;
            wantsMouseMove = true;
            wantsMouseEnterLeaveWindow = true; // 顔メッシュの一覧から外へ出たら、候補の 3D 表示を止める

            LiveEnabled = true;
            _toolService = new ToolService(_state);
            _toolService.Changed += OnToolServiceChanged;
            _live = new LiveFacePreview();
            _live.ProxiesChanged += OnLiveProxiesChanged;
            _orbit = new FaceOrbitView
            {
                HideDecorations = EditorPrefs.GetBool(HideDecorationsKey, false),
                AuxiliaryLight = EditorPrefs.GetBool(AuxLightKey, true),
                Background = ViewportBackground.FromSaved(EditorPrefs.GetInt(BackgroundKey, (int)ViewportBackground.Default))
            };
            _centerMode = (CenterMode)Mathf.Clamp(EditorPrefs.GetInt(CenterModeKey, 0), 0, 1);
            _preview.Updated += OnPreviewUpdated;
            Undo.undoRedoPerformed += OnUndoRedo;
            EditorApplication.update += OnEditorUpdate;
            EditorApplication.hierarchyChanged += OnSceneOrProjectChanged;
            EditorApplication.projectChanged += OnProjectChanged;
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
            _instance = this;
            RequestRefresh();
        }

        private void OnDisable()
        {
            if (_instance == this) _instance = null;

            EditorApplication.update -= OnEditorUpdate;
            EditorApplication.hierarchyChanged -= OnSceneOrProjectChanged;
            EditorApplication.projectChanged -= OnProjectChanged;
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
            _preview.Updated -= OnPreviewUpdated;
            Undo.undoRedoPerformed -= OnUndoRedo;

            FlushPendingSave();
            _history.Dispose();
            _historyAdjustment = null;
            _historyPairKey = null;

            // 装飾品の一時非表示が残らないように（フェイルセーフ）
            RendererIsolation.ForceRestoreAll();
            _orbit?.Dispose();
            _orbit = null;

            _live?.Dispose();
            _live = null;
            _preview.Dispose();
            DisposeTransientMakeupTexture();
            // 適用用に読んだ元のテクスチャの画素（4096 で 1 枚 64 MB）を返す
            FaceTextureReader.ClearSourceCache();

            _closeAfterApply = false;
            _switchAfterApply = false;
            _pendingSwitchAvatar = null;

            if (_toolService != null)
            {
                _toolService.Changed -= OnToolServiceChanged;
                _toolService.Cancel();
            }
        }

        /// <summary>再生の開始・終了で、適用ボタンと表示の状態（再生中は止める）を作り直す。</summary>
        private void OnPlayModeStateChanged(PlayModeStateChange change)
        {
            SyncLive();
            _orbit?.MarkDirty();
            MarkUiDirty();
            Repaint();
        }

        private void OnToolServiceChanged()
        {
            SyncHistoryBaseline();
            MarkUiDirty();
            Repaint();
        }

        private void OnDestroy()
        {
            RendererIsolation.ForceRestoreAll();
        }

        private void OnUndoRedo()
        {
            if (_history.TryTakeUndoRedo(_state.PairKey, out FaceMapAdjustment adj, out float opacity))
            {
                _state.Adjustment = adj;
                _state.PreviewMakeupOpacity = opacity;
                _historyAdjustment = adj;
                // 読み込んだままの値へ戻しただけなら、変えていない扱いに戻す
                if (_historyBaselineClean && _history.IsBaseline(_state.PairKey, adj, opacity)) _userEdits.Clear();
                else _userEdits.Record(UserEditKey);
                ApplyAdjustmentChange(recordHistory: false);
            }

            _slotsDirty = true; // 適用・適用を解除の Undo で、スロットのマテリアルが変わる
            _orbit?.MarkDirty();
            MarkUiDirty();
            Repaint();
        }

        private long _lastFolderCheckTicks;

        private void OnFocus()
        {
            // 外部でファイルが追加・削除された場合に備え、フォルダ更新時または未取得時のみ再走査する
            string folder = _state.FaceMapFolderPath;
            bool needRefresh = string.IsNullOrEmpty(folder) || _state.FaceMaps == null || _state.FaceMaps.Count == 0;
            if (!needRefresh && System.IO.Directory.Exists(folder))
            {
                long ticks = System.IO.Directory.GetLastWriteTimeUtc(folder).Ticks;
                if (ticks != _lastFolderCheckTicks)
                {
                    _lastFolderCheckTicks = ticks;
                    needRefresh = true;
                }
            }
            if (needRefresh) RequestRefresh();
            MarkUiDirty();
        }

        private void OnLostFocus()
        {
            // ウィンドウ外でボタンを離すと MouseUp が来ないことがあるので、ここで操作を終える
            _panning = false;
            _uiInteracting = false;
            ReleasePreviewHotControl();
            _orbit?.CancelDrag();
            _centerFocused = false;
            FlushPendingSave();
            // ウィンドウ外で離したボタン・キーは届かないので、比較・体験版の高画質長押しもここで終える
            _compareMouseHeld = false;
            _compareKeyHeld = false;
            bool needLiveResync = false;
            if (_comparing)
            {
                _comparing = false;
                needLiveResync = true;
            }
            if (_trialHighResHeld)
            {
                _trialHighResHeld = false;
                _preview.CancelTrialHigh();
                needLiveResync = true;
            }
            if (needLiveResync)
            {
                SyncLive();
                _orbit?.MarkDirty();
            }
            if (_previewDrag != PreviewDrag.None) EndPreviewDrag();
            MarkUiDirty();
            Repaint();
        }

        /// <summary>
        /// プレビュー上のドラッグ・表示移動が、離した MouseUp を受け取れずに残っていたら終える。
        /// ウィンドウ外で離した・ペンタブレットやタッチ・リモートデスクトップで MouseUp が来ない・
        /// 離した時点でプレビューが描かれていない（組み合わせが外れた）などの環境で、ドラッグ中の扱いが残ると
        /// PAD・左右の間隔・中心線のボタンが無効のままになる。次にボタンを押したら（前のドラッグは終わっているので）解除する。
        /// MouseUp はボタンを問わず解除する（ペンなどで左以外のボタンとして届くことがある）。
        /// </summary>
        private void RecoverLostPreviewDrag()
        {
            Event e = Event.current;
            if (e.rawType != EventType.MouseDown && e.rawType != EventType.MouseUp) return;
            if (_panning)
            {
                _panning = false;
                ReleasePreviewHotControl();
            }
            if (_previewDrag == PreviewDrag.None) return;
            EndPreviewDrag();
            Repaint();
        }

        /// <summary>
        /// プレビュー上のドラッグを終えて保存する。線のつまみも含め、保存先はこの組み合わせの調整（.adjust.json）だけ。
        /// アバター基準（対象の FaceMap）には書き戻さない（3ペイン仕様 §4「データ不変性」）。
        /// </summary>
        private void EndPreviewDrag()
        {
            _previewDrag = PreviewDrag.None;
            ReleasePreviewHotControl();
            // ドラッグ中は値を直接書き換えているので、離したときに元に戻すの履歴へ 1 回分として記録する
            RecordHistory("プレビューで調整");
            InvalidatePreview();
            _orbit?.MarkDirty();
            _toolService?.SaveAdjustment();
        }

        /// <summary>一時データを実ファイルに保存したとき、選択中のパスを新しいパスへ差し替える。</summary>
        internal void OnFaceMapPromoted(string from, string to)
        {
            _state.MakeupFaceMapPath = FaceMapStorage.RemapPath(_state.MakeupFaceMapPath, from, to);
            _state.AvatarFaceMapPath = FaceMapStorage.RemapPath(_state.AvatarFaceMapPath, from, to);
        }

        /// <summary>FaceMaps フォルダを再走査する（エディターの保存後などに呼ぶ）。</summary>
        internal void RequestRefresh()
        {
            _ = _toolService?.RefreshAsync();
        }

        private void OnEditorUpdate()
        {
            TickUiToolkit();
        }

        /// <summary>NDMF プレビューの代理に調整中の表示を付けた。3D 顔ビューは代理を映すので描き直す。</summary>
        private void OnLiveProxiesChanged()
        {
            _orbit?.MarkDirty();
            MarkUiDirty();
            Repaint();
        }

        private void OnPreviewUpdated()
        {
            SyncLive();
            _live?.Refresh();
            _orbit?.MarkDirty();
            MarkUiDirty();
            Repaint();
        }

        private void OnSceneOrProjectChanged()
        {
            _slotsDirty = true;
            _avatarsDirty = true;
            _faceCandidatesDirty = true;
            _live?.Invalidate();
            _orbit?.MarkDirty();
            MarkUiDirty();
            Repaint();
        }

        private void OnProjectChanged()
        {
            // 顔テクスチャが（同じアセットのまま）描き直された・インポート設定が変わった場合は、プレビューを読み直す
            if (_preview.CheckReimported()) InvalidatePreview();
            OnSceneOrProjectChanged();
        }

        private static void InitStyles()
        {
            if (_emptyViewStyle == null)
            {
                _emptyViewStyle = new GUIStyle(EditorStyles.centeredGreyMiniLabel) { wordWrap = true };
            }
        }

        private void UpdateSnapshot()
        {
            _showPreview = _state.PairMatch != null && _state.PairMatch.IsApplicable;
            _categories = AtaaCore.GetCategories(_state.PairMatch);
            _lowerLineNote = _showPreview ? MissingLowerLineNote(_state.PairMatch, _categories) : null;
            _lowerLineAvatarMissing = _lowerLineNote != null && !_state.PairMatch.AvatarHasEyeLowerLine;
            _keepsAvatarEye = _showPreview && _state.PairMatch.KeepsAvatarEyeOpening;
            if (_editTarget != null && !_categories.Contains(_editTarget) && _previewDrag == PreviewDrag.None)
                _editTarget = null;

            _validMaps = _state.FaceMaps.Where(m => m.IsValid).ToList();
            _invalidMaps = _state.FaceMaps.Where(m => !m.IsValid).ToList();

            _makeupNotes = _state.MakeupFaceMap != null
                ? new List<string>(_state.MakeupFaceMap.Warnings)
                : new List<string>();

            _avatarNotes = new List<string>();
            FaceMapMeta avatarMap = _state.AvatarFaceMap;
            if (avatarMap != null)
            {
                _avatarNotes.AddRange(avatarMap.Warnings);
                string w2 = FaceMapValidator.CheckTargetAvatar(
                    avatarMap.TargetAvatar,
                    _state.TargetAvatar != null ? _state.TargetAvatar.name : null);
                if (w2 != null) _avatarNotes.Add(w2);
            }

            UpdateFaceSlots();

            FaceMapAdjustment adj = _state.Adjustment;
            bool? applicable = null;
            if (_state.PairError != null) applicable = false;
            else if (_state.PairMatch != null) applicable = _state.PairMatch.IsApplicable;

            _readiness = MakeFixReadiness.Evaluate(new MakeFixReadiness.Inputs
            {
                HasMakeupFaceMap = _state.MakeupFaceMap != null && _state.MakeupFaceMap.IsValid,
                HasAvatarFaceMap = _state.AvatarFaceMap != null && _state.AvatarFaceMap.IsValid,
                HasAvatar = _state.TargetAvatar != null,
                AvatarIsAsset = _state.TargetAvatar != null && EditorUtility.IsPersistent(_state.TargetAvatar),
                HasAvatarTexture = _state.PreviewAvatarTexture != null,
                HasMakeupTexture = _state.PreviewMakeupTexture != null,
                HasFaceSlots = _hasFaceSlots,
                MatchApplicable = applicable,
                MatchError = _state.PairError,
                AnyPartEnabled = _categories.Count == 0 || _categories.Any(c => adj.IsEnabled(c))
            });

            _setupOk = MakeFixReadiness.AllOk(_readiness, MakeFixReadiness.SetupItemCount);
            _liveOk = MakeFixReadiness.AllOk(_readiness, MakeFixReadiness.LivePreviewItemCount);
            _allOk = MakeFixReadiness.FailedCount(_readiness) == 0;

            _avatarReady = _state.TargetAvatar != null && !EditorUtility.IsPersistent(_state.TargetAvatar);
            ReadinessItem next = NextItem();
            _currentCard = next != null ? CardFor(next) : FocusCard.None;
        }

        private void UpdateFaceSlots()
        {
            GameObject avatar = _state.TargetAvatar;
            Texture2D tex = _state.PreviewAvatarTexture;
            int avatarId = avatar != null ? avatar.GetInstanceID() : 0;
            int texId = tex != null ? tex.GetInstanceID() : 0;
            if (!_slotsDirty && avatarId == _slotsAvatarId && texId == _slotsTextureId) return;

            _slotsDirty = false;
            _slotsAvatarId = avatarId;
            _slotsTextureId = texId;
            _faceSlotRenderers = new List<Renderer>();
            _hasAppliedSlots = false;
            if (avatar != null && tex != null && !EditorUtility.IsPersistent(avatar))
            {
                foreach (FaceMaterialApplier.Slot slot in FaceMaterialApplier.FindFaceSlots(avatar, tex))
                {
                    if (slot.Renderer == null) continue;
                    if (!_faceSlotRenderers.Contains(slot.Renderer)) _faceSlotRenderers.Add(slot.Renderer);
                    // 元のマテリアルでなく、生成した複製が入っていれば適用済み
                    Material[] mats = slot.Renderer.sharedMaterials;
                    if (slot.Index < mats.Length && mats[slot.Index] != null && mats[slot.Index] != slot.Original)
                        _hasAppliedSlots = true;
                }
            }
            _hasFaceSlots = _faceSlotRenderers.Count > 0;
        }

        /// <summary>顔テクスチャ 2 つを、FaceMap の組み合わせごとに覚える・入れる（§13.9）。</summary>
        private void SyncTextureMemory()
        {
            string key = MakeFixTextureMemory.Key(_state.MakeupFaceMapPath, _state.AvatarFaceMapPath);

            if (key != _memoryKey)
            {
                _memoryKey = key;
                if (key != null && MakeFixTextureMemory.TryLoad(key, out Texture2D a, out Texture2D m))
                {
                    // 対象側は記憶があれば復元し、メイク側はすでに手動設定されていれば勝手に上書きしない
                    if (a != null && _state.PreviewAvatarTexture == null) _state.PreviewAvatarTexture = a;
                    if (m != null && _state.PreviewMakeupTexture == null) _state.PreviewMakeupTexture = m;
                    if (_state.PreviewAvatarTexture != null && _state.PreviewMakeupTexture != null
                        && (a == null || m == null))
                    {
                        MakeFixTextureMemory.Save(key, _state.PreviewAvatarTexture, _state.PreviewMakeupTexture);
                    }
                }
                else if (key != null && _state.PreviewAvatarTexture != null && _state.PreviewMakeupTexture != null)
                {
                    MakeFixTextureMemory.Save(key, _state.PreviewAvatarTexture, _state.PreviewMakeupTexture);
                    MakeFixTextureMemory.SaveMakeupLink(_state.PreviewMakeupTexture, _state.MakeupFaceMapPath);
                }
                _memAvatarTex = _state.PreviewAvatarTexture;
                _memMakeupTex = _state.PreviewMakeupTexture;
                return;
            }

            if (key != null && (_state.PreviewAvatarTexture != _memAvatarTex || _state.PreviewMakeupTexture != _memMakeupTex))
            {
                MakeFixTextureMemory.Save(key, _state.PreviewAvatarTexture, _state.PreviewMakeupTexture);
                if (_state.PreviewMakeupTexture != null)
                    MakeFixTextureMemory.SaveMakeupLink(_state.PreviewMakeupTexture, _state.MakeupFaceMapPath);
                _memAvatarTex = _state.PreviewAvatarTexture;
                _memMakeupTex = _state.PreviewMakeupTexture;
            }
        }
    }
}
