using System.Collections.Generic;
using System.Text;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// データのフォルダを以前の場所から移したあとに出すダイアログの文面。
    /// 黙って移すと、ユーザーが Project ビューで前の場所を探して見つからず、消えたと思うため知らせる。
    /// </summary>
    public sealed class DataMigrationNotice
    {
        /// <summary>ダイアログに並べる残したファイルの数の上限（ほかは「ほか N 個」にまとめ、全部は Console に出す）。</summary>
        public const int MaxListed = 8;

        public string Title;
        public string Message;
        /// <summary>移さずに以前の場所に残したものがある。</summary>
        public bool HasLeftovers;

        /// <param name="moved">移したファイルの数。</param>
        /// <param name="conflicts">新しい場所に同じ名前があったので残したもの（相対パス）。</param>
        /// <param name="failed">移せなかったもの（相対パスと理由）。</param>
        /// <returns>何も移さず何も残さなかったときは null（ダイアログを出さない）。</returns>
        public static DataMigrationNotice Build(string from, string to, int moved, IList<string> conflicts, IList<string> failed)
        {
            int conflictCount = conflicts?.Count ?? 0;
            int failedCount = failed?.Count ?? 0;
            bool leftovers = conflictCount + failedCount > 0;
            if (moved <= 0 && !leftovers) return null;

            var sb = new StringBuilder();
            sb.Append("ATAA のデータ（FaceMap・調整・メイク適用で書き出したファイル・読み込んだメイク画像）の保存先が変わりました。\n\n");
            sb.Append("移動前: ").Append(from).Append('\n');
            sb.Append("移動後: ").Append(to).Append("\n\n");
            if (moved > 0)
            {
                sb.Append(moved).Append(" 個のファイルを移しました。参照はそのまま保たれるので、適用済みのアバターはこのまま使えます。\n");
            }
            sb.Append("ツールを入れ直すときも、").Append(to).Append(" は削除しないでください。");

            if (leftovers)
            {
                sb.Append("\n\n移動後の場所に同じ名前のファイルがある・移せなかったなどの理由で、次のファイルは ")
                  .Append(from).Append(" に残しました。中身を確かめて整理してください（一覧と理由は Console にも出しています）。\n");
                var all = new List<string>();
                if (conflicts != null) foreach (string c in conflicts) all.Add(c + "（同じ名前があるため残した）");
                if (failed != null) all.AddRange(failed);
                for (int i = 0; i < all.Count && i < MaxListed; i++) sb.Append("\n・").Append(all[i]);
                if (all.Count > MaxListed) sb.Append("\n・ほか ").Append(all.Count - MaxListed).Append(" 個");
            }

            return new DataMigrationNotice
            {
                Title = leftovers ? "ATAA: データのフォルダを移動しました（一部は残しています）" : "ATAA: データのフォルダを移動しました",
                Message = sb.ToString(),
                HasLeftovers = leftovers,
            };
        }
    }
}
