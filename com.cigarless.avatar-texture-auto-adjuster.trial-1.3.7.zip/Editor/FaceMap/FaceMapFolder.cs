// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapFolder.cs
using System.IO;
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>以前の場所のフォルダを、今の場所へどう移すか。</summary>
    public enum DataFolderMove
    {
        /// <summary>以前の場所が無い。</summary>
        None,
        /// <summary>今の場所を（無ければ作って）、今の場所に無いものだけを 1 つずつ移す。</summary>
        Merge,
    }

    /// <summary>以前のフォルダの中身を今の場所へ移す手順（パスは以前のフォルダからの相対、区切りは /）。</summary>
    public sealed class DataFolderMergePlan
    {
        /// <summary>今の場所に作るフォルダ（親が先）。</summary>
        public string[] Folders;
        /// <summary>移すファイル（.meta は MoveAsset が一緒に移すので含めない）。</summary>
        public string[] Moves;
        /// <summary>今の場所に同じ名前があるので、上書きせずに残すファイル。</summary>
        public string[] Conflicts;
    }

    /// <summary>
    /// ユーザーのデータのフォルダ（Assets/Cigarless/ATAA_Data）と、その中の FaceMaps フォルダの特定と自動生成。
    /// ユーザーのデータ（FaceMap・調整・生成したテクスチャとマテリアル・読み込んだメイク画像）は、ショップのフォルダの直下で、
    /// ツールのフォルダ（Assets/Cigarless/AvatarTextureAutoAdjuster）の外に置く。
    /// ツールを入れ直すとき（古いフォルダを消してから新しい版を入れる）に、一緒に消えないようにするため。
    /// 以前の場所（1.3.5 までの Assets/ATAA_Data、さらに前のツールのフォルダの中の FaceMaps）にあれば、
    /// MoveAsset で GUID を保ったまま移す（適用済みのアバターのマテリアル参照は切れない）。
    /// ツールの位置は、このスクリプト自身（…/Editor/FaceMap/FaceMapFolder.cs）か、配布版の DLL（…/Editor/AvatarTextureAutoAdjuster.Editor.dll）の位置から求める。
    /// </summary>
    public static class FaceMapFolder
    {
        public const string FolderName = "FaceMaps";
        /// <summary>ユーザーのデータを置くフォルダ（ショップのフォルダの直下）。</summary>
        public const string DataFolderName = "ATAA_Data";
        public const string DataRoot = PackageLocation.ShopRoot + "/" + DataFolderName;
        public const string FolderAssetPath = DataRoot + "/" + FolderName;

        /// <summary>
        /// assetPath のフォルダを作るのに要る (親, 名前) を、Assets に近い順に返す（あるものも含む。作る側で飛ばす）。
        /// Assets の外や Assets そのものなら空。
        /// </summary>
        public static (string Parent, string Name)[] FoldersToCreate(string assetPath)
        {
            var list = new System.Collections.Generic.List<(string, string)>();
            if (string.IsNullOrEmpty(assetPath)) return list.ToArray();
            string[] parts = assetPath.Replace('\\', '/').Trim('/').Split('/');
            if (parts.Length < 2 || parts[0] != "Assets") return list.ToArray();
            string parent = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                if (parts[i].Length == 0) continue;
                list.Add((parent, parts[i]));
                parent += "/" + parts[i];
            }
            return list.ToArray();
        }

        /// <summary>
        /// 以前の場所のフォルダを、今の場所へどう移すか。フォルダごとの移動（ディレクトリの名前の変更）はしない。
        /// 中のファイルを 1 つでもほかのプログラム（エクスプローラーなど）が開いていると Windows に拒否され、
        /// Unity が閉じられないダイアログ（再試行 / キャンセル / 強制終了）を出すため。今の場所が無くても作ってから 1 つずつ移す。
        /// </summary>
        public static DataFolderMove DecideMove(bool legacyExists, bool newExists) =>
            legacyExists ? DataFolderMove.Merge : DataFolderMove.None;

        /// <summary>
        /// 移行を試すか。このセッションで「移せずに残したもの」をもう知らせていれば試さない
        /// （開き直すたびに同じ警告・ダイアログを出さない。Unity を再起動するともう一度試す）。
        /// </summary>
        public static bool ShouldTryMigration(bool leftoversReportedThisSession) => !leftoversReportedThisSession;

        /// <summary>
        /// 残したものがあったことを、このセッションの間覚えるか。全部移せたときは覚えない
        /// （覚えると、同じセッションで以前の場所にまたデータが置かれたときに移さず、空の新しいフォルダを読んでデータが消えたように見えた）。
        /// </summary>
        public static bool ShouldRememberLeftovers(int conflicts, int failed) => conflicts + failed > 0;

        /// <summary>
        /// 以前のフォルダの中身（フォルダとファイルの相対パス）から、移す手順を作る。
        /// existsAtDestination は、今の場所に同じ相対パスのファイルがあるか。
        /// </summary>
        public static DataFolderMergePlan PlanMerge(
            System.Collections.Generic.IEnumerable<string> legacyFolders,
            System.Collections.Generic.IEnumerable<string> legacyFiles,
            System.Func<string, bool> existsAtDestination)
        {
            string Norm(string p) => (p ?? "").Replace('\\', '/').Trim('/');

            var folders = new System.Collections.Generic.List<string>();
            foreach (string f in legacyFolders ?? new string[0])
            {
                string n = Norm(f);
                if (n.Length > 0 && !folders.Contains(n)) folders.Add(n);
            }
            // 親が先（親のパスは子のパスの先頭と同じなので、文字の順に並べれば親が先に来る）
            folders.RemoveAll(IsIgnoredByUnity);
            folders.Sort(string.CompareOrdinal);

            var moves = new System.Collections.Generic.List<string>();
            var conflicts = new System.Collections.Generic.List<string>();
            foreach (string f in legacyFiles ?? new string[0])
            {
                string n = Norm(f);
                if (n.Length == 0 || n.EndsWith(".meta") || IsIgnoredByUnity(n)) continue;
                if (existsAtDestination != null && existsAtDestination(n)) conflicts.Add(n);
                else moves.Add(n);
            }
            return new DataFolderMergePlan { Folders = folders.ToArray(), Moves = moves.ToArray(), Conflicts = conflicts.ToArray() };
        }

        /// <summary>Unity がアセットとして扱わない名前（. で始まる・~ で終わる）を含むか。MoveAsset では移せないので数えない。</summary>
        private static bool IsIgnoredByUnity(string relativePath)
        {
            foreach (string part in relativePath.Split('/'))
            {
                if (part.StartsWith(".") || part.EndsWith("~")) return true;
            }
            return false;
        }

        /// <summary>
        /// assetPath のフォルダを（途中のフォルダも含めて）作る。あれば何もしない。メインスレッドから呼ぶこと。
        /// </summary>
        public static bool TryEnsureFolder(string assetPath, out string error)
        {
            error = null;
            foreach ((string parent, string name) in FoldersToCreate(assetPath))
            {
                string path = parent + "/" + name;
                if (AssetDatabase.IsValidFolder(path)) continue;
                if (File.Exists(ToAbsolute(path)))
                {
                    error = $"{path} と同名のファイルが存在するため、フォルダを作成できません。";
                    return false;
                }
                if (string.IsNullOrEmpty(AssetDatabase.CreateFolder(parent, name)))
                {
                    error = $"{path} を作成できませんでした（読み取り専用の場所の可能性があります）。";
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// データのフォルダを用意する（以前の場所 Assets/ATAA_Data にあれば移してから、無ければ作る）。製品版だけ。メインスレッドから呼ぶこと。
        /// </summary>
        public static bool TryEnsureDataRoot(out string error)
        {
            foreach (string legacy in PackageLocation.LegacyDataRoots)
            {
                if (legacy == DataRoot) continue;
                MoveLegacy(legacy, DataRoot, "データ");
            }
            return TryEnsureFolder(DataRoot, out error);
        }

        /// <summary>
        /// FaceMaps フォルダを確認し、なければ作成する（以前の場所にあれば移す）。メインスレッドから呼ぶこと。
        /// </summary>
        public static bool TryEnsure(out string assetPath, out string absolutePath, out string error)
        {
            assetPath = FolderAssetPath;
            absolutePath = ToAbsolute(assetPath);
            error = null;

            string[] candidates = PackageLocation.LegacyFaceMapFolders(TryGetRoot(out string root, out _) ? root : null);

            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                // 体験版はフォルダを作らず、移しもしない（無ければファイルの FaceMap が 0 個になるだけ。保存先はメモリ）
                if (!AssetDatabase.IsValidFolder(assetPath))
                {
                    string legacyToRead = FirstExisting(candidates, assetPath, skipLegacyDataRoots: false);
                    if (legacyToRead != null)
                    {
                        assetPath = legacyToRead;
                        absolutePath = ToAbsolute(legacyToRead);
                    }
                }
                return true;
            }

            // 先にデータのフォルダごと移す（Assets/ATAA_Data/FaceMaps もここで一緒に移る）
            if (!TryEnsureDataRoot(out error))
            {
                assetPath = absolutePath = null;
                return false;
            }

            // さらに前の版がツールのフォルダの中に置いていた FaceMaps
            string legacy = FirstExisting(candidates, assetPath, skipLegacyDataRoots: true);
            if (legacy != null) MoveLegacy(legacy, assetPath, "FaceMaps");

            if (!TryEnsureFolder(assetPath, out error))
            {
                assetPath = absolutePath = null;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 候補のうち、最初にある以前のフォルダ。skipLegacyDataRoots なら以前のデータのフォルダの中は飛ばす
        /// （そこはデータのフォルダごと移すので、同じ名前で移せずに残ったものを 2 回目に数えない）。
        /// </summary>
        private static string FirstExisting(string[] candidates, string current, bool skipLegacyDataRoots)
        {
            foreach (string candidate in candidates)
            {
                if (candidate == current) continue;
                if (skipLegacyDataRoots && IsUnderLegacyDataRoot(candidate)) continue;
                if (AssetDatabase.IsValidFolder(candidate)) return candidate;
            }
            return null;
        }

        private static bool IsUnderLegacyDataRoot(string path)
        {
            foreach (string legacy in PackageLocation.LegacyDataRoots)
            {
                if (path.StartsWith(legacy + "/")) return true;
            }
            return false;
        }

        private const string MigrationLeftoversKeyPrefix = "ATAA.DataMigrationLeftovers:";

        /// <summary>
        /// 以前のフォルダの中身を新しい場所へ 1 つずつ移す（新しい場所が無ければ作る）。
        /// 同じ名前があるものは上書きせずに残す。全部移せたら以前のフォルダ（残った空のフォルダ）を消す。
        /// 残したものがあったときは、そのセッションではもう試さない（開き直すたびに同じ警告・ダイアログを出さない。
        /// Unity を再起動するともう一度試す）。全部移せたときは覚えないので、以前の場所にまたデータが置かれたら同じセッションでも移す。
        /// </summary>
        private static void MoveLegacy(string from, string to, string label)
        {
            if (DecideMove(AssetDatabase.IsValidFolder(from), AssetDatabase.IsValidFolder(to)) == DataFolderMove.None) return;

            string key = MigrationLeftoversKeyPrefix + from + ">" + to;
            if (!ShouldTryMigration(SessionState.GetBool(key, false))) return;

            if (!TryEnsureFolder(to, out string ensureError))
            {
                SessionState.SetBool(key, true);
                Debug.LogWarning($"[ATAA] {label}のフォルダを {from} から {to} へ移せませんでした: {ensureError}");
                return;
            }

            string absFrom = ToAbsolute(from);
            var folders = new System.Collections.Generic.List<string>();
            var files = new System.Collections.Generic.List<string>();
            foreach (string d in Directory.GetDirectories(absFrom, "*", SearchOption.AllDirectories)) folders.Add(Relative(absFrom, d));
            foreach (string f in Directory.GetFiles(absFrom, "*", SearchOption.AllDirectories)) files.Add(Relative(absFrom, f));

            DataFolderMergePlan plan = PlanMerge(folders, files, rel => File.Exists(ToAbsolute(to + "/" + rel)));

            var failed = new System.Collections.Generic.List<string>();
            foreach (string rel in plan.Folders)
            {
                if (!TryEnsureFolder(to + "/" + rel, out string folderError)) failed.Add(rel + "（" + folderError + "）");
            }
            int moved = 0;
            foreach (string rel in plan.Moves)
            {
                string moveError = AssetDatabase.MoveAsset(from + "/" + rel, to + "/" + rel);
                if (string.IsNullOrEmpty(moveError)) moved++;
                else failed.Add(rel + "（" + moveError + "）");
            }

            if (ShouldRememberLeftovers(plan.Conflicts.Length, failed.Count)) SessionState.SetBool(key, true);
            ShowNoticeLater(DataMigrationNotice.Build(from, to, moved, plan.Conflicts, failed), to, from);

            if (plan.Conflicts.Length == 0 && failed.Count == 0)
            {
                AssetDatabase.DeleteAsset(from); // 残っているのは空のフォルダだけ
                Debug.Log($"[ATAA] {label}を {from} から {to} へ移しました（{moved} 個。ツールを入れ直しても消えないように、ショップのフォルダの直下で、ツールのフォルダの外に置きます）。");
                return;
            }

            var msg = new System.Text.StringBuilder();
            msg.Append($"[ATAA] {label}を {from} から {to} へ移しました（{moved} 個）が、移さずに残したものがあります。中身を確かめて整理してください（Unity を再起動すると、もう一度移します）。");
            foreach (string rel in plan.Conflicts) msg.AppendLine().Append("・同じ名前があるため残した: ").Append(rel);
            foreach (string rel in failed) msg.AppendLine().Append("・移せなかった: ").Append(rel);
            Debug.LogWarning(msg.ToString());
        }

        /// <summary>
        /// 移したことをダイアログで知らせる。呼び出し元はウィンドウの OnEnable などの途中なので、その処理が終わってから出す。
        /// 「場所を表示」で移動後のフォルダ（残したものがあれば移動前のフォルダ）を Project ビューで選ぶ。
        /// バッチモード（テスト・ビルド）では出さない。
        /// </summary>
        private static void ShowNoticeLater(DataMigrationNotice notice, string to, string from)
        {
            if (notice == null || Application.isBatchMode) return;
            EditorApplication.delayCall += () =>
            {
                bool reveal = EditorUtility.DisplayDialog(notice.Title, notice.Message, "場所を表示", "閉じる");
                if (!reveal) return;
                string target = notice.HasLeftovers && AssetDatabase.IsValidFolder(from) ? from : to;
                Object folder = AssetDatabase.LoadAssetAtPath<Object>(target);
                if (folder == null) return;
                EditorUtility.FocusProjectWindow();
                Selection.activeObject = folder;
                EditorGUIUtility.PingObject(folder);
            };
        }

        private static string Relative(string absRoot, string absPath)
        {
            string root = Path.GetFullPath(absRoot).TrimEnd('\\', '/');
            string path = Path.GetFullPath(absPath);
            return path.Substring(root.Length).TrimStart('\\', '/').Replace('\\', '/');
        }

        /// <summary>
        /// ATAA ルート（Editor フォルダの親）の Assets 相対パスを返す。
        /// </summary>
        public static bool TryGetRoot(out string rootAssetPath, out string error)
        {
            rootAssetPath = null;
            error = null;

            // 開発中はソース（…/Editor/FaceMap/FaceMapFolder.cs）、配布版は DLL（…/Editor/<AssemblyName>.dll）が目印
            string scriptPath = FindAnchor("FaceMapFolder t:MonoScript", "/FaceMapFolder.cs")
                ?? FindAnchor(AssemblyName, "/Editor/" + AssemblyName + ".dll");

            if (scriptPath == null)
            {
                error = "ツールの場所を特定できませんでした（" + AssemblyName + ".dll が見つかりません）。";
                return false;
            }

            // 目印から "Editor" フォルダまでさかのぼり、その親を ATAA ルートとする
            string dir = Normalize(Path.GetDirectoryName(scriptPath));
            while (!string.IsNullOrEmpty(dir) && Path.GetFileName(dir) != "Editor")
                dir = Normalize(Path.GetDirectoryName(dir));

            if (string.IsNullOrEmpty(dir))
            {
                error = "ツールのフォルダ構成が想定と異なります（Editor フォルダが見つかりません）: " + scriptPath;
                return false;
            }

            rootAssetPath = Normalize(Path.GetDirectoryName(dir));
            if (string.IsNullOrEmpty(rootAssetPath))
            {
                error = "ATAA フォルダを特定できませんでした: " + scriptPath;
                return false;
            }

            return true;
        }

        /// <summary>このツールのアセンブリ名（asmdef の name・配布する DLL のファイル名）。</summary>
        private const string AssemblyName = "AvatarTextureAutoAdjuster.Editor";

        private static string FindAnchor(string filter, string pathSuffix)
        {
            foreach (string guid in AssetDatabase.FindAssets(filter))
            {
                string p = AssetDatabase.GUIDToAssetPath(guid);
                if (p.EndsWith(pathSuffix)) return p;
            }
            return null;
        }

        public static string ToAbsolute(string assetPath)
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath);
            return Path.GetFullPath(Path.Combine(projectRoot, assetPath));
        }

        private static string Normalize(string path)
        {
            return path?.Replace('\\', '/');
        }
    }
}
