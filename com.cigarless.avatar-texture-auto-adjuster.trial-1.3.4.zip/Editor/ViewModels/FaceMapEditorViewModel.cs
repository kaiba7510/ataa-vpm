// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/ViewModels/FaceMapEditorViewModel.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディターの UI 状態とインタラクションロジックを一元管理する ViewModel。
    /// Unity GUI 描画・イベント処理とは分離し、状態変更のロジックのみを担う。
    /// </summary>
    public class FaceMapEditorViewModel
    {
        // ── State / Service ──
        public FaceMapEditorState State { get; }
        public FaceMapEditorService Service { get; }

        /// <summary>元に戻す・やり直し（§12.5）。データを変える操作はすべてこれを通す。</summary>
        public FaceMapEditorHistory History { get; }

        public FaceMapEditorViewModel()
        {
            State = new FaceMapEditorState();
            Service = new FaceMapEditorService(State);
            History = new FaceMapEditorHistory(State);
        }

        /// <summary>
        /// Undo.undoRedoPerformed から呼ぶ。FaceMap が戻されたら true（再描画が必要）。
        /// 選択は同じ領域が残っていれば保ち、ドラッグ中なら中止する。
        /// </summary>
        public bool OnUndoRedo()
        {
            string selectedLabel = SelectedPoint >= 0 && SelectedPoint < State.Points.Count
                ? State.Points[SelectedPoint].Label
                : null;

            if (!History.OnUndoRedo()) return false;

            Dragging = DragMode.None;
            DraggingPointIndex = -1;
            SelectedPoint = selectedLabel != null ? Service.IndexOf(selectedLabel) : -1;
            return true;
        }

        /// <summary>action を 1 回の操作として履歴に残す（何も変わらなければ残らない）。</summary>
        private void Edit(string name, Action action, string mergeKey = null)
        {
            History.Record(name, mergeKey);
            action();
            History.Commit();
        }

        // ── 選択 ──
        public int SelectedPoint { get; private set; } = -1;

        // Layout イベント時点の選択状態のスナップショット。
        // 同じ OnGUI パス内で選択が変わっても、右パネルの構造が Layout/Repaint 間でズレないようにする。
        public int PanelSelected { get; set; } = -1;

        // ── ホバー ──
        public bool IsHovering { get; set; }
        public Vector2 HoverUV { get; set; }

        // ── ドラッグ ──
        public enum DragMode
        {
            None,
            Move,
            Resize,

            /// <summary>中心線のつまみ。</summary>
            Center,

            /// <summary>目の線のつまみ（v0.4 §4.2）。</summary>
            EyeLine,

            /// <summary>口の線のつまみ。</summary>
            MouthLine,

            /// <summary>目の下の線のつまみ。</summary>
            EyeLowerLine,

            /// <summary>目の輪郭の点のつまみ（目の輪郭リング写像の仕様 §5.1）。</summary>
            EyeContour
        }

        public DragMode Dragging { get; private set; } = DragMode.None;
        public int DraggingPointIndex { get; private set; } = -1;
        public bool IsDraggingControlPoint => Dragging != DragMode.None;

        // 相対ミラーのドラッグは、開始時の位置を基準に「開始位置 + 移動量」で計算する（§12.4）
        private Vector2 _dragStartPoint;

        // 1 回のドラッグを 1 回の Undo にまとめるためのキー（§12.5）
        private int _dragCounter;
        private string _dragKey;
        private Vector2? _dragStartPartner;

        // ── ポインタのサイズ（FaceMap 仕様 v0.4 §12.3）──
        public const string PointerScaleKey = "ATAA.FaceMapEditor.PointerScale";

        private float _pointerScale = -1f;

        /// <summary>テクスチャ上のマーカー・ハンドルと、その当たり判定に掛ける倍率。EditorPrefs に保存する。</summary>
        public float PointerScale
        {
            get
            {
                if (_pointerScale < 0f)
                    _pointerScale = ClampPointerScale(EditorPrefs.GetFloat(PointerScaleKey, FaceMapTextureRenderer.MaxPointerScale));
                return _pointerScale;
            }
            set
            {
                float v = ClampPointerScale(value);
                if (Mathf.Approximately(v, PointerScale)) return;
                _pointerScale = v;
                EditorPrefs.SetFloat(PointerScaleKey, v);
            }
        }

        private static float ClampPointerScale(float v) =>
            Mathf.Clamp(v, FaceMapTextureRenderer.MinPointerScale, FaceMapTextureRenderer.MaxPointerScale);

        // ── ミラー配置（FaceMap 仕様 v0.4 §12.4）──
        public const string MirrorKey = "ATAA.FaceMapEditor.Mirror";
        public const string MirrorOverlayKey = "ATAA.FaceMapEditor.MirrorOverlay";
        public const string MirrorOverlayAlphaKey = "ATAA.FaceMapEditor.MirrorOverlayAlpha";

        public const float MinOverlayAlpha = 0.1f;
        public const float MaxOverlayAlpha = 0.9f;
        public const float DefaultOverlayAlpha = 0.5f;

        /// <summary>ミラー配置の ON/OFF（既定 ON）。切り替えても点は動かさない。</summary>
        public bool MirrorEnabled
        {
            get => EditorPrefs.GetBool(MirrorKey, true);
            set => EditorPrefs.SetBool(MirrorKey, value);
        }

        /// <summary>反転オーバーレイの ON/OFF（既定 OFF）。表示のみ。</summary>
        public bool OverlayEnabled
        {
            get => EditorPrefs.GetBool(MirrorOverlayKey, false);
            set => EditorPrefs.SetBool(MirrorOverlayKey, value);
        }

        public float OverlayAlpha
        {
            get => Mathf.Clamp(EditorPrefs.GetFloat(MirrorOverlayAlphaKey, DefaultOverlayAlpha), MinOverlayAlpha, MaxOverlayAlpha);
            set => EditorPrefs.SetFloat(MirrorOverlayAlphaKey, Mathf.Clamp(value, MinOverlayAlpha, MaxOverlayAlpha));
        }

        /// <summary>ミラーが効く状態（ON かつ中心線が確定済み）。</summary>
        public bool MirrorActive => MirrorEnabled && State.CenterX.HasValue;

        /// <summary>反転オーバーレイを描く状態（ミラーが効いていて、テクスチャがある）。</summary>
        public bool OverlayVisible => OverlayEnabled && MirrorActive && State.Texture != null;

        /// <summary>中心線を c にする（点は動かさない）。</summary>
        public void SetCenter(float c) => Edit("中心線の移動", () => Service.SetCenterX(c), "center");

        /// <summary>中心線を鼻の x に合わせる。鼻がなければ何もしない。</summary>
        public void SnapCenterToNose()
        {
            int i = Service.IndexOf(FaceTemplate.NoseLabel);
            if (i >= 0) Edit("中心線を鼻に合わせる", () => Service.SetCenterX(State.Points[i].X));
        }

        /// <summary>「ミラーで揃える」。</summary>
        public void AlignMirror()
        {
            if (!MirrorActive) return;
            Edit("ミラーで揃える", () => Service.AlignMirror());
        }

        // ── 配置の誘導 ──

        /// <summary>
        /// ユーザーが「この領域を置く」と明示的に選んだ label（任意領域の追加や、置き直し用）。
        /// null なら、まだ置いていない必須領域を順に案内する。
        /// </summary>
        public string ArmedLabel { get; private set; }

        /// <summary>次にテクスチャをクリックしたときに置く領域。すべて置き終わっていれば null。</summary>
        public FaceTemplateEntry TargetEntry
        {
            get
            {
                if (!string.IsNullOrEmpty(ArmedLabel)) return FaceTemplate.Find(ArmedLabel);
                string next = NextWizardLabel();
                if (next != null) return FaceTemplate.Find(next);
                return FaceTemplate.NextRequired(Service.PlacedLabels());
            }
        }

        // ── 新規作成ウィザード（Issue #16 §3）──
        // 鼻（左右対称の軸）→ 左目（右目はミラーで自動。左右対称 OFF なら次に右目）→ 口 の順に案内し、口まで置くと頬は目と口の位置から仮配置する。
        // その後に足りない必須領域があれば、テンプレートの順に案内する。

        public const string LeftEyeLabel = "目_左";
        public const string RightEyeLabel = "目_右";
        public const string MouthLabel = "口_中央";
        public const string LeftCheekLabel = "頬_左";
        public const string RightCheekLabel = "頬_右";

        /// <summary>ウィザードで次に置く領域（左右対称 ON: 鼻 → 左目 → 口 / OFF: 鼻 → 左目 → 右目 → 口）。済んでいれば null。</summary>
        private string NextWizardLabel() => FaceMapWizard.NextLabel(Service.IsPlaced, MirrorEnabled);

        /// <summary>ウィザードの段階（1 始まり。0: 完了または明示の指定中）。</summary>
        public int WizardStep =>
            string.IsNullOrEmpty(ArmedLabel) ? FaceMapWizard.StepOf(NextWizardLabel(), MirrorEnabled) : 0;

        /// <summary>ステータスバーに出す案内（次に何をすればよいか）。</summary>
        public string GuideMessage()
        {
            if (State.Texture == null)
                return "まずメイクテクスチャを左のビューにドラッグ＆ドロップしてください（上部の［読込］で既存の FaceMap も開けます）。";

            FaceTemplateEntry target = TargetEntry;
            if (target == null)
            {
                return Service.IsComplete()
                    ? "基本パーツの配置が完了しました！ 上部の『保存』を押して ToolWindow へ進んでください。"
                    : "顔パレットからパーツを選び、テクスチャ上をクリックして置いてください。";
            }

            string step = WizardStep > 0 ? $"ステップ {WizardStep}/{FaceMapWizard.TotalSteps(MirrorEnabled)}: " : "";
            switch (target.Label)
            {
                case FaceTemplate.NoseLabel:
                    return step + "メイクの【鼻】のあたりをクリックしてください（ここが左右対称の軸になります）。";
                case LeftEyeLabel:
                    return step + (MirrorEnabled
                        ? "メイクの【左目】（画像の左側の目）をクリックしてください。右目も対称の位置に置かれます。"
                        : "メイクの【左目】（画像の左側の目）をクリックしてください。");
                case RightEyeLabel:
                    return step + "メイクの【右目】（画像の右側の目）をクリックしてください。";
                case MouthLabel:
                    return step + "メイクの【口】をクリックしてください。これで基本パーツの配置が完了します。";
                default:
                    return $"メイクの【{target.Label}】（{FaceTemplateText.Describe(target.Label)}）をクリックしてください。";
            }
        }

        /// <summary>
        /// 目・口が揃っていて頬が両方とも無ければ、目と口の位置から頬を仮配置する（自動作成と同じ考え方の比率）。置いたら true。
        /// 呼び出し側の履歴の記録の中で呼ぶ（置く操作と 1 回で元に戻せる）。
        /// </summary>
        private bool AutoPlaceCheeks()
        {
            if (Service.IsPlaced(LeftCheekLabel) || Service.IsPlaced(RightCheekLabel)) return false;
            int l = Service.IndexOf(LeftEyeLabel), r = Service.IndexOf(RightEyeLabel), m = Service.IndexOf(MouthLabel);
            if (l < 0 || r < 0 || m < 0) return false;

            Vector2 left = State.Points[l].Uv, right = State.Points[r].Uv, mouth = State.Points[m].Uv;
            float eyeDist = Mathf.Abs(right.x - left.x);
            if (eyeDist < 0.01f) return false;
            float c = State.CenterX ?? (left.x + right.x) * 0.5f;
            float eyeY = (left.y + right.y) * 0.5f;
            float d = eyeY - mouth.y;
            if (d < 0.01f) d = 0.9f * eyeDist;

            float y = eyeY - 0.45f * d;
            float half = 0.55f * eyeDist;
            Service.Place(FaceTemplate.Find(LeftCheekLabel), new Vector2(c - half, y));
            Service.Place(FaceTemplate.Find(RightCheekLabel), new Vector2(c + half, y));
            return true;
        }

        // ── パーツの状態（顔イラストパレット）──

        public enum PartState
        {
            Unplaced,
            Placed,
            Selected
        }

        public PartState GetPartState(string label)
        {
            int i = Service.IndexOf(label);
            if (i < 0) return PartState.Unplaced;
            return i == SelectedPoint ? PartState.Selected : PartState.Placed;
        }

        /// <summary>顔パレットでパーツをクリックした。置いてあれば選択（微調整モード）、無ければ次のクリックで置く対象にする。</summary>
        public void PickPart(string label)
        {
            int i = Service.IndexOf(label);
            if (i >= 0)
            {
                SelectedPoint = i;
                ArmedLabel = null;
            }
            else
            {
                ArmedLabel = label;
                SelectedPoint = -1;
            }
        }

        /// <summary>
        /// uv を内側に含む領域。選択中の領域を優先し、それ以外は面積の小さいもの（重なりで小さい枠もつかめるように）。無ければ -1。
        /// </summary>
        public int FindRegionAt(Vector2 uv)
        {
            int best = -1;
            float bestArea = float.MaxValue;
            for (int i = 0; i < State.Points.Count; i++)
            {
                FaceMapPoint p = State.Points[i];
                string category = FaceTemplate.CategoryOf(p.Label);
                if (category == null) continue;
                Vector2 size = Service.GetSize(category);
                if (!FaceMapFile.RegionRect(p.Uv, size).Contains(uv)) continue;
                if (i == SelectedPoint) return i;
                float area = size.x * size.y;
                if (area < bestArea)
                {
                    bestArea = area;
                    best = i;
                }
            }
            return best;
        }

        /// <summary>
        /// テンプレートの標準位置（ガイドの位置）に必須の領域を仮配置する（アバターが無いときの［自動生成］）。
        /// 置いてある領域は置き換える。1 回で元に戻せる。
        /// </summary>
        public void PlaceTemplateDefaults()
        {
            Edit("仮配置", () =>
            {
                Service.ResetControlPoints();
                foreach (FaceTemplateEntry entry in FaceTemplate.Entries)
                {
                    if (entry.Required) Service.Place(entry, entry.GuidePosition);
                }
                Service.SetCenterX(0.5f);
            });
            SelectedPoint = -1;
            ArmedLabel = null;
            State.Warning = "テンプレートの標準位置に仮配置しました（未保存）。メイクに合わせて枠を動かしてください。";
            State.WarningType = MessageType.Info;
        }

        /// <summary>この領域を次に置く対象にする（置いてあれば置き直し＝移動になる）。同じものをもう一度押すと解除。</summary>
        public void Arm(string label)
        {
            ArmedLabel = string.Equals(ArmedLabel, label, StringComparison.Ordinal) ? null : label;
        }

        public void Disarm() => ArmedLabel = null;

        // ── 点の操作 ──

        /// <summary>
        /// uv の位置から、スクリーン上で当たり判定の半径以内にある最も近い点を返す。該当なければ -1。
        /// texRect はテクスチャを表示しているスクリーン上の矩形。
        /// </summary>
        public int FindNearPoint(Vector2 uv, Rect texRect)
        {
            Vector2 mouse = UVCoordinateConverter.UvToScreen(uv, texRect);
            int best = -1;
            float bestDist = FaceMapTextureRenderer.ScaledPointHitRadius(PointerScale);
            for (int i = 0; i < State.Points.Count; i++)
            {
                float d = Vector2.Distance(mouse, UVCoordinateConverter.UvToScreen(State.Points[i].Uv, texRect));
                if (d < bestDist)
                {
                    bestDist = d;
                    best = i;
                }
            }
            return best;
        }

        /// <summary>
        /// 案内中の領域を uv に置いて選択する。置く対象がなければ false。
        /// ミラーが効いていれば、左右ペアはクリックした側で左右を決めて相方を鏡像に置き、中央パーツは x = c に置く。
        /// singleSide（Alt）なら相方は置かない・動かさない。
        /// </summary>
        public bool TryPlaceTarget(Vector2 uv, bool singleSide = false)
        {
            FaceTemplateEntry target = TargetEntry;
            if (target == null) return false;

            bool isNose = string.Equals(target.Label, FaceTemplate.NoseLabel, StringComparison.Ordinal);
            bool pair = FaceMapMirror.IsPair(target.Label);

            History.Record(Service.IsPlaced(target.Label) ? "置き直し" : "置く");

            if (!State.CenterX.HasValue && isNose)
            {
                // 中心線が未確定なら、鼻のクリック位置で中心線を決める（ミラー OFF でも同じ）
                SelectedPoint = Service.Place(target, uv);
                Service.SetCenterX(State.Points[SelectedPoint].X);
            }
            else if (MirrorActive && pair)
            {
                int placed = Service.PlacePair(target.Category, uv, !singleSide);
                SelectedPoint = placed >= 0 ? placed : Service.Place(target, uv);
            }
            else if (MirrorActive && FaceMapMirror.IsCenterPart(target.Label))
            {
                SelectedPoint = Service.Place(target, new Vector2(State.CenterX.Value, uv.y));
            }
            else
            {
                SelectedPoint = Service.Place(target, uv);
                if (MirrorEnabled && pair && !State.CenterX.HasValue)
                    Info("中心線が未確定のため相方は置いていません。先に鼻を置くか「中心 u」を入力してください。");
            }

            // ウィザード（明示の指定でない配置）で目・口が揃ったら、頬を仮配置する（置く操作と同じ 1 回で元に戻せる）
            bool wasArmed = !string.IsNullOrEmpty(ArmedLabel);
            bool cheeks = !wasArmed && AutoPlaceCheeks();

            History.Commit();
            ArmedLabel = null;
            if (cheeks) Info("頬は目と口の位置から自動で仮配置しました。ずれていればドラッグで直してください。");
            return true;
        }

        public void SelectPoint(int index) => SelectedPoint = index;

        public void ClearSelection() => SelectedPoint = -1;

        /// <summary>
        /// 選択 + 位置のドラッグ開始。singleSide（Alt を押して開始）なら、そのドラッグ中は相方を動かさない。
        /// </summary>
        public void StartDrag(int index, bool singleSide = false)
        {
            StartDrag(index, State.Points[index].Uv, singleSide);
        }

        /// <summary>
        /// 枠の内側をつかんでのドラッグ開始（Issue #16 Step 4）。grabUv はつかんだ位置。中心がマウスへ飛ばないよう、ずれを保つ。
        /// </summary>
        public void StartDrag(int index, Vector2 grabUv, bool singleSide)
        {
            _grabOffset = State.Points[index].Uv - grabUv;
            ArmedLabel = null;
            SelectedPoint = index;
            DraggingPointIndex = index;
            Dragging = DragMode.Move;
            _dragKey = "drag" + (++_dragCounter);

            _dragStartPoint = State.Points[index].Uv;
            _dragStartPartner = singleSide ? null : PartnerPosition(index);
        }

        /// <summary>中心線のつまみのドラッグ開始。</summary>
        public void StartCenterDrag()
        {
            DraggingPointIndex = -1;
            Dragging = DragMode.Center;
            _dragKey = "drag" + (++_dragCounter);
        }

        /// <summary>目の線のつまみのドラッグ開始。index は線を動かす基準にする目の領域。</summary>
        public void StartEyeLineDrag(int index)
        {
            SelectedPoint = index;
            DraggingPointIndex = index;
            Dragging = DragMode.EyeLine;
            _dragKey = "drag" + (++_dragCounter);
        }

        /// <summary>目の線を使う・使わない、または高さを変える（v0.4 §4.2）。</summary>
        public void SetEyeLine(float? line) => Edit("目の線", () => Service.SetEyeLine(line), "eyeline");

        /// <summary>目の下の線を使う・使わない、または高さを変える。</summary>
        public void SetEyeLowerLine(float? line) => Edit("目の下の線", () => Service.SetEyeLowerLine(line), "eyelowerline");

        /// <summary>口の線を使う・使わない、または高さを変える。</summary>
        public void SetMouthLine(float? line) => Edit("口の線", () => Service.SetMouthLine(line), "mouthline");

        /// <summary>口の線を新しく置くときの高さ（口の領域の真ん中）。</summary>
        public const float DefaultMouthLine = 0.5f;

        /// <summary>口の線のつまみのドラッグ開始。</summary>
        public void StartMouthLineDrag(int index)
        {
            SelectedPoint = index;
            DraggingPointIndex = index;
            Dragging = DragMode.MouthLine;
            _dragKey = "drag" + (++_dragCounter);
        }

        /// <summary>目の開いていない素体か（FaceMapFile.NoEyeOpening）を切り替える。</summary>
        public void SetNoEyeOpening(bool value) => Edit("目の開いていない素体", () => Service.SetNoEyeOpening(value), "noeyeopening");

        /// <summary>目の下の線のつまみのドラッグ開始。</summary>
        public void StartEyeLowerLineDrag(int index)
        {
            SelectedPoint = index;
            DraggingPointIndex = index;
            Dragging = DragMode.EyeLowerLine;
            _dragKey = "drag" + (++_dragCounter);
        }

        /// <summary>
        /// 目の輪郭の点のつまみのドラッグ開始。index は基準にする目の領域、onUpper・pointIndex は動かす点
        /// （EyeContourEditing.Handles）。輪郭は左右の目で共通なので、もう片方の目の輪郭も鏡写しで動く。
        /// </summary>
        public void StartEyeContourDrag(int index, bool onUpper, int pointIndex)
        {
            SelectedPoint = index;
            DraggingPointIndex = index;
            Dragging = DragMode.EyeContour;
            _contourOnUpper = onUpper;
            _contourPointIndex = pointIndex;
            _dragKey = "drag" + (++_dragCounter);
        }

        private bool _contourOnUpper;
        private int _contourPointIndex;

        /// <summary>目の輪郭を使う（目の線・目の下の線から初期の形を作る）・使わない（消す）。</summary>
        public void SetEyeContourEnabled(bool on) => Edit("目の輪郭", () =>
        {
            if (!on)
            {
                Service.SetEyeContour(null, null);
                return;
            }
            if (State.EyeContourUpper != null) return;
            EyeContourEditing.CreateDefault(State.EyeLine, State.EyeLowerLine, out Vector2[] upper, out Vector2[] lower);
            Service.SetEyeContour(upper, lower);
        }, "eyecontour");

        /// <summary>目の下の線を新しく置くときの、目の線からの下がり（目の領域の高さに対する割合）。</summary>
        public const float DefaultEyeLowerGap = 0.3f;

        /// <summary>目の線を新しく置くときの高さ（目の領域の下端からの割合）。</summary>
        public const float DefaultEyeLine = 0.6f;

        /// <summary>
        /// 選択 + 領域サイズのドラッグ開始。sign はつかんだハンドルの向き（UV で右・上が +1。
        /// FaceMapTextureRenderer.HitResizeHandle の戻り値）。
        /// 四隅 (±1, ±1) は反対の角を固定し、つかんだ角に接する 2 辺だけを動かす（中心も動く）。
        /// 辺の中点のつまみ（片方が 0）は反対の辺を固定し、つかんだ辺だけを動かす。0 の軸は変えない。
        /// centerFixed（Shift を押して開始）なら、中心を固定して両側を動かす。
        /// singleSide（Alt を押して開始）なら、左右ペアの相方の中心は動かさない。
        /// </summary>
        public void StartResize(int index, Vector2 sign, bool centerFixed = false, bool singleSide = false)
        {
            SelectedPoint = index;
            DraggingPointIndex = index;
            Dragging = DragMode.Resize;
            _dragKey = "drag" + (++_dragCounter);

            FaceMapPoint p = State.Points[index];
            string category = FaceTemplate.CategoryOf(p.Label);
            Vector2 size = category != null ? Service.GetSize(category) : Vector2.zero;
            _resizeCenterFixed = centerFixed;
            _resizeSign = sign;
            _resizeStartSize = size;
            _resizeAnchor = FaceMapResizeMath.Anchor(p.Uv, size, sign);
            _dragStartPoint = p.Uv;
            _dragStartPartner = singleSide ? null : PartnerPosition(index);

            // 目の線・目の下の線は、辺を動かしても画面上の高さが変わらないように覚えておく（割合で持っているため）
            bool eye = category == FaceMapFile.EyeCategory;
            float bottom = p.Y - size.y * 0.5f;
            _resizeEyeLineY = eye && State.EyeLine.HasValue ? bottom + size.y * State.EyeLine.Value : (float?)null;
            _resizeEyeLowerY = eye && State.EyeLowerLine.HasValue ? bottom + size.y * State.EyeLowerLine.Value : (float?)null;
        }

        // 範囲のドラッグ: つかんだ角の向き（UV で右・上が +1）、固定する反対の角、中心固定か、目の線の開始時の高さ（UV）
        private Vector2 _resizeSign;
        private Vector2 _resizeAnchor;
        private Vector2 _resizeStartSize;
        private bool _resizeCenterFixed;
        private float? _resizeEyeLineY;
        private float? _resizeEyeLowerY;

        /// <summary>
        /// ドラッグ中の点を新しい UV に移動、またはサイズを変更する。
        /// サイズは中心からの距離の 2 倍（中心を動かさない）。
        /// </summary>
        public void DragTo(Vector2 uv)
        {
            if (Dragging == DragMode.None) return;
            if (Dragging != DragMode.Center && (DraggingPointIndex < 0 || DraggingPointIndex >= State.Points.Count)) return;

            string name = Dragging == DragMode.Center ? "中心線の移動"
                : Dragging == DragMode.Resize ? "範囲の変更"
                : Dragging == DragMode.EyeLine ? "目の線"
                : Dragging == DragMode.EyeLowerLine ? "目の下の線"
                : Dragging == DragMode.MouthLine ? "口の線"
                : Dragging == DragMode.EyeContour ? "目の輪郭"
                : "移動";
            History.Record(name, _dragKey, mergeAlways: true);
            DragToCore(uv);
            History.Commit();
        }

        private void DragToCore(Vector2 uv)
        {
            if (Dragging == DragMode.Center)
            {
                Service.SetCenterX(uv.x);
                return;
            }

            if (Dragging == DragMode.MouthLine)
            {
                FaceMapPoint mouth = State.Points[DraggingPointIndex];
                Vector2 size = Service.GetSize(FaceMapFile.MouthCategory);
                if (size.y <= 0f) return;
                Service.SetMouthLine((uv.y - (mouth.Y - size.y * 0.5f)) / size.y);
                return;
            }

            if (Dragging == DragMode.EyeContour)
            {
                FaceMapPoint eye = State.Points[DraggingPointIndex];
                Vector2 size = Service.GetSize(FaceMapFile.EyeCategory);
                if (State.EyeContourUpper == null || State.EyeContourLower == null || size.x <= 0f || size.y <= 0f) return;
                Vector2 local = EyeContourEditing.UvToLocal(uv, eye.Uv, size, EyeContourEditing.InnerAtMax(eye.Label));
                // 輪郭として成り立たない位置へは動かさない（直前の正しい形で止まる）
                if (EyeContourEditing.TryMovePoint(State.EyeContourUpper, State.EyeContourLower, _contourOnUpper, _contourPointIndex,
                                                   local, out Vector2[] upper, out Vector2[] lower))
                    Service.SetEyeContour(upper, lower);
                return;
            }

            if (Dragging == DragMode.EyeLine || Dragging == DragMode.EyeLowerLine)
            {
                FaceMapPoint eye = State.Points[DraggingPointIndex];
                Vector2 size = Service.GetSize(FaceMapFile.EyeCategory);
                if (size.y <= 0f) return;
                float ratio = (uv.y - (eye.Y - size.y * 0.5f)) / size.y;
                if (Dragging == DragMode.EyeLine) Service.SetEyeLine(ratio);
                else Service.SetEyeLowerLine(ratio);
                return;
            }

            if (Dragging == DragMode.Move)
            {
                uv += _grabOffset;
                if (UsesRelativeMirror(DraggingPointIndex))
                    Service.MoveRelative(DraggingPointIndex, _dragStartPoint, _dragStartPartner, uv - _dragStartPoint);
                else
                    Service.SetPosition(DraggingPointIndex, uv);
            }
            else if (Dragging == DragMode.Resize)
            {
                FaceMapPoint p = State.Points[DraggingPointIndex];
                string category = FaceTemplate.CategoryOf(p.Label);
                if (category == null) return;

                if (_resizeCenterFixed)
                {
                    // 中心を固定して動かす（サイズは中心からの距離の 2 倍）。辺のつまみなら、その軸だけ
                    Service.SetSize(category, FaceMapResizeMath.CenterFixedSize(p.Uv, _resizeSign, uv, _resizeStartSize));
                    return;
                }

                // 反対の角（辺のつまみなら反対の辺）を固定し、つかんだ側だけを動かす。反対側へ回り込んだら最小サイズで止める
                Service.SetSize(category, FaceMapResizeMath.DesiredSize(_resizeAnchor, _resizeSign, uv, _resizeStartSize));
                Vector2 size = Service.GetSize(category);
                Vector2 center = FaceMapResizeMath.CenterFor(_resizeAnchor, _resizeSign, size);

                // 左右ペアはミラーが効いていれば、相方は左右反転して同じ辺が動く（相対ミラー）
                if (UsesRelativeMirror(DraggingPointIndex))
                    Service.MoveRelative(DraggingPointIndex, _dragStartPoint, _dragStartPartner, center - _dragStartPoint);
                else
                    Service.SetPosition(DraggingPointIndex, center);

                if (category == FaceMapFile.EyeCategory && size.y > 0f)
                {
                    float bottom = State.Points[DraggingPointIndex].Y - size.y * 0.5f;
                    float? line = _resizeEyeLineY.HasValue ? (_resizeEyeLineY.Value - bottom) / size.y : (float?)null;
                    float? lower = _resizeEyeLowerY.HasValue ? (_resizeEyeLowerY.Value - bottom) / size.y : (float?)null;
                    // 2 本の間隔の制約で止まらないよう、下げるときは下の線から、上げるときは上の線から動かす
                    bool lowerFirst = lower.HasValue && State.EyeLowerLine.HasValue && lower.Value < State.EyeLowerLine.Value;
                    if (lowerFirst) Service.SetEyeLowerLine(lower);
                    if (line.HasValue) Service.SetEyeLine(line);
                    if (lower.HasValue && !lowerFirst) Service.SetEyeLowerLine(lower);
                }
            }
        }

        private Vector2 _grabOffset;

        public void EndDrag()
        {
            _grabOffset = Vector2.zero;
            Dragging = DragMode.None;
            DraggingPointIndex = -1;
        }

        /// <summary>
        /// 選択中の領域を削除。
        /// </summary>
        public void RemoveSelected()
        {
            if (SelectedPoint < 0 || SelectedPoint >= State.Points.Count) return;
            Remove(State.Points[SelectedPoint].Label);
        }

        /// <summary>
        /// 指定した領域を削除。ミラーが効いていれば、左右ペアは相方も一緒に削除する。
        /// </summary>
        public void Remove(string label)
        {
            Edit("削除", () =>
            {
                RemoveOne(label);
                if (MirrorActive) RemoveOne(FaceMapMirror.PartnerLabel(label));
            });
        }

        private void RemoveOne(string label)
        {
            int index = Service.IndexOf(label);
            if (index < 0) return;

            Service.RemoveControlPoint(index);
            if (SelectedPoint == index) SelectedPoint = -1;
            else if (SelectedPoint > index) SelectedPoint--;
        }

        /// <summary>
        /// 全領域を削除。
        /// </summary>
        public void RemoveAll()
        {
            Edit("すべて削除", () => Service.ResetControlPoints());
            SelectedPoint = -1;
            ArmedLabel = null;
        }

        /// <summary>数値入力。ミラーが効いていれば、入力前との差を相方に逆向きで掛ける（相対ミラー）。</summary>
        public void SetPosition(int index, Vector2 uv)
        {
            if (index < 0 || index >= State.Points.Count) return;

            Edit("中心の入力", () =>
            {
                if (UsesRelativeMirror(index))
                    NudgeCore(index, uv - State.Points[index].Uv, false);
                else
                    Service.SetPosition(index, uv);
            }, "pos:" + State.Points[index].Label);
        }

        /// <summary>
        /// 領域の中心を delta（UV）だけ動かす。範囲は変えない。0〜1 に収める。
        /// ミラーが効いていれば相対ミラーで相方も動かす。singleSide（Alt）なら相方は動かさない。
        /// </summary>
        public void Nudge(int index, Vector2 delta, bool singleSide = false)
        {
            if (index < 0 || index >= State.Points.Count) return;
            Edit("中心を移動", () => NudgeCore(index, delta, singleSide), "nudge:" + State.Points[index].Label);
        }

        private void NudgeCore(int index, Vector2 delta, bool singleSide)
        {

            if (UsesRelativeMirror(index))
            {
                Vector2? partner = singleSide ? null : PartnerPosition(index);
                Service.MoveRelative(index, State.Points[index].Uv, partner, delta);
            }
            else
            {
                Service.SetPosition(index, State.Points[index].Uv + delta);
            }
        }

        /// <summary>範囲（幅・高さ）の数値入力。分類で共通。</summary>
        public void SetSize(string category, Vector2 size) =>
            Edit("範囲の入力", () => Service.SetSize(category, size), "size:" + category);

        /// <summary>左右の間隔を amount だけ変える（+ で広げる）。</summary>
        public void ChangePairGap(string category, float amount) =>
            Edit("左右の間隔", () => Service.ChangePairGap(category, amount), "gap:" + category);

        /// <summary>中央パーツの x を中心線に合わせる。</summary>
        public void SnapToCenter(int index) => Edit("中心線に合わせる", () => Service.SnapToCenter(index));

        /// <summary>この点の移動に相対ミラー（と中心線を越えない制約）を使うか。左右ペアかつミラーが効いているとき。</summary>
        private bool UsesRelativeMirror(int index) =>
            MirrorActive && FaceMapMirror.IsPair(State.Points[index].Label);

        /// <summary>相方の現在位置。相方がいなければ null。</summary>
        private Vector2? PartnerPosition(int index)
        {
            int partner = Service.IndexOf(FaceMapMirror.PartnerLabel(State.Points[index].Label));
            return partner >= 0 ? State.Points[partner].Uv : (Vector2?)null;
        }

        // ── アバターから自動作成（自動ポインティング仕様 §11）──

        /// <summary>自動作成に使う顔のレンダラーとシェイプ（-1 = 未選択）。アバターを変えると推定し直す。</summary>
        public SkinnedMeshRenderer AutoRenderer { get; private set; }
        public int AutoBlink { get; set; } = -1;
        public int AutoMouth { get; set; } = -1;

        /// <summary>特定した顔のマテリアルとテクスチャの表示用の名前（まだなら null）。</summary>
        public string AutoFaceText { get; private set; }

        // スタイルの上書きと検出感度補正（自動ポインティング仕様 §12.6）。エディターの設定として覚える
        public const string AutoStyleKey = "ATAA.FaceMapEditor.AutoStyle";
        public const string AutoBiasKey = "ATAA.FaceMapEditor.AutoBias";

        /// <summary>スタイルの手動の上書き。Auto なら自動で判定する。</summary>
        public AvatarStyle AutoStyle
        {
            get
            {
                int v = EditorPrefs.GetInt(AutoStyleKey, (int)AvatarStyle.Auto);
                return Enum.IsDefined(typeof(AvatarStyle), v) ? (AvatarStyle)v : AvatarStyle.Auto;
            }
            set => EditorPrefs.SetInt(AutoStyleKey, (int)value);
        }

        /// <summary>検出感度補正（−1〜+1。0 = 既定）。+ で小さな動きまで拾う（領域が広がる）。</summary>
        public float AutoBias
        {
            get => GenerationOptions.ClampBias(EditorPrefs.GetFloat(AutoBiasKey, 0f));
            set => EditorPrefs.SetFloat(AutoBiasKey, GenerationOptions.ClampBias(value));
        }

        /// <summary>最後の自動作成で使ったスタイルの表示（「デフォルメ（自動判定）」など）。まだなら null。</summary>
        public string AutoStyleText { get; private set; }

        /// <summary>
        /// 自動作成の直後に立つ。ウィンドウが、選択した要確認の領域の欄（微調整 PAD）を見える位置に出してから下ろす。
        /// </summary>
        public bool AdjustFocusRequested { get; private set; }

        public void ConsumeAdjustFocus() => AdjustFocusRequested = false;

        private GameObject _autoAvatarSeen;

        // 要確認の領域を案内する順（自動作成の結果の CheckOrder）
        private readonly List<string> _checkOrder = new List<string>();

        // 要確認の領域（§11.5）: 自動作成したときの位置と範囲。どちらかが変わったら要確認でなくなる。保存しない
        private readonly Dictionary<string, (Vector2 Center, Vector2 Size)> _checkSnapshot =
            new Dictionary<string, (Vector2, Vector2)>(StringComparer.Ordinal);

        /// <summary>アバター欄が変わっていたら、顔のレンダラーとシェイプを推定し直す。</summary>
        public void RefreshAutoInputs()
        {
            if (State.TargetAvatarObject == _autoAvatarSeen) return;
            _autoAvatarSeen = State.TargetAvatarObject;
            SetAutoRenderer(AvatarFaceMapGenerator.GuessRenderer(_autoAvatarSeen, State.Texture));
        }

        public void SetAutoRenderer(SkinnedMeshRenderer smr)
        {
            AutoRenderer = smr;
            Mesh mesh = smr != null ? smr.sharedMesh : null;
            AutoBlink = AvatarFaceMapGenerator.GuessBlink(mesh);
            AutoMouth = AvatarFaceMapGenerator.GuessMouth(mesh);
            UpdateAutoFaceText();
        }

        public void UpdateAutoFaceText()
        {
            AutoFaceText = AvatarFaceMapGenerator.TryFindFaceMaterial(AutoRenderer, AutoBlink, AutoMouth, out int slot, out Material mat, out Texture tex)
                ? $"顔のマテリアル: {slot}: {(mat != null ? mat.name : "なし")} / テクスチャ: {(tex != null ? tex.name : "なし")}"
                : null;
        }

        /// <summary>要確認の領域のうち、自動作成のあと動かしていない・範囲を変えていないもの。</summary>
        public HashSet<string> ActiveCheckLabels()
        {
            var result = new HashSet<string>(StringComparer.Ordinal);
            foreach (var kv in _checkSnapshot)
            {
                int i = Service.IndexOf(kv.Key);
                if (i < 0) continue;
                string category = FaceTemplate.CategoryOf(kv.Key);
                if (State.Points[i].Uv == kv.Value.Center && Service.GetSize(category) == kv.Value.Size) result.Add(kv.Key);
            }
            return result;
        }

        /// <summary>
        /// まだ確かめていない要確認の領域のうち、current の次に案内するもの（順は自動作成の結果のまま、末尾まで行ったら先頭へ）。
        /// 無ければ null。
        /// </summary>
        public string NextCheckLabel(string current)
        {
            HashSet<string> active = ActiveCheckLabels();
            if (active.Count == 0) return null;
            int start = current != null ? _checkOrder.IndexOf(current) : -1;
            for (int k = 1; k <= _checkOrder.Count; k++)
            {
                string label = _checkOrder[(start + k + _checkOrder.Count) % _checkOrder.Count];
                if (active.Contains(label) && !string.Equals(label, current, StringComparison.Ordinal)) return label;
            }
            return null;
        }

        /// <summary>要確認の領域を選択して、その欄（微調整 PAD）へ案内する。置かれていなければ何もしない。</summary>
        public bool SelectCheckLabel(string label)
        {
            int i = label != null ? Service.IndexOf(label) : -1;
            if (i < 0) return false;
            SelectedPoint = i;
            ArmedLabel = null;
            AdjustFocusRequested = true;
            return true;
        }

        /// <summary>
        /// 「自動作成」。結果は既存の点を置き換えて読み込み、未保存にする（保存はしない）。元に戻すで 1 回として戻せる。
        /// 要確認の領域があれば、その先頭を選択して微調整へ案内する。無ければ選択を解除する（§12.6）。
        /// </summary>
        public void RunAutoGenerate()
        {
            if (State.TargetAvatarObject == null)
            {
                Fail("自動作成: アバターを指定してください。");
                return;
            }
            if (AutoRenderer == null)
            {
                Fail("自動作成: 顔のレンダラーを指定してください。");
                return;
            }

            var options = new GenerationOptions { Style = AutoStyle, DetectionThresholdBias = AutoBias };
            AvatarFaceMapGenerator.AvatarResult r = AvatarFaceMapGenerator.Generate(AutoRenderer, AutoBlink, AutoMouth, options);
            if (!r.Success)
            {
                Fail("自動作成: " + r.Error);
                return;
            }

            // 顔のテクスチャとエディターのテクスチャ（§9.2 手順 5）
            if (!(r.FaceTexture is Texture2D faceTex))
            {
                Fail("自動作成: 顔のマテリアルのテクスチャが見つかりません（2D テクスチャのみ対応）。");
                return;
            }
            if (State.Texture != null && State.Texture != faceTex)
            {
                if (!EditorUtility.DisplayDialog("テクスチャの切り替え",
                        $"顔のマテリアルのテクスチャは「{faceTex.name}」です。エディターのテクスチャ「{State.Texture.name}」を切り替えて続けますか?",
                        "切り替える", "中止"))
                    return;
            }
            if (State.Points.Count > 0 &&
                !EditorUtility.DisplayDialog("自動作成", "置いた領域を自動作成の結果で置き換えます。よろしいですか?\n（Ctrl+Z で元に戻せます）",
                    "置き換える", "キャンセル"))
                return;

            State.Texture = faceTex;

            History.Record("自動作成");
            State.Points = new List<FaceMapPoint>();
            foreach (FaceTemplateEntry entry in FaceTemplate.Entries)
                if (r.Centers.TryGetValue(entry.Label, out Vector2 c)) State.Points.Add(new FaceMapPoint(c.x, c.y, entry.Label));
            State.Sizes = new Dictionary<string, Vector2>(r.Sizes, StringComparer.Ordinal);
            State.CenterX = r.CenterX;
            State.CenterXFromNose = false;
            State.EyeLine = r.EyeLine;
            State.EyeLowerLine = r.EyeLowerLine;
            State.NoEyeOpening = r.NoEyeOpening;
            State.MouthLine = r.MouthLine;
            State.MouthLinePoints = r.MouthLine.HasValue ? MouthLineShape.Clone(r.MouthLinePoints) : null;
            State.Dirty = true;
            History.Commit();

            SelectedPoint = -1;
            ArmedLabel = null;
            AdjustFocusRequested = false;

            _checkSnapshot.Clear();
            _checkOrder.Clear();
            foreach (string label in r.CheckOrder)
            {
                int i = Service.IndexOf(label);
                if (i < 0) continue;
                _checkSnapshot[label] = (State.Points[i].Uv, Service.GetSize(FaceTemplate.CategoryOf(label)));
                _checkOrder.Add(label);
            }

            // 要確認があれば先頭を選択して微調整へ、無ければ選択を解除して全体を見てもらう
            if (_checkOrder.Count > 0) SelectCheckLabel(_checkOrder[0]);

            AutoStyleText = GenerationLabels.DisplayName(r.Style) + (r.StyleIsAuto ? "（自動判定）" : "（手動で指定）");

            Mesh mesh = AutoRenderer.sharedMesh;
            var lines = new List<string>
            {
                $"自動作成しました（未保存。Ctrl+Z で作成前に戻せます）。レンダラー: {AutoRenderer.name} / まばたき: {mesh.GetBlendShapeName(AutoBlink)} / " +
                $"口: {(AutoMouth >= 0 ? mesh.GetBlendShapeName(AutoMouth) : "なし")} / 顔のマテリアル: {(r.FaceMaterial != null ? r.FaceMaterial.name : "なし")}"
            };
            lines.AddRange(r.Notes);
            lines.Add(_checkOrder.Count > 0
                ? $"オレンジの枠は要確認です（{string.Join(" → ", _checkOrder)}）。「{_checkOrder[0]}」を選択しました。右の十字ボタンか矢印キーで合わせてください。"
                : "要確認の領域はありません。全体の位置を確かめて保存してください。");
            State.Warning = string.Join("\n", lines);
            State.WarningType = r.Fallbacks > 0 || r.EyeLineIssue != null ? MessageType.Warning : MessageType.Info;

            if (r.EyeLineIssue != null) AskEyeLineReview(r.EyeLineIssue);
        }

        /// <summary>
        /// 目の線を自動で決められなかったとき、ユーザーに合わせてもらうよう案内する（§11.22）。
        /// 「合わせる」なら左の目を選び、ウィンドウに 3D ビューを開かせる（EyeLineReviewRequested）。
        /// </summary>
        private void AskEyeLineReview(string issue)
        {
            bool hasLine = State.EyeLine.HasValue;
            string how = hasLine
                ? "テクスチャ上の目の枠の右端のつまみ（黄: 目の線、緑: 目の下の線）か、右の「高さ」で合わせてください。"
                : "右の「目の線」「目の下の線」をオンにして、テクスチャ上の目の枠の右端のつまみか「高さ」で合わせてください。";
            if (!EditorUtility.DisplayDialog("目の線を合わせてください",
                    issue + "\n\n" +
                    "目の線（上まつげの生え際）と目の下の線（下まつげの生え際）は、メイクの目の部分を写す基準です。\n" +
                    how + "\n" +
                    "3D ビューに、線が顔のどこに当たるかを同じ色で表示します。",
                    "目の線を合わせる", "あとで"))
                return;

            int i = Service.IndexOf(FaceMapAutoGenerator.EyeL);
            if (i < 0) i = Service.IndexOf(FaceMapAutoGenerator.EyeR);
            if (i >= 0)
            {
                SelectedPoint = i;
                ArmedLabel = null;
                AdjustFocusRequested = true;
            }
            EyeLineReviewRequested = true;
        }

        /// <summary>目の線を合わせる案内を受けた直後に立つ。ウィンドウが 3D ビューを開いて目に寄せてから下ろす。</summary>
        public bool EyeLineReviewRequested { get; private set; }

        public void ConsumeEyeLineReview() => EyeLineReviewRequested = false;

        // ── FaceMap の新規作成・読み込み・保存 ──

        /// <summary>閉じる・破棄の前に確認するか（開いただけで何も置いていなければ確認しない）。</summary>
        public bool NeedsSavePrompt =>
            FaceMapEditorUi.NeedsSavePrompt(State.Dirty, State.Points.Count, State.TargetAvatarObject != null);

        public bool ConfirmDiscardIfDirty()
        {
            if (!NeedsSavePrompt) return true;
            return EditorUtility.DisplayDialog(
                "未保存の変更",
                "未保存の変更があります。破棄しますか?",
                "破棄する", "キャンセル");
        }

        private Action<string> _onSavedCallback;

        public void NewFaceMap()
        {
            if (!ConfirmDiscardIfDirty()) return;
            _onSavedCallback = null;
            State.Clear();
            History.Clear();
            SelectedPoint = -1;
            ArmedLabel = null;
            _checkSnapshot.Clear();
            _checkOrder.Clear();
            Info("新しい FaceMap を作成しました。");
        }

        /// <summary>
        /// メインウィンドウの「この画像で手動作成」から開く。
        /// 選択中のメイクテクスチャを引き継いだ新規作成状態にし、保存時に onSaved へ保存先パスを通知する。
        /// </summary>
        public bool OpenForNewMakeup(Texture2D makeupTexture, Action<string> onSaved)
        {
            if (!ConfirmDiscardIfDirty()) return false;
            State.Clear();
            History.Clear();
            SelectedPoint = -1;
            ArmedLabel = null;
            _checkSnapshot.Clear();
            _checkOrder.Clear();
            State.Texture = makeupTexture;
            _onSavedCallback = onSaved;
            Info(makeupTexture != null
                ? "メイクテクスチャから新しい FaceMap を作成します。鼻 → 左目 → 口の順に配置して保存してください。"
                : "新しい FaceMap を作成します。まずメイクテクスチャを左のビューへドラッグ＆ドロップしてください。");
            return true;
        }

        public bool Load()
        {
            if (!ConfirmDiscardIfDirty()) return false;

            string initialDir = FaceMapFolder.TryEnsure(out _, out string abs, out _) ? abs : "";
            string path = EditorUtility.OpenFilePanel("FaceMap を読み込み", initialDir, "json");
            if (string.IsNullOrEmpty(path)) return false;
            return LoadPath(path);
        }

        /// <summary>
        /// メイクフィックス画面の「アバター基準を自動生成」で目の線を決められなかったとき（§9.9・§11.22）。
        /// 保存した FaceMap を開き、アバター・顔のレンダラー・顔のテクスチャを設定して、左の目を選び 3D ビューを開かせる。
        /// </summary>
        public bool OpenForEyeLineReview(string path, GameObject avatar, SkinnedMeshRenderer renderer, Texture2D faceTexture, string issue)
        {
            if (!ConfirmDiscardIfDirty()) return false;
            if (!LoadPath(path)) return false;

            State.TargetAvatarObject = avatar;
            State.Texture = faceTexture;
            _autoAvatarSeen = avatar; // RefreshAutoInputs で顔のレンダラーを推定し直さないようにする
            SetAutoRenderer(renderer);

            int i = Service.IndexOf(FaceMapAutoGenerator.EyeL);
            if (i < 0) i = Service.IndexOf(FaceMapAutoGenerator.EyeR);
            if (i >= 0)
            {
                SelectedPoint = i;
                AdjustFocusRequested = true;
            }
            EyeLineReviewRequested = true;
            State.Warning = $"読み込みました: {Path.GetFileName(path)}\n目の線を合わせてください: {issue}\n" +
                            "テクスチャ上の目の枠の右端のつまみ（黄: 目の線、緑: 目の下の線）か、右の「高さ」で合わせ、上書き保存してください。";
            State.WarningType = MessageType.Warning;
            return true;
        }

        /// <summary>FaceMap を開いて、アバター・顔メッシュ・顔テクスチャを引き継ぐ（メインウィンドウの「微調整」から）。</summary>
        public bool OpenForRefinement(string path, GameObject avatar, SkinnedMeshRenderer renderer, Texture2D faceTexture)
        {
            if (!ConfirmDiscardIfDirty()) return false;
            if (!LoadPath(path)) return false;

            State.TargetAvatarObject = avatar;
            State.Texture = faceTexture;
            _autoAvatarSeen = avatar; // RefreshAutoInputs で顔のレンダラーを推定し直さないようにする
            SetAutoRenderer(renderer);
            return true;
        }

        /// <summary>パスを指定して開く（体験版の「読込」で、一時保存した FaceMap を選んだとき）。</summary>
        public bool LoadFromPath(string path)
        {
            if (!ConfirmDiscardIfDirty()) return false;
            return LoadPath(path);
        }

        private bool LoadPath(string path)
        {
            if (!FaceMapRepository.TryLoadFile(path, out FaceMapFile file, out List<string> errors, out List<string> warnings))
            {
                Fail("読み込みに失敗しました: " + string.Join(" / ", errors));
                return false;
            }

            _onSavedCallback = null;
            State.LoadFrom(file, path);
            History.Clear();
            SelectedPoint = -1;
            ArmedLabel = null;
            _checkSnapshot.Clear();
            _checkOrder.Clear();

            string centerWarning = warnings.Find(w => w.StartsWith(FaceMapValidator.CenterXWarningPrefix, StringComparison.Ordinal));
            if (centerWarning != null)
            {
                State.Warning = $"読み込みました: {Path.GetFileName(path)}\n{centerWarning}";
                State.WarningType = MessageType.Warning;
            }
            else
            {
                Info($"読み込みました: {Path.GetFileName(path)}");
            }
            return true;
        }

        /// <summary>
        /// 保存先が決まっていれば上書き保存、なければ新規保存。
        /// </summary>
        public bool SaveOverwrite()
        {
            if (string.IsNullOrEmpty(State.BoundPath)) return SaveNew();

            // 保存先が別のアバターの FaceMap なら確認する（開いたまま別のアバターに切り替えて作業し、
            // 上書き保存で別のアバターの FaceMap を消してしまうのを防ぐ）
            string boundOwner = OwnerOfFile(State.BoundPath);
            string currentOwner = OwnerOf(State.TargetAvatarName, State.Name);
            if (boundOwner != null && currentOwner != null &&
                !string.Equals(boundOwner, currentOwner, StringComparison.OrdinalIgnoreCase))
            {
                int choice = EditorUtility.DisplayDialogComplex(
                    "保存先の確認",
                    $"保存先「{Path.GetFileName(State.BoundPath)}」は「{boundOwner}」の FaceMap ですが、" +
                    $"いま編集しているのは「{currentOwner}」の FaceMap です。\n" +
                    $"上書きすると「{boundOwner}」の FaceMap は失われます。",
                    "新規保存する", "キャンセル", "上書きする");
                if (choice == 1) return false;
                if (choice == 0) return SaveNew(currentOwner);
            }
            return SaveTo(State.BoundPath, syncNameToFileName: false);
        }

        /// <summary>FaceMap の持ち主の名前（対応アバター名、無ければ FaceMap の名前）。どちらも空なら null。</summary>
        private static string OwnerOf(string targetAvatar, string name)
        {
            if (!string.IsNullOrWhiteSpace(targetAvatar)) return targetAvatar.Trim();
            if (!string.IsNullOrWhiteSpace(name)) return name.Trim();
            return null;
        }

        /// <summary>保存済みファイルの持ち主の名前。ファイルが無い・読めないときは null（確認しない）。</summary>
        private static string OwnerOfFile(string path)
        {
            if (!FaceMapStorage.Exists(path)) return null;
            if (!FaceMapRepository.TryLoadFile(path, out FaceMapFile file, out _, out _) || file == null) return null;
            return OwnerOf(file.TargetAvatar, file.Name);
        }

        /// <summary>
        /// FaceMaps フォルダへ、name（または指定したファイル名）で保存する。同名ファイルがあれば上書きを確認する。
        /// fallbackName は、名前から決めたファイル名が今の保存先と同じになるときに代わりに使う名前
        /// （保存先の確認で「新規保存する」を選んだのに、同じファイルへ上書きしてしまわないように）。
        /// </summary>
        public bool SaveNew(string fallbackName = null)
        {
            if (!FaceMapStorage.TryGetSaveFolder(out string folder, out string error))
            {
                Fail(error);
                return false;
            }

            string path = Path.Combine(folder, ResolveFileName() + ".json");
            if (fallbackName != null && IsBoundPath(path))
            {
                string alt = FaceMapSerializer.SanitizeFileName(fallbackName);
                if (alt.Length > 0) path = Path.Combine(folder, alt + ".json");
                if (IsBoundPath(path) && RequestFileName == null)
                {
                    Fail("新規保存のファイル名が今の保存先と同じです。「ファイル名」欄に別の名前を入れてから保存してください。");
                    return false;
                }
            }

            // 画面があれば、保存する名前を聞く（初期値は上で決めた名前。今の保存先と同じなら、空いている番号を付ける）
            if (RequestFileName != null)
            {
                string initial = Path.GetFileNameWithoutExtension(path);
                if (IsBoundPath(path)) initial = UniqueFileName(folder, initial);
                string chosen = RequestFileName(initial, folder);
                if (chosen == null) return false;
                string sanitized = FaceMapSerializer.SanitizeFileName(chosen);
                if (sanitized.Length == 0)
                {
                    Fail("ファイル名に使える文字がありません。");
                    return false;
                }
                State.FileNameOverride = sanitized; // 「メイク基準の情報」のファイル名欄にも反映する
                path = Path.Combine(folder, sanitized + ".json");
                if (IsBoundPath(path)) return SaveTo(path, syncNameToFileName: true); // 今のファイルと同じ名前でも、指定名で name を揃える
            }

            if (FaceMapStorage.Exists(path) && !IsBoundPath(path))
            {
                bool overwrite = EditorUtility.DisplayDialog(
                    "上書きの確認",
                    $"{Path.GetFileName(path)} は既に存在します。上書きしますか?",
                    "上書きする", "キャンセル");
                if (!overwrite) return false;
            }

            return SaveTo(path, syncNameToFileName: true);
        }

        /// <summary>
        /// 新規保存の名前を聞く（画面が設定する）。引数は初期値（拡張子なし）と保存先フォルダ（絶対パス）。
        /// 取り消されたら null を返す。null のまま（画面が無い）なら聞かずに ResolveFileName の名前で保存する。
        /// </summary>
        public Func<string, string, string> RequestFileName { get; set; }

        /// <summary>folder に無いファイル名（拡張子なし）。name が使われていれば「name_2」「name_3」…にする。</summary>
        public static string UniqueFileName(string folder, string name)
        {
            for (int i = 2; i < 1000; i++)
            {
                string candidate = $"{name}_{i}";
                if (!FaceMapStorage.Exists(Path.Combine(folder, candidate + ".json"))) return candidate;
            }
            return name;
        }

        private bool IsBoundPath(string path) =>
            !string.IsNullOrEmpty(State.BoundPath) &&
            string.Equals(Path.GetFullPath(State.BoundPath), Path.GetFullPath(path), StringComparison.OrdinalIgnoreCase);

        /// <summary>
        /// 新規保存時のファイル名（拡張子なし）。ファイル名欄 → 名前 → 対応アバター名 → 顔テクスチャ名 の順に決める。
        /// </summary>
        public string ResolveFileName()
        {
            return FaceMapEditorUi.ResolveFileName(
                State.FileNameOverride,
                State.Name,
                State.TargetAvatarName,
                State.Texture != null ? State.Texture.name : null);
        }

        private bool SaveTo(string path, bool syncNameToFileName)
        {
            if (AtaaCore.Edition == CoreEdition.Trial && !FaceMapStorage.CanWrite(path))
            {
                // 体験版で、ファイルから読み込んだ FaceMap に上書きしようとしたとき
                Fail("体験版ではファイルに上書きできません。「別名で一時保存」でメモリに保存してください。");
                return false;
            }

            FaceMapFile file = State.ToFile();
            string texName = null;
            string texGuid = null;
            if (State.Texture != null)
            {
                texName = State.Texture.name;
                string assetPath = AssetDatabase.GetAssetPath(State.Texture);
                if (!string.IsNullOrEmpty(assetPath))
                    texGuid = AssetDatabase.AssetPathToGUID(assetPath);
            }
            FaceMapStorage.PrepareForSave(file, path, syncNameToFileName, texName, texGuid);

            if (!FaceMapStorage.TrySave(path, file, out string error))
            {
                // メモリ上のデータは保持し、再試行できるようにする
                Fail("保存に失敗しました: " + error);
                return false;
            }

            // 自動生成の一時データ（ATAA-Auto/）を保存したときは、FaceMaps フォルダへ実ファイルとして残し、一時データを消す
            if (FaceMapStorage.IsDraft(path))
            {
                string draftPath = path;
                if (!FaceMapStorage.TryGetSaveFolder(out string folder, out error)
                    || !FaceMapStorage.TryPromote(draftPath, folder, out path, out error))
                {
                    Fail("FaceMaps フォルダへの保存に失敗しました: " + error);
                    return false;
                }
                string promotedStem = Path.GetFileNameWithoutExtension(path);
                if (!string.Equals(promotedStem, Path.GetFileNameWithoutExtension(draftPath), StringComparison.Ordinal))
                    file.Name = promotedStem;
                MakeFixWindow.GetMainInstance()?.OnFaceMapPromoted(draftPath, path);
            }

            State.Name = file.Name ?? "";
            State.MetaJson = file.MetaJson;
            State.BoundPath = path;
            State.Dirty = false;
            History.MarkSaved();
            FaceMapStorage.RefreshAssets();
            // どのフォルダに保存したかも分かるように、プロジェクトからの相対パスで出す
            Info($"保存しました: {FaceMapStorage.Describe(path)}");

            MakeFixWindow.GetMainInstance()?.RequestRefresh();
            _onSavedCallback?.Invoke(path);
            return true;
        }

        private void Info(string message)
        {
            State.Warning = message;
            State.WarningType = MessageType.Info;
        }

        private void Fail(string message)
        {
            State.Warning = message;
            State.WarningType = MessageType.Error;
        }
    }
}
