// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/State/FaceMapUndoState.cs
using System;
using System.Collections.Generic;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディターの元に戻す・やり直し（FaceMap 仕様 v0.4 §12.5）のために、
    /// 編集中のデータ（点・範囲・中心線）を Unity の Undo が扱える形で持つ。
    /// FaceMapEditorState と常に同じ内容に保つ（FaceMapEditorHistory が書き写す）。保存はしない。
    /// </summary>
    internal class FaceMapUndoState : ScriptableObject
    {
        [Serializable]
        public struct PointData
        {
            public string label;
            public float x;
            public float y;
        }

        [Serializable]
        public struct SizeData
        {
            public string category;
            public Vector2 size;
        }

        public List<PointData> points = new List<PointData>();
        public List<SizeData> sizes = new List<SizeData>();
        public bool hasCenter;
        public float centerX;
        public bool centerFromNose;
        public bool hasEyeLine;
        public float eyeLine;
        public bool hasEyeLowerLine;
        public float eyeLowerLine;
        public bool noEyeOpening;
        public bool hasMouthLine;
        public float mouthLine;
        public List<Vector2> mouthLinePoints = new List<Vector2>();
        public bool hasEyeContour;
        public List<Vector2> eyeContourUpper = new List<Vector2>();
        public List<Vector2> eyeContourLower = new List<Vector2>();

        public void CopyFrom(FaceMapEditorState state)
        {
            points.Clear();
            foreach (FaceMapPoint p in state.Points)
                points.Add(new PointData { label = p.Label, x = p.X, y = p.Y });

            // Dictionary の列挙順は保証されないので、比較が安定するよう分類名で並べる
            sizes.Clear();
            var keys = new List<string>(state.Sizes.Keys);
            keys.Sort(StringComparer.Ordinal);
            foreach (string k in keys)
                sizes.Add(new SizeData { category = k, size = state.Sizes[k] });

            hasCenter = state.CenterX.HasValue;
            centerX = state.CenterX ?? 0f;
            centerFromNose = state.CenterXFromNose;
            hasEyeLine = state.EyeLine.HasValue;
            eyeLine = state.EyeLine ?? 0f;
            hasEyeLowerLine = state.EyeLowerLine.HasValue;
            eyeLowerLine = state.EyeLowerLine ?? 0f;
            noEyeOpening = state.NoEyeOpening;
            hasMouthLine = state.MouthLine.HasValue;
            mouthLine = state.MouthLine ?? 0f;
            mouthLinePoints.Clear();
            if (state.MouthLinePoints != null) mouthLinePoints.AddRange(state.MouthLinePoints);
            hasEyeContour = state.EyeContourUpper != null && state.EyeContourLower != null;
            eyeContourUpper.Clear();
            eyeContourLower.Clear();
            if (hasEyeContour)
            {
                eyeContourUpper.AddRange(state.EyeContourUpper);
                eyeContourLower.AddRange(state.EyeContourLower);
            }
        }

        public void CopyTo(FaceMapEditorState state)
        {
            state.Points = new List<FaceMapPoint>();
            foreach (PointData p in points)
                state.Points.Add(new FaceMapPoint(p.x, p.y, p.label));

            state.Sizes = new Dictionary<string, Vector2>(StringComparer.Ordinal);
            foreach (SizeData s in sizes)
                state.Sizes[s.category] = s.size;

            state.CenterX = hasCenter ? centerX : (float?)null;
            state.CenterXFromNose = centerFromNose;
            state.EyeLine = hasEyeLine ? eyeLine : (float?)null;
            state.EyeLowerLine = hasEyeLowerLine ? eyeLowerLine : (float?)null;
            state.NoEyeOpening = noEyeOpening;
            state.MouthLine = hasMouthLine ? mouthLine : (float?)null;
            state.MouthLinePoints = hasMouthLine && mouthLinePoints.Count > 0 ? mouthLinePoints.ToArray() : null;
            state.EyeContourUpper = hasEyeContour ? eyeContourUpper.ToArray() : null;
            state.EyeContourLower = hasEyeContour ? eyeContourLower.ToArray() : null;
        }
    }
}
