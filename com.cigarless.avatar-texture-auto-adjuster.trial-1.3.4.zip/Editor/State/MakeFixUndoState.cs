using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メイク調整画面の元に戻す・やり直しで Unity の Undo に記録する内容（MakeFixHistory が使う）。
    /// 調整は FaceMapAdjustment の JSON、メイクの濃さはそのまま持つ。
    /// </summary>
    public class MakeFixUndoState : ScriptableObject
    {
        public string PairKey;
        public string AdjustmentJson;
        public float Opacity;
    }
}
