// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/State/FaceMapEditorHistory.cs
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディターの元に戻す・やり直し（FaceMap 仕様 v0.4 §12.5）。Unity 標準の Undo に乗せる。
    /// データを変える操作は Record → 変更 → Commit の順に呼ぶ。何も変わらなかった操作は Unity が履歴に残さない。
    /// 同じ mergeKey の操作が続く間（押し続け・続けての入力・1 回のドラッグ）は 1 回にまとめる。
    /// </summary>
    public class FaceMapEditorHistory
    {
        /// <summary>同じ欄・ボタンへの操作を 1 回にまとめる間隔（秒）。</summary>
        public const double MergeSeconds = 0.8;

        private const string NamePrefix = "FaceMap: ";

        private readonly FaceMapEditorState _state;
        private FaceMapUndoState _so;

        // 最後に書き写した内容。Undo 後にこれと違えば、FaceMap の履歴が戻された（シーンの Undo ではない）
        private string _writtenJson;

        // 最後に保存（または読み込み）した状態。Undo 後の Dirty の判定に使う
        private string _savedKey;

        private string _lastKey;
        private double _lastTime;
        private int _lastGroup = -1;
        private bool _merging;

        public FaceMapEditorHistory(FaceMapEditorState state)
        {
            _state = state;
        }

        /// <summary>データを変える直前に呼ぶ。name は Edit メニューに出る操作名。</summary>
        public void Record(string name, string mergeKey = null, bool mergeAlways = false)
        {
            EnsureObject();
            _so.CopyFrom(_state);

            double now = EditorApplication.timeSinceStartup;
            _merging = mergeKey != null && mergeKey == _lastKey && _lastGroup >= 0
                       && (mergeAlways || now - _lastTime < MergeSeconds);
            if (!_merging)
            {
                Undo.IncrementCurrentGroup();
                _lastGroup = Undo.GetCurrentGroup();
            }

            Undo.RecordObject(_so, NamePrefix + name);
            Undo.SetCurrentGroupName(NamePrefix + name);

            _lastKey = mergeKey;
            _lastTime = now;
        }

        /// <summary>データを変えた直後に呼ぶ。</summary>
        public void Commit()
        {
            if (_so == null) return;
            _so.CopyFrom(_state);
            _writtenJson = JsonUtility.ToJson(_so);
            if (_merging) Undo.CollapseUndoOperations(_lastGroup);
            _merging = false;
        }

        /// <summary>
        /// Undo.undoRedoPerformed から呼ぶ。FaceMap の履歴が動いていたらデータを書き戻して true。
        /// シーンなど他の Undo なら何もしない。
        /// </summary>
        public bool OnUndoRedo()
        {
            if (_so == null) return false;

            string json = JsonUtility.ToJson(_so);
            if (json == _writtenJson) return false;

            _so.CopyTo(_state);
            _writtenJson = json;
            _state.Dirty = _savedKey == null || SavedKey(json) != _savedKey;

            // 戻した操作の続きにまとめないよう、まとめの状態を切る
            _lastKey = null;
            _lastGroup = -1;
            return true;
        }

        /// <summary>保存・読み込みの後に呼ぶ。今の状態を「保存済み」として覚える。</summary>
        public void MarkSaved()
        {
            EnsureObject();
            _so.CopyFrom(_state);
            _writtenJson = JsonUtility.ToJson(_so);
            _savedKey = SavedKey(_writtenJson);
        }

        /// <summary>「新規」「読み込み」の後に呼ぶ。履歴を消し、今の状態を保存済みとして覚える。</summary>
        public void Clear()
        {
            if (_so != null) Undo.ClearUndo(_so);
            _lastKey = null;
            _lastGroup = -1;
            MarkSaved();
        }

        /// <summary>ウィンドウを閉じる・再コンパイルの前に呼ぶ。履歴を消してオブジェクトを破棄する。</summary>
        public void Dispose()
        {
            if (_so == null) return;
            Undo.ClearUndo(_so);
            Object.DestroyImmediate(_so);
            _so = null;
            _writtenJson = null;
            _lastKey = null;
            _lastGroup = -1;
        }

        private void EnsureObject()
        {
            if (_so != null) return;

            _so = ScriptableObject.CreateInstance<FaceMapUndoState>();
            _so.hideFlags = HideFlags.HideAndDontSave;
            _so.CopyFrom(_state);
            _writtenJson = JsonUtility.ToJson(_so);

            // 未保存の変更が無ければ、今の状態が保存済みの状態
            if (_savedKey == null && !_state.Dirty) _savedKey = SavedKey(_writtenJson);
        }

        // 名前・対応アバター名は Undo の対象外だが、変えていれば保存済みとは違う
        private string SavedKey(string json) => json + "\n" + _state.Name + "\n" + _state.TargetAvatarName;
    }
}
