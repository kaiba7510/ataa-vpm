using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メイク調整画面（MakeFixWindow）の元に戻す・やり直し。Unity 標準の Undo に乗せるので、
    /// Ctrl+Z / Ctrl+Y（Ctrl+Shift+Z）と Edit メニューがそのまま使える。
    /// 記録用のオブジェクトにはいつも「最後に記録した状態」を入れておき、変更のあとで Commit する
    /// （Undo.RecordObject が変更前＝記録用オブジェクトの今の中身を覚える）。
    /// 組み合わせ（メイク元・アバター）が変わったら Reset で履歴を消す。
    /// </summary>
    public class MakeFixHistory
    {
        private const string NamePrefix = "ATAA: ";

        private readonly MakeFixHistoryMerge _merge = new MakeFixHistoryMerge();
        private MakeFixUndoState _so;
        private int _group = -1;

        // 最後に書き写した内容。Undo 後にこれと違えば、この履歴が戻された（シーンなど他の Undo ではない）
        private string _writtenJson;

        /// <summary>組み合わせを読み込んだ・切り替えたときに呼ぶ。履歴を消し、今の状態を起点にする。</summary>
        public void Reset(string pairKey, FaceMapAdjustment adj, float opacity)
        {
            EnsureObject();
            Undo.ClearUndo(_so);
            Write(pairKey, adj, opacity);
            _merge.Reset();
            _group = -1;
        }

        /// <summary>
        /// 調整を変えた直後に呼ぶ。interacting はドラッグ・スライダー・押し続けの最中か（同じ操作の間は 1 回にまとめる）。
        /// 何も変わっていなければ記録しない。
        /// </summary>
        public void Commit(string name, string pairKey, FaceMapAdjustment adj, float opacity, bool interacting)
        {
            if (adj == null) return;
            if (_so == null)
            {
                Reset(pairKey, adj, opacity);
                return;
            }

            string json = adj.ToJson();
            if (_so.PairKey == pairKey && _so.AdjustmentJson == json && Mathf.Approximately(_so.Opacity, opacity)) return;

            bool merge = _merge.Next(interacting) && _group >= 0;
            if (!merge)
            {
                Undo.IncrementCurrentGroup();
                _group = Undo.GetCurrentGroup();
            }

            Undo.RecordObject(_so, NamePrefix + name);
            Undo.SetCurrentGroupName(NamePrefix + name);
            _so.PairKey = pairKey;
            _so.AdjustmentJson = json;
            _so.Opacity = opacity;
            _writtenJson = JsonUtility.ToJson(_so);
            if (merge) Undo.CollapseUndoOperations(_group);
        }

        /// <summary>操作（ドラッグなど）が終わったときに呼ぶ。次の変更は別の 1 回になる。</summary>
        public void EndGesture() => _merge.EndGesture();

        /// <summary>
        /// Undo.undoRedoPerformed から呼ぶ。この履歴が動いていて、いまの組み合わせのものなら、戻した値を返して true。
        /// </summary>
        public bool TryTakeUndoRedo(string pairKey, out FaceMapAdjustment adj, out float opacity)
        {
            adj = null;
            opacity = 0f;
            if (_so == null) return false;

            string json = JsonUtility.ToJson(_so);
            if (json == _writtenJson) return false;
            _writtenJson = json;

            // 戻した操作の続きにまとめないよう、まとめの状態を切る
            _merge.Reset();
            _group = -1;

            if (_so.PairKey != pairKey) return false;
            adj = FaceMapAdjustmentFile.FromJson(_so.AdjustmentJson);
            if (adj == null) return false;
            opacity = _so.Opacity;
            return true;
        }

        /// <summary>ウィンドウを閉じる・再コンパイルの前に呼ぶ。履歴を消してオブジェクトを破棄する。</summary>
        public void Dispose()
        {
            if (_so == null) return;
            Undo.ClearUndo(_so);
            Object.DestroyImmediate(_so);
            _so = null;
            _writtenJson = null;
            _group = -1;
            _merge.Reset();
        }

        private void Write(string pairKey, FaceMapAdjustment adj, float opacity)
        {
            _so.PairKey = pairKey;
            _so.AdjustmentJson = adj?.ToJson();
            _so.Opacity = opacity;
            _writtenJson = JsonUtility.ToJson(_so);
        }

        private void EnsureObject()
        {
            if (_so != null) return;
            _so = ScriptableObject.CreateInstance<MakeFixUndoState>();
            _so.hideFlags = HideFlags.HideAndDontSave;
        }
    }
}
