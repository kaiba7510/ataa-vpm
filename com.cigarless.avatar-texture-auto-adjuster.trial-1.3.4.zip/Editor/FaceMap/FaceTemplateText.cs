// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceTemplateText.cs
using System;
using System.Collections.Generic;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// テンプレートの領域ごとの、エディターに表示する説明。左右は「画像の左/右」で書く。
    /// 領域そのもの（ラベル・分類・必須・目安の位置）はコアの FaceTemplate（UI の文言はコアに置かない）。
    /// </summary>
    public static class FaceTemplateText
    {
        private static readonly Dictionary<string, string> Descriptions = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["目_左"] = "画像の左側の目",
            ["目_右"] = "画像の右側の目",
            ["鼻_中央"] = "鼻",
            ["口_中央"] = "口",
            ["頬_左"] = "画像の左側の頬",
            ["頬_右"] = "画像の右側の頬",
            ["顎_中央"] = "顎（任意）",
        };

        /// <summary>ラベルの説明。テンプレートに無いラベル・null なら null。</summary>
        public static string Describe(string label) =>
            label != null && Descriptions.TryGetValue(label, out string d) ? d : null;
    }
}
