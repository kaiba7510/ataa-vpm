// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/AvatarFaceMapGenerator.cs
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 自動生成エンジン（自動ポインティング仕様 §11・§12）。アバターのブレンドシェイプ（まばたき・口）から
    /// FaceMap の 6 領域を作る。メッシュ・マテリアル・ブレンドシェイプのウェイトは変更しない
    /// （計測中にウェイトを一時的に変えるが、必ず元に戻す）。
    ///
    /// このクラスは Unity のオブジェクトから計算の入力（FaceMeshData）を取り出すところまでを受け持つ:
    ///  1. まばたきと口の両方で動く UV の島を持つサブメッシュを顔のマテリアルとする（§11.10）
    ///  2. UV・頂点・三角形・シェイプの差分・開いた形と閉じた形・頭身を配列にする
    /// 目・口の検出、スタイルの判定、自己診断、鼻・頬の配置は FaceMapAutoSolver が行う（Unity に依存しない）。
    /// しきい値・係数は GenerationProfile にまとめてあり、エディターには出さない。
    /// 結果の型・領域の名前（FaceMapAutoGenerator）と計算（FaceMapAutoSolver）はコア、このクラスは UI 側
    /// （docs~/コアとUIの分割_設計メモ.md 手順 3）。
    /// </summary>
    internal static class AvatarFaceMapGenerator
    {
        /// <summary>コアの結果に、取り出したときの顔のマテリアルとテクスチャ（Unity のアセット。コアは持てない）を足したもの。</summary>
        public sealed class AvatarResult : FaceMapAutoGenerator.Result
        {
            public Material FaceMaterial;
            public Texture FaceTexture;
        }

        // テクスチャに描かれた口から幅を取るときに読む大きさ（長辺。§11.9）
        private const int TextureReadSize = 2048;

        // ── 推定 ──

        private static readonly string[] BlinkExact = { "vrc.blink", "blink", "まばたき", "eye_close", "eyes_close", "blink_both", "eyeblink", "目閉じ" };
        private static readonly string[] BlinkContains = { "blink", "まばたき" };
        private static readonly string[] MouthExact = { "vrc.v_aa", "vrc.v.aa", "v_aa", "あ", "mouth_a", "mth_a", "aa", "a", "mouth_open", "jawopen" };
        private static readonly string[] MouthContains = { "v_aa", "v.aa", "mouth_a" };

        /// <summary>両目を閉じるシェイプの番号。左右別のシェイプは選ばない。見つからなければ -1。</summary>
        public static int GuessBlink(Mesh mesh)
        {
            if (mesh == null) return -1;
            int i = FindExact(mesh, BlinkExact);
            if (i >= 0) return i;
            for (int k = 0; k < mesh.blendShapeCount; k++)
            {
                string n = Normalize(mesh.GetBlendShapeName(k));
                if (BlinkContains.Any(n.Contains) && !IsOneSide(n)) return k;
            }
            return -1;
        }

        /// <summary>シェイプ名の一覧から、口を開くシェイプの番号（完全一致 → 部分一致）。見つからなければ -1。</summary>
        internal static int GuessMouthIndex(IReadOnlyList<string> names)
        {
            int i = ShapeNames.FindExact(names, MouthExact);
            return i >= 0 ? i : ShapeNames.FindContains(names, MouthContains);
        }

        /// <summary>口を開くシェイプの番号。見つからなければ -1。</summary>
        public static int GuessMouth(Mesh mesh)
        {
            if (mesh == null) return -1;
            var names = new List<string>(mesh.blendShapeCount);
            for (int k = 0; k < mesh.blendShapeCount; k++) names.Add(mesh.GetBlendShapeName(k));
            return GuessMouthIndex(names);
        }

        /// <summary>
        /// 顔のレンダラーを選ぶ: まばたきらしいシェイプを持ち、faceTexture を参照するもの → まばたきらしいシェイプを持つもの
        /// → ブレンドシェイプが最も多いもの。
        /// </summary>
        public static SkinnedMeshRenderer GuessRenderer(GameObject avatar, Texture faceTexture)
        {
            if (avatar == null) return null;
            var all = avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true)
                .Where(r => r.sharedMesh != null && r.sharedMesh.blendShapeCount > 0).ToList();
            if (all.Count == 0) return null;

            var blink = all.Where(r => GuessBlink(r.sharedMesh) >= 0).ToList();
            var withTex = faceTexture != null ? blink.Where(r => References(r, faceTexture)).ToList() : new List<SkinnedMeshRenderer>();
            var pool = withTex.Count > 0 ? withTex : blink.Count > 0 ? blink : all;
            return pool.OrderByDescending(r => r.sharedMesh.blendShapeCount).First();
        }

        /// <summary>
        /// 顔のマテリアル（ATAA の複製なら元のマテリアル）とそのテクスチャ（§11.10）。
        /// 口のシェイプがあれば、まばたきと口の両方で動く UV の島を持つサブメッシュを選ぶ。
        /// 島ごとに「まばたきの動きの合計の割合」と「口の動きの合計の割合」の小さい方を点数とし、最大の島を持つもの。
        /// 目・まつげが別のマテリアルの素体（kipfel）では、まばたきで最も動くのは目のマテリアルだが、口は動かないので選ばれない。
        /// 口の中が別のマテリアルの素体（lumina）では、口の中はまばたきで動かないので選ばれない。
        /// 口のシェイプが無い・どの島も点数 0 なら、まばたきで最も動くサブメッシュにする。
        /// </summary>
        public static bool TryFindFaceMaterial(SkinnedMeshRenderer smr, int blink, int mouth,
                                               out int slot, out Material material, out Texture texture)
        {
            slot = -1;
            material = null;
            texture = null;
            Mesh mesh = smr != null ? smr.sharedMesh : null;
            float[] mag = DeltaMagnitudes(mesh, blink);
            if (mag == null) return false;

            var tris = new int[mesh.subMeshCount][];
            for (int s = 0; s < tris.Length; s++) tris[s] = mesh.GetTriangles(s);
            slot = AtaaCore.FindFaceSubmesh(mesh.vertexCount, tris, mag, DeltaMagnitudes(mesh, mouth));
            if (slot < 0) return false;

            Material[] mats = smr.sharedMaterials;
            material = slot < mats.Length ? FaceMaterialApplier.ResolveOriginal(mats[slot]) : null;
            texture = TextureOf(material);
            return true;
        }

        // ── 作成 ──

        public static AvatarResult Generate(SkinnedMeshRenderer smr, int blink, int mouth, GenerationOptions options = null)
        {
            var r = new AvatarResult();
            if (!TryExtract(smr, blink, mouth, r, out FaceMeshData data)) return r;
            AtaaCore.SolveAutoFaceMap(data, options, r);
            return r;
        }

        /// <summary>
        /// レンダラーから計算の入力を取り出す。取り出せなければ r.Error に理由を入れて false。
        /// 顔のマテリアルとテクスチャは r に入れる。
        /// </summary>
        internal static bool TryExtract(SkinnedMeshRenderer smr, int blink, int mouth, AvatarResult r, out FaceMeshData data)
        {
            data = null;
            Mesh mesh = smr != null ? smr.sharedMesh : null;
            if (mesh == null) return Fail(r, "顔のレンダラーを指定してください。");
            if (blink < 0 || blink >= mesh.blendShapeCount) return Fail(r, "まばたきのブレンドシェイプを選んでください。");

            int n = mesh.vertexCount;
            Vector2[] uv = mesh.uv;
            if (uv == null || uv.Length != n) return Fail(r, $"顔のメッシュ「{mesh.name}」に UV がありません。");
            for (int i = 0; i < n; i++) uv[i] = new Vector2(FaceMeshData.Tile(uv[i].x), FaceMeshData.Tile(uv[i].y));

            // メッシュの配列は 1 回だけ取り出して使い回す（取り出すたびにコピーが作られるため）
            int subCount = mesh.subMeshCount;
            var tris = new int[subCount][];
            for (int s = 0; s < subCount; s++) tris[s] = mesh.GetTriangles(s);

            float[] blinkMag = DeltaMagnitudes(mesh, blink);
            if (blinkMag == null || Max(blinkMag) <= 0f)
                return Fail(r, $"まばたき「{mesh.GetBlendShapeName(blink)}」で動く頂点がありません。");
            bool mouthValid = mouth >= 0 && mouth < mesh.blendShapeCount;
            float[] mouthMag = mouthValid ? DeltaMagnitudes(mesh, mouth) : null;

            // 顔のマテリアルと、同じテクスチャを使うサブメッシュ
            int faceSlot = AtaaCore.FindFaceSubmesh(n, tris, blinkMag, mouthMag);
            if (faceSlot < 0) return Fail(r, "顔のマテリアルを特定できませんでした。");
            Material[] mats = smr.sharedMaterials;
            Material faceMat = faceSlot < mats.Length ? FaceMaterialApplier.ResolveOriginal(mats[faceSlot]) : null;
            Texture faceTex = TextureOf(faceMat);
            r.FaceMaterial = faceMat;
            r.FaceTexture = faceTex;

            var faceSub = new bool[subCount];
            for (int s = 0; s < subCount; s++)
            {
                Material m = s < mats.Length ? FaceMaterialApplier.ResolveOriginal(mats[s]) : null;
                faceSub[s] = s == faceSlot || (faceTex != null && TextureOf(m) == faceTex);
            }

            Animator anim = smr.GetComponentInParent<Animator>();
            Transform root = anim != null ? anim.transform : smr.transform.root;
            Vector3 up = root.up;

            data = new FaceMeshData
            {
                MeshName = mesh.name,
                VertexCount = n,
                Uv = uv,
                Position = mesh.vertices,
                Triangles = tris,
                FaceSubmesh = faceSub,
                Up = up,
                Blink = BakeShape(smr, blink, blinkMag),
                MouthSelected = mouthValid,
                MouthName = mouthValid ? mesh.GetBlendShapeName(mouth) : null,
            };
            if (mouthMag != null && Max(mouthMag) > 0f) data.Mouth = BakeShape(smr, mouth, mouthMag);
            data.HeadRatio = HeadRatio(anim, root, up, data.Blink.Open);

            if (faceTex != null && faceTex.width > 0 && faceTex.height > 0)
            {
                data.ReadFaceTexture = () =>
                {
                    FaceMapPreview.FitSize(faceTex.width, faceTex.height, TextureReadSize, out int w, out int h);
                    FacePixels px = FaceTextureReader.Read(faceTex, w, h, FaceTextureReader.IsLinear(faceTex));
                    return new TexturePixels { Data = px.Data, Width = px.Width, Height = px.Height };
                };
            }
            return true;
        }

        private static bool Fail(FaceMapAutoGenerator.Result r, string message)
        {
            r.Error = message;
            return false;
        }

        /// <summary>
        /// 頭身の目安 = 床（アバターのルート）から頭頂 ÷ Head ボーンから頭頂。頭頂は顔のメッシュのいちばん上の頂点。
        /// Humanoid でない・Head ボーンが無い・値が不自然なときは null。
        /// </summary>
        private static float? HeadRatio(Animator anim, Transform root, Vector3 up, Vector3[] worldVertices)
        {
            if (anim == null || !anim.isHuman || worldVertices == null || worldVertices.Length == 0) return null;
            Transform head = anim.GetBoneTransform(HumanBodyBones.Head);
            if (head == null) return null;

            float top = float.MinValue;
            for (int i = 0; i < worldVertices.Length; i++)
            {
                float y = Vector3.Dot(worldVertices[i], up);
                if (y > top) top = y;
            }
            float floor = Vector3.Dot(root.position, up), headBase = Vector3.Dot(head.position, up);
            float height = top - floor, headHeight = top - headBase;
            if (height <= 1e-4f || headHeight <= 1e-4f || headHeight >= height) return null;
            return height / headHeight;
        }

        // ── 補助 ──

        /// <summary>
        /// シェイプを 0 にした形（開いた形）と最大にした形（閉じた形）のワールド座標。ウェイトは一時的に変えて、必ず元に戻す。
        /// </summary>
        private static ShapeData BakeShape(SkinnedMeshRenderer smr, int shape, float[] magnitude)
        {
            Mesh mesh = smr.sharedMesh;
            var baked = new Mesh();
            float saved = smr.GetBlendShapeWeight(shape);
            Vector3[] a, b;
            try
            {
                smr.SetBlendShapeWeight(shape, 0f);
                smr.BakeMesh(baked, true);
                a = baked.vertices;
                smr.SetBlendShapeWeight(shape, mesh.GetBlendShapeFrameWeight(shape, mesh.GetBlendShapeFrameCount(shape) - 1));
                smr.BakeMesh(baked, true);
                b = baked.vertices;
            }
            finally
            {
                smr.SetBlendShapeWeight(shape, saved);
                UnityEngine.Object.DestroyImmediate(baked);
            }

            // BakeMesh の頂点はスケール込みのレンダラー座標系（位置と回転だけ掛ける）
            Matrix4x4 toWorld = Matrix4x4.TRS(smr.transform.position, smr.transform.rotation, Vector3.one);
            int n = mesh.vertexCount;
            var open = new Vector3[n];
            var closed = new Vector3[n];
            for (int i = 0; i < n; i++)
            {
                open[i] = i < a.Length ? toWorld.MultiplyPoint3x4(a[i]) : Vector3.zero;
                closed[i] = i < b.Length ? toWorld.MultiplyPoint3x4(b[i]) : open[i];
            }
            return new ShapeData { Name = mesh.GetBlendShapeName(shape), Magnitude = magnitude, Open = open, Closed = closed };
        }

        private static float[] DeltaMagnitudes(Mesh mesh, int shape)
        {
            if (mesh == null || shape < 0 || shape >= mesh.blendShapeCount) return null;
            int frames = mesh.GetBlendShapeFrameCount(shape);
            if (frames <= 0) return null;
            int n = mesh.vertexCount;
            var dv = new Vector3[n];
            mesh.GetBlendShapeFrameVertices(shape, frames - 1, dv, null, null);
            var w = new float[n];
            for (int i = 0; i < n; i++) w[i] = dv[i].magnitude;
            return w;
        }

        private static float Max(float[] values)
        {
            float mx = 0f;
            for (int i = 0; i < values.Length; i++) if (values[i] > mx) mx = values[i];
            return mx;
        }

        public static Texture TextureOf(Material m)
        {
            if (m == null) return null;
            if (m.HasProperty("_MainTex") && m.GetTexture("_MainTex") != null) return m.GetTexture("_MainTex");
            if (m.HasProperty("_BaseMap") && m.GetTexture("_BaseMap") != null) return m.GetTexture("_BaseMap");
            foreach (int id in m.GetTexturePropertyNameIDs())
            {
                Texture t = m.GetTexture(id);
                if (t != null) return t;
            }
            return null;
        }

        private static bool References(Renderer r, Texture tex)
        {
            foreach (Material m in r.sharedMaterials)
            {
                Material o = FaceMaterialApplier.ResolveOriginal(m);
                if (o == null) continue;
                foreach (int id in o.GetTexturePropertyNameIDs())
                    if (o.GetTexture(id) == tex) return true;
            }
            return false;
        }

        private static int FindExact(Mesh mesh, string[] patterns)
        {
            var names = new List<string>(mesh.blendShapeCount);
            for (int k = 0; k < mesh.blendShapeCount; k++) names.Add(mesh.GetBlendShapeName(k));
            return ShapeNames.FindExact(names, patterns);
        }

        private static string Normalize(string s) => s.Trim().ToLowerInvariant();

        private static bool IsOneSide(string n) =>
            n.EndsWith("_l") || n.EndsWith("_r") || n.EndsWith(".l") || n.EndsWith(".r") ||
            n.Contains("left") || n.Contains("right") || n.Contains("左") || n.Contains("右");
    }
}
