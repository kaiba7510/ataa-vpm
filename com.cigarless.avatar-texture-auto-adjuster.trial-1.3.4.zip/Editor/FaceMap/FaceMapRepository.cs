// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapRepository.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMaps フォルダの走査と読み込み。Unity API に依存せず、ワーカースレッドで動く。
    /// メモリには FaceMapMeta だけを返し、points 本体は Load したときだけ読む。
    /// </summary>
    public static class FaceMapRepository
    {
        public class LoadResult
        {
            public LoadedFaceMap Map;
            public List<string> Errors = new List<string>();

            public bool Succeeded => Map != null;
        }

        public static Task<List<FaceMapMeta>> ListAsync(string folderAbsolutePath, CancellationToken ct)
        {
            return Task.Run(() => List(folderAbsolutePath, ct), ct);
        }

        public static Task<LoadResult> LoadAsync(string filePath, CancellationToken ct)
        {
            return Task.Run(() =>
            {
                ct.ThrowIfCancellationRequested();
                return Load(filePath);
            }, ct);
        }

        /// <summary>
        /// 直下の .json のみを走査して検証する（再帰しない・隠しファイルと .json 以外は無視）。
        /// </summary>
        public static List<FaceMapMeta> List(string folderAbsolutePath, CancellationToken ct)
        {
            var result = new List<FaceMapMeta>();

            string[] files;
            try
            {
                files = Directory.Exists(folderAbsolutePath) ? Directory.GetFiles(folderAbsolutePath) : new string[0];
            }
            catch (Exception)
            {
                files = new string[0];
            }

            foreach (string path in files)
            {
                ct.ThrowIfCancellationRequested();

                string fileName = Path.GetFileName(path);
                if (fileName.StartsWith(".", StringComparison.Ordinal)) continue;
                if (!string.Equals(Path.GetExtension(fileName), ".json", StringComparison.OrdinalIgnoreCase)) continue;

                result.Add(Inspect(path));
            }
            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                // 体験版: メモリに一時保存した FaceMap も一覧に入れる（入れないと選択が外される）
                foreach (string path in TrialStore.FaceMapPaths())
                {
                    ct.ThrowIfCancellationRequested();
                    result.Add(Inspect(path));
                }
            }
            else
            {
                // 製品版: 自動生成しただけの一時データも一覧に入れる。同名の実ファイルがあれば実ファイルを優先する
                var realNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (FaceMapMeta m in result) realNames.Add(m.FileName);
                foreach (string path in AutoFaceMapStore.FaceMapPaths())
                {
                    ct.ThrowIfCancellationRequested();
                    if (realNames.Contains(Path.GetFileName(path))) continue;
                    result.Add(Inspect(path));
                }
            }

            result.Sort((a, b) => string.Compare(a.DisplayName, b.DisplayName, StringComparison.OrdinalIgnoreCase));
            return result;
        }

        public static FaceMapMeta Inspect(string path)
        {
            string fileName = Path.GetFileName(path);
            var meta = new FaceMapMeta
            {
                FilePath = path,
                FileName = fileName,
                DisplayName = Path.GetFileNameWithoutExtension(fileName)
            };

            string text;
            try
            {
                meta.LastWriteTicks = FaceMapStorage.LastWriteTicks(path);
                text = FaceMapStorage.ReadAllText(path);
            }
            catch (Exception ex)
            {
                // スキャン中にファイルが消えた・書き込み中、などに耐える
                meta.Errors.Add("ファイルを読み込めません: " + ex.Message);
                return meta;
            }

            FaceMapValidator.Result r = FaceMapValidator.Validate(text);
            meta.SchemaVersion = r.SchemaVersion;
            meta.Errors.AddRange(r.Errors);
            meta.Warnings.AddRange(r.Warnings);

            if (r.IsValid)
            {
                meta.Status = FaceMapStatus.Valid;
                meta.PointCount = r.File.Points.Count;
                meta.TargetAvatar = r.File.TargetAvatar;
                FaceTextureHint.Read(r.File.MetaJson, out meta.FaceTextureName, out meta.FaceTextureGuid);
                if (!string.IsNullOrEmpty(r.File.Name)) meta.DisplayName = r.File.Name;
            }

            return meta;
        }

        /// <summary>
        /// 再検証したうえで points を読み込む。
        /// </summary>
        public static LoadResult Load(string path)
        {
            var result = new LoadResult();

            string text;
            try
            {
                text = FaceMapStorage.ReadAllText(path);
            }
            catch (Exception ex)
            {
                result.Errors.Add("ファイルを読み込めません: " + ex.Message);
                return result;
            }

            FaceMapValidator.Result r = FaceMapValidator.Validate(text);
            if (!r.IsValid)
            {
                result.Errors.AddRange(r.Errors);
                return result;
            }

            result.Map = new LoadedFaceMap
            {
                SourceFile = path,
                DisplayName = !string.IsNullOrEmpty(r.File.Name)
                    ? r.File.Name
                    : Path.GetFileNameWithoutExtension(path),
                TargetAvatar = r.File.TargetAvatar,
                Points = r.File.Points,
                Sizes = r.File.Sizes,
                EyeLine = r.File.EyeLine,
                EyeLowerLine = r.File.EyeLowerLine,
                NoEyeOpening = r.File.NoEyeOpening,
                MouthLine = r.File.MouthLine,
                MouthLinePoints = r.File.MouthLinePoints,
                EyeContourUpper = r.File.EyeContourUpper,
                EyeContourLower = r.File.EyeContourLower,
                Warnings = r.Warnings,
                CenterX = r.File.CenterX
            };
            return result;
        }

        /// <summary>
        /// エディター用に、FaceMapFile（meta を含む編集可能な形）として読み込む。
        /// </summary>
        public static bool TryLoadFile(string path, out FaceMapFile file, out List<string> errors)
        {
            return TryLoadFile(path, out file, out errors, out _);
        }

        /// <summary>警告も受け取る版。</summary>
        public static bool TryLoadFile(string path, out FaceMapFile file, out List<string> errors, out List<string> warnings)
        {
            file = null;
            errors = new List<string>();
            warnings = new List<string>();

            string text;
            try
            {
                text = FaceMapStorage.ReadAllText(path);
            }
            catch (Exception ex)
            {
                errors.Add("ファイルを読み込めません: " + ex.Message);
                return false;
            }

            FaceMapValidator.Result r = FaceMapValidator.Validate(text);
            if (!r.IsValid)
            {
                errors.AddRange(r.Errors);
                return false;
            }

            file = r.File;
            warnings.AddRange(r.Warnings);
            return true;
        }
    }
}
