// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapAdjustmentFile.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 微調整（FaceMapAdjustment）の JSON 化とファイルの読み書き。データの型はコア（Core/FaceMap/FaceMapAdjustment.cs）、
    /// Newtonsoft・ファイル・体験版のメモリ保存はここ（docs~/コアとUIの分割_設計メモ.md 手順 3）。
    /// ToJson / TrySave は拡張メソッドなので、呼び出し側は今までどおり adjustment.ToJson() と書ける。
    /// </summary>
    public static class FaceMapAdjustmentFile
    {
        // ── 保存 ──

        public static string ToJson(this FaceMapAdjustment a)
        {
            var root = new JObject
            {
                ["schemaVersion"] = FaceMapAdjustment.SchemaVersion,
                ["offset"] = WriteVector(a.Global.Offset),
                ["scale"] = WriteVector(a.Global.Scale),
                ["maskMargin"] = a.MaskMargin,
                ["maskFeather"] = a.MaskFeather,
                ["excludeFeather"] = a.ExcludeFeather
            };

            if (!Mathf.Approximately(a.Global.Rotation, 0f)) root["rotation"] = a.Global.Rotation;
            if (!a.MatchSkinTone) root["matchSkinTone"] = false;
            if (!a.LocalPartAdjust) root["localPartAdjust"] = false;

            var parts = new JObject();
            foreach (string category in FaceTemplate.Categories())
            {
                FaceMapTransform t = a.FindPart(category);
                bool enabled = a.IsEnabled(category);
                if ((t == null || t.IsIdentity) && enabled) continue;

                var o = new JObject();
                if (t != null && !t.IsIdentity)
                {
                    o["offset"] = WriteVector(t.Offset);
                    o["scale"] = WriteVector(t.Scale);
                    if (!Mathf.Approximately(t.Gap, 0f)) o["gap"] = t.Gap;
                    if (!Mathf.Approximately(t.Rotation, 0f)) o["rotation"] = t.Rotation;
                }
                o["enabled"] = enabled;
                parts[category] = o;
            }
            if (parts.Count > 0) root["parts"] = parts;

            if (a.HasEyeAdjustment)
            {
                var eye = new JObject
                {
                    ["lowerEyeWidthScale"] = a.LowerEyeWidthScale,
                    ["lowerEyeOuterFlare"] = a.LowerEyeOuterFlare
                };
                if (a.OverrideAvatarEyeLine.HasValue) eye["overrideAvatarEyeLine"] = a.OverrideAvatarEyeLine.Value;
                if (a.OverrideAvatarEyeLowerLine.HasValue) eye["overrideAvatarEyeLowerLine"] = a.OverrideAvatarEyeLowerLine.Value;
                root["eye"] = eye;
            }

            if (a.HasMouthAdjustment) root["mouth"] = new JObject { ["bend"] = a.MouthBend, ["fold"] = a.MouthFold };

            return root.ToString(Formatting.Indented);
        }

        /// <summary>壊れたデータや範囲外の値は null を返す（呼び出し側は「調整なし」に戻す）。</summary>
        public static FaceMapAdjustment FromJson(string text)
        {
            try
            {
                var raw = JObject.Parse((text ?? "").TrimStart('﻿'));
                FaceMapSchemaMigrator.MigrationResult migrated = FaceMapSchemaMigrator.MigrateAdjustment(raw);
                if (!migrated.Succeeded) return null;
                JObject root = migrated.Root;

                if (!TryReadVector(root["offset"], out Vector2 offset)) return null;
                if (!TryReadVector(root["scale"], out Vector2 scale)) return null;

                var adj = new FaceMapAdjustment();
                adj.Global.Offset = offset;
                adj.Global.Scale = scale;
                if (IsFiniteNumber(root["rotation"], out float globalRotation))
                    adj.Global.Rotation = Mathf.Clamp(globalRotation, -FaceMapTransform.MaxRotation, FaceMapTransform.MaxRotation);
                // 合成範囲は後から加わった項目。無い・壊れている場合は既定値のままにする（旧既定値の移行は MigrateAdjustment で実施済み）
                if (IsFiniteNumber(root["maskMargin"], out float margin)) adj.MaskMargin = margin;
                if (IsFiniteNumber(root["maskFeather"], out float feather)) adj.MaskFeather = feather;
                if (IsFiniteNumber(root["excludeFeather"], out float excludeFeather)) adj.ExcludeFeather = excludeFeather;
                if (root["matchSkinTone"] is JValue skinTone && skinTone.Type == JTokenType.Boolean) adj.MatchSkinTone = (bool)skinTone;
                if (root["localPartAdjust"] is JValue local && local.Type == JTokenType.Boolean) adj.LocalPartAdjust = (bool)local;

                // パーツごとの調整（schemaVersion 2）。テンプレートに無い分類・壊れた項目は無視する
                if (root["parts"] is JObject parts)
                {
                    List<string> known = FaceTemplate.Categories();
                    foreach (JProperty prop in parts.Properties())
                    {
                        if (!known.Contains(prop.Name) || !(prop.Value is JObject o)) continue;

                        if (TryReadVector(o["offset"], out Vector2 po) && TryReadVector(o["scale"], out Vector2 ps))
                        {
                            FaceMapTransform t = adj.GetPart(prop.Name);
                            t.Offset = po;
                            t.Scale = ps;
                            // 左右の間隔は後から加わった項目。無い・壊れている場合は 0
                            if (IsFiniteNumber(o["gap"], out float gap)) t.Gap = Mathf.Clamp(gap, -1f, 1f);
                            if (IsFiniteNumber(o["rotation"], out float rot))
                                t.Rotation = Mathf.Clamp(rot, -FaceMapTransform.MaxRotation, FaceMapTransform.MaxRotation);
                        }
                        if (o["enabled"] != null && o["enabled"].Type == JTokenType.Boolean && !(bool)o["enabled"])
                            adj.SetEnabled(prop.Name, false);
                    }
                }

                // 目の調整（schemaVersion 4）。無い・壊れている項目は既定値
                if (root["eye"] is JObject eyeObj)
                {
                    if (IsFiniteNumber(eyeObj["overrideAvatarEyeLine"], out float upper)) adj.OverrideAvatarEyeLine = upper;
                    if (IsFiniteNumber(eyeObj["overrideAvatarEyeLowerLine"], out float lower)) adj.OverrideAvatarEyeLowerLine = lower;
                    if (IsFiniteNumber(eyeObj["lowerEyeWidthScale"], out float width)) adj.LowerEyeWidthScale = width;
                    if (IsFiniteNumber(eyeObj["lowerEyeOuterFlare"], out float flare)) adj.LowerEyeOuterFlare = flare;
                }

                adj.ClampScale();
                adj.ClampMask();
                // 口の調整（schemaVersion 6）。無い・壊れている項目は既定値
                // 口の折れ（schemaVersion 7）
                if (root["mouth"] is JObject mouthObj)
                {
                    if (IsFiniteNumber(mouthObj["bend"], out float bend)) adj.MouthBend = bend;
                    if (IsFiniteNumber(mouthObj["fold"], out float fold)) adj.MouthFold = fold;
                }

                adj.ClampEye();
                adj.ClampMouth();
                return adj;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static JObject WriteVector(Vector2 v) => new JObject { ["x"] = v.x, ["y"] = v.y };

        private static bool TryReadVector(JToken token, out Vector2 v)
        {
            v = Vector2.zero;
            var o = token as JObject;
            if (o == null) return false;
            if (!IsFiniteNumber(o["x"], out float x) || !IsFiniteNumber(o["y"], out float y)) return false;
            v = new Vector2(x, y);
            return true;
        }

        private static bool IsFiniteNumber(JToken t, out float value)
        {
            value = 0f;
            if (t == null || (t.Type != JTokenType.Integer && t.Type != JTokenType.Float)) return false;
            double d = (double)t;
            if (double.IsNaN(d) || double.IsInfinity(d)) return false;
            value = (float)d;
            return !float.IsInfinity(value);
        }

        // ── ファイル ──

        public const string FolderName = "Adjustments";

        /// <summary>
        /// 組み合わせごとの保存先。FaceMaps フォルダの下の Adjustments フォルダに置く
        /// （FaceMap の一覧は直下の .json しか見ないので混ざらない）。
        /// </summary>
        public static string GetPath(string faceMapFolder, string makeupFilePath, string avatarFilePath)
        {
            string a = FaceMapSerializer.SanitizeFileName(Path.GetFileNameWithoutExtension(makeupFilePath));
            string b = FaceMapSerializer.SanitizeFileName(Path.GetFileNameWithoutExtension(avatarFilePath));
            // 体験版はメモリに持つ（TrialStore。Unity を閉じると消える）
            if (AtaaCore.Edition == CoreEdition.Trial) faceMapFolder = TrialStore.Folder;
            return Path.Combine(faceMapFolder, FolderName, a + "__" + b + ".adjust.json");
        }

        public static FaceMapAdjustment Load(string path)
        {
            try
            {
                if (AtaaCore.Edition == CoreEdition.Trial && TrialStore.IsVirtual(path))
                {
                    return TrialStore.TryGet(path, out string text, out _)
                        ? FromJson(text) ?? new FaceMapAdjustment()
                        : new FaceMapAdjustment();
                }
                if (!File.Exists(path)) return new FaceMapAdjustment();
                return FromJson(File.ReadAllText(path)) ?? new FaceMapAdjustment();
            }
            catch (Exception)
            {
                return new FaceMapAdjustment();
            }
        }

        /// <summary>調整なしの状態なら、保存済みファイルを削除する。</summary>
        public static bool TrySave(this FaceMapAdjustment a, string path, out string error)
        {
            error = null;
            try
            {
                if (AtaaCore.Edition == CoreEdition.Trial)
                {
                    // 体験版はメモリにだけ保存する
                    if (!TrialStore.IsVirtual(path))
                    {
                        error = "体験版ではファイルに保存できません（製品版で使えます）。";
                        return false;
                    }
                    if (a.IsIdentity) TrialStore.Remove(path);
                    else TrialStore.Put(path, a.ToJson());
                    return true;
                }

                if (a.IsIdentity)
                {
                    if (File.Exists(path)) File.Delete(path);
                    return true;
                }

                string dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                File.WriteAllText(path, a.ToJson(), new UTF8Encoding(false));
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }
    }
}
