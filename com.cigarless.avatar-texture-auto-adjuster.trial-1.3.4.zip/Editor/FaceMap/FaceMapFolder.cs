// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapFolder.cs
using System.IO;
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMaps フォルダ（Assets/ATAA_Data/FaceMaps）の特定と自動生成。
    /// ユーザーのデータ（FaceMap・調整・生成したテクスチャとマテリアル）は、ツールのフォルダの外に置く。
    /// ツールを入れ直すとき（古いフォルダを消してから新しい版を入れる）に、一緒に消えないようにするため。
    /// 以前の場所（ツールのフォルダの中: Assets/&lt;ショップ名&gt;/AvatarTextureAutoAdjuster/FaceMaps）にあれば、
    /// MoveAsset で GUID を保ったまま移す（適用済みのアバターのマテリアル参照は切れない）。
    /// ツールの位置は、このスクリプト自身（…/Editor/FaceMap/FaceMapFolder.cs）か、配布版の DLL（…/Editor/AvatarTextureAutoAdjuster.Editor.dll）の位置から求める。
    /// </summary>
    public static class FaceMapFolder
    {
        public const string FolderName = "FaceMaps";
        /// <summary>ユーザーのデータを置くフォルダ（Assets 直下）。</summary>
        public const string DataFolderName = "ATAA_Data";
        public const string DataRoot = "Assets/" + DataFolderName;
        public const string FolderAssetPath = DataRoot + "/" + FolderName;

        /// <summary>
        /// FaceMaps フォルダを確認し、なければ作成する（以前の場所にあれば移す）。メインスレッドから呼ぶこと。
        /// </summary>
        public static bool TryEnsure(out string assetPath, out string absolutePath, out string error)
        {
            assetPath = FolderAssetPath;
            absolutePath = ToAbsolute(assetPath);
            error = null;

            if (File.Exists(ToAbsolute(DataRoot)) || File.Exists(absolutePath))
            {
                error = $"{assetPath} と同名のファイルが存在するため、フォルダを作成できません。";
                assetPath = absolutePath = null;
                return false;
            }

            string legacy = null;
            foreach (string candidate in PackageLocation.LegacyFaceMapFolders(TryGetRoot(out string root, out _) ? root : null))
            {
                if (candidate != assetPath && AssetDatabase.IsValidFolder(candidate)) { legacy = candidate; break; }
            }
            bool hasLegacy = legacy != null;

            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                // 体験版はフォルダを作らず、移しもしない（無ければファイルの FaceMap が 0 個になるだけ。保存先はメモリ）
                if (!AssetDatabase.IsValidFolder(assetPath) && hasLegacy)
                {
                    assetPath = legacy;
                    absolutePath = ToAbsolute(legacy);
                }
                return true;
            }

            if (!AssetDatabase.IsValidFolder(DataRoot)
                && string.IsNullOrEmpty(AssetDatabase.CreateFolder("Assets", DataFolderName)))
            {
                error = $"{DataRoot} を作成できませんでした（読み取り専用の場所の可能性があります）。";
                assetPath = absolutePath = null;
                return false;
            }

            if (hasLegacy) MoveLegacy(legacy, assetPath);

            if (!AssetDatabase.IsValidFolder(assetPath)
                && string.IsNullOrEmpty(AssetDatabase.CreateFolder(DataRoot, FolderName)))
            {
                error = $"{assetPath} を作成できませんでした（読み取り専用の場所の可能性があります）。";
                assetPath = absolutePath = null;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 以前の FaceMaps フォルダを新しい場所へ移す。新しい場所がまだ無ければフォルダごと移す。
        /// 両方にあるときは、新しい場所に無いものだけを 1 つずつ移し（フォルダは中へさかのぼって合わせる）、
        /// 同じ名前があるものは上書きせずに残す。空になった以前のフォルダは消す。
        /// </summary>
        private static void MoveLegacy(string from, string to)
        {
            if (!AssetDatabase.IsValidFolder(to))
            {
                string moveError = AssetDatabase.MoveAsset(from, to);
                if (string.IsNullOrEmpty(moveError))
                {
                    Debug.Log($"[ATAA] FaceMaps フォルダを {from} から {to} へ移しました（ツールを入れ直しても消えないように、ツールのフォルダの外に置きます）。");
                    return;
                }
                Debug.LogWarning($"[ATAA] FaceMaps フォルダを {from} から {to} へ移せませんでした: {moveError}");
                return;
            }

            int left = MergeInto(from, to);
            if (left == 0) AssetDatabase.DeleteAsset(from);
            else Debug.LogWarning($"[ATAA] {from} に、{to} と同じ名前のファイルが {left} 個あるため、移さずに残しました。中身を確かめて整理してください。");
        }

        /// <summary>from の中身を to へ移す。移せずに残ったファイルの数を返す。</summary>
        private static int MergeInto(string from, string to)
        {
            int left = 0;
            string absFrom = ToAbsolute(from);
            foreach (string dir in Directory.GetDirectories(absFrom))
            {
                string name = Path.GetFileName(dir);
                string src = from + "/" + name, dst = to + "/" + name;
                if (!AssetDatabase.IsValidFolder(dst))
                {
                    if (!string.IsNullOrEmpty(AssetDatabase.MoveAsset(src, dst))) left++;
                    continue;
                }
                int sub = MergeInto(src, dst);
                if (sub == 0) AssetDatabase.DeleteAsset(src);
                left += sub;
            }
            foreach (string file in Directory.GetFiles(absFrom))
            {
                if (file.EndsWith(".meta")) continue;
                string name = Path.GetFileName(file);
                string dst = to + "/" + name;
                if (File.Exists(ToAbsolute(dst)) || !string.IsNullOrEmpty(AssetDatabase.MoveAsset(from + "/" + name, dst))) left++;
            }
            return left;
        }

        /// <summary>
        /// ATAA ルート（Editor フォルダの親）の Assets 相対パスを返す。
        /// </summary>
        public static bool TryGetRoot(out string rootAssetPath, out string error)
        {
            rootAssetPath = null;
            error = null;

            // 開発中はソース（…/Editor/FaceMap/FaceMapFolder.cs）、配布版は DLL（…/Editor/<AssemblyName>.dll）が目印
            string scriptPath = FindAnchor("FaceMapFolder t:MonoScript", "/FaceMapFolder.cs")
                ?? FindAnchor(AssemblyName, "/Editor/" + AssemblyName + ".dll");

            if (scriptPath == null)
            {
                error = "ツールの場所を特定できませんでした（" + AssemblyName + ".dll が見つかりません）。";
                return false;
            }

            // 目印から "Editor" フォルダまでさかのぼり、その親を ATAA ルートとする
            string dir = Normalize(Path.GetDirectoryName(scriptPath));
            while (!string.IsNullOrEmpty(dir) && Path.GetFileName(dir) != "Editor")
                dir = Normalize(Path.GetDirectoryName(dir));

            if (string.IsNullOrEmpty(dir))
            {
                error = "ツールのフォルダ構成が想定と異なります（Editor フォルダが見つかりません）: " + scriptPath;
                return false;
            }

            rootAssetPath = Normalize(Path.GetDirectoryName(dir));
            if (string.IsNullOrEmpty(rootAssetPath))
            {
                error = "ATAA フォルダを特定できませんでした: " + scriptPath;
                return false;
            }

            return true;
        }

        /// <summary>このツールのアセンブリ名（asmdef の name・配布する DLL のファイル名）。</summary>
        private const string AssemblyName = "AvatarTextureAutoAdjuster.Editor";

        private static string FindAnchor(string filter, string pathSuffix)
        {
            foreach (string guid in AssetDatabase.FindAssets(filter))
            {
                string p = AssetDatabase.GUIDToAssetPath(guid);
                if (p.EndsWith(pathSuffix)) return p;
            }
            return null;
        }

        public static string ToAbsolute(string assetPath)
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath);
            return Path.GetFullPath(Path.Combine(projectRoot, assetPath));
        }

        private static string Normalize(string path)
        {
            return path?.Replace('\\', '/');
        }
    }
}
