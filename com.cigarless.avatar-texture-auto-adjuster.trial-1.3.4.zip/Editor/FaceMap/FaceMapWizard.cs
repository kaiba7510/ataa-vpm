// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapWizard.cs
using System;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディターの新規作成ウィザードの順序（Issue #16 §3）。副作用なし。
    /// 左右対称 ON: 鼻 → 左目（右目はミラーで自動）→ 口。
    /// 左右対称 OFF: 鼻 → 左目 → 右目 → 口。
    /// </summary>
    public static class FaceMapWizard
    {
        public const string NoseLabel = "鼻_中央";
        public const string LeftEyeLabel = "目_左";
        public const string RightEyeLabel = "目_右";
        public const string MouthLabel = "口_中央";

        /// <summary>ウィザードで次に置く領域。済んでいれば null。</summary>
        public static string NextLabel(Func<string, bool> isPlaced, bool mirror)
        {
            if (!isPlaced(NoseLabel)) return NoseLabel;
            bool left = isPlaced(LeftEyeLabel), right = isPlaced(RightEyeLabel);
            if (mirror)
            {
                if (!left && !right) return LeftEyeLabel;
            }
            else
            {
                if (!left) return LeftEyeLabel;
                if (!right) return RightEyeLabel;
            }
            if (!isPlaced(MouthLabel)) return MouthLabel;
            return null;
        }

        public static int TotalSteps(bool mirror) => mirror ? 3 : 4;

        /// <summary>label がウィザードの何番目か（1 始まり）。ウィザードの対象でなければ 0。</summary>
        public static int StepOf(string label, bool mirror)
        {
            switch (label)
            {
                case NoseLabel: return 1;
                case LeftEyeLabel: return 2;
                case RightEyeLabel: return mirror ? 0 : 3;
                case MouthLabel: return mirror ? 3 : 4;
                default: return 0;
            }
        }
    }
}
