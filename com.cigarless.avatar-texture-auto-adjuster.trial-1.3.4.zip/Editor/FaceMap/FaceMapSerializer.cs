// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapSerializer.cs
using System;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap の JSON 化と、アトミック置換での保存。Unity API には依存しない
    /// （AssetDatabase.Refresh は呼び出し側が行う）。
    /// </summary>
    public static class FaceMapSerializer
    {
        public static string ToJson(FaceMapFile file)
        {
            var root = new JObject();
            root["schemaVersion"] = FaceMapFile.CurrentSchemaVersion;
            if (!string.IsNullOrEmpty(file.Name)) root["name"] = file.Name;
            if (!string.IsNullOrEmpty(file.TargetAvatar)) root["targetAvatar"] = file.TargetAvatar;
            if (file.MetaJson != null) root["meta"] = FaceMapValidator.ParseJson(file.MetaJson);

            var points = new JArray();
            foreach (FaceMapPoint p in file.Points)
            {
                points.Add(new JObject
                {
                    ["x"] = p.X,
                    ["y"] = p.Y,
                    ["label"] = p.Label
                });
            }
            root["points"] = points;

            // 使っている分類のサイズだけを、テンプレートの定義順で書き出す
            var sizes = new JObject();
            foreach (string category in FaceTemplate.Categories())
            {
                if (!file.Sizes.TryGetValue(category, out Vector2 size)) continue;
                if (!file.Points.Exists(pt => FaceTemplate.CategoryOf(pt.Label) == category)) continue;
                var so = new JObject { ["w"] = size.x, ["h"] = size.y };
                if (category == FaceMapFile.EyeCategory && file.EyeLine.HasValue) so["line"] = file.EyeLine.Value;
                if (category == FaceMapFile.EyeCategory && file.EyeLowerLine.HasValue) so["lowerLine"] = file.EyeLowerLine.Value;
                if (category == FaceMapFile.EyeCategory && file.NoEyeOpening) so["noOpening"] = true;
                // 目の輪郭（目の輪郭リング写像の仕様 §3）。目の開いていない素体では使わないので書かない
                if (category == FaceMapFile.EyeCategory && !file.NoEyeOpening && file.EyeContourUpper != null && file.EyeContourLower != null)
                    so["contour"] = new JObject { ["upper"] = PointsToJson(file.EyeContourUpper), ["lower"] = PointsToJson(file.EyeContourLower) };
                if (category == FaceMapFile.MouthCategory && file.MouthLine.HasValue)
                {
                    // line は代表の高さ。折れ線は水平でないときだけ書く（水平なら line だけで同じ）
                    so["line"] = file.MouthLine.Value;
                    if (!MouthLineShape.IsHorizontal(file.MouthLinePoints))
                    {
                        var lp = new JArray();
                        foreach (Vector2 p in file.MouthLinePoints)
                        {
                            var pair = new JArray();
                            pair.Add(p.x);
                            pair.Add(p.y);
                            lp.Add(pair);
                        }
                        so["linePoints"] = lp;
                    }
                }
                sizes[category] = so;
            }
            root["sizes"] = sizes;

            if (file.CenterX.HasValue) root["centerX"] = file.CenterX.Value;

            return root.ToString(Formatting.Indented);
        }

        /// <summary>点の列を [[x, y], ...] にする。</summary>
        private static JArray PointsToJson(Vector2[] points)
        {
            var arr = new JArray();
            foreach (Vector2 p in points)
            {
                var pair = new JArray();
                pair.Add(p.x);
                pair.Add(p.y);
                arr.Add(pair);
            }
            return arr;
        }

        /// <summary>
        /// ファイル名に使えない文字（\ / : * ? " &lt; &gt; | など）を "_" に置き換え、拡張子 .json を除いて返す。
        /// 結果が空になる場合は空文字を返す。
        /// </summary>
        public static string SanitizeFileName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "";

            const string extra = "\\/:*?\"<>|";
            char[] invalid = Path.GetInvalidFileNameChars();

            var sb = new StringBuilder();
            foreach (char c in name.Trim())
                sb.Append(Array.IndexOf(invalid, c) >= 0 || extra.IndexOf(c) >= 0 ? '_' : c);

            string s = sb.ToString();
            if (s.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
                s = s.Substring(0, s.Length - ".json".Length);

            return s.TrimEnd('.', ' ');
        }

        /// <summary>
        /// 保存時の name を決める。新規保存・別名保存・自動生成（syncToFileName = true）、または名前が空のときは
        /// 保存先ファイル名（拡張子なし）に揃える。上書き保存で既存の非空 name があるときはそのまま保つ。
        /// </summary>
        public static string ResolveSavedName(string currentName, string savePath, bool syncToFileName)
        {
            string stem = string.IsNullOrEmpty(savePath) ? "" : Path.GetFileNameWithoutExtension(savePath);
            if (syncToFileName || string.IsNullOrWhiteSpace(currentName))
                return !string.IsNullOrEmpty(stem) ? stem : currentName;
            return currentName;
        }

        /// <summary>
        /// JSON 文字列のトップレベルに文字列の name がある場合だけ newName へ書き換える（昇格時のリネーム同期用）。
        /// 日付らしい meta の書式を壊さないよう ParseJson を使う。対象外の JSON はそのまま返す。
        /// </summary>
        public static string SyncNameInJson(string json, string newName)
        {
            if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(newName)) return json;
            try
            {
                if (!(FaceMapValidator.ParseJson(json) is JObject obj)) return json;
                if (!obj.TryGetValue("name", out JToken nt) || nt.Type != JTokenType.String) return json;
                obj["name"] = newName;
                return obj.ToString(Formatting.Indented);
            }
            catch (Exception)
            {
                return json;
            }
        }

        /// <summary>
        /// 1) シリアライズ 2) 再バリデーション 3) 一時ファイルへ書き出し 4) 正規ファイルへ置換。
        /// 失敗時は旧ファイルを保持し、呼び出し側のメモリ上データには触れない。
        /// </summary>
        public static bool TrySave(string path, FaceMapFile file, out string error)
        {
            error = null;

            string json = ToJson(file);
            FaceMapValidator.Result check = FaceMapValidator.Validate(json);
            if (!check.IsValid)
            {
                error = "保存するデータが仕様に合っていません: " + string.Join(" / ", check.Errors);
                return false;
            }

            string dir = Path.GetDirectoryName(path);
            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir))
            {
                error = "保存先フォルダが存在しません: " + dir;
                return false;
            }

            // 末尾 "~" のファイルは Unity が無視するため .meta が作られない
            string tmp = path + ".tmp~";
            try
            {
                File.WriteAllText(tmp, json, new UTF8Encoding(false));

                if (File.Exists(path))
                    File.Replace(tmp, path, null);
                else
                    File.Move(tmp, path);

                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { /* 後始末の失敗は無視 */ }
                return false;
            }
        }
    }
}
