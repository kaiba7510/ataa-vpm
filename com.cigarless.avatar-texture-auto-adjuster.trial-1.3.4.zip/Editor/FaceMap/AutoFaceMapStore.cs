// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/AutoFaceMapStore.cs
using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using UnityEditor;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 製品版だけ: 自動生成しただけの FaceMap をファイルにせず、メモリに一時保持する（FaceMaps フォルダや Git を汚さない）。
    /// パスは「ATAA-Auto/～」の仮想パス。SessionState に写すので、再コンパイル・Play モードでは消えず、Unity を閉じると消える。
    /// 実ファイルへは FaceMapStorage.TryPromote で昇格する（メイク適用時・FaceMap エディターで保存したとき）。
    /// 読み込みはワーカースレッドからも来るので lock する。書き込み（Put / Remove）はメインスレッドから呼ぶ。
    /// 体験版は従来どおり TrialStore を使うので、このクラスは入らない。
    /// </summary>
    [InitializeOnLoad]
    public static class AutoFaceMapStore
    {
        /// <summary>仮想の保存フォルダ。</summary>
        public const string Folder = "ATAA-Auto";

        private const string SessionKey = "ATAA.Auto.Store";
        private static readonly object Lock = new object();
        private static readonly Dictionary<string, Entry> Entries = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);
        private static long _lastTicks;

        private struct Entry
        {
            public string Text;
            public long Ticks;
        }

        static AutoFaceMapStore()
        {
            try
            {
                string saved = SessionState.GetString(SessionKey, "");
                if (string.IsNullOrEmpty(saved)) return;
                foreach (JProperty p in JObject.Parse(saved).Properties())
                {
                    var e = new Entry { Text = (string)p.Value["text"], Ticks = (long)p.Value["ticks"] };
                    if (e.Text == null) continue;
                    Entries[p.Name] = e;
                    _lastTicks = Math.Max(_lastTicks, e.Ticks);
                }
            }
            catch (Exception)
            {
                // 壊れていたら空から始める
                Entries.Clear();
            }
        }

        private static string Key(string path) => path?.Replace('\\', '/');

        public static bool IsVirtual(string path)
        {
            string k = Key(path);
            return k != null && k.StartsWith(Folder + "/", StringComparison.OrdinalIgnoreCase);
        }

        public static bool Exists(string path)
        {
            lock (Lock) return path != null && Entries.ContainsKey(Key(path));
        }

        public static bool TryGet(string path, out string text, out long ticks)
        {
            text = null;
            ticks = 0;
            if (path == null) return false;
            lock (Lock)
            {
                if (!Entries.TryGetValue(Key(path), out Entry e)) return false;
                text = e.Text;
                ticks = e.Ticks;
                return true;
            }
        }

        /// <summary>仮想フォルダ直下の FaceMap（.json）の仮想パス。入れ子（Adjustments/ の下）は入れない。</summary>
        public static List<string> FaceMapPaths()
        {
            var list = new List<string>();
            lock (Lock)
            {
                foreach (string k in Entries.Keys)
                {
                    string rest = k.Substring(Folder.Length + 1);
                    if (rest.IndexOf('/') < 0 && rest.EndsWith(".json", StringComparison.OrdinalIgnoreCase)) list.Add(k);
                }
            }
            list.Sort(StringComparer.OrdinalIgnoreCase);
            return list;
        }

        public static void Put(string path, string text)
        {
            if (!IsVirtual(path)) throw new ArgumentException("一時保存は仮想パス（" + Folder + "/…）にしか入れられません: " + path);
            lock (Lock)
            {
                // 更新日時は単調に増やす（PairKey・一覧の並びが変化に気付けるように）
                _lastTicks = Math.Max(_lastTicks + 1, DateTime.UtcNow.Ticks);
                Entries[Key(path)] = new Entry { Text = text, Ticks = _lastTicks };
            }
            Persist();
        }

        public static void Remove(string path)
        {
            bool removed;
            lock (Lock) removed = path != null && Entries.Remove(Key(path));
            if (removed) Persist();
        }

        /// <summary>全部消す（テスト・やり直し用）。</summary>
        public static void Clear()
        {
            lock (Lock) Entries.Clear();
            Persist();
        }

        private static void Persist()
        {
            var root = new JObject();
            lock (Lock)
            {
                foreach (KeyValuePair<string, Entry> kv in Entries)
                    root[kv.Key] = new JObject { ["text"] = kv.Value.Text, ["ticks"] = kv.Value.Ticks };
            }
            SessionState.SetString(SessionKey, root.ToString(Newtonsoft.Json.Formatting.None));
        }
    }
}
