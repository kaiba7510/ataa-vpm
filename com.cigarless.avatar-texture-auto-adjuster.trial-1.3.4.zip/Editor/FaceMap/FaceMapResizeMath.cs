// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapResizeMath.cs
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディターの枠のサイズ変更の計算（副作用なし）。
    /// sign はつかんだハンドルの向き（UV で右・上が +1）。四隅は (±1, ±1)、辺の中点のつまみは片方が 0 で、0 の軸は動かさない。
    /// </summary>
    public static class FaceMapResizeMath
    {
        /// <summary>固定する点（つかんだハンドルの反対側）。0 の軸は中心のまま。</summary>
        public static Vector2 Anchor(Vector2 center, Vector2 size, Vector2 sign) =>
            center - Vector2.Scale(sign, size) * 0.5f;

        /// <summary>
        /// 反対側を固定したときの新しいサイズ。0 の軸は startSize のまま。
        /// 反対側を越えると負になる（最小サイズで止めるのは呼び出し側の SetSize）。
        /// </summary>
        public static Vector2 DesiredSize(Vector2 anchor, Vector2 sign, Vector2 uv, Vector2 startSize) =>
            new Vector2(
                sign.x != 0f ? (uv.x - anchor.x) * sign.x : startSize.x,
                sign.y != 0f ? (uv.y - anchor.y) * sign.y : startSize.y);

        /// <summary>中心を固定したとき（Shift）の新しいサイズ（中心からの距離の 2 倍）。0 の軸は startSize のまま。</summary>
        public static Vector2 CenterFixedSize(Vector2 center, Vector2 sign, Vector2 uv, Vector2 startSize) =>
            new Vector2(
                sign.x != 0f ? Mathf.Abs(uv.x - center.x) * 2f : startSize.x,
                sign.y != 0f ? Mathf.Abs(uv.y - center.y) * 2f : startSize.y);

        /// <summary>反対側を固定したまま size にしたときの中心。0 の軸は anchor（= 開始時の中心）のまま。</summary>
        public static Vector2 CenterFor(Vector2 anchor, Vector2 sign, Vector2 size) =>
            anchor + Vector2.Scale(sign, size) * 0.5f;

        /// <summary>四隅のハンドルか（辺の中点のつまみでないか）。</summary>
        public static bool IsCorner(Vector2 sign) => sign.x != 0f && sign.y != 0f;

        /// <summary>ハンドルの上に出すカーソル。</summary>
        public static MouseCursor CursorFor(Vector2 sign)
        {
            if (sign.y == 0f) return MouseCursor.ResizeHorizontal;
            if (sign.x == 0f) return MouseCursor.ResizeVertical;
            // UV の右上・左下はスクリーンでも右上・左下（UV は上が +）
            return sign.x * sign.y > 0f ? MouseCursor.ResizeUpRight : MouseCursor.ResizeUpLeft;
        }
    }
}
