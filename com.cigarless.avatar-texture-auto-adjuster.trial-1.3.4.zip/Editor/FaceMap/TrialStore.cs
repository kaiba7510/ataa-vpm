// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/TrialStore.cs
using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using UnityEditor;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 体験版だけ: ファイルの代わりに FaceMap・微調整の JSON をメモリに持つ。
    /// パスは「ATAA-Trial/～」の仮想パス（実在のパスは絶対パスなので混ざらない）。
    /// SessionState に写すので、再コンパイル・Play モードのドメインリロードでは消えず、Unity を閉じると消える。
    /// 読み込みはワーカースレッドからも来るので lock する。書き込み（Put / Remove）はメインスレッドから呼ぶ。
    /// </summary>
    [InitializeOnLoad]
    internal static class TrialStore
    {
        /// <summary>仮想の FaceMaps フォルダ。Path.Combine で作ったパスもそのまま使える。</summary>
        public const string Folder = "ATAA-Trial";

        private const string SessionKey = "ATAA.Trial.Store";
        private static readonly object Lock = new object();
        private static readonly Dictionary<string, Entry> Entries = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);
        private static long _lastTicks;

        private struct Entry
        {
            public string Text;
            public long Ticks;
        }

        static TrialStore()
        {
            try
            {
                string saved = SessionState.GetString(SessionKey, "");
                if (string.IsNullOrEmpty(saved)) return;
                foreach (JProperty p in JObject.Parse(saved).Properties())
                {
                    var e = new Entry { Text = (string)p.Value["text"], Ticks = (long)p.Value["ticks"] };
                    if (e.Text == null) continue;
                    Entries[p.Name] = e;
                    _lastTicks = Math.Max(_lastTicks, e.Ticks);
                }
            }
            catch (Exception)
            {
                // 壊れていたら空から始める
                Entries.Clear();
            }
        }

        private static string Key(string path) => path?.Replace('\\', '/');

        public static bool IsVirtual(string path)
        {
            string k = Key(path);
            return k != null && k.StartsWith(Folder + "/", StringComparison.OrdinalIgnoreCase);
        }

        public static bool Exists(string path)
        {
            lock (Lock) return path != null && Entries.ContainsKey(Key(path));
        }

        public static bool TryGet(string path, out string text, out long ticks)
        {
            text = null;
            ticks = 0;
            if (path == null) return false;
            lock (Lock)
            {
                if (!Entries.TryGetValue(Key(path), out Entry e)) return false;
                text = e.Text;
                ticks = e.Ticks;
                return true;
            }
        }

        /// <summary>仮想フォルダ直下の FaceMap（.json）の仮想パス。微調整（Adjustments/ の下）は入れない。</summary>
        public static List<string> FaceMapPaths()
        {
            var list = new List<string>();
            lock (Lock)
            {
                foreach (string k in Entries.Keys)
                {
                    string rest = k.Substring(Folder.Length + 1);
                    if (rest.IndexOf('/') < 0 && rest.EndsWith(".json", StringComparison.OrdinalIgnoreCase)) list.Add(k);
                }
            }
            list.Sort(StringComparer.OrdinalIgnoreCase);
            return list;
        }

        public static void Put(string path, string text)
        {
            if (!IsVirtual(path)) throw new ArgumentException("体験版では仮想パスにしか保存できません: " + path);
            lock (Lock)
            {
                // 更新日時は単調に増やす（PairKey・一覧の並びが変化に気付けるように）
                _lastTicks = Math.Max(_lastTicks + 1, DateTime.UtcNow.Ticks);
                Entries[Key(path)] = new Entry { Text = text, Ticks = _lastTicks };
            }
            Persist();
        }

        public static void Remove(string path)
        {
            bool removed;
            lock (Lock) removed = path != null && Entries.Remove(Key(path));
            if (removed) Persist();
        }

        private static void Persist()
        {
            var root = new JObject();
            lock (Lock)
            {
                foreach (KeyValuePair<string, Entry> kv in Entries)
                    root[kv.Key] = new JObject { ["text"] = kv.Value.Text, ["ticks"] = kv.Value.Ticks };
            }
            SessionState.SetString(SessionKey, root.ToString(Newtonsoft.Json.Formatting.None));
        }
    }
}
