// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceLabel.cs
using System;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap の label ("分類_部位", 例: "目_左外側") の組み立て・解析。副作用なし。
    /// </summary>
    public static class FaceLabel
    {
        public const char Separator = '_';

        /// <summary>分類の一覧（エディターの入力支援と色分けに使う）。</summary>
        public static readonly string[] Categories = { "目", "鼻", "口", "頬", "顎" };

        public static string Build(string category, string part)
        {
            return category + Separator + part;
        }

        /// <summary>
        /// 推奨形式（既知の分類 + "_" + 空でない部位名）なら true。
        /// </summary>
        public static bool TryParse(string label, out string category, out string part)
        {
            category = null;
            part = null;
            if (string.IsNullOrEmpty(label)) return false;

            int idx = label.IndexOf(Separator);
            if (idx <= 0 || idx >= label.Length - 1) return false;

            string c = label.Substring(0, idx);
            if (Array.IndexOf(Categories, c) < 0) return false;

            category = c;
            part = label.Substring(idx + 1);
            return true;
        }

        public static bool IsRecommendedFormat(string label)
        {
            return TryParse(label, out _, out _);
        }

        /// <summary>
        /// label から分類を取り出す。推奨形式でなければ null。
        /// </summary>
        public static string GetCategory(string label)
        {
            return TryParse(label, out string category, out _) ? category : null;
        }
    }
}
