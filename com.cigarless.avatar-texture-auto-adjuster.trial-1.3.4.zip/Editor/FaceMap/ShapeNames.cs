// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/ShapeNames.cs
using System.Collections.Generic;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>ブレンドシェイプ名の判定（名前だけで決まる部分。テストのため Mesh から切り離している）。</summary>
    internal static class ShapeNames
    {
        // 区切りに使われる文字の並び。半角・全角の記号と罫線（─ ━ など）
        private static readonly string[] SeparatorRuns =
        {
            "---", "===", "***", "___", "~~~",
            "───", "━━━", "═══", "＝＝＝", "＊＊＊", "－－－", "ーーー", "▬▬▬", "■■■"
        };

        /// <summary>区切り（動かないシェイプを見出しにしたもの）らしい名前か。</summary>
        public static bool IsSeparator(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            foreach (string run in SeparatorRuns)
                if (name.Contains(run)) return true;
            return false;
        }

        /// <summary>patterns を優先順に、名前（前後の空白と大文字小文字を除く）が一致する最初の番号。無ければ -1。</summary>
        public static int FindExact(IReadOnlyList<string> names, string[] patterns)
        {
            if (names == null || patterns == null) return -1;
            foreach (string p in patterns)
                for (int k = 0; k < names.Count; k++)
                    if (names[k] != null && names[k].Trim().ToLowerInvariant() == p) return k;
            return -1;
        }

        /// <summary>名前（前後の空白と大文字小文字を除く）に patterns のいずれかを含む最初の番号。無ければ -1。</summary>
        public static int FindContains(IReadOnlyList<string> names, string[] patterns)
        {
            if (names == null || patterns == null) return -1;
            for (int k = 0; k < names.Count; k++)
            {
                if (names[k] == null) continue;
                string n = names[k].Trim().ToLowerInvariant();
                foreach (string p in patterns)
                    if (n.Contains(p)) return k;
            }
            return -1;
        }
    }
}
