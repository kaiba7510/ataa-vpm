// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapMeta.cs
using System.Collections.Generic;

namespace AvatarTextureAutoAdjuster.Editor
{
    // FaceMap の一覧表示用（UI 側。コアの計算は使わない。docs~/コアとUIの分割_設計メモ.md 手順 4a）
    public enum FaceMapStatus
    {
        Valid,
        Invalid
    }

    /// <summary>一覧表示用の軽量情報。points 本体は持たない。</summary>
    public class FaceMapMeta
    {
        public string FilePath;
        public string FileName;

        /// <summary>走査時点のファイル更新日時（UTC ticks）。内容が変わったかの判定に使う。</summary>
        public long LastWriteTicks;

        public string DisplayName;
        public string TargetAvatar;
        public int PointCount;
        public int? SchemaVersion;
        public FaceMapStatus Status = FaceMapStatus.Invalid;
        public List<string> Errors = new List<string>();
        public List<string> Warnings = new List<string>();

        /// <summary>前回この FaceMap で使った顔テクスチャ（meta.faceTexture。無ければ null）。</summary>
        public string FaceTextureName;
        public string FaceTextureGuid;

        public bool IsValid => Status == FaceMapStatus.Valid;
    }
}
