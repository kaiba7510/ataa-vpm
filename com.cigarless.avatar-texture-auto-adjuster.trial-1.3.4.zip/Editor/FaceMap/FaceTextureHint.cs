// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceTextureHint.cs
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap の meta に「前回使った顔テクスチャ」を残す・読む（meta.faceTexture = { name, guid }）。
    /// meta はスキーマ外の自由欄なので、古いバージョンのツールでも警告にならず、上書き保存でも消えない。
    /// GUID は同じプロジェクト内、name はプロジェクトが変わったとき（GUID が違う）の手がかりに使う。
    /// Unity API には依存しない（ワーカースレッドの走査からも呼ぶ）。
    /// </summary>
    public static class FaceTextureHint
    {
        public const string Key = "faceTexture";

        /// <summary>meta の JSON（FaceMapFile.MetaJson）から faceTexture を読む。無い・壊れているときは両方 null。</summary>
        public static void Read(string metaJson, out string name, out string guid)
        {
            name = null;
            guid = null;
            if (!(TryParse(metaJson) is JObject obj) || !(obj[Key] is JObject ft)) return;
            if (ft["name"] is JValue n && n.Type == JTokenType.String) name = (string)n;
            if (ft["guid"] is JValue g && g.Type == JTokenType.String) guid = (string)g;
            if (string.IsNullOrEmpty(name)) name = null;
            if (string.IsNullOrEmpty(guid)) guid = null;
        }

        /// <summary>meta に faceTexture を書き込んだ JSON を返す（元の文字列は変えない。meta がオブジェクトでなければ作り直す）。</summary>
        public static string With(string metaJson, string name, string guid)
        {
            JObject obj = TryParse(metaJson) as JObject ?? new JObject();
            obj[Key] = new JObject { ["name"] = name ?? "", ["guid"] = guid ?? "" };
            return obj.ToString(Formatting.None);
        }

        private static JToken TryParse(string json)
        {
            if (string.IsNullOrEmpty(json)) return null;
            try { return FaceMapValidator.ParseJson(json); }
            catch (JsonException) { return null; }
        }
    }
}
