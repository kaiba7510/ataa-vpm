using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── 右ペイン: ステップ集計・調整レイヤー計算・履歴管理 ──

        private const int TotalSteps = 6;

        /// <summary>回転の 1 ステップ（度）。ドラッグでは 5 ピクセルで 1 ステップ。</summary>
        private const float RotationStep = 1f;

        /// <summary>済んだステップの数（①〜⑥。カードのステップ番号の緑と同じ判定）。</summary>
        private int CountDoneSteps()
        {
            bool avatar = ItemsOk(3);
            int n = 0;
            if (avatar) n++;                                   // ① アバター
            if (avatar && _state.FaceRenderer != null) n++;    // ② 顔メッシュ
            if (ItemsOk(2)) n++;                               // ③ アバター基準
            if (ItemsOk(4, 6)) n++;                            // ④ 顔テクスチャ
            if (ItemsOk(1, 5)) n++;                            // ⑤ メイク元
            if (_allOk) n++;                                   // ⑥ 調整（対応付け・合成するパーツ）
            return n;
        }

        /// <summary>指定した番号の項目のうち、最初の ✗。</summary>
        private ReadinessItem FirstFailedOf(params int[] numbers)
        {
            foreach (ReadinessItem it in _readiness)
            {
                if (!it.Ok && System.Array.IndexOf(numbers, it.Number) >= 0) return it;
            }
            return null;
        }

        private void SetGap(FaceMapTransform layer, float gap, float minGap)
        {
            float next = AtaaCore.ClampGap(gap, minGap);
            if (Mathf.Approximately(next, layer.Gap)) return;
            layer.Gap = next;
            MarkAdjustmentChanged();
        }

        /// <summary>
        /// 調整の変更を反映する。ボタン・スライダーを操作中（押し続け・ドラッグ中）は保存を後回しにし、
        /// 操作が終わったときに 1 回だけ保存する（FlushPendingSave）。元に戻す（Ctrl+Z）の履歴にも記録する。
        /// </summary>
        private void MarkAdjustmentChanged(string undoName = "調整を変更") => ApplyAdjustmentChange(true, undoName);

        private void ApplyAdjustmentChange(bool recordHistory, string undoName = null)
        {
            if (recordHistory) RecordHistory(undoName);
            AtaaCore.ApplyEyeLineOverrides(_state.PairMatch, _state.Adjustment);
            InvalidatePreview();
            _orbit?.MarkDirty();
            if (IsInteracting)
            {
                _pendingSave = true;
                return;
            }
            _pendingSave = false;
            _toolService.SaveAdjustment();
        }

        /// <summary>元に戻す（Ctrl+Z）の履歴に、今の調整とメイクの濃さを記録する。操作中の変更は 1 回にまとめる。</summary>
        private void RecordHistory(string undoName)
        {
            SyncHistoryBaseline();
            _history.Commit(undoName ?? "調整を変更", _state.PairKey, _state.Adjustment, _state.PreviewMakeupOpacity, IsInteracting);
        }

        /// <summary>組み合わせ・調整が差し替わっていたら（読み込み・切り替え）、履歴を消して今の状態を起点にする。</summary>
        private void SyncHistoryBaseline()
        {
            if (ReferenceEquals(_state.Adjustment, _historyAdjustment) && _state.PairKey == _historyPairKey) return;
            _historyAdjustment = _state.Adjustment;
            _historyPairKey = _state.PairKey;
            _history.Reset(_state.PairKey, _state.Adjustment, _state.PreviewMakeupOpacity);
        }

        /// <summary>後回しにした保存があれば保存する。</summary>
        private void FlushPendingSave()
        {
            _history.EndGesture();
            if (!_pendingSave) return;
            _pendingSave = false;
            _toolService?.SaveAdjustment();
        }

        private bool _pendingSave;

        private const string AllTargetName = "全体";

        private string EditTargetName => _editTarget ?? AllTargetName;

        /// <summary>いま編集している層（全体 or パーツ）。</summary>
        private FaceMapTransform EditLayer(FaceMapAdjustment adj)
        {
            return _editTarget == null ? adj.Global : adj.GetPart(_editTarget);
        }

        // 編集している層の外側に掛かる変換（パーツを編集中なら全体の調整、全体なら無し）

        private Vector2 OuterScale(FaceMapAdjustment adj) => _editTarget == null ? Vector2.one : adj.Global.Scale;

        private Vector2 OuterApply(FaceMapAdjustment adj, Vector2 p, Vector2 globalPivot) =>
            _editTarget == null ? p : adj.Global.Apply(p, globalPivot);

        private Vector2 OuterInverse(FaceMapAdjustment adj, Vector2 p, Vector2 globalPivot) =>
            _editTarget == null ? p : adj.Global.Inverse(p, globalPivot);

        /// <summary>編集している層の枠（調整後、UV）。baseBounds はその層の調整前の外接矩形。</summary>
        private void GetEditBox(FaceMapMatch match, FaceMapAdjustment adj,
                                out Rect baseBounds, out Vector2 globalPivot, out Vector2 boxCenter, out Vector2 boxSize)
        {
            baseBounds = AtaaCore.GetAvatarBounds(match, _editTarget);
            globalPivot = AtaaCore.GetAvatarBounds(match).center;
            FaceMapTransform layer = EditLayer(adj);
            boxCenter = OuterApply(adj, baseBounds.center + layer.Offset, globalPivot);
            boxSize = Vector2.Scale(Vector2.Scale(baseBounds.size, layer.Scale), OuterScale(adj))
                      + new Vector2(LayerGap(layer) * OuterScale(adj).x, 0f);
        }

        /// <summary>編集中の層の左右の間隔（左右ペアのパーツのときだけ。それ以外は 0）。</summary>
        private float LayerGap(FaceMapTransform layer) =>
            _editTarget != null && IsPairCategory(_editTarget) ? layer.Gap : 0f;

        private static bool IsPairCategory(string category) =>
            category != null && FaceMapMirror.IsPair(FaceMapMirror.PairLabel(category, true));

        private static bool IsCenterCategory(string category) =>
            category != null && FaceMapMirror.IsCenterPart(category + "_中央");
    }
}
