using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 自動セットアップ: シーン内のアクティブなアバターを 1 フレーム 1 体ずつ解析して、アバター基準を一時データ（ATAA-Auto/）に作る。
    /// ダイアログは出さない。失敗・目の線の要確認はアバターごとの結果として持ち、選択中のアバターには警告で知らせる。
    /// 判断（対象の選別・順番・再生成するか）は MakeFixAutoSetup に置く。
    /// </summary>
    public partial class MakeFixWindow
    {
        /// <summary>アバター 1 体分の自動生成の結果。</summary>
        internal class AutoResult
        {
            /// <summary>作った FaceMap のパス（失敗なら null）。</summary>
            public string Path;
            /// <summary>失敗した理由（成功なら null）。</summary>
            public string Error;
            /// <summary>目の線を自動で決められなかった理由（問題なしなら null）。</summary>
            public string EyeLineIssue;
        }

        private readonly Dictionary<int, AutoResult> _autoResults = new Dictionary<int, AutoResult>();
        private List<string> _autoQueue = new List<string>();
        private bool _autoQueueDirty = true;
        private bool _autoWasScanning = true;
        private bool _autoSelectTried;
        private int _autoBatchDone;
        private int _autoBatchTotal;

        /// <summary>顔メッシュを選び直したが、保存済みのアバター基準は上書きしなかった（③に「作り直す」案内を出す）。</summary>
        internal bool MeshChangeOffer { get; private set; }

        /// <summary>左ペイン上部・ステータスバーに出す解析中の文言（解析中でなければ空）。</summary>
        internal string AutoProgressText => MakeFixAutoSetup.ProgressText(_autoBatchDone, _autoBatchTotal);

        /// <summary>このアバターの自動生成の結果（まだなら null）。</summary>
        internal AutoResult AutoResultOf(GameObject avatar) =>
            avatar != null && _autoResults.TryGetValue(avatar.GetInstanceID(), out AutoResult r) ? r : null;

        private static string AutoKey(GameObject avatar) => avatar.GetInstanceID().ToString();

        private void MarkAutoQueueDirty() => _autoQueueDirty = true;

        /// <summary>EditorApplication.update から毎フレーム呼ぶ。1 回に 1 体だけ生成する（フリーズ防止）。</summary>
        private void TickAutoSetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling) return;

            // 一覧の走査が終わるまでは、既存の FaceMap があるか分からないので待つ
            bool scanning = _state.IsScanning || string.IsNullOrEmpty(_state.FaceMapFolderPath);
            if (_autoWasScanning && !scanning) _autoQueueDirty = true;
            _autoWasScanning = scanning;
            if (scanning) return;

            if (_autoQueueDirty)
            {
                _autoQueueDirty = false;
                RebuildAutoQueue();
            }
            if (_autoQueue.Count == 0) return;

            string key = _autoQueue[0];
            _autoQueue.RemoveAt(0);
            GameObject avatar = _sceneAvatars.Find(a => a != null && AutoKey(a) == key);
            if (avatar != null) AutoGenerate(avatar);
            _autoBatchDone++;

            if (_autoQueue.Count == 0)
            {
                _autoBatchDone = _autoBatchTotal = 0;
                RequestRefresh();
            }
            MarkUiDirty();
        }

        private void RebuildAutoQueue()
        {
            var candidates = new List<MakeFixAutoSetup.Candidate>();
            foreach (GameObject avatar in _sceneAvatars)
            {
                if (avatar == null) continue;
                FaceMapMeta existing = FindAvatarFaceMap(avatar);
                bool isDraft = existing != null && FaceMapStorage.IsDraft(existing.FilePath);
                candidates.Add(new MakeFixAutoSetup.Candidate
                {
                    Key = AutoKey(avatar),
                    Active = avatar.activeInHierarchy,
                    HasSavedFaceMap = existing != null && !isDraft,
                    // 一時データが残っている（再コンパイル後など）・生成を試した（失敗も）なら、また作らない
                    Analyzed = isDraft || _autoResults.ContainsKey(avatar.GetInstanceID()),
                });
            }

            string selectedKey = _state.TargetAvatar != null ? AutoKey(_state.TargetAvatar) : null;
            _autoQueue = MakeFixAutoSetup.BuildQueue(candidates, selectedKey);
            _autoBatchTotal = _autoQueue.Count == 0 ? 0 : _autoBatchDone + _autoQueue.Count;
            if (_autoQueue.Count == 0) _autoBatchDone = 0;
        }

        /// <summary>
        /// ダイアログ無しで、このアバターのアバター基準を一時データに作る（作り直しは同じ名前で上書き）。
        /// 選択中のアバターなら、顔メッシュ・顔テクスチャ・アバター基準の選択も更新する。
        /// </summary>
        private AutoResult AutoGenerate(GameObject avatar)
        {
            bool isSelected = ReferenceEquals(avatar, _state.TargetAvatar);
            var outcome = new AutoResult();
            _autoResults[avatar.GetInstanceID()] = outcome;

            SkinnedMeshRenderer smr = isSelected && _state.FaceRenderer != null
                ? _state.FaceRenderer
                : AvatarFaceMapGenerator.GuessRenderer(avatar, isSelected ? _state.PreviewAvatarTexture : null);
            Mesh mesh = smr != null ? smr.sharedMesh : null;
            int blink = AvatarFaceMapGenerator.GuessBlink(mesh);
            int mouth = AvatarFaceMapGenerator.GuessMouth(mesh);
            if (smr == null || blink < 0)
            {
                outcome.Error = "顔メッシュにまばたきのブレンドシェイプが見つかりません。";
                if (isSelected) SetAutoWarning("アバター基準を自動認識できませんでした: " + outcome.Error, MessageType.Warning);
                return outcome;
            }

            AvatarFaceMapGenerator.AvatarResult result = AvatarFaceMapGenerator.Generate(smr, blink, mouth);
            if (!result.Success)
            {
                outcome.Error = result.Error;
                if (isSelected) SetAutoWarning("アバター基準を自動認識できませんでした: " + result.Error, MessageType.Warning);
                return outcome;
            }

            string baseName = FaceMapSerializer.SanitizeFileName(avatar.name);
            if (string.IsNullOrEmpty(baseName)) baseName = "avatar";
            string path = FaceMapStorage.AutoSaveFolder + "/" + baseName + ".json";
            Texture2D usedTex = isSelected && _state.PreviewAvatarTexture != null
                ? _state.PreviewAvatarTexture
                : (result.FaceTexture as Texture2D) ?? GuessFaceTexture(smr);
            FaceMapFile file = BuildAutoFaceMapFile(avatar, result, null, usedTex, path);
            if (!FaceMapStorage.TrySave(path, file, out string saveError))
            {
                outcome.Error = saveError;
                if (isSelected) SetAutoWarning("アバター基準を保存できませんでした: " + saveError, MessageType.Error);
                return outcome;
            }

            outcome.Path = path;
            outcome.EyeLineIssue = result.EyeLineIssue;

            if (isSelected)
            {
                if (_faceCandidates.Contains(smr)) _state.FaceRenderer = smr;
                if (_state.PreviewAvatarTexture == null && usedTex != null) _state.PreviewAvatarTexture = usedTex;
                _state.AvatarFaceMapPath = path;
                _slotsDirty = true;
                if (result.EyeLineIssue != null)
                    SetAutoWarning($"目の線を自動で決められませんでした: {result.EyeLineIssue}\nFaceMap エディターで確かめてください。", MessageType.Warning);
                else if (result.CheckLabels.Count > 0)
                    SetAutoWarning($"自動認識しました。要確認: {string.Join("・", result.CheckLabels)}", MessageType.Info);
            }
            RequestRefresh();
            return outcome;
        }

        private void SetAutoWarning(string message, MessageType type)
        {
            _state.Warning = message;
            _state.WarningType = type;
        }

        /// <summary>未選択でアクティブなアバターが 1 体だけなら、それを選ぶ（シーンにアバターが現れた最初の 1 回だけ）。</summary>
        private void TryAutoSelectSingleAvatar()
        {
            if (_autoSelectTried || _sceneAvatars.Count == 0) return;
            _autoSelectTried = true;

            List<GameObject> active = _sceneAvatars.Where(a => a != null && a.activeInHierarchy).ToList();
            if (MakeFixAutoSetup.ShouldAutoSelectSingle(active.Count, _state.TargetAvatar != null))
                _state.TargetAvatar = active[0];
        }

        /// <summary>「おかしい場合は手動変更」を開いている。ヘッダーの「あと N ステップ」で左ペインへ飛んだときも開く。</summary>
        private bool _manualCardsOpen;

        /// <summary>選択中のアバターについて、②〜④を開く理由になる状態（手動・ジャンプは含まない）。</summary>
        private MakeFixAutoSetup.CardState ComputeProblemState()
        {
            GameObject target = _state.TargetAvatar;
            AutoResult r = AutoResultOf(target);
            bool pending = target != null && r == null && _autoQueue.Contains(AutoKey(target));
            FaceMapMeta map = _state.AvatarFaceMap;
            return new MakeFixAutoSetup.CardState
            {
                FaceMeshMissing = _state.FaceRenderer == null || (r != null && r.Error != null && map == null),
                EyeLineIssue = r != null && r.EyeLineIssue != null && r.Path == _state.AvatarFaceMapPath,
                BaseMissing = map == null && !_state.IsScanning && !pending,
                BaseWarning = _avatarNotes.Count > 0 || (map != null && !map.IsValid),
                FaceTextureProblem = _state.PreviewAvatarTexture == null || !ItemsOk(6),
            };
        }

        /// <summary>アバター一覧の状態ドット（緑: 準備 OK / 橙: 要確認 / 灰: 未解析）。</summary>
        private MakeFixAutoSetup.AvatarStatus AvatarStatusOf(GameObject avatar)
        {
            FaceMapMeta map = FindAvatarFaceMap(avatar);
            AutoResult r = AutoResultOf(avatar);
            bool problem = (map != null && !map.IsValid)
                           || (r != null && r.EyeLineIssue != null && map != null && r.Path == map.FilePath);
            bool analyzed = r != null || (map != null && FaceMapStorage.IsDraft(map.FilePath));
            return MakeFixAutoSetup.StatusOf(map != null && map.IsValid, analyzed, problem);
        }

        /// <summary>③の「FaceMap エディターで微調整」。目の線が要確認ならその案内つきで開く。</summary>
        private void OpenFaceMapEditorForCurrent()
        {
            string path = _state.AvatarFaceMapPath;
            if (string.IsNullOrEmpty(path) || _state.TargetAvatar == null) return;

            AutoResult r = AutoResultOf(_state.TargetAvatar);
            if (r != null && r.EyeLineIssue != null && r.Path == path)
                MyVrcToolFaceMapEditorWindow.OpenForEyeLineReview(path, _state.TargetAvatar, _state.FaceRenderer, _state.PreviewAvatarTexture, r.EyeLineIssue);
            else
                MyVrcToolFaceMapEditorWindow.OpenForRefinement(path, _state.TargetAvatar, _state.FaceRenderer, _state.PreviewAvatarTexture);
        }

        /// <summary>②で顔メッシュを選び直したとき、一時生成のアバター基準なら作り直し、保存済みなら案内だけにする。</summary>
        private void OnFaceRendererChangedByUser()
        {
            GameObject avatar = _state.TargetAvatar;
            if (avatar == null) return;

            MeshChangeOffer = false;
            MakeFixAutoSetup.MeshChangeAction action = MakeFixAutoSetup.OnFaceMeshChanged(
                hasBase: _state.AvatarFaceMap != null,
                baseIsDraft: FaceMapStorage.IsDraft(_state.AvatarFaceMapPath));

            if (action == MakeFixAutoSetup.MeshChangeAction.Regenerate)
            {
                // 新しいメッシュのテクスチャを推定し直してから、そのメッシュで基準を作り直す
                _state.PreviewAvatarTexture = GuessFaceTexture(_state.FaceRenderer);
                AutoGenerate(avatar);
            }
            else if (action == MakeFixAutoSetup.MeshChangeAction.Offer)
            {
                MeshChangeOffer = true;
            }
        }
    }
}
