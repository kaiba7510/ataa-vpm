using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MyVrcToolFaceMapEditorWindow
    {
        // ── 3D ビュー（目の線のマーカー。自動ポインティング仕様 §11.22）。描画と操作は IMGUIContainer ──

        private VisualElement _pane3D;
        private IMGUIContainer _view3DImgui;
        private bool _show3D;
        private bool _focusEyesPending;
        private FaceOrbitView _orbit;
        private readonly EyeLineMarkers3D _markers = new EyeLineMarkers3D();
        private SkinnedMeshRenderer _markerRenderer;
        private int _markerBlink = int.MinValue, _markerMouth = int.MinValue;
        private string _orbitMessage;
        private bool _show3DFrames = true; // 3D ビューに各パーツの枠を描く
        private readonly List<EyeLineMarkers3D.Frame> _frames3D = new List<EyeLineMarkers3D.Frame>();

        private void Bind3DUi()
        {
            _pane3D = _root.Q<VisualElement>("fm-3d");
            _view3DImgui = _root.Q<IMGUIContainer>("fm-3d-imgui");
            _view3DImgui.onGUIHandler = Draw3DPane;
            Set3DVisible(_show3D);
        }

        private void Set3DVisible(bool show)
        {
            _show3D = show;
            _pane3D?.EnableInClassList("hidden", !show);
            if (show) _view3DImgui?.MarkDirtyRepaint();
        }

        /// <summary>
        /// アバターの顔を 3D で表示し、目の線・目の下の線を顔の上に重ねる。
        /// 3D の画はカメラを動かしたときだけ描き直し（FaceOrbitView のキャッシュ）、線は画の上に GUI で重ねるだけなので、
        /// テクスチャ上でつまみをドラッグしても 3D の描き直しは起きない。
        /// </summary>
        private void Draw3DPane()
        {
            bool ready = PrepareOrbit();

            // ボタンの数は ready に関係なく同じにする（Layout と Repaint でコントロール数を揃える）
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("3D ビュー", EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            using (new EditorGUI.DisabledScope(!ready))
            {
                if (GUILayout.Button(new GUIContent("目に寄る", "両目が入るように、正面から目に寄せます。"), EditorStyles.miniButtonLeft, GUILayout.Width(56f)))
                {
                    _focusEyesPending = true;
                    _view3DImgui.MarkDirtyRepaint();
                }
                if (GUILayout.Button(new GUIContent("正面", "顔の正面に戻します。アバターのポーズや位置を変えたときは、これで顔を取り直します。"),
                        EditorStyles.miniButtonMid, GUILayout.Width(40f)))
                {
                    _orbit.ResetToFront();
                    _markers.Rebake();
                    _view3DImgui.MarkDirtyRepaint();
                }
                bool hide = GUILayout.Toggle(_orbit.HideDecorations, new GUIContent("前髪等を隠す", "顔のレンダラー以外（前髪・メガネ・服など）を描きません。"),
                    EditorStyles.miniButtonRight, GUILayout.Width(80f));
                if (hide != _orbit.HideDecorations)
                {
                    _orbit.HideDecorations = hide;
                    _view3DImgui.MarkDirtyRepaint();
                }
                bool frames = GUILayout.Toggle(_show3DFrames, new GUIContent("枠", "目・鼻・口・頬などの枠を、顔の上に描きます。"),
                    EditorStyles.miniButton, GUILayout.Width(28f));
                if (frames != _show3DFrames)
                {
                    _show3DFrames = frames;
                    _view3DImgui.MarkDirtyRepaint();
                }
            }
            EditorGUILayout.EndHorizontal();

            Rect rect = GUILayoutUtility.GetRect(GUIContent.none, GUIStyle.none, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
            if (ready)
            {
                if (_orbit.HandleInput(rect)) _view3DImgui.MarkDirtyRepaint();
                UpdateMarkers();
                if (_focusEyesPending && Event.current.type == EventType.Repaint)
                {
                    _focusEyesPending = false;
                    FocusEyes();
                }
                _orbit.Draw(rect);
                _markers.Draw(_orbit, rect);
            }
            else if (Event.current.type == EventType.Repaint)
            {
                EditorGUI.DrawRect(rect, new Color(0.125f, 0.125f, 0.125f, 1f));
                GUI.Label(new Rect(rect.x + 12f, rect.y, rect.width - 24f, rect.height), _orbitMessage, EditorStyles.wordWrappedMiniLabel);
            }

            GUILayout.Label("黄: 目の線　緑: 目の下の線　桃: 口の線　枠: 各パーツ（選択中は黄）\n右ドラッグ: 回転　中ドラッグ: 移動　ホイール: ズーム", EditorStyles.centeredGreyMiniLabel);
        }

        /// <summary>3D ビューに映すアバターと、線を載せる顔を用意する。用意できなければ理由を _orbitMessage に入れて false。</summary>
        private bool PrepareOrbit()
        {
            if (_orbit == null) _orbit = new FaceOrbitView();
            _vm.RefreshAutoInputs();
            GameObject avatar = _vm.State.TargetAvatarObject;
            SkinnedMeshRenderer smr = _vm.AutoRenderer;
            if (avatar == null || smr == null || smr.sharedMesh == null)
            {
                _orbitMessage = "\n右の「アバターから自動作成」で、シーンのアバターと顔のレンダラーを指定すると、ここに顔を表示します。";
                return false;
            }

            _orbit.SetTarget(avatar, smr, null);

            // 顔のサブメッシュはまばたき・口の指定で決まるので、どれかが変わったときだけ探し直す（重いので毎回はしない）
            if (smr != _markerRenderer || _vm.AutoBlink != _markerBlink || _vm.AutoMouth != _markerMouth)
            {
                _markerRenderer = smr;
                _markerBlink = _vm.AutoBlink;
                _markerMouth = _vm.AutoMouth;
                _markers.SetSource(smr, FindFaceSlot(smr));
            }
            if (!_markers.IsReady)
            {
                _orbitMessage = "\n顔のメッシュに UV が無いため、目の線を表示できません。";
                return false;
            }
            return true;
        }

        /// <summary>線を載せるサブメッシュ: 自動作成と同じ顔のサブメッシュ。決められなければ、エディターのテクスチャを使うもの、無ければ 0。</summary>
        private int FindFaceSlot(SkinnedMeshRenderer smr)
        {
            if (AvatarFaceMapGenerator.TryFindFaceMaterial(smr, _vm.AutoBlink, _vm.AutoMouth, out int slot, out _, out _)) return slot;
            Texture tex = _vm.State.Texture;
            Material[] mats = smr.sharedMaterials;
            for (int s = 0; s < mats.Length && s < smr.sharedMesh.subMeshCount; s++)
            {
                if (tex != null && AvatarFaceMapGenerator.TextureOf(FaceMaterialApplier.ResolveOriginal(mats[s])) == tex) return s;
            }
            return 0;
        }

        /// <summary>目の枠（UV）。置かれていなければ null。</summary>
        private Rect? EyeRect(string label)
        {
            int i = _vm.Service.IndexOf(label);
            if (i < 0 || i >= _vm.State.Points.Count) return null;
            Vector2 size = _vm.Service.GetSize(FaceMapFile.EyeCategory);
            return new Rect(_vm.State.Points[i].Uv - size * 0.5f, size);
        }

        private void UpdateMarkers()
        {
            _markers.Update(EyeRect(FaceMapAutoGenerator.EyeL), EyeRect(FaceMapAutoGenerator.EyeR),
                _vm.State.EyeLine, _vm.State.EyeLowerLine);
            int mi = _vm.Service.IndexOf(FaceMapAutoGenerator.Mouth);
            Rect? mouthRect = null;
            if (mi >= 0 && mi < _vm.State.Points.Count)
            {
                Vector2 ms = _vm.Service.GetSize(FaceMapFile.MouthCategory);
                mouthRect = new Rect(_vm.State.Points[mi].Uv - ms * 0.5f, ms);
            }
            _markers.UpdateMouthLine(mouthRect, _vm.State.MouthLine);

            // 各パーツの枠（テクスチャ側と同じ色。選択中は黄）。枠が変わらなければ線分は作り直されない
            _frames3D.Clear();
            if (_show3DFrames)
            {
                for (int i = 0; i < _vm.State.Points.Count; i++)
                {
                    FaceMapPoint p = _vm.State.Points[i];
                    string category = FaceTemplate.CategoryOf(p.Label);
                    if (category == null) continue;
                    Vector2 size = _vm.Service.GetSize(category);
                    _frames3D.Add(new EyeLineMarkers3D.Frame
                    {
                        Uv = new Rect(p.Uv - size * 0.5f, size),
                        Color = FaceMapTextureRenderer.GetLabelColor(p.Label),
                        Selected = i == _vm.SelectedPoint,
                    });
                }
            }
            _markers.UpdateFrames(_frames3D);
        }

        /// <summary>両目（片方だけならその目）が入るように、正面から寄せる。</summary>
        private void FocusEyes()
        {
            var points = new List<Vector3>(2);
            foreach (string label in new[] { FaceMapAutoGenerator.EyeL, FaceMapAutoGenerator.EyeR })
            {
                Rect? r = EyeRect(label);
                if (r.HasValue && _markers.TryUvToWorld(r.Value.center, out Vector3 w)) points.Add(w);
            }
            if (points.Count == 0) return;

            Vector3 center = points.Count == 2 ? (points[0] + points[1]) * 0.5f : points[0];
            // 画角 30° で、両目の間隔のおよそ 2.5 倍が横に入る距離
            float distance = points.Count == 2 ? Vector3.Distance(points[0], points[1]) * 8f : 0.15f;
            _orbit.FocusOn(center, Mathf.Clamp(distance, 0.06f, 0.5f));
        }
    }
}
