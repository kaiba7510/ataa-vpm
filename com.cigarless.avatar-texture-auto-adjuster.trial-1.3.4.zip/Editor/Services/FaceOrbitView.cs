// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/FaceOrbitView.cs
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 3D ピボット顔ビュー（3ペイン仕様 §2「3D顔ビュー」・§5 Step 2）。
    /// アバターの顔の中心（Head ボーン、無ければ顔メッシュの中心）をピボットにして、周りを旋回・ズームできる独立した 3D ビュー。
    /// シーンには保存されない一時カメラ（HideFlags.HideAndDontSave）と、カメラに追従する補助ライトで RenderTexture に描く。
    ///
    /// 描画はキャッシュする: 毎回の Repaint では Camera.Render() を呼ばず、MarkDirty（カメラ操作・パラメータ変更・
    /// テクスチャ生成の完了・アバター/メッシュの切り替え）のあとの最初の描画でだけ描き直す。
    /// 調整中のメイクは LiveFacePreview（MaterialPropertyBlock）でシーンのアバターに一時表示されたものを映す。
    /// </summary>
    public sealed class FaceOrbitView : IDisposable
    {
        public const float FieldOfView = 30f;
        public const float DefaultDistance = 0.4f;
        public const float MinDistance = 0.05f;
        public const float MaxDistance = 5f;
        private const float MaxPitch = 85f;
        private const float RotateSpeed = 0.4f; // 度 / ピクセル
        private const float ZoomStep = 1.1f;

        private const int GradientTextureSize = 64;

        private GameObject _cameraObject;
        private Texture2D _backgroundTexture;
        private ViewportBackgroundPreset _backgroundTexturePreset;
        private Camera _camera;
        private Light _light;
        private RenderTexture _texture;
        private bool _dirty = true;

        private GameObject _avatar;
        private Renderer _faceRenderer;
        private readonly List<Renderer> _faceRenderers = new List<Renderer>();

        private Vector3 _pivot;
        private Vector3 _front = Vector3.forward;
        private Vector3 _up = Vector3.up;
        private float _yaw;
        private float _pitch;
        private float _distance = DefaultDistance;
        private Vector3 _pan;

        private enum Drag
        {
            None,
            Rotate,
            Pan
        }

        private Drag _drag;

        /// <summary>前髪・メガネなどの装飾品を描かない（顔メッシュだけを描く）。</summary>
        public bool HideDecorations
        {
            get => _hideDecorations;
            set
            {
                if (_hideDecorations == value) return;
                _hideDecorations = value;
                MarkDirty();
            }
        }

        private bool _hideDecorations;

        /// <summary>
        /// これだけを描くレンダラー（顔メッシュの一覧で、マウスを乗せた候補を見せる）。null ならふだんどおり。
        /// カメラは動かさない（顔の位置のまま、そのメッシュだけが映る）。
        /// </summary>
        public Renderer SoloRenderer
        {
            get => _soloRenderer;
            set
            {
                if (ReferenceEquals(_soloRenderer, value)) return;
                _soloRenderer = value;
                MarkDirty();
            }
        }

        private Renderer _soloRenderer;

        /// <summary>カメラに追従する補助ライト。暗いワールドでも発色と境界を確認できるようにする。</summary>
        public bool AuxiliaryLight
        {
            get => _auxiliaryLight;
            set
            {
                if (_auxiliaryLight == value) return;
                _auxiliaryLight = value;
                MarkDirty();
            }
        }

        private bool _auxiliaryLight = true;

        /// <summary>背景（無彩色のグラデーション 暗/中/明、またはチェッカー）。</summary>
        public ViewportBackgroundPreset Background
        {
            get => _background;
            set
            {
                if (_background == value) return;
                _background = value;
                MarkDirty();
            }
        }

        private ViewportBackgroundPreset _background = ViewportBackground.Default;

        /// <summary>映す対象がある。</summary>
        public bool HasTarget => _avatar != null;

        /// <summary>カメラを操作中（ドラッグ中）。</summary>
        public bool IsDragging => _drag != Drag.None;

        /// <summary>最後に描き直した回数（確認用）。</summary>
        public int RenderCount { get; private set; }

        /// <summary>次の描画で Camera.Render() を呼ぶ。</summary>
        public void MarkDirty() => _dirty = true;

        /// <summary>
        /// 映すアバターと顔メッシュを設定する。前回と同じなら何もしない（カメラ位置を保つ）。
        /// 変わったときは顔の正面にカメラを戻す。faceRenderers は装飾品を隠すときに残すレンダラー（顔のスロット）。
        /// </summary>
        public void SetTarget(GameObject avatar, Renderer faceRenderer, IEnumerable<Renderer> faceRenderers)
        {
            bool changed = !ReferenceEquals(avatar, _avatar) || !ReferenceEquals(faceRenderer, _faceRenderer);

            _faceRenderers.Clear();
            if (faceRenderer != null) _faceRenderers.Add(faceRenderer);
            if (faceRenderers != null)
            {
                foreach (Renderer r in faceRenderers)
                {
                    if (r != null && !_faceRenderers.Contains(r)) _faceRenderers.Add(r);
                }
            }

            if (!changed) return;
            _avatar = avatar;
            _faceRenderer = faceRenderer;
            ResetToFront();
        }

        /// <summary>顔の正面・既定の距離に戻す（「正面リセット」）。ピボットも取り直す。</summary>
        public void ResetToFront()
        {
            _yaw = 0f;
            _pitch = 0f;
            _pan = Vector3.zero;
            _distance = DefaultDistance;
            ComputePivot();
            MarkDirty();
        }

        /// <summary>
        /// ピボット: Humanoid なら Head ボーン（目の高さのあたりまで少し上げる）、無ければ顔メッシュの範囲の中心。
        /// 正面: アバターのルートの正面（+Z）。
        /// </summary>
        private void ComputePivot()
        {
            if (_avatar == null) return;

            Transform root = _avatar.transform;
            _up = root.up;
            _front = root.forward;

            Animator animator = _avatar.GetComponentInChildren<Animator>(true);
            Transform head = animator != null && animator.isHuman ? animator.GetBoneTransform(HumanBodyBones.Head) : null;
            if (head != null)
            {
                _pivot = head.position + _up * 0.06f;
                return;
            }

            Renderer r = _faceRenderer != null ? _faceRenderer : (_faceRenderers.Count > 0 ? _faceRenderers[0] : null);
            if (r != null)
            {
                Bounds b = r.bounds;
                _pivot = b.center;
                _distance = Mathf.Clamp(b.extents.magnitude * 2.5f, MinDistance, MaxDistance);
                return;
            }

            _pivot = root.position + _up * 1.3f;
        }

        /// <summary>
        /// worldPoint を正面から distance の距離で見る（ピボットはそのまま、平行移動で寄せる）。
        /// 「目に寄る」など、顔の一部を確かめるときに使う。
        /// </summary>
        public void FocusOn(Vector3 worldPoint, float distance)
        {
            _yaw = 0f;
            _pitch = 0f;
            _pan = worldPoint - _pivot;
            _distance = Mathf.Clamp(distance, MinDistance, MaxDistance);
            MarkDirty();
        }

        /// <summary>最後に描いたカメラの位置（まだ描いていなければ false）。</summary>
        public bool TryGetCameraPosition(out Vector3 position)
        {
            position = _camera != null ? _camera.transform.position : Vector3.zero;
            return _camera != null && _texture != null;
        }

        /// <summary>
        /// ワールド座標を、最後に描いた画（rect に貼ったもの）の上の位置（rect の左上を原点とする GUI 座標）にする。
        /// カメラの後ろなら false。カメラは描くときにしか動かないので、Draw のあとに呼べば画と一致する。
        /// Camera.Render() は呼ばないので、線などを重ねるだけなら描き直しは要らない（軽い）。
        /// </summary>
        public bool TryProject(Rect rect, Vector3 world, out Vector2 local)
        {
            local = default;
            if (_camera == null || _texture == null) return false;
            Vector3 vp = _camera.WorldToViewportPoint(world);
            if (vp.z <= _camera.nearClipPlane) return false;
            local = new Vector2(vp.x * rect.width, (1f - vp.y) * rect.height);
            return true;
        }

        // ── 操作 ──

        private int _dragControlId;

        /// <summary>
        /// rect の上のマウス操作（右ドラッグ: 回転、中ドラッグ: 平行移動、ホイール: ズーム）を処理する。
        /// 処理したら true（呼び出し側で Repaint する）。
        /// </summary>
        public bool HandleInput(Rect rect)
        {
            Event e = Event.current;
            if (!HasTarget) return false;

            switch (e.type)
            {
                case EventType.ScrollWheel:
                    if (!rect.Contains(e.mousePosition)) return false;
                    _distance = Mathf.Clamp(_distance * (e.delta.y > 0f ? ZoomStep : 1f / ZoomStep), MinDistance, MaxDistance);
                    MarkDirty();
                    e.Use();
                    return true;

                case EventType.MouseDown:
                    if (!rect.Contains(e.mousePosition)) return false;
                    if (e.button == 1) _drag = Drag.Rotate;
                    else if (e.button == 2 || (e.button == 0 && e.alt)) _drag = Drag.Pan;
                    else return false;
                    _dragControlId = GUIUtility.GetControlID(FocusType.Passive);
                    GUIUtility.hotControl = _dragControlId;
                    e.Use();
                    return true;

                case EventType.MouseDrag:
                    if (_drag == Drag.None) return false;
                    if (_drag == Drag.Rotate)
                    {
                        _yaw += e.delta.x * RotateSpeed;
                        _pitch = Mathf.Clamp(_pitch + e.delta.y * RotateSpeed, -MaxPitch, MaxPitch);
                    }
                    else
                    {
                        // 画面上の移動量を、ピボットの距離での世界の移動量に直す（カーソルに付いてくるように）
                        float worldPerPixel = 2f * _distance * Mathf.Tan(FieldOfView * 0.5f * Mathf.Deg2Rad)
                                              / Mathf.Max(rect.height, 1f);
                        Quaternion rot = CameraRotation();
                        _pan += (rot * Vector3.left) * e.delta.x * worldPerPixel + (rot * Vector3.up) * e.delta.y * worldPerPixel;
                    }
                    MarkDirty();
                    e.Use();
                    return true;
            }

            if (e.rawType == EventType.MouseUp && _drag != Drag.None)
            {
                CancelDrag();
                e.Use();
                return true;
            }
            return false;
        }

        /// <summary>ドラッグを途中で終える（フォーカスを失ったときなど）。</summary>
        public void CancelDrag()
        {
            _drag = Drag.None;
            if (_dragControlId != 0 && GUIUtility.hotControl == _dragControlId)
                GUIUtility.hotControl = 0;
            _dragControlId = 0;
        }

        private Quaternion CameraRotation()
        {
            // カメラは顔の正面からアバターの方を向く。そこから上方向の軸で左右に、カメラの横軸で上下に回す
            Quaternion facing = Quaternion.LookRotation(-_front, _up);
            return Quaternion.AngleAxis(_yaw, _up) * facing * Quaternion.Euler(_pitch, 0f, 0f);
        }

        // ── 描画 ──

        /// <summary>
        /// rect に 3D 顔ビューを描く（Repaint のときだけ呼ぶ）。汚れているか大きさが変わったときだけ Camera.Render() する。
        /// </summary>
        public void Draw(Rect rect)
        {
            if (Event.current.type != EventType.Repaint) return;

            DrawBackground(rect);
            if (!HasTarget || rect.width < 2f || rect.height < 2f) return;

            float ppp = EditorGUIUtility.pixelsPerPoint;
            int w = Mathf.Clamp(Mathf.RoundToInt(rect.width * ppp), 16, 4096);
            int h = Mathf.Clamp(Mathf.RoundToInt(rect.height * ppp), 16, 4096);

            if (_texture == null || _texture.width != w || _texture.height != h)
            {
                ReleaseTexture();
                _texture = new RenderTexture(w, h, 24, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Default)
                {
                    antiAliasing = 4,
                    hideFlags = HideFlags.HideAndDontSave,
                    name = "ATAA_FaceView"
                };
                _texture.Create();
                _dirty = true;
            }

            if (_dirty)
            {
                _dirty = false;
                Render();
            }

            GUI.DrawTexture(rect, _texture, ScaleMode.StretchToFill, false);
        }

        /// <summary>まだ描いていないとき・映す対象が無いときにも、同じ背景を見せる。</summary>
        private void DrawBackground(Rect rect)
        {
            Texture2D bg = EnsureBackgroundTexture();
            if (_background == ViewportBackgroundPreset.Checker)
            {
                Vector2 tiling = ViewportBackground.CheckerTiling(rect.width, rect.height, ViewportBackground.CheckerCellPoints);
                GUI.DrawTextureWithTexCoords(rect, bg, new Rect(0f, 0f, tiling.x, tiling.y), false);
            }
            else
            {
                GUI.DrawTexture(rect, bg, ScaleMode.StretchToFill, false);
            }
        }

        /// <summary>背景を RenderTexture に描く（このあとカメラは深度だけを消して重ねる）。</summary>
        private void BlitBackground()
        {
            Texture2D bg = EnsureBackgroundTexture();
            RenderTexture prev = RenderTexture.active;
            if (_background == ViewportBackgroundPreset.Checker)
            {
                float cell = ViewportBackground.CheckerCellPoints * EditorGUIUtility.pixelsPerPoint;
                Graphics.Blit(bg, _texture, ViewportBackground.CheckerTiling(_texture.width, _texture.height, cell), Vector2.zero);
            }
            else
            {
                Graphics.Blit(bg, _texture);
            }
            RenderTexture.active = prev;
        }

        private Texture2D EnsureBackgroundTexture()
        {
            if (_backgroundTexture != null && _backgroundTexturePreset == _background) return _backgroundTexture;
            ReleaseBackgroundTexture();

            bool checker = _background == ViewportBackgroundPreset.Checker;
            int size = checker ? 2 : GradientTextureSize;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false, false)
            {
                hideFlags = HideFlags.HideAndDontSave,
                name = "ATAA_FaceViewBackground",
                filterMode = checker ? FilterMode.Point : FilterMode.Bilinear,
                wrapMode = checker ? TextureWrapMode.Repeat : TextureWrapMode.Clamp
            };
            var pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                pixels[y * size + x] = checker
                    ? ViewportBackground.CheckerCell(x, y)
                    : ViewportBackground.Sample(_background, x / (size - 1f), y / (size - 1f));
            }
            tex.SetPixels(pixels);
            tex.Apply(false, false);

            _backgroundTexture = tex;
            _backgroundTexturePreset = _background;
            return tex;
        }

        private void ReleaseBackgroundTexture()
        {
            if (_backgroundTexture != null) UnityEngine.Object.DestroyImmediate(_backgroundTexture);
            _backgroundTexture = null;
        }

        private void Render()
        {
            if (_avatar == null || _texture == null) return;
            EnsureCamera();

            Quaternion rot = CameraRotation();
            Vector3 target = _pivot + _pan;
            _cameraObject.transform.SetPositionAndRotation(target - rot * Vector3.forward * _distance, rot);

            _camera.aspect = (float)_texture.width / _texture.height;
            _camera.nearClipPlane = Mathf.Max(0.005f, _distance * 0.05f);
            _camera.farClipPlane = Mathf.Max(10f, _distance * 20f);
            _camera.targetTexture = _texture;

            _light.transform.rotation = rot * Quaternion.Euler(15f, -20f, 0f);

            bool hooked = false;
            try
            {
                // 【トランザクション登録】装飾品を隠すときは、顔のレンダラー以外を退避してから止める
                // 候補を見せるときはそのメッシュだけ、装飾品を隠すときは顔のレンダラーだけを残す
                List<Renderer> keep = _soloRenderer != null ? new List<Renderer> { _soloRenderer }
                    : _hideDecorations ? _faceRenderers : null;
                if (keep != null)
                {
                    List<Renderer> decorations = DecorationRenderers(keep);
                    RendererIsolation.Begin(decorations);

                    // NDMF プレビューが ON だと、描く直前（Camera.onPreCull）に NDMF が装飾品の代理を表示し直すので、
                    // そのあとで代理を止め直す。onPreCull は登録した順に呼ばれるので、描く直前に登録すれば必ず NDMF より後になる
                    _hiddenProxies = HiddenProxies(decorations, keep);
                    if (_hiddenProxies.Count > 0)
                    {
                        Camera.onPreCull += HideProxiesOnPreCull;
                        hooked = true;
                    }
                }
                _light.enabled = _auxiliaryLight;

                BlitBackground();

                // 【レンダリング実行】
                _camera.Render();
                RenderCount++;
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
            finally
            {
                // 【通常復元】例外が起きても、ここで必ず元に戻す
                // （止めた代理は、描き終わったときに NDMF が元の「描かない」状態に戻す）
                if (hooked) Camera.onPreCull -= HideProxiesOnPreCull;
                _hiddenProxies = null;
                _light.enabled = false;
                _camera.targetTexture = null;
                RendererIsolation.ForceRestoreAll();
            }
        }

        // 描画中に止める、装飾品の NDMF の代理レンダラー（描いていないときは null）
        private List<Renderer> _hiddenProxies;

        /// <summary>装飾品の代理（顔のレンダラーの代理と見分けがつかないものは残す）。</summary>
        private List<Renderer> HiddenProxies(List<Renderer> decorations, List<Renderer> keep)
        {
            List<Renderer> proxies = NdmfProxies.FindAll();
            if (proxies.Count == 0) return proxies;
            List<Renderer> face = NdmfProxies.ProxiesOf(proxies, keep);
            List<Renderer> hidden = NdmfProxies.ProxiesOf(proxies, decorations);
            hidden.RemoveAll(face.Contains);
            return hidden;
        }

        private void HideProxiesOnPreCull(Camera cam)
        {
            if (cam != _camera || _hiddenProxies == null) return;
            foreach (Renderer r in _hiddenProxies)
            {
                if (r != null) r.forceRenderingOff = true;
            }
        }

        /// <summary>アバターの中で、keep 以外のレンダラー（装飾品を隠すときは前髪・メガネ・体・服など）。</summary>
        private List<Renderer> DecorationRenderers(List<Renderer> keep)
        {
            var list = new List<Renderer>();
            if (_avatar == null) return list;
            foreach (Renderer r in _avatar.GetComponentsInChildren<Renderer>(false))
            {
                if (keep.Contains(r)) continue;
                if (r is ParticleSystemRenderer || r is TrailRenderer || r is LineRenderer) continue;
                list.Add(r);
            }
            return list;
        }

        private void EnsureCamera()
        {
            if (_camera != null && _light != null) return;
            DestroyCamera();

            _cameraObject = new GameObject("ATAA_FaceViewCamera") { hideFlags = HideFlags.HideAndDontSave };
            _camera = _cameraObject.AddComponent<Camera>();
            _camera.enabled = false;
            // 背景は描く直前に RenderTexture へ Blit するので、カメラは深度だけを消す
            _camera.clearFlags = CameraClearFlags.Depth;
            _camera.fieldOfView = FieldOfView;
            _camera.cullingMask = ~0;
            _camera.allowHDR = false;
            _camera.allowMSAA = true;

            var lightObject = new GameObject("ATAA_FaceViewLight") { hideFlags = HideFlags.HideAndDontSave };
            lightObject.transform.SetParent(_cameraObject.transform, false);
            _light = lightObject.AddComponent<Light>();
            _light.type = LightType.Directional;
            _light.intensity = 0.9f;
            _light.color = Color.white;
            _light.shadows = LightShadows.None;
            _light.enabled = false;
        }

        private void DestroyCamera()
        {
            if (_cameraObject != null) UnityEngine.Object.DestroyImmediate(_cameraObject);
            _cameraObject = null;
            _camera = null;
            _light = null;
        }

        private void ReleaseTexture()
        {
            if (_texture == null) return;
            _texture.Release();
            UnityEngine.Object.DestroyImmediate(_texture);
            _texture = null;
        }

        public void Dispose()
        {
            RendererIsolation.ForceRestoreAll();
            DestroyCamera();
            ReleaseTexture();
            ReleaseBackgroundTexture();
            _avatar = null;
            _faceRenderer = null;
            _faceRenderers.Clear();
        }
    }
}
