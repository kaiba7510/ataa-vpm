// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/FaceTextureGenerator.cs
using System.Threading;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 対象の顔テクスチャにメイク元のテクスチャを重ねた、合成済みの PNG を作る（FaceMap 仕様 v0.4 §8）。
    /// 出力は対象の顔テクスチャの元のファイル（PNG / JPG）と同じ解像度（読めなければインポート後の解像度）。
    /// マスクの外は対象のまま。
    /// 合成そのものはプレビューと共通（FaceCompositor）。
    /// </summary>
    internal static class FaceTextureGenerator
    {
        public const int MaxSize = AtaaCore.MaxTextureSize;

        // 体験版の DLL には、書き出し用の PNG を作る処理を入れない

        public struct Result
        {
            public byte[] Png;
            public string Error;
        }

        /// <summary>
        /// 合成済みの PNG を作る。テクスチャの読み込みはメインスレッドで、合成と PNG への変換はワーカースレッドで行う
        /// （8K の合成でエディターが固まらないように）。deformer・mask は終わるまで変更しないこと。
        /// メインスレッドから呼び、メインスレッドで続きを受け取る（await の続きは Unity の同期コンテキストに戻る）。
        /// timing があれば、読み込み・合成・PNG 変換の所要時間を記録する（null 可）。
        /// </summary>
        public static async Task<Result> GenerateAsync(Texture2D avatarTex, Texture2D makeupTex, AvatarDeformer deformer,
                                                       FaceMask mask, float opacity, ApplyTiming timing = null)
        {
            if (avatarTex == null || makeupTex == null || deformer == null || !deformer.IsInitialized || mask == null)
                return new Result { Error = "テクスチャまたは変形の準備ができていません。" };

            int w = avatarTex.width, h = avatarTex.height;
            if (w > MaxSize || h > MaxSize)
                return new Result { Error = $"対象の顔テクスチャが大きすぎます（{w}x{h}、上限 {MaxSize}）。" };

            bool linear = IsLinear(avatarTex);
            try
            {
                EditorUtility.DisplayProgressBar("メイクを合成中", "テクスチャを読み込み中...", 0f);
                // 元のファイルが読めれば、その解像度で作る（インポート後の大きさと違うことがある）
                FacePixels basePx = FaceTextureReader.ReadSource(avatarTex, MaxSize, linear);
                timing?.Lap("対象の顔テクスチャの読み込み");
                FacePixels makeupPx = ReadMakeup(makeupTex, linear);
                timing?.Lap("メイク元のテクスチャの読み込み");

                // 進み具合はワーカーが書き、メインスレッドが読んでバーに出す
                int progress = 0; // 0〜1000
                // ワーカーで測った時間（await の後にメインスレッドで読む）
                double composeMs = 0.0, encodeMs = 0.0;
                Task<byte[]> work = Task.Run(() =>
                {
                    var sw = System.Diagnostics.Stopwatch.StartNew();
                    int pw = basePx.Width, ph = basePx.Height;
                    var dst = new Color32[pw * ph];
                    AtaaCore.Compose(basePx, makeupPx, deformer, mask, opacity, dst,
                        p => Volatile.Write(ref progress, (int)(p * 1000f)));
                    composeMs = sw.Elapsed.TotalMilliseconds;
                    sw.Restart();
                    // EncodeArrayToPNG はメインスレッド以外からも呼べる（Texture2D を作らずに済む）
                    byte[] encoded = ImageConversion.EncodeArrayToPNG(dst, GraphicsFormat.R8G8B8A8_UNorm, (uint)pw, (uint)ph);
                    encodeMs = sw.Elapsed.TotalMilliseconds;
                    return encoded;
                });

                while (!work.IsCompleted)
                {
                    EditorUtility.DisplayProgressBar("メイクを合成中", "合成中...", Volatile.Read(ref progress) / 1000f);
                    await Task.Delay(50);
                }

                byte[] png = await work;
                if (timing != null)
                {
                    timing.Lap("合成と PNG 変換（待ち込み）");
                    timing.Detail("合成（格子の構築を含む）", composeMs);
                    timing.Detail("PNG 変換", encodeMs);
                    timing.Note("対象", basePx.Width + "x" + basePx.Height);
                    timing.Note("メイク元", makeupPx.Width + "x" + makeupPx.Height);
                    if (png != null) timing.Note("PNG", ApplyTiming.MegaBytes(png.Length));
                }
                if (png == null || png.Length == 0) return new Result { Error = "PNG への変換に失敗しました。" };
                return new Result { Png = png };
            }
            catch (System.Exception e)
            {
                return new Result { Error = e.GetBaseException().Message };
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        /// <summary>メイク元の顔テクスチャを、生成用の解像度（上限 MaxSize）で読む。</summary>
        public static FacePixels ReadMakeup(Texture2D makeupTex, bool linear)
        {
            return FaceTextureReader.ReadSource(makeupTex, MaxSize, linear);
        }

        /// <summary>テクスチャが線形（sRGB でない）扱いか。インポート設定が分からなければ sRGB 扱い。</summary>
        public static bool IsLinear(Texture tex) => FaceTextureReader.IsLinear(tex);
    }
}
