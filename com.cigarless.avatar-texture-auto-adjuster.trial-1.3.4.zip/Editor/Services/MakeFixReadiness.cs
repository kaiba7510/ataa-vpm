// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/MakeFixReadiness.cs
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>✗ の項目を直すボタンの種類（§13.8）。</summary>
    public enum ReadinessFix
    {
        None,
        PickAvatarTexture,
        OpenFaceMapEditor,
        EnableAllParts
    }

    /// <summary>準備チェックの 1 項目。</summary>
    public sealed class ReadinessItem
    {
        public int Number;
        public bool Ok;

        /// <summary>✗ のときの 1 行（§13.7）。</summary>
        public string Message;

        /// <summary>詳しい説明（ツールチップ）。</summary>
        public string Detail;

        public ReadinessFix Fix;
    }

    /// <summary>
    /// メイクフィックス画面の準備チェック（FaceMap 仕様 v0.4 §13.8）。判定は入力の値だけで決まる（副作用なし）。
    /// </summary>
    public static class MakeFixReadiness
    {
        /// <summary>判定に使う値。</summary>
        public struct Inputs
        {
            public bool HasMakeupFaceMap;
            public bool HasAvatarFaceMap;
            public bool HasAvatar;
            public bool AvatarIsAsset;
            public bool HasAvatarTexture;
            public bool HasMakeupTexture;
            public bool HasFaceSlots;

            /// <summary>対応付けの結果。null なら読み込み中。</summary>
            public bool? MatchApplicable;
            public string MatchError;

            public bool AnyPartEnabled;
        }

        /// <summary>左右のペインで選ぶもの（項目 1〜5）。</summary>
        public const int SetupItemCount = 5;

        /// <summary>ライブプレビューに必要な項目（1〜7）。</summary>
        public const int LivePreviewItemCount = 7;

        public static List<ReadinessItem> Evaluate(Inputs i)
        {
            var items = new List<ReadinessItem>
            {
                Item(1, i.HasMakeupFaceMap, "メイク基準（メイク元の FaceMap）を選んでください",
                     "右ペインの「メイク基準 (FaceMap)」で、メイクを持ってくる側の FaceMap を選びます。"),
                Item(2, i.HasAvatarFaceMap, "アバター基準（対象の FaceMap）を選んでください",
                     "左ペインの「アバター基準 (FaceMap)」で選ぶか、「アバター基準を自動生成」で作ります。"),
                Item(3, i.HasAvatar && !i.AvatarIsAsset,
                     i.HasAvatar ? "シーン上のアバターを指定してください" : "対象アバターをシーンから指定してください",
                     "左ペインの一覧から選ぶか、ヒエラルキーのアバターをドラッグ＆ドロップします。プロジェクト内のプレハブは変更できません。"),
                Item(4, i.HasAvatarTexture, "対象の顔テクスチャを指定してください",
                     "対象アバターの顔のマテリアルが使っているテクスチャです。左ペインの「候補」でアバターのテクスチャから選べます。",
                     ReadinessFix.PickAvatarTexture),
                Item(5, i.HasMakeupTexture, "メイクテクスチャ（メイク元の顔テクスチャ）を指定してください",
                     "メイク元の FaceMap を作ったときの顔テクスチャ（またはメイクだけの透過画像）です。"),
            };

            // 6 以降は、前提の項目が揃っているときだけ意味がある
            bool slotsKnown = i.HasAvatar && !i.AvatarIsAsset && i.HasAvatarTexture;
            items.Add(Item(6, slotsKnown && i.HasFaceSlots, "このアバターは指定した顔テクスチャを使っていません",
                "対象アバターのマテリアルの中に、「対象の顔テクスチャ」を使っているものがありません。顔のマテリアルのテクスチャを選び直してください。",
                ReadinessFix.PickAvatarTexture));

            bool pairSelected = i.HasMakeupFaceMap && i.HasAvatarFaceMap;
            string matchMessage = !pairSelected
                ? "FaceMap を選ぶと対応付けを確認します"
                : i.MatchApplicable == null
                    ? "FaceMap を読み込み中です"
                    : FirstLine(i.MatchError) ?? "FaceMap を対応付けできません";
            items.Add(Item(7, pairSelected && i.MatchApplicable == true, matchMessage,
                i.MatchError ?? "メイク元と対象の FaceMap の領域を対応付けられません。FaceMap エディターで領域を確認してください。",
                ReadinessFix.OpenFaceMapEditor));

            items.Add(Item(8, i.AnyPartEnabled, "合成するパーツがすべて OFF です",
                "右ペインのパーツ選択で、少なくとも 1 つのパーツの「合成する」を ON にしてください。",
                ReadinessFix.EnableAllParts));

            return items;
        }

        /// <summary>items の先頭 count 項目がすべて ✓ か。</summary>
        public static bool AllOk(List<ReadinessItem> items, int count)
        {
            for (int n = 0; n < count && n < items.Count; n++)
            {
                if (!items[n].Ok) return false;
            }
            return true;
        }

        public static int FailedCount(List<ReadinessItem> items)
        {
            int c = 0;
            foreach (ReadinessItem it in items)
            {
                if (!it.Ok) c++;
            }
            return c;
        }

        /// <summary>最初の ✗ の項目。すべて ✓ なら null。</summary>
        public static ReadinessItem FirstFailed(List<ReadinessItem> items, int from = 1, int to = int.MaxValue)
        {
            foreach (ReadinessItem it in items)
            {
                if (it.Number >= from && it.Number <= to && !it.Ok) return it;
            }
            return null;
        }

        private static ReadinessItem Item(int number, bool ok, string message, string detail,
                                          ReadinessFix fix = ReadinessFix.None)
        {
            return new ReadinessItem { Number = number, Ok = ok, Message = message, Detail = detail, Fix = fix };
        }

        /// <summary>最初の行（改行の前）。null・空なら null。</summary>
        public static string FirstLine(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            int nl = s.IndexOf('\n');
            return nl >= 0 ? s.Substring(0, nl) : s;
        }
    }

    /// <summary>
    /// 顔テクスチャ 2 つを、FaceMap の組み合わせごとに覚える（§13.9）。EditorPrefs に GUID で保存する。
    /// さらに、メイクテクスチャ GUID → メイク基準、メイク基準 → 直近メイクテクスチャ、最近使ったメイク履歴も保持する。
    /// </summary>
    public static class MakeFixTextureMemory
    {
        public const string KeyPrefix = "ATAA.MakeFix.Textures.";
        public const string TexToMapPrefix = "ATAA.MakeFix.TexToMap.";
        public const string MapToTexPrefix = "ATAA.MakeFix.MapToTex.";
        public const string HistoryPrefsKey = "ATAA.MakeFix.MakeupHistory";

        /// <summary>FaceMap のパスから、一時データ（ATAA-Auto/）と実ファイルで共通になる基準キーを作る。</summary>
        public static string MapKey(string faceMapPath)
        {
            if (string.IsNullOrEmpty(faceMapPath)) return null;
            string name = FaceMapSerializer.SanitizeFileName(Path.GetFileNameWithoutExtension(faceMapPath));
            return string.IsNullOrEmpty(name) ? null : name;
        }

        public static string Key(string makeupFaceMapPath, string avatarFaceMapPath)
        {
            string m = MapKey(makeupFaceMapPath);
            string a = MapKey(avatarFaceMapPath);
            if (m == null || a == null) return null;
            return KeyPrefix + m + "__" + a;
        }

        public static void Save(string key, Texture2D avatarTex, Texture2D makeupTex)
        {
            if (key == null) return;
            EditorPrefs.SetString(key, Format(Guid(avatarTex), Guid(makeupTex)));
        }

        /// <summary>覚えていれば true。テクスチャが見つからない（削除された）ものは null で返す。</summary>
        public static bool TryLoad(string key, out Texture2D avatarTex, out Texture2D makeupTex)
        {
            avatarTex = null;
            makeupTex = null;
            if (key == null || !EditorPrefs.HasKey(key)) return false;

            Parse(EditorPrefs.GetString(key), out string a, out string m);
            avatarTex = LoadByGuid(a);
            makeupTex = LoadByGuid(m);
            return true;
        }

        /// <summary>ペア記憶に保存されているメイクテクスチャの GUID（無ければ null）。</summary>
        public static string LoadPairMakeupGuid(string key)
        {
            if (key == null || !EditorPrefs.HasKey(key)) return null;
            Parse(EditorPrefs.GetString(key), out _, out string m);
            return m;
        }

        /// <summary>このメイクテクスチャとメイク基準の結びつき（双方向）を覚える。</summary>
        public static void SaveMakeupLink(Texture2D makeupTex, string makeupFaceMapPath)
        {
            string texGuid = Guid(makeupTex);
            string mapKey = MapKey(makeupFaceMapPath);
            if (string.IsNullOrEmpty(texGuid) || string.IsNullOrEmpty(mapKey)) return;
            EditorPrefs.SetString(TexToMapPrefix + texGuid, mapKey);
            EditorPrefs.SetString(MapToTexPrefix + mapKey, texGuid);
        }

        /// <summary>このメイクテクスチャで前回使ったメイク基準の MapKey（無ければ null）。</summary>
        public static string LoadMapKeyForTexture(Texture2D makeupTex)
        {
            string texGuid = Guid(makeupTex);
            if (string.IsNullOrEmpty(texGuid)) return null;
            string v = EditorPrefs.GetString(TexToMapPrefix + texGuid, "");
            return string.IsNullOrEmpty(v) ? null : v;
        }

        /// <summary>このメイク基準で直近使ったメイクテクスチャの GUID（無ければ null）。</summary>
        public static string LoadTextureGuidForMap(string makeupFaceMapPath)
        {
            string mapKey = MapKey(makeupFaceMapPath);
            if (string.IsNullOrEmpty(mapKey)) return null;
            string v = EditorPrefs.GetString(MapToTexPrefix + mapKey, "");
            return string.IsNullOrEmpty(v) ? null : v;
        }

        /// <summary>最近使ったメイクテクスチャの先頭に記録する（プロジェクト内のアセットのみ）。</summary>
        public static void RecordMakeupHistory(Texture2D makeupTex)
        {
            string texGuid = Guid(makeupTex);
            if (string.IsNullOrEmpty(texGuid)) return;
            List<string> cur = MakeFixMakeupSource.ParseHistory(EditorPrefs.GetString(HistoryPrefsKey, ""));
            List<string> next = MakeFixMakeupSource.RecordHistory(cur, texGuid);
            EditorPrefs.SetString(HistoryPrefsKey, MakeFixMakeupSource.FormatHistory(next));
        }

        /// <summary>最近使ったメイクテクスチャの一覧（削除済みアセットは省く）。</summary>
        public static List<Texture2D> LoadMakeupHistory()
        {
            var result = new List<Texture2D>();
            foreach (string g in MakeFixMakeupSource.ParseHistory(EditorPrefs.GetString(HistoryPrefsKey, "")))
            {
                Texture2D t = LoadByGuid(g);
                if (t != null && !result.Contains(t)) result.Add(t);
            }
            return result;
        }

        /// <summary>保存する値（"対象の GUID|メイク元の GUID"）。</summary>
        public static string Format(string avatarGuid, string makeupGuid) => (avatarGuid ?? "") + "|" + (makeupGuid ?? "");

        public static void Parse(string value, out string avatarGuid, out string makeupGuid)
        {
            avatarGuid = null;
            makeupGuid = null;
            if (string.IsNullOrEmpty(value)) return;

            string[] parts = value.Split('|');
            if (parts.Length > 0 && parts[0].Length > 0) avatarGuid = parts[0];
            if (parts.Length > 1 && parts[1].Length > 0) makeupGuid = parts[1];
        }

        public static Texture2D LoadTextureByGuid(string guid) => LoadByGuid(guid);

        private static string Guid(Texture2D tex)
        {
            if (tex == null) return null;
            string path = AssetDatabase.GetAssetPath(tex);
            return string.IsNullOrEmpty(path) ? null : AssetDatabase.AssetPathToGUID(path);
        }

        private static Texture2D LoadByGuid(string guid)
        {
            if (string.IsNullOrEmpty(guid)) return null;
            string path = AssetDatabase.GUIDToAssetPath(guid);
            return string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }
    }
}
