// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/NdmfProxies.cs
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// NDMF のプレビュー（Modular Avatar・TexTransTool・AAO などのプレビュー）の代理レンダラーを探す。
    /// プレビューが ON の間は、元のレンダラーは描かれず、NDMF が作った代理のレンダラー
    /// （ルートに置かれた "Proxy renderer for &lt;元の名前&gt;"）が、シーンビューにも、親の無いカメラにも描かれる。
    /// NDMF の API には依存せず（入っていなくても動く）、名前と、スキンメッシュならルートボーンで見分ける。
    /// </summary>
    public static class NdmfProxies
    {
        public const string NamePrefix = "Proxy renderer for ";

        /// <summary>読み込まれているシーン（NDMF のプレビュー用のシーンを含む）のルートにある代理のレンダラーを集める。</summary>
        public static List<Renderer> FindAll()
        {
            var list = new List<Renderer>();
            for (int s = 0; s < SceneManager.sceneCount; s++)
            {
                Scene scene = SceneManager.GetSceneAt(s);
                if (!scene.isLoaded) continue;
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    if (!root.name.StartsWith(NamePrefix, StringComparison.Ordinal)) continue;
                    Renderer proxy = root.GetComponent<Renderer>();
                    if (proxy != null) list.Add(proxy);
                }
            }
            return list;
        }

        /// <summary>proxy が original の代理か。名前と、スキンメッシュならルートボーン（代理は元のボーンを使う）で見分ける。</summary>
        public static bool IsProxyOf(Renderer proxy, Renderer original)
        {
            if (proxy == null || original == null || proxy == original) return false;
            if (proxy.gameObject.name != NamePrefix + original.gameObject.name) return false;
            if (original is SkinnedMeshRenderer o)
            {
                if (!(proxy is SkinnedMeshRenderer p)) return false;
                Transform root = o.rootBone != null ? o.rootBone : o.transform;
                return p.rootBone == root;
            }
            return proxy is MeshRenderer && original is MeshRenderer;
        }

        /// <summary>proxies のうち、originals のどれかの代理であるもの。</summary>
        public static List<Renderer> ProxiesOf(List<Renderer> proxies, ICollection<Renderer> originals)
        {
            var list = new List<Renderer>();
            foreach (Renderer proxy in proxies)
            {
                foreach (Renderer original in originals)
                {
                    if (!IsProxyOf(proxy, original)) continue;
                    list.Add(proxy);
                    break;
                }
            }
            return list;
        }
    }
}
