// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/EyeLineMarkers3D.cs
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap の目の線・目の下の線と、各パーツの枠（目・鼻・口・頬などの領域）を、3D ビュー（FaceOrbitView）の顔の上に重ねて描くマーカー
    /// （自動ポインティング仕様 §11.22）。枠は UV の矩形の 4 辺を、目の線と同じやり方で顔の三角形で切って描く。
    /// 目の開いた部分がテクスチャに無い素体（Lapwing・rurune）では、上下の縁が UV でほぼ重なり、テクスチャだけでは
    /// 線を決められない。3D の顔の上で「線がまぶたのどこに当たるか」を見ながら合わせてもらうためのもの。
    ///
    /// 線はつまみのドラッグで毎フレーム変わるので、すぐ追従できるよう軽くしてある:
    ///  - 顔のメッシュは 1 回だけ焼く（BakeMesh）。顔のサブメッシュの三角形ごとの UV の範囲と向きも、そのとき求めておく
    ///  - 線や目の枠が変わったときだけ、UV の水平線（v = 一定）と交わる三角形を拾って 3D の線分にする
    ///    （三角形の数に比例する 1 回の走査。数千〜1 万の三角形で 1ms 未満）。変わらなければ線分を使い回す
    ///  - 描くのは 3D ビューの画の上に GUI の線として重ねるだけで、Camera.Render() は呼ばない
    ///    （3D ビューを描き直すのはカメラを動かしたときだけ）
    /// </summary>
    internal sealed class EyeLineMarkers3D
    {
        private struct Segment
        {
            public Vector3 A, B, Normal;
        }

        private const float LineWidth = 3f;

        // 焼いた顔（SetSource / Rebake）
        private SkinnedMeshRenderer _smr;
        private Mesh _mesh;
        private int _slot = -1;
        private Vector2[] _uv;
        private Vector3[] _pos;
        private int[] _tris;
        private float[] _uMin, _uMax, _vMin, _vMax;
        private Vector3[] _normal;

        // 線分（Update）。目の枠と線の高さが前回と同じなら作り直さない
        private readonly List<Segment> _upper = new List<Segment>();
        private readonly List<Segment> _lower = new List<Segment>();
        private readonly List<Segment> _mouth = new List<Segment>();
        private (Rect? Mouth, float? Line) _mouthKey;
        private bool _hasMouthKey;
        private (Rect? L, Rect? R, float? Line, float? Lower) _key;
        private bool _hasKey;

        // 交点を集める作業用（確保し直さない）
        private readonly float[] _hitU = new float[3];
        private readonly Vector3[] _hitP = new Vector3[3];

        /// <summary>顔のメッシュを焼いてあり、線を作れる。</summary>
        public bool IsReady => _tris != null;

        /// <summary>今の線分の数（確認用）。</summary>
        public int SegmentCount => _upper.Count + _lower.Count;

        /// <summary>
        /// 線を載せる顔（レンダラーと顔のサブメッシュ）を設定する。前回と同じなら何もしない。変わったら焼き直す。
        /// </summary>
        public void SetSource(SkinnedMeshRenderer smr, int slot)
        {
            Mesh mesh = smr != null ? smr.sharedMesh : null;
            if (smr == _smr && mesh == _mesh && slot == _slot && IsReady) return;
            _smr = smr;
            _mesh = mesh;
            _slot = slot;
            Rebake();
        }

        /// <summary>今のポーズ・位置で顔を焼き直す（アバターを動かしたとき）。</summary>
        public void Rebake()
        {
            _tris = null;
            _hasKey = false;
            _hasFrameKey = false;
            _hasMouthKey = false;
            _upper.Clear();
            _lower.Clear();
            _mouth.Clear();
            _frameSegments.Clear();
            if (_smr == null || _mesh == null || _slot < 0 || _slot >= _mesh.subMeshCount) return;

            int n = _mesh.vertexCount;
            Vector2[] uv = _mesh.uv;
            if (uv == null || uv.Length != n) return;
            for (int i = 0; i < n; i++) uv[i] = new Vector2(FaceMeshData.Tile(uv[i].x), FaceMeshData.Tile(uv[i].y));

            Vector3[] local;
            var baked = new Mesh();
            try
            {
                _smr.BakeMesh(baked, true);
                local = baked.vertices;
            }
            finally
            {
                Object.DestroyImmediate(baked);
            }
            if (local == null || local.Length != n) return;

            // BakeMesh の頂点はスケール込みのレンダラー座標系（位置と回転だけ掛ける。自動作成と同じ）
            Matrix4x4 toWorld = Matrix4x4.TRS(_smr.transform.position, _smr.transform.rotation, Vector3.one);
            var pos = new Vector3[n];
            for (int i = 0; i < n; i++) pos[i] = toWorld.MultiplyPoint3x4(local[i]);

            int[] t = _mesh.GetTriangles(_slot);
            int m = t.Length / 3;
            _uMin = new float[m];
            _uMax = new float[m];
            _vMin = new float[m];
            _vMax = new float[m];
            _normal = new Vector3[m];
            for (int k = 0; k < m; k++)
            {
                Vector2 a = uv[t[3 * k]], b = uv[t[3 * k + 1]], c = uv[t[3 * k + 2]];
                _uMin[k] = Mathf.Min(a.x, Mathf.Min(b.x, c.x));
                _uMax[k] = Mathf.Max(a.x, Mathf.Max(b.x, c.x));
                _vMin[k] = Mathf.Min(a.y, Mathf.Min(b.y, c.y));
                _vMax[k] = Mathf.Max(a.y, Mathf.Max(b.y, c.y));
                Vector3 p0 = pos[t[3 * k]];
                _normal[k] = Vector3.Cross(pos[t[3 * k + 1]] - p0, pos[t[3 * k + 2]] - p0);
            }
            _uv = uv;
            _pos = pos;
            _tris = t;
        }

        /// <summary>
        /// 目の枠（UV）と線の高さ（枠の下端 0〜上端 1）から線分を作る。前回と同じなら何もしない。
        /// 枠や線が無ければ、その線は描かない。
        /// </summary>
        public void Update(Rect? eyeL, Rect? eyeR, float? line, float? lower)
        {
            var key = (eyeL, eyeR, line, lower);
            if (_hasKey && key.Equals(_key)) return;
            _key = key;
            _hasKey = true;
            _upper.Clear();
            _lower.Clear();
            if (_tris == null) return;

            if (eyeL.HasValue) AddEye(eyeL.Value, line, lower);
            if (eyeR.HasValue) AddEye(eyeR.Value, line, lower);
        }

        /// <summary>口の線（口の枠の中の水平線）の線分を作る。前回と同じなら何もしない。</summary>
        public void UpdateMouthLine(Rect? mouth, float? line)
        {
            var key = (mouth, line);
            if (_hasMouthKey && key.Equals(_mouthKey)) return;
            _mouthKey = key;
            _hasMouthKey = true;
            _mouth.Clear();
            if (_tris == null || !mouth.HasValue || !line.HasValue) return;
            Rect m = mouth.Value;
            AddIsoLine(true, m.yMin + m.height * line.Value, m.xMin, m.xMax, _mouth);
        }

        private void AddEye(Rect eye, float? line, float? lower)
        {
            if (line.HasValue) AddIsoLine(true, eye.yMin + eye.height * line.Value, eye.xMin, eye.xMax, _upper);
            if (lower.HasValue) AddIsoLine(true, eye.yMin + eye.height * lower.Value, eye.xMin, eye.xMax, _lower);
        }

        /// <summary>
        /// UV の直線を、顔の上の線分にする。horizontal なら v = level の水平線（u = from〜to）、そうでなければ u = level の垂直線（v = from〜to）。
        /// </summary>
        private void AddIsoLine(bool horizontal, float level, float from, float to, List<Segment> list)
        {
            float u0 = from, u1 = to; // ここから下の u は「線に沿った向きの座標」（垂直線なら v）
            int m = _uMin.Length;
            for (int k = 0; k < m; k++)
            {
                if (horizontal)
                {
                    if (level < _vMin[k] || level > _vMax[k] || _uMax[k] < u0 || _uMin[k] > u1) continue;
                }
                else if (level < _uMin[k] || level > _uMax[k] || _vMax[k] < u0 || _vMin[k] > u1) continue;

                int i0 = _tris[3 * k], i1 = _tris[3 * k + 1], i2 = _tris[3 * k + 2];
                int hits = 0;
                Cross(i0, i1, level, horizontal, ref hits);
                Cross(i1, i2, level, horizontal, ref hits);
                Cross(i2, i0, level, horizontal, ref hits);
                if (hits < 2) continue;

                // 頂点がちょうど線の上だと同じ点が 2 回入るので、u がいちばん離れた 2 点を使う
                int a = 0, b = 1;
                if (hits == 3)
                {
                    float d01 = Mathf.Abs(_hitU[0] - _hitU[1]), d02 = Mathf.Abs(_hitU[0] - _hitU[2]), d12 = Mathf.Abs(_hitU[1] - _hitU[2]);
                    if (d02 >= d01 && d02 >= d12) b = 2;
                    else if (d12 >= d01) { a = 1; b = 2; }
                }

                float ua = _hitU[a], ub = _hitU[b];
                Vector3 pa = _hitP[a], pb = _hitP[b];
                if (ua > ub)
                {
                    (ua, ub) = (ub, ua);
                    (pa, pb) = (pb, pa);
                }
                if (ub - ua < 1e-7f || ub < u0 || ua > u1) continue;

                // 目の枠の左右の端で切る
                Vector3 ca = ua < u0 ? Vector3.Lerp(pa, pb, (u0 - ua) / (ub - ua)) : pa;
                Vector3 cb = ub > u1 ? Vector3.Lerp(pa, pb, (u1 - ua) / (ub - ua)) : pb;
                list.Add(new Segment { A = ca, B = cb, Normal = _normal[k] });
            }
        }

        /// <summary>
        /// 辺 (a, b) が UV の直線（horizontal なら v = level、そうでなければ u = level）と交われば、
        /// その点（線に沿った向きの座標と 3D の位置）を足す。
        /// </summary>
        private void Cross(int a, int b, float level, bool horizontal, ref int hits)
        {
            Vector2 pa = _uv[a], pb = _uv[b];
            float da = (horizontal ? pa.y : pa.x) - level, db = (horizontal ? pb.y : pb.x) - level;
            if (da * db > 0f || Mathf.Approximately(da, db)) return; // 交わらない・辺が線に重なる（隣の辺で拾う）
            float t = da / (da - db);
            _hitU[hits] = horizontal ? Mathf.Lerp(pa.x, pb.x, t) : Mathf.Lerp(pa.y, pb.y, t);
            _hitP[hits] = Vector3.Lerp(_pos[a], _pos[b], t);
            hits++;
        }

        // ── 各パーツの枠（目・鼻・口・頬などの領域の矩形）──

        /// <summary>3D に描く枠 1 つ（UV の矩形・色・選択中か）。</summary>
        public struct Frame : System.IEquatable<Frame>
        {
            public Rect Uv;
            public Color Color;
            public bool Selected;

            public bool Equals(Frame o) => Uv == o.Uv && Color == o.Color && Selected == o.Selected;
        }

        private const float FrameWidth = 2f, SelectedFrameWidth = 3.5f;
        private static readonly Color SelectedFrameColor = Color.yellow;

        private readonly List<Frame> _frameKey = new List<Frame>();
        private readonly List<List<Segment>> _frameSegments = new List<List<Segment>>();
        private bool _hasFrameKey;

        /// <summary>
        /// 各パーツの枠（UV の矩形）の線分を作る。前回と同じ枠なら何もしない。枠の 4 辺を、目の線と同じく顔の三角形で切って 3D にする。
        /// </summary>
        public void UpdateFrames(IReadOnlyList<Frame> frames)
        {
            bool same = _hasFrameKey && frames.Count == _frameKey.Count;
            for (int i = 0; same && i < frames.Count; i++) same = frames[i].Equals(_frameKey[i]);
            if (same) return;

            _hasFrameKey = true;
            _frameKey.Clear();
            _frameKey.AddRange(frames);
            _frameSegments.Clear();
            if (_tris == null) return;
            foreach (Frame f in frames)
            {
                var list = new List<Segment>();
                Rect r = f.Uv;
                AddIsoLine(true, r.yMin, r.xMin, r.xMax, list);
                AddIsoLine(true, r.yMax, r.xMin, r.xMax, list);
                AddIsoLine(false, r.xMin, r.yMin, r.yMax, list);
                AddIsoLine(false, r.xMax, r.yMin, r.yMax, list);
                _frameSegments.Add(list);
            }
        }

        /// <summary>UV の点が載る顔の位置（最初に見つかった三角形）。無ければ false。</summary>
        public bool TryUvToWorld(Vector2 p, out Vector3 world)
        {
            world = default;
            if (_tris == null) return false;
            int m = _uMin.Length;
            for (int k = 0; k < m; k++)
            {
                if (p.x < _uMin[k] || p.x > _uMax[k] || p.y < _vMin[k] || p.y > _vMax[k]) continue;
                int i0 = _tris[3 * k], i1 = _tris[3 * k + 1], i2 = _tris[3 * k + 2];
                Vector2 a = _uv[i0], b = _uv[i1], c = _uv[i2];
                float den = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
                if (Mathf.Abs(den) < 1e-12f) continue;
                float w0 = ((b.y - c.y) * (p.x - c.x) + (c.x - b.x) * (p.y - c.y)) / den;
                float w1 = ((c.y - a.y) * (p.x - c.x) + (a.x - c.x) * (p.y - c.y)) / den;
                float w2 = 1f - w0 - w1;
                if (w0 < -1e-5f || w1 < -1e-5f || w2 < -1e-5f) continue;
                world = _pos[i0] * w0 + _pos[i1] * w1 + _pos[i2] * w2;
                return true;
            }
            return false;
        }

        /// <summary>
        /// 3D ビューの画（rect）の上に線を重ねる（Repaint のときだけ。view.Draw(rect) のあとに呼ぶ）。
        /// カメラから見て裏を向いた三角形の線分は描かない（頭の後ろへ回ったとき、裏側から透けて見えないように）。
        /// </summary>
        public void Draw(FaceOrbitView view, Rect rect)
        {
            if (Event.current.type != EventType.Repaint || (SegmentCount == 0 && _frameSegments.Count == 0 && _mouth.Count == 0)) return;
            if (!view.TryGetCameraPosition(out Vector3 camera)) return;

            GUI.BeginClip(rect);
            try
            {
                Color saved = Handles.color;
                // 枠を先に（目の線が枠の上に見えるように）。選択中の枠は最後に、太く
                for (int pass = 0; pass < 2; pass++)
                {
                    for (int i = 0; i < _frameSegments.Count && i < _frameKey.Count; i++)
                    {
                        Frame f = _frameKey[i];
                        if (f.Selected != (pass == 1)) continue;
                        DrawList(view, rect, camera, _frameSegments[i], f.Selected ? SelectedFrameColor : f.Color,
                            f.Selected ? SelectedFrameWidth : FrameWidth);
                    }
                }
                DrawList(view, rect, camera, _upper, FaceMapTextureRenderer.EyeLineColor, LineWidth);
                DrawList(view, rect, camera, _lower, FaceMapTextureRenderer.EyeLowerLineColor, LineWidth);
                DrawList(view, rect, camera, _mouth, FaceMapTextureRenderer.MouthLineColor, LineWidth);
                Handles.color = saved;
            }
            finally
            {
                GUI.EndClip();
            }
        }

        private static void DrawList(FaceOrbitView view, Rect rect, Vector3 camera, List<Segment> list, Color color, float width)
        {
            Handles.color = color;
            foreach (Segment s in list)
            {
                if (Vector3.Dot(s.Normal, camera - s.A) <= 0f) continue;
                if (!view.TryProject(rect, s.A, out Vector2 a) || !view.TryProject(rect, s.B, out Vector2 b)) continue;
                Handles.DrawAAPolyLine(width, (Vector3)a, (Vector3)b);
            }
        }
    }
}
