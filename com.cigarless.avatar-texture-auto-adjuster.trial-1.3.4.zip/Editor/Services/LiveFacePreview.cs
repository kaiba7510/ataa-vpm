// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/LiveFacePreview.cs
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// ライブプレビュー（FaceMap 仕様 v0.4 §13.6）。シーン上の対象アバターの顔のスロットに、
    /// MaterialPropertyBlock で調整中のテクスチャを一時的に表示する。
    /// マテリアル・シーン・プレハブには書き込まない（シーンは Dirty にならず、保存もされない）。
    /// 再生・再コンパイル・シーンを閉じるときは自動で外す。
    /// </summary>
    public sealed class LiveFacePreview : IDisposable
    {
        private sealed class Target
        {
            public Renderer Renderer;
            public int Index;
            public string[] Properties;

            /// <summary>付ける前の PropertyBlock（外すときに戻す）。空なら null に戻す。</summary>
            public MaterialPropertyBlock Original;
            public bool OriginalEmpty;
        }

        private readonly List<Target> _targets = new List<Target>();
        private GameObject _avatar;
        private Texture _faceTexture;
        private Texture _shown;

        /// <summary>シーンに一時表示中。</summary>
        public bool IsAttached => _targets.Count > 0;

        public GameObject Avatar => _avatar;
        public Texture FaceTexture => _faceTexture;

        public LiveFacePreview()
        {
            EditorApplication.playModeStateChanged += OnPlayModeChanged;
            AssemblyReloadEvents.beforeAssemblyReload += Detach;
            EditorSceneManager.sceneClosing += OnSceneClosing;
            EditorApplication.update += OnEditorUpdate;
        }

        public void Dispose()
        {
            Detach();
            EditorApplication.update -= OnEditorUpdate;
            EditorApplication.playModeStateChanged -= OnPlayModeChanged;
            AssemblyReloadEvents.beforeAssemblyReload -= Detach;
            EditorSceneManager.sceneClosing -= OnSceneClosing;
        }

        /// <summary>
        /// avatar の顔のスロット（faceTexture を参照するマテリアル。生成済みの複製は元マテリアルで判定）に、
        /// display を表示する。対象が前回と同じなら、テクスチャだけ差し替える。表示したスロットの数を返す。
        /// </summary>
        public int Show(GameObject avatar, Texture faceTexture, Texture display)
        {
            if (avatar == null || faceTexture == null || display == null || EditorApplication.isPlayingOrWillChangePlaymode)
            {
                Detach();
                return 0;
            }

            bool sameTarget = ReferenceEquals(avatar, _avatar) && ReferenceEquals(faceTexture, _faceTexture);

            // シーンが変わった後は、顔のスロットが本当に変わったときだけ付け直す
            List<FaceMaterialApplier.Slot> slots = null;
            if (sameTarget && _stale)
            {
                slots = FaceMaterialApplier.FindFaceSlots(avatar, faceTexture);
                if (!SameSlots(slots)) sameTarget = false;
            }
            _stale = false;

            if (!sameTarget || !TargetsAlive())
            {
                Detach();
                Attach(avatar, faceTexture, slots); // _shown が null に戻るので、付け直したスロットにも下で表示する
                if (IsAttached) HookPreCull();
            }

            if (!ReferenceEquals(display, _shown))
            {
                _shown = display;
                foreach (Target t in _targets) ApplyTexture(t, display);
                foreach (Target t in _proxyTargets) ApplyTexture(t, display);
                if (_proxyTargets.Count == 0) SyncProxies(); // 付けた直後・付け直した直後は、すぐ代理を探す
                SceneView.RepaintAll();
            }

            return _targets.Count;
        }

        private static MaterialPropertyBlock _sharedBlock;

        /// <summary>付ける前の内容 + テクスチャの上書きを、スロットに設定する。</summary>
        private static void ApplyTexture(Target t, Texture display)
        {
            if (t.Renderer == null) return;
            MaterialPropertyBlock block = _sharedBlock ?? (_sharedBlock = new MaterialPropertyBlock());
            block.Clear();
            if (!t.OriginalEmpty) t.Renderer.GetPropertyBlock(block, t.Index);
            foreach (string prop in t.Properties) block.SetTexture(prop, display);
            t.Renderer.SetPropertyBlock(block, t.Index);
        }

        // ── NDMF プレビューの代理レンダラー ──
        // NDMF のプレビュー（Modular Avatar・TexTransTool・AAO などのプレビュー）が ON の間は、
        // 元のレンダラーは描かれず、NDMF が作った代理のレンダラー（"Proxy renderer for <元の名前>"）が描かれる
        // （シーンビューにも、3D 顔ビューのカメラにも）。代理には MaterialPropertyBlock がコピーされないので、
        // 代理を探して同じテクスチャを付ける（見分け方は NdmfProxies）。
        // 代理はプレビューの作り直しで入れ替わるので、表示中は定期的に探し直す。

        private const double ProxyScanInterval = 0.5;

        private readonly List<Target> _proxyTargets = new List<Target>();
        private double _nextProxyScan;

        private void OnEditorUpdate()
        {
            if (!IsAttached || _shown == null) return;
            if (EditorApplication.timeSinceStartup < _nextProxyScan) return;
            _nextProxyScan = EditorApplication.timeSinceStartup + ProxyScanInterval;
            SyncProxies();
            HookPreCull(); // NDMF が後から登録し直していても、また後ろに並ぶ
        }

        // ── 描く直前の付け直し ──
        // NDMF は描くたびに（Camera.onPreCull・Scene ビューの onGUIStarted で）元のレンダラーを代理へ
        // EditorUtility.CopySerializedIfDifferent で写し直すため、代理に付けた PropertyBlock が消えることがある。
        // そこで、NDMF の後に呼ばれる onPreCull で、代理に今のテクスチャを付け直す。
        // onPreCull は登録した順に呼ばれるので、外してから付け直して、いつも NDMF より後ろに並べる
        // （Scene ビューは NDMF が onGUIStarted で先に済ませるので、順序に関係なく後になる）。

        private bool _preCullHooked;

        private void HookPreCull()
        {
            Camera.onPreCull -= OnPreCull;
            Camera.onPreCull += OnPreCull;
            _preCullHooked = true;
        }

        private void UnhookPreCull()
        {
            if (!_preCullHooked) return;
            Camera.onPreCull -= OnPreCull;
            _preCullHooked = false;
        }

        private void OnPreCull(Camera cam)
        {
            if (_shown == null || _proxyTargets.Count == 0) return;
            foreach (Target t in _proxyTargets) ApplyTexture(t, _shown);
        }

        /// <summary>代理のレンダラーを探し直し、新しく見つかったものに今のテクスチャを付ける。消えたものは忘れる。</summary>
        private void SyncProxies()
        {
            _proxyTargets.RemoveAll(t => t.Renderer == null);

            var found = new List<Target>();
            foreach (Renderer proxy in NdmfProxies.FindAll())
            {
                foreach (Target t in _targets)
                {
                    if (NdmfProxies.IsProxyOf(proxy, t.Renderer) && t.Index < proxy.sharedMaterials.Length)
                        found.Add(new Target { Renderer = proxy, Index = t.Index, Properties = t.Properties });
                }
            }

            bool changed = false;
            foreach (Target f in found)
            {
                if (_proxyTargets.Exists(p => p.Renderer == f.Renderer && p.Index == f.Index)) continue;
                var original = new MaterialPropertyBlock();
                f.Renderer.GetPropertyBlock(original, f.Index);
                f.Original = original;
                f.OriginalEmpty = original.isEmpty;
                _proxyTargets.Add(f);
                ApplyTexture(f, _shown);
                changed = true;
            }
            if (changed)
            {
                SceneView.RepaintAll();
                ProxiesChanged?.Invoke();
            }
        }

        /// <summary>NDMF プレビューの代理に表示を付けた（3D 顔ビューの描き直しに使う）。</summary>
        public event Action ProxiesChanged;

        /// <summary>代理に付けた表示を外す（代理が残っていれば、付ける前の PropertyBlock に戻す）。</summary>
        private void DetachProxies()
        {
            foreach (Target t in _proxyTargets)
            {
                if (t.Renderer == null) continue;
                t.Renderer.SetPropertyBlock(t.OriginalEmpty ? null : t.Original, t.Index);
            }
            _proxyTargets.Clear();
        }

        /// <summary>テクスチャの中身だけが変わった（同じ Texture2D に書き直した）ときに、Scene ビューを描き直す。</summary>
        public void Refresh()
        {
            if (IsAttached) SceneView.RepaintAll();
        }

        /// <summary>
        /// ヒエラルキーやマテリアルが変わった。次の Show で対象のスロットを数え直し、変わっていたときだけ付け直す
        /// （変更のたびに付け直すと、関係のない編集でも全スロットの走査と再描画が走るため）。
        /// </summary>
        public void Invalidate()
        {
            if (IsAttached) _stale = true;
        }

        /// <summary>次の Show でスロットを数え直す。</summary>
        private bool _stale;

        /// <summary>slots が今表示しているスロットと同じ（同じレンダラー・同じ番号・同じプロパティ）か。</summary>
        private bool SameSlots(List<FaceMaterialApplier.Slot> slots)
        {
            var current = new List<Target>();
            foreach (FaceMaterialApplier.Slot slot in slots)
            {
                string[] props = FaceProperties(slot);
                if (props.Length > 0) current.Add(new Target { Renderer = slot.Renderer, Index = slot.Index, Properties = props });
            }
            if (current.Count != _targets.Count) return false;

            for (int i = 0; i < current.Count; i++)
            {
                Target a = current[i], b = _targets[i];
                if (a.Renderer != b.Renderer || a.Index != b.Index) return false;
                if (a.Properties.Length != b.Properties.Length) return false;
                for (int p = 0; p < a.Properties.Length; p++)
                {
                    if (!string.Equals(a.Properties[p], b.Properties[p], StringComparison.Ordinal)) return false;
                }
            }
            return true;
        }

        /// <summary>スロットの元マテリアルで、顔テクスチャを参照しているテクスチャプロパティ。</summary>
        private string[] FaceProperties(FaceMaterialApplier.Slot slot)
        {
            var props = new List<string>();
            foreach (string prop in slot.Original.GetTexturePropertyNames())
            {
                if (slot.Original.GetTexture(prop) == _faceTexture) props.Add(prop);
            }
            return props.ToArray();
        }

        /// <summary>表示を外し、元の PropertyBlock に戻す。</summary>
        public void Detach()
        {
            UnhookPreCull();
            DetachProxies();
            foreach (Target t in _targets)
            {
                if (t.Renderer == null) continue;
                t.Renderer.SetPropertyBlock(t.OriginalEmpty ? null : t.Original, t.Index);
            }

            bool had = _targets.Count > 0;
            _targets.Clear();
            _avatar = null;
            _faceTexture = null;
            _shown = null;
            if (had) SceneView.RepaintAll();
        }

        /// <summary>slots が null なら、ここで数える。</summary>
        private void Attach(GameObject avatar, Texture faceTexture, List<FaceMaterialApplier.Slot> slots = null)
        {
            _avatar = avatar;
            _faceTexture = faceTexture;
            _shown = null;

            foreach (FaceMaterialApplier.Slot slot in slots ?? FaceMaterialApplier.FindFaceSlots(avatar, faceTexture))
            {
                string[] props = FaceProperties(slot);
                if (props.Length == 0) continue;

                var original = new MaterialPropertyBlock();
                slot.Renderer.GetPropertyBlock(original, slot.Index);

                _targets.Add(new Target
                {
                    Renderer = slot.Renderer,
                    Index = slot.Index,
                    Properties = props,
                    Original = original,
                    OriginalEmpty = original.isEmpty
                });
            }
        }

        private bool TargetsAlive()
        {
            if (_targets.Count == 0) return false;
            foreach (Target t in _targets)
            {
                if (t.Renderer == null) return false;
            }
            return true;
        }

        private void OnPlayModeChanged(PlayModeStateChange change)
        {
            if (change == PlayModeStateChange.ExitingEditMode) Detach();
        }

        private void OnSceneClosing(UnityEngine.SceneManagement.Scene scene, bool removingScene) => Detach();

        // ── 顔を映す ──

        /// <summary>
        /// 最後に使った Scene ビューのカメラを、アバターの顔の正面に向ける（§13.6）。
        /// Humanoid なら頭のボーン、そうでなければ顔のスロットのレンダラーの範囲を映す。映せなければ false。
        /// </summary>
        public static bool FrameFace(GameObject avatar, Texture faceTexture)
        {
            SceneView view = SceneView.lastActiveSceneView;
            if (view == null || avatar == null) return false;

            Animator animator = avatar.GetComponentInChildren<Animator>(true);
            Transform head = animator != null && animator.isHuman ? animator.GetBoneTransform(HumanBodyBones.Head) : null;
            if (head != null)
            {
                Transform root = avatar.transform;
                Vector3 pivot = head.position + root.up * 0.06f;
                // カメラはアバターの正面から、アバターの方を向く
                Quaternion rotation = Quaternion.LookRotation(-root.forward, root.up);
                view.LookAt(pivot, rotation, 0.25f);
                return true;
            }

            var slots = faceTexture != null ? FaceMaterialApplier.FindFaceSlots(avatar, faceTexture) : null;
            if (slots == null || slots.Count == 0) return false;

            Bounds bounds = slots[0].Renderer.bounds;
            foreach (FaceMaterialApplier.Slot s in slots) bounds.Encapsulate(s.Renderer.bounds);
            view.Frame(bounds, false);
            return true;
        }
    }
}
