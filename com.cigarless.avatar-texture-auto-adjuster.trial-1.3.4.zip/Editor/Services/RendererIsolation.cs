// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/RendererIsolation.cs
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 装飾品単体表示（IsolateFace / FaceSolo、3ペイン仕様 §4 案A）の「一時無効化トランザクション」。
    /// 3D 顔ビューの描画（Camera.Render）の間だけ、前髪・メガネなどのレンダラーを描かないようにする。
    ///
    /// 三重のフェイルセーフ:
    /// 1. 無効化する前に、対象と元の状態を静的リスト（_disabled）へ即時退避する。
    /// 2. 呼び出し側は try/finally の finally で ForceRestoreAll を呼び、描画が終わったらすぐ戻す。
    /// 3. 例外・割り込みで finally に届かなかった場合に備え、アセンブリの再読み込み前・再生モードの切り替え・
    ///    毎フレームの EditorApplication.update・ウィンドウの OnDisable / OnDestroy のすべてから ForceRestoreAll を呼ぶ。
    ///
    /// 無効化には Renderer.forceRenderingOff を使う。enabled と違いシリアライズされない実行時だけのフラグなので、
    /// 万一戻し損ねてもシーン・プレハブには保存されず、シーンも Dirty にならない。
    /// </summary>
    [InitializeOnLoad]
    public static class RendererIsolation
    {
        private struct Entry
        {
            public Renderer Renderer;
            public bool WasForcedOff;
        }

        private static readonly List<Entry> _disabled = new List<Entry>();

        /// <summary>一時的に描画を止めているレンダラーがある。</summary>
        public static bool IsActive => _disabled.Count > 0;

        static RendererIsolation()
        {
            AssemblyReloadEvents.beforeAssemblyReload += ForceRestoreAll;
            EditorApplication.playModeStateChanged += _ => ForceRestoreAll();
            EditorApplication.update += OnUpdate;
            EditorApplication.quitting += ForceRestoreAll;
        }

        /// <summary>
        /// renderers の描画を止める（すでに止まっているものはそのまま）。必ず try/finally で ForceRestoreAll と対にする。
        /// 前のトランザクションが残っていれば、先に戻してから始める。
        /// </summary>
        public static void Begin(IEnumerable<Renderer> renderers)
        {
            ForceRestoreAll();
            if (renderers == null) return;

            foreach (Renderer r in renderers)
            {
                if (r == null || r.forceRenderingOff) continue;
                // 退避してから止める（止めた後に例外が起きても、リストから必ず戻せる）
                _disabled.Add(new Entry { Renderer = r, WasForcedOff = false });
                r.forceRenderingOff = true;
            }
        }

        /// <summary>止めたレンダラーをすべて元に戻し、リストを空にする。何度呼んでもよい。</summary>
        public static void ForceRestoreAll()
        {
            if (_disabled.Count == 0) return;
            for (int i = _disabled.Count - 1; i >= 0; i--)
            {
                Entry e = _disabled[i];
                try
                {
                    if (e.Renderer != null) e.Renderer.forceRenderingOff = e.WasForcedOff;
                }
                catch (System.Exception ex)
                {
                    Debug.LogException(ex);
                }
            }
            _disabled.Clear();
        }

        private static void OnUpdate()
        {
            // 描画は同じフレームの中で終わるので、update の時点で残っていれば戻し損ね
            if (_disabled.Count > 0) ForceRestoreAll();
        }
    }
}
