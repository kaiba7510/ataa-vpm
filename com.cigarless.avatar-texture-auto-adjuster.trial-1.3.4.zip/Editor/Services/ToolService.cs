// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/ToolService.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// フィッティング（メイク適用）の処理。FaceMaps フォルダの走査と、
    /// 選択した 2 つの FaceMap を label で対応付けて UV を変形する流れを担う。
    /// </summary>
    internal class ToolService
    {
        private readonly MyVrcToolState _state;
        private CancellationTokenSource _scanCts;
        private CancellationTokenSource _applyCts;
        private CancellationTokenSource _pairCts;

        /// <summary>直近に読み込んだ組み合わせのファイルパス（更新日時を含まない）。</summary>
        private string _pairPaths;

        /// <summary>状態が変わった（再描画してほしい）ことを通知する。</summary>
        public event Action Changed;

        public ToolService(MyVrcToolState state)
        {
            _state = state ?? throw new ArgumentNullException(nameof(state));
        }

        public void Cancel()
        {
            _scanCts?.Cancel();
            _applyCts?.Cancel();
            _pairCts?.Cancel();
        }

        /// <summary>
        /// FaceMaps フォルダを確認（なければ作成）し、直下の .json を非同期で走査・検証する。
        /// 走査中に再度呼ばれた場合は、古い走査の結果を破棄する。
        /// </summary>
        public Task RefreshAsync()
        {
            _scanCts?.Cancel();
            var cts = new CancellationTokenSource();
            _scanCts = cts;

            string folder = null;
            try
            {
                if (!FaceMapFolder.TryEnsure(out _, out folder, out string error))
                {
                    _state.FaceMapFolderPath = null;
                    _state.FaceMaps = new List<FaceMapMeta>();
                    _state.IsScanning = false;
                    SetWarning(error, MessageType.Error);
                    return Task.CompletedTask;
                }

                _state.FaceMapFolderPath = folder;
                _state.IsScanning = true;

                List<FaceMapMeta> list = FaceMapRepository.List(folder, cts.Token);
                if (cts.IsCancellationRequested) return Task.CompletedTask;

                _state.FaceMaps = list;

                // 一覧から消えた、または invalid になった選択は解除する
                FaceMapMeta makeup = _state.MakeupFaceMap;
                if (makeup == null || !makeup.IsValid) _state.MakeupFaceMapPath = null;
                FaceMapMeta avatar = _state.AvatarFaceMap;
                if (avatar == null || !avatar.IsValid) _state.AvatarFaceMapPath = null;
            }
            catch (OperationCanceledException)
            {
                // 新しい走査に置き換えられた
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
                SetWarning("FaceMap の走査に失敗しました: " + ex.Message, MessageType.Error);
            }
            finally
            {
                if (ReferenceEquals(_scanCts, cts))
                {
                    _state.IsScanning = false;
                    Changed?.Invoke();
                }
            }

            return Task.CompletedTask;
        }

        /// <summary>
        /// 選択中のメイク元と対象の FaceMap を読み込んで対応付け、保存済みの微調整を読み込む。
        /// 組み合わせが前回と同じなら何もしない（毎フレーム呼んでよい）。
        /// </summary>
        public Task RefreshPairAsync()
        {
            FaceMapMeta makeupMeta = _state.MakeupFaceMap;
            FaceMapMeta avatarMeta = _state.AvatarFaceMap;
            string paths = _state.HasPair ? makeupMeta.FilePath + "|" + avatarMeta.FilePath : null;
            string key = paths != null
                ? paths + "|" + makeupMeta.LastWriteTicks + "|" + avatarMeta.LastWriteTicks
                : null;
            if (key == _state.PairKey) return Task.CompletedTask;

            _pairCts?.Cancel();
            var cts = new CancellationTokenSource();
            _pairCts = cts;

            // 同じ組み合わせで FaceMap の内容だけが変わった場合は、微調整（編集中の値）と
            // 直前の対応付けを残したまま読み直す（プレビューが一瞬消えたり、値が巻き戻ったりしない）
            bool samePair = paths != null && paths == _pairPaths;
            _pairPaths = paths;

            _state.PairKey = key;
            _state.PairError = null;
            if (!samePair)
            {
                _state.PairMatch = null;
                _state.Adjustment = new FaceMapAdjustment();
                _state.AdjustmentPath = null;
            }

            if (key == null)
            {
                Changed?.Invoke();
                return Task.CompletedTask;
            }

            try
            {
                FaceMapRepository.LoadResult makeup = FaceMapRepository.Load(makeupMeta.FilePath);
                FaceMapRepository.LoadResult avatar = FaceMapRepository.Load(avatarMeta.FilePath);
                if (cts.IsCancellationRequested) return Task.CompletedTask;

                if (!makeup.Succeeded || !avatar.Succeeded)
                {
                    List<string> errors = !makeup.Succeeded ? makeup.Errors : avatar.Errors;
                    _state.PairMatch = null;
                    _state.PairError = "FaceMap を読み込めません: " + string.Join(" / ", errors);
                    return Task.CompletedTask;
                }

                FaceMapMatch match = AtaaCore.Match(makeup.Map, avatar.Map);
                _state.PairMatch = match;
                _state.PairError = match.Error;

                if (!(samePair && _state.AdjustmentPath != null)
                    && FaceMapFolder.TryEnsure(out _, out string folder, out _))
                {
                    _state.AdjustmentPath = FaceMapAdjustmentFile.GetPath(folder, makeupMeta.FilePath, avatarMeta.FilePath);
                    _state.Adjustment = FaceMapAdjustmentFile.Load(_state.AdjustmentPath);
                }

                // 目の線の上書き（組み合わせごとの調整）を、対象の FaceMap の値に重ねる。FaceMap のファイルは変えない
                AtaaCore.ApplyEyeLineOverrides(match, _state.Adjustment);
            }
            catch (OperationCanceledException)
            {
                // 新しい組み合わせに置き換えられた
            }
            catch (Exception ex)
            {
                _state.PairError = "FaceMap の読み込みに失敗しました: " + ex.Message;
            }
            finally
            {
                if (ReferenceEquals(_pairCts, cts)) Changed?.Invoke();
            }

            return Task.CompletedTask;
        }

        /// <summary>現在の微調整を、組み合わせごとのファイルに保存する（調整なしなら削除する）。</summary>
        public void SaveAdjustment()
        {
            if (string.IsNullOrEmpty(_state.AdjustmentPath)) return;

            if (!_state.Adjustment.TrySave(_state.AdjustmentPath, out string error))
                SetWarning("微調整を保存できませんでした: " + error, MessageType.Warning);
        }

        // 体験版の DLL には、メイク適用（テクスチャの書き出し・マテリアルの差し替え）と解除を入れない
        /// <summary>
        /// 選択中のメイク元・対象の FaceMap が一時データなら、FaceMaps フォルダへ実ファイルとして保存し、選択を差し替える。
        /// 微調整・テクスチャ記憶はファイル名（拡張子なし）が鍵なので、そのまま引き継がれる。失敗したら理由を出して false。
        /// </summary>
        private async Task<bool> PromoteDraftSelectionsAsync()
        {
            if (!FaceMapStorage.IsDraft(_state.MakeupFaceMapPath) && !FaceMapStorage.IsDraft(_state.AvatarFaceMapPath)) return true;

            if (!FaceMapStorage.TryGetSaveFolder(out string folder, out string error))
            {
                SetWarning("FaceMap を保存できません: " + error, MessageType.Error);
                return false;
            }

            // 同じ一時データを両方に選んでいても 1 回だけ保存する（保存後に両方のパスを差し替えるので、毎回選択を読み直す）
            for (int i = 0; i < 2; i++)
            {
                string path = i == 0 ? _state.MakeupFaceMapPath : _state.AvatarFaceMapPath;
                if (!FaceMapStorage.IsDraft(path)) continue;
                if (!FaceMapStorage.TryPromote(path, folder, out string newPath, out error))
                {
                    SetWarning("自動生成した FaceMap を保存できません: " + error, MessageType.Error);
                    return false;
                }
                _state.MakeupFaceMapPath = FaceMapStorage.RemapPath(_state.MakeupFaceMapPath, path, newPath);
                _state.AvatarFaceMapPath = FaceMapStorage.RemapPath(_state.AvatarFaceMapPath, path, newPath);
            }

            FaceMapStorage.RefreshAssets();
            await RefreshAsync();
            return true;
        }

        /// <summary>
        /// メイク元と対象の FaceMap を読み込み、領域を対応付けて、メイク元の顔テクスチャを対象の UV 空間に写して
        /// 対象の顔テクスチャに重ねた PNG を生成し、顔のマテリアルに適用する（FaceMap 仕様 v0.4 §8）。
        /// メッシュの UV は変更しない。保存済みの微調整・合成範囲があれば反映する。
        /// 成功したら生成したテクスチャのアセットパスを、できなかったら null を返す。
        /// ApplyTiming.Enabled なら、終わったときに段階ごとの所要時間を Console に出す（高速化の検討用）。
        /// </summary>
        public async Task<string> ApplyMakeupAsync()
        {
            var timing = new ApplyTiming();
            string generated = null;
            try
            {
                generated = await ApplyMakeupCoreAsync(timing);
                return generated;
            }
            finally
            {
                if (ApplyTiming.Enabled && timing.HasLaps)
                    Debug.Log(timing.Format(generated != null ? "メイク適用" : "メイク適用（途中で終了）"));
            }
        }

        private async Task<string> ApplyMakeupCoreAsync(ApplyTiming timing)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                // 再生モードのマテリアル変更は再生を止めると戻る。一時停止中は await の続きも進まない
                SetWarning("再生モード中は適用できません。再生を止めてから適用してください。", MessageType.Warning);
                return null;
            }
            if (!_state.IsReady)
            {
                SetWarning("準備が完了していません（対象アバターと、メイク元・対象の FaceMap を選択してください）。", MessageType.Warning);
                return null;
            }
            if (_state.PreviewAvatarTexture == null || _state.PreviewMakeupTexture == null)
            {
                SetWarning("「対象の顔テクスチャ」と「メイク元の顔テクスチャ」を指定してください。", MessageType.Warning);
                return null;
            }
            if (EditorUtility.IsPersistent(_state.TargetAvatar))
            {
                SetWarning("対象アバターは、シーン上のオブジェクトを指定してください（プロジェクト内のアセットは変更できません）。", MessageType.Warning);
                return null;
            }

            // 自動生成しただけの一時データ（ATAA-Auto/）は、使うこのタイミングで実ファイルに保存する
            if (!await PromoteDraftSelectionsAsync()) return null;
            timing.Lap("一時データの保存");
            if (!_state.IsReady) return null;

            _applyCts?.Cancel();
            var cts = new CancellationTokenSource();
            _applyCts = cts;

            FaceMapMeta makeupMeta = _state.MakeupFaceMap;
            FaceMapMeta avatarMeta = _state.AvatarFaceMap;
            GameObject avatarObject = _state.TargetAvatar;
            Texture2D avatarTex = _state.PreviewAvatarTexture;
            Texture2D makeupTex = _state.PreviewMakeupTexture;
            float opacity = _state.PreviewMakeupOpacity;

            try
            {
                // 微調整が、いま選んでいる組み合わせのものになっていることを保証する
                await RefreshPairAsync();
                timing.Lap("組み合わせの更新");
                if (cts.IsCancellationRequested) return null;
                FaceMapAdjustment adjustment = _state.Adjustment.Clone();

                Task<FaceMapRepository.LoadResult> makeupTask = FaceMapRepository.LoadAsync(makeupMeta.FilePath, cts.Token);
                Task<FaceMapRepository.LoadResult> avatarTask = FaceMapRepository.LoadAsync(avatarMeta.FilePath, cts.Token);
                FaceMapRepository.LoadResult makeup = await makeupTask;
                FaceMapRepository.LoadResult avatar = await avatarTask;
                timing.Lap("FaceMap の読み込み");

                if (cts.IsCancellationRequested) return null;

                if (!makeup.Succeeded)
                {
                    SetWarning($"メイク元 FaceMap「{makeupMeta.DisplayName}」を読み込めません: " + string.Join(" / ", makeup.Errors), MessageType.Error);
                    return null;
                }
                if (!avatar.Succeeded)
                {
                    SetWarning($"対象 FaceMap「{avatarMeta.DisplayName}」を読み込めません: " + string.Join(" / ", avatar.Errors), MessageType.Error);
                    return null;
                }
                if (avatarObject == null)
                {
                    SetWarning("対象アバターが見つかりません。", MessageType.Warning);
                    return null;
                }

                FaceMapMatch match = AtaaCore.Match(makeup.Map, avatar.Map);
                AtaaCore.ApplyEyeLineOverrides(match, adjustment);
                if (!match.IsApplicable)
                {
                    SetWarning(match.Error, MessageType.Warning);
                    return null;
                }

                FaceMask mask = AtaaCore.BuildMask(match, adjustment);
                timing.Lap("対応付け・マスク");
                // 重ねるだけのメイクの肌色合わせ用に、メイク元の素体の肌色を入れておく（プレビューと同じ）
                MakeupBaseSkin.Assign(mask, makeupMeta, makeupTex, FaceTextureGenerator.IsLinear(avatarTex));
                timing.Lap("素体の肌色の推定");
                if (mask.IsEmpty)
                {
                    SetWarning("合成するパーツがすべて OFF になっています。少なくとも 1 つのパーツを ON にしてください。", MessageType.Warning);
                    return null;
                }

                if (!AtaaCore.TryBuildDeformer(match, adjustment, out AvatarDeformer deformer, out string controlError,
                                                     out bool initFailed))
                {
                    // 制御点の問題は警告、変形の計算の失敗はエラー（統合前と同じ区別）
                    SetWarning(controlError, initFailed ? MessageType.Error : MessageType.Warning);
                    return null;
                }
                timing.Lap("変形の構築");

                // 顔のマテリアル（対象の顔テクスチャを参照しているもの）。無ければテクスチャも作らない
                List<FaceMaterialApplier.Slot> slots = FaceMaterialApplier.FindFaceSlots(avatarObject, avatarTex);
                if (slots.Count == 0)
                {
                    SetWarning($"対象アバターに、顔テクスチャ「{avatarTex.name}」を使うマテリアルが見つかりません。", MessageType.Warning);
                    return null;
                }

                // 出力先は FaceMaps/Generated/<対象>/<メイク元>。組み合わせごとに名前は固定（再適用は同じファイルを上書きする）
                string makeupName = FaceMapSerializer.SanitizeFileName(Path.GetFileNameWithoutExtension(makeupMeta.FilePath));
                string avatarName = FaceMapSerializer.SanitizeFileName(Path.GetFileNameWithoutExtension(avatarMeta.FilePath));
                if (!FaceMaterialApplier.TryEnsureOutputFolder(makeupName, avatarName, out string folder, out string folderError))
                {
                    SetWarning(folderError, MessageType.Error);
                    return null;
                }
                timing.Lap("顔のスロット・出力先の確認");

                FaceTextureGenerator.Result generatedPng =
                    await FaceTextureGenerator.GenerateAsync(avatarTex, makeupTex, deformer, mask, opacity, timing);
                if (generatedPng.Error != null)
                {
                    SetWarning("テクスチャを生成できませんでした: " + generatedPng.Error, MessageType.Error);
                    return null;
                }
                byte[] png = generatedPng.Png;

                // 合成の間はエディターを操作できるので、アバター・マテリアルが変わっていないか確かめ直す
                if (cts.IsCancellationRequested) return null;
                if (avatarObject == null || avatarTex == null)
                {
                    SetWarning("合成中に対象アバターまたは顔テクスチャが無くなったため、適用しませんでした。", MessageType.Warning);
                    return null;
                }
                slots = FaceMaterialApplier.FindFaceSlots(avatarObject, avatarTex);
                if (slots.Count == 0)
                {
                    SetWarning($"対象アバターに、顔テクスチャ「{avatarTex.name}」を使うマテリアルが見つかりません。", MessageType.Warning);
                    return null;
                }

                string textureName = FaceMapSerializer.SanitizeFileName(avatarTex.name) + ".png";

                timing.Lap("スロットの確かめ直し");

                Texture2D generated = FaceMaterialApplier.SaveTexture(png, folder, textureName, avatarTex);
                timing.Lap("PNG の保存とインポート");
                if (generated == null)
                {
                    SetWarning("生成したテクスチャを読み込めませんでした: " + folder + "/" + textureName, MessageType.Error);
                    return null;
                }

                int applied = FaceMaterialApplier.Apply(slots, avatarTex, generated, folder, out string applyError);
                timing.Lap("マテリアルの差し替え");
                if (applied < 0)
                {
                    SetWarning(applyError, MessageType.Error);
                    return null;
                }

                var notes = new List<string>();
                string w2 = FaceMapValidator.CheckTargetAvatar(avatar.Map.TargetAvatar, avatarObject.name);
                if (w2 != null) notes.Add(w2);
                if (match.UnmatchedMakeup.Count > 0 || match.UnmatchedAvatar.Count > 0)
                {
                    notes.Add("F3: 片方にしかない任意の領域は無視しました"
                              + $"（メイク元のみ: {JoinLabels(match.UnmatchedMakeup)} / 対象のみ: {JoinLabels(match.UnmatchedAvatar)}）");
                }

                if (adjustment.IsEnabled(FaceMapFile.MouthCategory) && AtaaCore.IsExtremeMouthScale(match))
                {
                    notes.Add($"口の大きさがメイク元と大きく違うため（顔に対して約 {AtaaCore.RelativeMouthScale(match):0.#} 倍）、唇が崩れることがあります。" +
                              "合わなければ「口」の「合成する」を OFF にしてください。");
                }

                var off = new List<string>();
                foreach (string category in AtaaCore.GetCategories(match))
                {
                    if (!adjustment.IsEnabled(category)) off.Add(category);
                }

                string message = $"メイクを適用しました（{applied} スロットのマテリアルを差し替え、{match.Regions.Count} 領域で対応付け"
                                 + (adjustment.IsIdentity ? "" : "、微調整あり")
                                 + (off.Count > 0 ? "、合成しないパーツ: " + string.Join("・", off) : "") + "）。\n"
                                 + $"生成: {folder}/{textureName}";
                if (notes.Count > 0) message += "\n" + string.Join("\n", notes);
                SetWarning(message, notes.Count > 0 ? MessageType.Warning : MessageType.Info);
                return folder + "/" + textureName;
            }
            catch (OperationCanceledException)
            {
                // 新しい適用に置き換えられた
            }
            catch (Exception ex)
            {
                SetWarning("メイクの適用に失敗しました: " + ex.Message, MessageType.Error);
            }
            return null;
        }

        /// <summary>生成したマテリアルが入っているスロットを、元のマテリアルに戻す。</summary>
        /// <returns>元に戻したスロット数（対象アバターが無ければ 0）。</returns>
        public int RevertMakeup()
        {
            GameObject avatar = _state.TargetAvatar;
            if (avatar == null)
            {
                SetWarning("対象アバターを指定してください。", MessageType.Warning);
                return 0;
            }

            int reverted = FaceMaterialApplier.Revert(avatar);
            SetWarning(reverted == 0
                ? "解除するスロットがありません（メイクを適用したマテリアルが見つかりません）。"
                : $"適用を解除しました（{reverted} スロットを元のマテリアルに戻しました）。",
                reverted == 0 ? MessageType.Warning : MessageType.Info);
            return reverted;
        }

        private static string JoinLabels(List<string> labels)
        {
            return labels.Count == 0 ? "なし" : string.Join(", ", labels);
        }

        private void SetWarning(string message, MessageType type)
        {
            _state.Warning = message;
            _state.WarningType = type;
            Changed?.Invoke();
        }
    }
}
