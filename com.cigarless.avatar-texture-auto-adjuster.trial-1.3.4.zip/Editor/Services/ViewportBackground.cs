// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/ViewportBackground.cs
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>3D 顔ビューの背景の種類。保存値（EditorPrefs）に使うので順番を変えない。</summary>
    public enum ViewportBackgroundPreset
    {
        Dark = 0,
        Mid = 1,
        Light = 2,
        Checker = 3
    }

    /// <summary>
    /// 3D 顔ビューの背景（色・グラデーション・チェッカー）の決め方。
    /// 背景に色相があると肌の色が反対色に寄って見える（同時対比）ので、どれも無彩色にする。
    /// グラデーションとビネットは見栄えのためなので、色の判断を邪魔しない程度に弱くする。
    /// </summary>
    public static class ViewportBackground
    {
        public const ViewportBackgroundPreset Default = ViewportBackgroundPreset.Dark;

        /// <summary>チェッカーの 1 マスの大きさ（GUI ポイント）。</summary>
        public const float CheckerCellPoints = 12f;

        private const float GradientAmount = 0.03f; // 上下それぞれの明るさの差
        private const float VignetteAmount = 0.06f; // 四隅での暗さ

        public static ViewportBackgroundPreset FromSaved(int saved)
        {
            return saved >= 0 && saved <= (int)ViewportBackgroundPreset.Checker
                ? (ViewportBackgroundPreset)saved
                : Default;
        }

        public static ViewportBackgroundPreset Next(ViewportBackgroundPreset preset)
        {
            return (ViewportBackgroundPreset)(((int)preset + 1) % 4);
        }

        public static string Label(ViewportBackgroundPreset preset)
        {
            switch (preset)
            {
                case ViewportBackgroundPreset.Mid: return "背景: 中間";
                case ViewportBackgroundPreset.Light: return "背景: 明るい";
                case ViewportBackgroundPreset.Checker: return "背景: チェッカー";
                default: return "背景: 暗い";
            }
        }

        private static float BaseValue(ViewportBackgroundPreset preset)
        {
            switch (preset)
            {
                case ViewportBackgroundPreset.Mid: return 0.42f;
                case ViewportBackgroundPreset.Light: return 0.72f;
                default: return 0.2f;
            }
        }

        /// <summary>
        /// グラデーション背景の (u, v) の色（u: 左 0 → 右 1、v: 下 0 → 上 1）。
        /// 上が少し明るく、四隅が少し暗い。チェッカーには使わない（中間と同じ色を返す）。
        /// </summary>
        public static Color Sample(ViewportBackgroundPreset preset, float u, float v)
        {
            if (preset == ViewportBackgroundPreset.Checker) preset = ViewportBackgroundPreset.Mid;
            float du = u - 0.5f;
            float dv = v - 0.5f;
            float edge = (du * du + dv * dv) * 2f; // 中心 0 → 四隅 1
            float value = BaseValue(preset) + dv * 2f * GradientAmount - edge * VignetteAmount;
            value = Mathf.Clamp01(value);
            return new Color(value, value, value, 1f);
        }

        /// <summary>チェッカーの (x, y) マスの色。</summary>
        public static Color CheckerCell(int x, int y)
        {
            float value = ((x + y) & 1) == 0 ? 0.4f : 0.3f;
            return new Color(value, value, value, 1f);
        }

        /// <summary>2×2 のチェッカーテクスチャを width×height ピクセルに貼るときの繰り返し回数（マスを正方形に保つ）。</summary>
        public static Vector2 CheckerTiling(float width, float height, float cellPixels)
        {
            float cell = Mathf.Max(cellPixels, 1f) * 2f;
            return new Vector2(width / cell, height / cell);
        }
    }
}
