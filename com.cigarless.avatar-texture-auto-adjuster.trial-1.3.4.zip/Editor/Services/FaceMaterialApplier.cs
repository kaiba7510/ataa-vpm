// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/FaceMaterialApplier.cs
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 生成したテクスチャの保存と、顔のマテリアルへの適用（FaceMap 仕様 v0.4 §8）。
    /// 元のマテリアルは変更せず、複製に差し替える。複製には元マテリアルの GUID をアセットラベルで記録する。
    /// </summary>
    internal static class FaceMaterialApplier
    {
        public const string GeneratedFolderName = "Generated";
        public const string OriginLabelPrefix = "ATAA-origin:";

        public struct Slot
        {
            public Renderer Renderer;
            public int Index;
            /// <summary>複製ではなく、元のマテリアル。</summary>
            public Material Original;
        }

        // 体験版の DLL には、テクスチャの保存・マテリアルの差し替えを入れない（顔のスロットの特定はプレビューで使うので残す）
        /// <summary>
        /// 組み合わせごとの出力先 FaceMaps/Generated/&lt;対象&gt;/&lt;メイク元&gt;（アセットパス）を確認し、なければ作成する。
        /// 以前の平置き（Generated 直下の &lt;メイク元&gt;__&lt;対象&gt;__&lt;名前&gt;）が残っていれば、GUID を保ったまま新しい場所へ移す。
        /// </summary>
        public static bool TryEnsureOutputFolder(string makeupName, string avatarName, out string assetPath, out string error)
        {
            assetPath = null;
            if (!FaceMapFolder.TryEnsure(out string faceMaps, out _, out error)) return false;

            if (!TryEnsureSubFolder(faceMaps, GeneratedFolderName, out string root, out error)) return false;

            MoveLegacyFlatFiles(root);

            if (!TryEnsureSubFolder(root, avatarName, out string avatarFolder, out error)) return false;
            return TryEnsureSubFolder(avatarFolder, makeupName, out assetPath, out error);
        }

        private static bool TryEnsureSubFolder(string parent, string name, out string assetPath, out string error)
        {
            error = null;
            assetPath = parent + "/" + name;
            if (AssetDatabase.IsValidFolder(assetPath)) return true;
            if (File.Exists(FaceMapFolder.ToAbsolute(assetPath)))
            {
                error = $"{assetPath} と同名のファイルが存在するため、フォルダを作成できません。";
                return false;
            }
            if (string.IsNullOrEmpty(AssetDatabase.CreateFolder(parent, name)))
            {
                error = $"{assetPath} を作成できませんでした。";
                return false;
            }
            return true;
        }

        /// <summary>
        /// Generated 直下に平置きされた &lt;メイク元&gt;__&lt;対象&gt;__&lt;名前&gt;.png / .mat を、
        /// &lt;対象&gt;/&lt;メイク元&gt;/&lt;名前&gt; へ移す。MoveAsset なので GUID が残り、適用済みのアバターの参照は切れない。
        /// 区切りが 2 つちょうどでない名前（名前の中に「__」がある）は、どこで切るか決められないので動かさない。
        /// 移し先に同じ名前があれば、上書きせずに残す。
        /// </summary>
        private static void MoveLegacyFlatFiles(string root)
        {
            string absoluteRoot = FaceMapFolder.ToAbsolute(root);
            if (!Directory.Exists(absoluteRoot)) return;

            foreach (string file in Directory.GetFiles(absoluteRoot))
            {
                string ext = Path.GetExtension(file);
                if (ext != ".png" && ext != ".mat") continue;

                string[] parts = Path.GetFileNameWithoutExtension(file).Split(new[] { "__" }, System.StringSplitOptions.None);
                if (parts.Length != 3 || parts.Any(string.IsNullOrEmpty)) continue;

                if (!TryEnsureSubFolder(root, parts[1], out string avatarFolder, out _)) continue;
                if (!TryEnsureSubFolder(avatarFolder, parts[0], out string folder, out _)) continue;

                string to = folder + "/" + parts[2] + ext;
                if (File.Exists(FaceMapFolder.ToAbsolute(to))) continue;

                string from = root + "/" + Path.GetFileName(file);
                string moveError = AssetDatabase.MoveAsset(from, to);
                if (!string.IsNullOrEmpty(moveError)) Debug.LogWarning($"[ATAA] {from} を {to} へ移せませんでした: {moveError}");
            }
        }

        // ── 顔のマテリアルの特定 ──

        /// <summary>対象の顔テクスチャを参照しているマテリアルを持つスロットを集める。</summary>
        public static List<Slot> FindFaceSlots(GameObject avatar, Texture faceTexture)
        {
            var slots = new List<Slot>();
            foreach (Renderer r in avatar.GetComponentsInChildren<Renderer>(true))
            {
                Material[] mats = r.sharedMaterials;
                for (int i = 0; i < mats.Length; i++)
                {
                    Material original = ResolveOriginal(mats[i]);
                    if (original != null && ReferencesTexture(original, faceTexture))
                        slots.Add(new Slot { Renderer = r, Index = i, Original = original });
                }
            }
            return slots;
        }

        /// <summary>生成した複製なら、記録された元のマテリアルを返す。そうでなければそのまま返す。</summary>
        public static Material ResolveOriginal(Material m)
        {
            if (m == null) return null;
            string origin = GetOriginGuid(m);
            if (origin == null) return m;

            Material original = LoadOrigin(origin);
            return original != null ? original : m;
        }

        /// <summary>
        /// 記録から元のマテリアルを読む。記録は「GUID:ローカル ID」（FBX の埋め込みマテリアルなど、
        /// 1 つのファイルに複数のマテリアルがあるときに区別するため）。古い記録の「GUID」だけにも対応する。
        /// </summary>
        private static Material LoadOrigin(string origin)
        {
            int colon = origin.IndexOf(':');
            string guid = colon < 0 ? origin : origin.Substring(0, colon);
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (string.IsNullOrEmpty(path)) return null;

            if (colon >= 0 && long.TryParse(origin.Substring(colon + 1), out long localId))
            {
                foreach (Object asset in AssetDatabase.LoadAllAssetsAtPath(path))
                {
                    if (asset is Material mat
                        && AssetDatabase.TryGetGUIDAndLocalFileIdentifier(mat, out _, out long id)
                        && id == localId)
                        return mat;
                }
                return null; // ファイルはあるが、そのマテリアルが無くなった（別のマテリアルにすり替えない）
            }
            return AssetDatabase.LoadAssetAtPath<Material>(path);
        }

        private static string OriginKey(Material original)
        {
            if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(original, out string guid, out long localId))
                return guid + ":" + localId;
            return AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(original));
        }

        private static string GetOriginGuid(Material m)
        {
            if (!EditorUtility.IsPersistent(m)) return null;
            foreach (string label in AssetDatabase.GetLabels(m))
            {
                if (label.StartsWith(OriginLabelPrefix)) return label.Substring(OriginLabelPrefix.Length);
            }
            return null;
        }

        private static bool ReferencesTexture(Material m, Texture tex)
        {
            foreach (string prop in m.GetTexturePropertyNames())
            {
                if (m.GetTexture(prop) == tex) return true;
            }
            return false;
        }

        // ── 保存 ──

        /// <summary>
        /// PNG を保存してインポートする。既存ファイルは上書きし GUID を保つ。
        /// 新規作成のときだけ、インポート設定を source から引き継ぐ。
        /// Max Size は書き出した解像度まで上げる（新規のとき・既存でも source から引き継いだままのとき）。
        /// 対象の顔テクスチャの Max Size（Yumeka 2048）のままだと 4096 の書き出しが半分で読み込まれ、
        /// メイクを大きく縮めて写した口がさらに半分になってぼやけた。利用者が変えた Max Size はそのまま。
        /// </summary>
        public static Texture2D SaveTexture(byte[] png, string folderAssetPath, string fileName, Texture2D source)
        {
            string assetPath = folderAssetPath + "/" + fileName;
            string absolute = FaceMapFolder.ToAbsolute(assetPath);
            bool existed = File.Exists(absolute);
            int pngSize = TryReadPngSize(png, out int pngW, out int pngH) ? System.Math.Max(pngW, pngH) : 0;

            // 既存のファイルで、Max Size が source から引き継いだままなら、書き出しの解像度まで上げる（下の取り込みで 1 回だけ読み込む）
            if (existed && pngSize > 0 && AssetImporter.GetAtPath(assetPath) is TextureImporter existing)
            {
                int inherited = SourceMaxTextureSize(source);
                int raised = MaxSizeForPng(existing.maxTextureSize, pngSize);
                if (inherited > 0 && existing.maxTextureSize == inherited && raised != existing.maxTextureSize)
                {
                    File.WriteAllBytes(absolute, png);
                    existing.maxTextureSize = raised;
                    existing.SaveAndReimport();
                    return AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath);
                }
            }

            // 新規のときは、まず 1×1 の仮画像で .meta を作って設定を写してから本物を書く。
            // 本物を先にインポートして設定し直すと、高解像度のミップマップ生成・圧縮が 2 回走るため。
            // AssetPostprocessor（OnPreprocessTexture）で付けると、導入・削除のたびに
            // プロジェクトの全テクスチャが再インポートされるので使わない（FaceTextureSaveTests）。
            if (!existed)
            {
                File.WriteAllBytes(absolute, PlaceholderPng());
                AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceSynchronousImport);
                if (AssetImporter.GetAtPath(assetPath) is TextureImporter importer)
                {
                    CopyImportSettings(importer, source);
                    if (pngSize > 0) importer.maxTextureSize = MaxSizeForPng(importer.maxTextureSize, pngSize);
                    importer.SaveAndReimport();
                }
            }

            File.WriteAllBytes(absolute, png);
            AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);

            return AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath);
        }

        private static byte[] PlaceholderPng()
        {
            var tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            try
            {
                return tex.EncodeToPNG();
            }
            finally
            {
                Object.DestroyImmediate(tex);
            }
        }

        /// <summary>TextureImporter の Max Size の上限。</summary>
        internal const int LargestMaxTextureSize = 16384;

        /// <summary>
        /// 一辺 pngSize の画像を縮めずに読み込む Max Size。current より小さくはしない（2 の累乗。上限 16384）。
        /// </summary>
        internal static int MaxSizeForPng(int current, int pngSize)
        {
            int needed = 32;
            while (needed < pngSize && needed < LargestMaxTextureSize) needed *= 2;
            return System.Math.Max(current, needed);
        }

        /// <summary>PNG のヘッダー（IHDR）から幅・高さを読む。PNG でなければ false。</summary>
        internal static bool TryReadPngSize(byte[] png, out int width, out int height)
        {
            width = height = 0;
            if (png == null || png.Length < 24) return false;
            byte[] signature = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A };
            for (int i = 0; i < signature.Length; i++)
                if (png[i] != signature[i]) return false;
            width = (png[16] << 24) | (png[17] << 16) | (png[18] << 8) | png[19];
            height = (png[20] << 24) | (png[21] << 16) | (png[22] << 8) | png[23];
            return width > 0 && height > 0;
        }

        private static int SourceMaxTextureSize(Texture2D source)
        {
            string sourcePath = source != null ? AssetDatabase.GetAssetPath(source) : null;
            if (string.IsNullOrEmpty(sourcePath)) return 0;
            return AssetImporter.GetAtPath(sourcePath) is TextureImporter importer ? importer.maxTextureSize : 0;
        }

        /// <summary>source のインポート設定を、新しく作ったテクスチャのインポーターへ写す。</summary>
        internal static void CopyImportSettings(TextureImporter importer, Texture2D source)
        {
            string sourcePath = source != null ? AssetDatabase.GetAssetPath(source) : null;
            var sourceImporter = string.IsNullOrEmpty(sourcePath)
                ? null
                : AssetImporter.GetAtPath(sourcePath) as TextureImporter;

            if (sourceImporter != null)
            {
                var settings = new TextureImporterSettings();
                sourceImporter.ReadTextureSettings(settings);
                importer.SetTextureSettings(settings);
                importer.maxTextureSize = sourceImporter.maxTextureSize;
                importer.textureCompression = sourceImporter.textureCompression;
                importer.crunchedCompression = sourceImporter.crunchedCompression;
                importer.compressionQuality = sourceImporter.compressionQuality;
            }
            else
            {
                importer.sRGBTexture = !FaceTextureGenerator.IsLinear(source);
            }
        }

        // ── 適用 ──

        /// <summary>
        /// 顔のマテリアルを複製して生成テクスチャに差し替え、スロットを複製に切り替える。
        /// 切り替えたスロット数を返す（失敗時は -1 と error）。
        /// </summary>
        public static int Apply(List<Slot> slots, Texture faceTexture, Texture2D generated,
                                string folderAssetPath, out string error)
        {
            error = null;

            foreach (Slot s in slots)
            {
                if (!EditorUtility.IsPersistent(s.Original))
                {
                    error = $"マテリアル「{s.Original.name}」がプロジェクトのアセットではないため複製できません。";
                    return -1;
                }
            }

            var duplicates = new Dictionary<Material, Material>();
            foreach (Slot s in slots)
            {
                if (duplicates.ContainsKey(s.Original)) continue;
                duplicates[s.Original] = CreateOrUpdateDuplicate(s.Original, faceTexture, generated, folderAssetPath);
            }

            foreach (var group in slots.GroupBy(s => s.Renderer))
            {
                Renderer r = group.Key;
                Undo.RecordObject(r, "メイクを適用");
                Material[] mats = r.sharedMaterials;
                foreach (Slot s in group)
                {
                    if (s.Index < mats.Length) mats[s.Index] = duplicates[s.Original];
                }
                r.sharedMaterials = mats;
                EditorUtility.SetDirty(r);
            }

            AssetDatabase.SaveAssets();
            return slots.Count;
        }

        private static Material CreateOrUpdateDuplicate(Material original, Texture faceTexture, Texture2D generated,
                                                        string folderAssetPath)
        {
            // 組み合わせはフォルダで分かれているので、名前は元のマテリアルの名前のまま
            string baseName = FaceMapSerializer.SanitizeFileName(original.name);
            string path = folderAssetPath + "/" + baseName + ".mat";
            string originKey = OriginKey(original);

            Material dup = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (dup == null)
            {
                dup = new Material(original) { name = baseName };
                AssetDatabase.CreateAsset(dup, path);
            }
            else
            {
                // 同じ GUID のまま、元のマテリアルの内容で作り直す
                EditorUtility.CopySerialized(original, dup);
                dup.name = baseName;
            }

            foreach (string prop in dup.GetTexturePropertyNames())
            {
                if (dup.GetTexture(prop) == faceTexture) dup.SetTexture(prop, generated);
            }

            var labels = AssetDatabase.GetLabels(dup).Where(l => !l.StartsWith(OriginLabelPrefix)).ToList();
            labels.Add(OriginLabelPrefix + originKey);
            AssetDatabase.SetLabels(dup, labels.ToArray());

            EditorUtility.SetDirty(dup);
            return dup;
        }

        // ── 元に戻す ──

        /// <summary>生成した複製が入っているスロットを元のマテリアルに戻す。戻したスロット数を返す。</summary>
        public static int Revert(GameObject avatar)
        {
            int reverted = 0;
            foreach (Renderer r in avatar.GetComponentsInChildren<Renderer>(true))
            {
                Material[] mats = r.sharedMaterials;
                bool changed = false;
                for (int i = 0; i < mats.Length; i++)
                {
                    if (mats[i] == null || GetOriginGuid(mats[i]) == null) continue;

                    Material original = ResolveOriginal(mats[i]);
                    if (original == mats[i]) continue; // 元のマテリアルが見つからない

                    if (!changed) Undo.RecordObject(r, "メイクを元に戻す");
                    mats[i] = original;
                    changed = true;
                    reverted++;
                }
                if (changed)
                {
                    r.sharedMaterials = mats;
                    EditorUtility.SetDirty(r);
                    RevertPrefabMaterialOverride(r);
                }
            }
            return reverted;
        }

        /// <summary>
        /// プレハブのインスタンスで、戻した結果がプレハブ側のマテリアルと同じになったら、
        /// マテリアルの変更（Override）自体を外して、最初の状態に戻す。
        /// </summary>
        private static void RevertPrefabMaterialOverride(Renderer r)
        {
            if (!PrefabUtility.IsPartOfPrefabInstance(r)) return;

            var source = PrefabUtility.GetCorrespondingObjectFromSource(r);
            if (source == null || !source.sharedMaterials.SequenceEqual(r.sharedMaterials)) return;

            var so = new SerializedObject(r);
            SerializedProperty materials = so.FindProperty("m_Materials");
            if (materials != null && materials.prefabOverride)
                PrefabUtility.RevertPropertyOverride(materials, InteractionMode.UserAction);
        }
    }
}
