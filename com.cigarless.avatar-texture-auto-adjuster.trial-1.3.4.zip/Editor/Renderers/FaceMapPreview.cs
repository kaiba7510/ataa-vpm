// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Renderers/FaceMapPreview.cs
using System;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 微調整のプレビュー（FaceMap 仕様 v0.4 §13.5）。テクスチャ生成と同じ合成（FaceCompositor）で、
    /// 対象の顔テクスチャにメイクを重ねた画像を作る。ウィンドウ内の表示とライブプレビュー（§13.6）が同じ画像を使う。
    /// 計算はワーカースレッドで行い、Poll（メインスレッド）で結果をテクスチャに反映する。
    /// 計算中に次の依頼が来たら、最新の依頼だけを残して、今の計算が終わってから始める。
    /// </summary>
    public sealed class FaceMapPreview : IDisposable
    {
        /// <summary>ドラッグ中の解像度（長辺）。体験版の通常プレビュー（透かしなし）にも使う。</summary>
        public const int LowResolution = 512;

        /// <summary>体験版で高画質確認ボタンを押し続けている間の解像度上限（長辺。コアの TrialLimits.HighResMaxSide と揃える）。</summary>
        public const int TrialHighResolution = 2048;

        /// <summary>
        /// 止まっているときの解像度の上限（長辺）。画面と Scene ビューでの確認にはこれで足りる。
        /// 原寸（最大 8192）で持つと配列だけで数百 MB になり、操作のたびにエディターが固まるため。
        /// 書き出す PNG（FaceTextureGenerator）は今まで通り原寸で作る。
        /// 体験版は通常時 512（透かしなし）。高画質確認ボタンを押し続けている間だけ TrialHighResolution（2048・透かし入り）を使う。
        /// 体験版かどうかはコアの Edition で決める（UI のソースは全エディションで 1 つ）。制限の本体は体験版コアの出力
        /// （TrialLimits）で、ここは無駄に大きく読まないための合わせ。
        /// </summary>
        public static readonly int FullResolution = AtaaCore.Edition == CoreEdition.Trial ? LowResolution : 4096;

        public enum Quality
        {
            Low,
            Full
        }

        /// <summary>プレビューの表示（§13.5）。Before は対象の顔テクスチャをそのまま描くので計算しない。</summary>
        public enum ViewMode
        {
            Result,
            Before,
            Makeup,
            Mask
        }

        private static readonly Color32 MakeupBackground = new Color32(40, 40, 40, 255);

        private Texture2D _avatarSource;
        private Texture2D _makeupSource;
        private bool _linear;
        private FacePixels _baseFull;
        private FacePixels _baseLow;
        private FacePixels _makeup;
        private FacePixels _baseTrialHigh;
        private FacePixels _makeupTrialHigh;

        private Texture2D _fullTex;
        private Texture2D _lowTex;
        private Texture2D _viewTex;
        private Texture2D _trialHighTex;
        private Color32[] _fullBuffer;
        private Color32[] _lowBuffer;
        private Color32[] _viewBuffer;
        private Color32[] _trialHighBuffer;

        private sealed class Request
        {
            public int Generation;
            public AvatarDeformer Deformer;
            public FaceMask Mask;
            public float Opacity;
            public Quality Quality;
            public ViewMode View;
            public string Tag;
            public bool IsTrialHigh;

            /// <summary>調整なしの変形とマスク（基準の折り返しの数を測る。無ければ測らない）。</summary>
            public AvatarDeformer BaselineDeformer;
            public FaceMask BaselineMask;
        }

        private sealed class Result
        {
            public Request Request;
            public string Error;
            public DistortionReport Distortion;
            public DistortionReport? Baseline;
            public SkinToneStatus SkinTone;
            public Color SkinToneTint;
        }

        private int _generation;

        /// <summary>この番号より前の依頼の結果は使わない（テクスチャを差し替えたとき）。</summary>
        private int _validFrom;
        private Request _queued;
        private Request _queuedTrialHigh;
        private Task<Result> _running;
        private bool _runningTrialHigh;

        /// <summary>最新の合成結果（Low か Full）。まだ無ければ null。</summary>
        public Texture2D Output { get; private set; }

        /// <summary>Output の解像度。</summary>
        public Quality OutputQuality { get; private set; }

        /// <summary>Output を作った依頼に付けた印（Render の tag）。どの組み合わせの結果かを見分けるのに使う。</summary>
        public string OutputTag { get; private set; }

        /// <summary>体験版の高画質長押し確認（2048px）の最新結果。通常プレビュー Output とは別に保持する。</summary>
        public Texture2D TrialHighOutput { get; private set; }

        /// <summary>TrialHighOutput を作った依頼に付けた印（組み合わせ・調整リビジョン等の指紋）。</summary>
        public string TrialHighOutputTag { get; private set; }

        /// <summary>体験版の高画質確認を計算中、または計算待ちか。</summary>
        public bool IsTrialHighBusy => _runningTrialHigh || _queuedTrialHigh != null;

        /// <summary>「メイク元」「マスク」表示の画像（低解像度）。</summary>
        public Texture2D ViewOutput => _viewTex;

        /// <summary>ViewOutput がどの表示のものか。</summary>
        public ViewMode ViewOutputMode { get; private set; } = ViewMode.Result;

        public Texture2D AvatarSource => _avatarSource;
        public bool HasMakeup => _makeup != null;

        /// <summary>計算中、または計算待ちの依頼がある。</summary>
        public bool IsBusy => _running != null || _queued != null || _queuedTrialHigh != null;

        public string LastError { get; private set; }

        /// <summary>
        /// 最後に Full で作ったときの、変形の折り返しの検出・補正の結果。Low（操作中）の結果では更新しない
        /// （反復の上限を減らしていて判定が揺れ、警告の行が点滅するため）。
        /// </summary>
        public DistortionReport Distortion { get; private set; }

        /// <summary>
        /// Distortion と同じ Full の計算で測った、調整なしのときの結果。調整で増えた折り返しだけを警告にするために使う
        /// （<see cref="DistortionNotice"/>）。測れなかったとき（調整なしの変形が作れない・依頼に付けなかった）は null。
        /// </summary>
        public DistortionReport? BaselineDistortion { get; private set; }

        /// <summary>Distortion と同じ Full の計算での、肌色合わせの状態（SkinToneNotice）。</summary>
        public SkinToneStatus SkinTone { get; private set; }

        /// <summary>SkinTone と同じ計算で、メイクの色に掛けた比（合わせていなければ白）。</summary>
        public Color SkinToneTint { get; private set; } = Color.white;

        /// <summary>Output・ViewOutput が新しくなった（メインスレッドで呼ばれる）。</summary>
        public event Action Updated;

        /// <summary>
        /// 読み込んだときのアセットの依存ハッシュ（画像・インポート設定が変わると変わる）。
        /// 同じ Texture2D のまま再インポートされたのを見分けるのに使う。
        /// </summary>
        private Hash128 _avatarHash;
        private Hash128 _makeupHash;
        private bool _forceReload;

        /// <summary>
        /// 元のテクスチャが再インポートされていたら、次の SetTextures で読み直すようにする。
        /// 読み直しが必要なら true。プロジェクトが変わったとき（EditorApplication.projectChanged）に呼ぶ。メインスレッド専用。
        /// </summary>
        public bool CheckReimported()
        {
            bool stale = (_avatarSource != null && AssetHash(_avatarSource) != _avatarHash) ||
                         (_makeupSource != null && AssetHash(_makeupSource) != _makeupHash);
            if (stale) _forceReload = true;
            return stale;
        }

        private static Hash128 AssetHash(Texture tex)
        {
            string path = AssetDatabase.GetAssetPath(tex);
            return string.IsNullOrEmpty(path) ? default : AssetDatabase.GetAssetDependencyHash(path);
        }

        /// <summary>元になるテクスチャを設定する。変わったときだけ読み直し、変わったら true を返す。メインスレッド専用。</summary>
        public bool SetTextures(Texture2D avatar, Texture2D makeup)
        {
            bool changed = false;
            bool reloadMakeup = false;
            bool force = _forceReload;
            _forceReload = false;

            if (force || !ReferenceEquals(avatar, _avatarSource))
            {
                _avatarSource = avatar;
                _avatarHash = avatar != null ? AssetHash(avatar) : default;
                _baseFull = null;
                _baseLow = null;
                _baseTrialHigh = null;
                _makeupTrialHigh = null;
                LastError = null;
                if (avatar != null && (avatar.width > AtaaCore.MaxTextureSize || avatar.height > AtaaCore.MaxTextureSize))
                {
                    // 適用（FaceTextureGenerator.TryGenerate）と同じ文言で、プレビューを作らない理由を出す
                    LastError = $"対象の顔テクスチャが大きすぎます（{avatar.width}x{avatar.height}、上限 {AtaaCore.MaxTextureSize}）。";
                }
                else if (avatar != null)
                {
                    _linear = FaceTextureReader.IsLinear(avatar);
                    FitSize(avatar.width, avatar.height, FullResolution, out int fw, out int fh);
                    _baseFull = FaceTextureReader.Read(avatar, fw, fh, _linear);
                    LowSize(avatar.width, avatar.height, out int lw, out int lh);
                    _baseLow = lw == fw && lh == fh
                        ? _baseFull
                        : FaceTextureReader.Read(avatar, lw, lh, _linear);
                }
                DestroyOutputs();

                // 色空間はメイク元の読み込みにも効くので、メイク元も読み直す（null になった場合も含めて必ず）
                reloadMakeup = true;
                changed = true;
            }
            if (reloadMakeup || !ReferenceEquals(makeup, _makeupSource))
            {
                _makeupSource = makeup;
                _makeupHash = makeup != null ? AssetHash(makeup) : default;
                _makeup = makeup != null ? ReadMakeupForPreview(makeup, _linear) : null;
                _makeupTrialHigh = null;
                _queuedTrialHigh = null;
                TrialHighOutputTag = null;
                changed = true;
            }
            return changed;
        }

        /// <summary>
        /// 合成を依頼する。deformer・mask は以後変更しないこと（ワーカースレッドで読む）。
        /// tag は結果を反映したときに OutputTag になる。
        /// </summary>
        public void Render(AvatarDeformer deformer, FaceMask mask, float opacity, Quality quality, ViewMode view, string tag = null,
                           AvatarDeformer baselineDeformer = null, FaceMask baselineMask = null)
        {
            if (_baseFull == null) return;

            _queued = new Request
            {
                Generation = ++_generation,
                Deformer = deformer,
                Mask = mask,
                Opacity = opacity,
                Quality = quality,
                View = view,
                Tag = tag,
                BaselineDeformer = baselineDeformer,
                BaselineMask = baselineMask
            };
            StartNextIfIdle();
        }

        /// <summary>
        /// 体験版の高画質長押し確認（最大 TrialHighResolution = 2048px）を依頼する。メインスレッド専用。
        /// 元画像の高画質版は初回押下時に遅延読み込みして保持する。通常プレビュー Output は上書きしない。
        /// </summary>
        public void RenderTrialHigh(AvatarDeformer deformer, FaceMask mask, float opacity, string tag)
        {
            if (_avatarSource == null || _baseFull == null) return;

            if (_baseTrialHigh == null)
            {
                FitSize(_avatarSource.width, _avatarSource.height, TrialHighResolution, out int hw, out int hh);
                _baseTrialHigh = hw == _baseFull.Width && hh == _baseFull.Height
                    ? _baseFull
                    : FaceTextureReader.Read(_avatarSource, hw, hh, _linear);
            }
            if (_makeupSource != null && _makeupTrialHigh == null)
            {
                FitSize(_makeupSource.width, _makeupSource.height, TrialHighResolution, out int mw, out int mh);
                _makeupTrialHigh = _makeup != null && mw == _makeup.Width && mh == _makeup.Height
                    ? _makeup
                    : FaceTextureReader.Read(_makeupSource, mw, mh, _linear);
            }

            _queuedTrialHigh = new Request
            {
                Generation = ++_generation,
                Deformer = deformer,
                Mask = mask,
                Opacity = opacity,
                Quality = Quality.Full,
                View = ViewMode.Result,
                Tag = tag,
                IsTrialHigh = true
            };
            StartNextIfIdle();
        }

        /// <summary>開始待ちの高画質確認の依頼を取り消す（ボタンを離したとき）。</summary>
        public void CancelTrialHigh()
        {
            _queuedTrialHigh = null;
        }

        /// <summary>終わった計算の結果を反映し、待っている依頼を始める。EditorApplication.update などから毎フレーム呼ぶ。</summary>
        public void Poll()
        {
            if (_running == null || !_running.IsCompleted) return;

            Result result = _running.IsFaulted
                ? new Result { Error = _running.Exception?.GetBaseException().Message }
                : _running.Result;
            _running = null;
            _runningTrialHigh = false;

            bool errorChanged = LastError != result.Error;
            LastError = result.Error;

            // 依頼は 1 つずつ順に計算するので、終わった結果は常に前回より新しい。
            // テクスチャの差し替え前（古い大きさ）の依頼だけは捨てる
            bool uploaded = false;
            if (result.Error == null && result.Request != null && result.Request.Generation >= _validFrom)
            {
                Upload(result.Request);
                // 操作中（Low）は反復を減らしているので判定が揺れる。警告の行が点滅・出入りしないよう、
                // 直前の Full の結果を残し、操作を離した後の Full で更新する
                if (!result.Request.IsTrialHigh && result.Request.Quality == Quality.Full)
                {
                    Distortion = result.Distortion;
                    BaselineDistortion = result.Baseline;
                    SkinTone = result.SkinTone;
                    SkinToneTint = result.SkinToneTint;
                }
                uploaded = true;
            }

            StartNextIfIdle();
            // 捨てた結果では知らせない（3D ビューの再描画・SyncLive の空振りを防ぐ）。
            // エラーが出た・消えたときは、表示を変えるために知らせる
            if (uploaded || errorChanged) Updated?.Invoke();
        }

        private void StartNextIfIdle()
        {
            if (_running != null) return;

            Request req;
            if (_queued != null)
            {
                req = _queued;
                _queued = null;
            }
            else if (_queuedTrialHigh != null)
            {
                req = _queuedTrialHigh;
                _queuedTrialHigh = null;
            }
            else
            {
                return;
            }

            FacePixels baseSrc = req.IsTrialHigh
                ? _baseTrialHigh
                : req.Quality == Quality.Full ? _baseFull : _baseLow;
            FacePixels makeup = req.IsTrialHigh ? _makeupTrialHigh : _makeup;
            FacePixels baseLow = _baseLow;
            if (baseSrc == null) return;

            Color32[] dst = req.IsTrialHigh
                ? EnsureBuffer(ref _trialHighBuffer, baseSrc.Width * baseSrc.Height)
                : req.Quality == Quality.Full
                    ? EnsureBuffer(ref _fullBuffer, baseSrc.Width * baseSrc.Height)
                    : EnsureBuffer(ref _lowBuffer, baseSrc.Width * baseSrc.Height);
            Color32[] view = !req.IsTrialHigh && (req.View == ViewMode.Makeup || req.View == ViewMode.Mask)
                ? EnsureBuffer(ref _viewBuffer, baseLow.Width * baseLow.Height)
                : null;

            _runningTrialHigh = req.IsTrialHigh;
            _running = Task.Run(() =>
            {
                try
                {
                    // 操作中は折り返しの補正の反復を減らして追従を優先する（格子の解像度は同じ。離すと Full で作り直す）
                    bool preview = !req.IsTrialHigh && req.Quality == Quality.Low;
                    DistortionReport distortion =
                        AtaaCore.Compose(baseSrc, makeup, req.Deformer, req.Mask, req.Opacity, dst, null, preview);
                    if (!req.IsTrialHigh)
                    {
                        if (req.View == ViewMode.Makeup)
                            AtaaCore.ComposeWarpedMakeup(makeup, req.Deformer, baseLow.Width, baseLow.Height, MakeupBackground,
                                view, preview);
                        else if (req.View == ViewMode.Mask)
                            AtaaCore.ComposeMaskView(baseLow, req.Mask, view);
                    }
                    // 調整なしのときに残る折り返しの数（Full のときだけ。調整で増えた分を警告にするため）
                    DistortionReport? baseline = null;
                    if (!req.IsTrialHigh && req.Quality == Quality.Full && req.BaselineDeformer != null && req.BaselineMask != null)
                        baseline = AtaaCore.MeasureDistortion(req.BaselineDeformer, req.BaselineMask);
                    // 肌色合わせが効いたか（Full のときだけ。合成と同じ画素で判断する）
                    SkinToneStatus skinTone = SkinToneStatus.Off;
                    Color tint = Color.white;
                    if (!req.IsTrialHigh && req.Quality == Quality.Full && makeup != null && req.Mask != null)
                        skinTone = AtaaCore.EvaluateSkinTone(makeup, baseSrc, req.Mask.SkinTone, out tint);
                    return new Result
                    {
                        Request = req, Distortion = distortion, Baseline = baseline, SkinTone = skinTone, SkinToneTint = tint
                    };
                }
                catch (Exception ex)
                {
                    return new Result { Request = req, Error = ex.Message };
                }
            });
        }

        /// <summary>計算の終わったバッファをテクスチャに書く。メインスレッド専用。</summary>
        private void Upload(Request req)
        {
            if (_avatarSource == null) return;

            if (req.IsTrialHigh)
            {
                if (_baseTrialHigh == null || _trialHighBuffer == null) return;
                EnsureTexture(ref _trialHighTex, _baseTrialHigh.Width, _baseTrialHigh.Height, "FaceMapPreview(TrialHigh)");
                _trialHighTex.SetPixels32(_trialHighBuffer);
                _trialHighTex.Apply(true);
                TrialHighOutput = _trialHighTex;
                TrialHighOutputTag = req.Tag;
                return;
            }

            if (req.Quality == Quality.Full)
            {
                EnsureTexture(ref _fullTex, _baseFull.Width, _baseFull.Height, "FaceMapPreview(Full)");
                _fullTex.SetPixels32(_fullBuffer);
                _fullTex.Apply(true);
                Output = _fullTex;
            }
            else
            {
                EnsureTexture(ref _lowTex, _baseLow.Width, _baseLow.Height, "FaceMapPreview(Low)");
                _lowTex.SetPixels32(_lowBuffer);
                _lowTex.Apply(true);
                Output = _lowTex;
            }
            OutputQuality = req.Quality;
            OutputTag = req.Tag;

            if (req.View == ViewMode.Makeup || req.View == ViewMode.Mask)
            {
                EnsureTexture(ref _viewTex, _baseLow.Width, _baseLow.Height, "FaceMapPreview(View)");
                _viewTex.SetPixels32(_viewBuffer);
                _viewTex.Apply(false);
                ViewOutputMode = req.View;
            }
        }

        /// <summary>長辺を LowResolution にした大きさ（元が小さければそのまま）。</summary>
        public static void LowSize(int w, int h, out int lw, out int lh) => FitSize(w, h, LowResolution, out lw, out lh);

        /// <summary>メイク元の顔テクスチャを、プレビューの上限（FullResolution）以下の解像度で読む。</summary>
        private static FacePixels ReadMakeupForPreview(Texture2D makeup, bool linear)
        {
            FitSize(makeup.width, makeup.height, FullResolution, out int mw, out int mh);
            return FaceTextureReader.Read(makeup, mw, mh, linear);
        }

        /// <summary>長辺を maxSide 以下にした大きさ（縦横比は保つ。元が小さければそのまま）。</summary>
        public static void FitSize(int w, int h, int maxSide, out int fw, out int fh)
        {
            int longSide = Mathf.Max(w, h);
            if (longSide <= maxSide)
            {
                fw = w;
                fh = h;
                return;
            }
            float s = maxSide / (float)longSide;
            fw = Mathf.Max(1, Mathf.RoundToInt(w * s));
            fh = Mathf.Max(1, Mathf.RoundToInt(h * s));
        }

        private static Color32[] EnsureBuffer(ref Color32[] buffer, int length)
        {
            if (buffer == null || buffer.Length != length) buffer = new Color32[length];
            return buffer;
        }

        /// <summary>表示用テクスチャ。色空間・フィルター・ラップ・異方性は対象の顔テクスチャに合わせる（§13.6）。</summary>
        private void EnsureTexture(ref Texture2D tex, int w, int h, string name)
        {
            if (tex != null && tex.width == w && tex.height == h) return;
            if (tex != null) UnityEngine.Object.DestroyImmediate(tex);

            tex = new Texture2D(w, h, TextureFormat.RGBA32, true, _linear)
            {
                name = name,
                hideFlags = HideFlags.HideAndDontSave,
                filterMode = _avatarSource.filterMode,
                wrapMode = _avatarSource.wrapMode,
                anisoLevel = _avatarSource.anisoLevel
            };
        }

        private void DestroyOutputs()
        {
            if (_fullTex != null) UnityEngine.Object.DestroyImmediate(_fullTex);
            if (_lowTex != null) UnityEngine.Object.DestroyImmediate(_lowTex);
            if (_viewTex != null) UnityEngine.Object.DestroyImmediate(_viewTex);
            if (_trialHighTex != null) UnityEngine.Object.DestroyImmediate(_trialHighTex);
            _fullTex = null;
            _lowTex = null;
            _viewTex = null;
            _trialHighTex = null;
            _fullBuffer = null;
            _lowBuffer = null;
            _viewBuffer = null;
            _trialHighBuffer = null;
            Output = null;
            OutputTag = null;
            TrialHighOutput = null;
            TrialHighOutputTag = null;
            _queuedTrialHigh = null;
            // 前のテクスチャでの結果を、新しいテクスチャの Low の表示中に出さない
            Distortion = default;
            BaselineDistortion = null;

            // 古い大きさのバッファに書いている計算の結果は使わない
            _validFrom = _generation + 1;
        }

        public void Dispose()
        {
            _queued = null;
            _queuedTrialHigh = null;
            DestroyOutputs();
            _baseFull = null;
            _baseLow = null;
            _makeup = null;
            _baseTrialHigh = null;
            _makeupTrialHigh = null;
            _avatarSource = null;
            _makeupSource = null;
        }
    }
}
