// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Renderers/FaceMapTextureRenderer.cs
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// テクスチャパネルの描画ロジック。副作用なし（GUI 座標 Rect を引子に受け、Unity GUI API を呼ぶのみ）。
    /// 各領域は「中心点 + 矩形（サイズ）」で描き、選択中の領域には四隅と辺の中点にサイズ変更ハンドルを出す。
    /// </summary>
    public static class FaceMapTextureRenderer
    {
        /// <summary>サイズ変更ハンドルの一辺と、当たり判定の半径（スクリーンピクセル。ポインタのサイズ 1.0 倍のとき）。</summary>
        public const float HandleSize = 9f;
        public const float HandleHitRadius = 10f;

        /// <summary>中心点のマーカーの一辺、ホバー時の枠の一辺、中心点をつかむ判定の半径（1.0 倍のとき）。</summary>
        public const float MarkerSize = 8f;
        public const float HoverFrameSize = 18f;
        public const float PointHitRadius = 14f;

        /// <summary>ポインタのサイズの範囲（FaceMap 仕様 v0.4 §12.3）。</summary>
        public const float MinPointerScale = 0.25f;
        public const float MaxPointerScale = 1f;

        /// <summary>小さくしても掴めなくならないよう、当たり判定の半径はこれ以上にする。</summary>
        public const float MinHitRadius = 4f;

        public static float ScaledHandleHitRadius(float pointerScale) =>
            Mathf.Max(MinHitRadius, HandleHitRadius * pointerScale);

        public static float ScaledPointHitRadius(float pointerScale) =>
            Mathf.Max(MinHitRadius, PointHitRadius * pointerScale);

        /// <summary>中心線のつまみの幅・高さと、当たり判定の半径（1.0 倍のとき。§12.4）。</summary>
        public const float CenterKnobWidth = 12f;
        public const float CenterKnobHeight = 14f;
        public const float CenterKnobHitRadius = 10f;

        private static readonly Color CenterLineColor = new Color(1f, 0.85f, 0.2f, 0.9f);
        private static readonly Color CheckColor = new Color(1f, 0.55f, 0.1f, 1f);

        public static float ScaledCenterKnobHitRadius(float pointerScale) =>
            Mathf.Max(MinHitRadius, CenterKnobHitRadius * pointerScale);

        /// <summary>
        /// 中心線のつまみの中心（スクリーン座標）。テクスチャの上端に付ける。
        /// 拡大して上端が欄の外に出たら、欄の上端に付ける（§12.6。つまみを見失わないように）。
        /// </summary>
        public static Vector2 CenterKnobPosition(Rect areaRect, Rect texRect, float centerX, float pointerScale = 1f)
        {
            float x = texRect.xMin + centerX * texRect.width;
            float top = Mathf.Max(texRect.yMin, areaRect.yMin);
            return new Vector2(x, top + CenterKnobHeight * pointerScale * 0.5f);
        }

        /// <summary>mouse が中心線のつまみの上にあるか。線そのものには当たり判定を持たせない。</summary>
        public static bool IsOnCenterKnob(Rect areaRect, Rect texRect, float centerX, Vector2 mouse, float pointerScale = 1f)
        {
            return Vector2.Distance(CenterKnobPosition(areaRect, texRect, centerX, pointerScale), mouse)
                   <= ScaledCenterKnobHitRadius(pointerScale);
        }

        // 分類カラーの静的キャッシュ (GC排除)。キーは label の分類部分（目・鼻・口・頬・顎）。
        private static readonly Dictionary<string, Color> _categoryColors = new()
        {
            ["目"] = new Color(0.2f, 0.8f, 1f),
            ["鼻"] = new Color(1f, 0.3f, 0.3f),
            ["口"] = new Color(0.3f, 1f, 0.4f),
            ["頬"] = new Color(1f, 0.5f, 0.7f),
            ["顎"] = new Color(0.4f, 0.7f, 0.5f),
        };

        private static readonly Color UnknownCategoryColor = Color.white;

        public static Color GetLabelColor(string label)
        {
            string category = FaceLabel.GetCategory(label);
            return category != null && _categoryColors.TryGetValue(category, out var c) ? c : UnknownCategoryColor;
        }

        /// <summary>領域の矩形をスクリーン座標で返す。</summary>
        public static Rect RegionScreenRect(Rect texRect, Vector2 center, Vector2 size)
        {
            Vector2 c = UVCoordinateConverter.UvToScreen(center, texRect);
            float w = size.x * texRect.width;
            float h = size.y * texRect.height;
            return new Rect(c.x - w * 0.5f, c.y - h * 0.5f, w, h);
        }

        /// <summary>
        /// サイズ変更ハンドル（四隅）をスクリーン座標で返す。
        /// </summary>
        public static Vector2[] HandlePositions(Rect regionScreenRect)
        {
            return new[]
            {
                new Vector2(regionScreenRect.xMin, regionScreenRect.yMin),
                new Vector2(regionScreenRect.xMax, regionScreenRect.yMin),
                new Vector2(regionScreenRect.xMin, regionScreenRect.yMax),
                new Vector2(regionScreenRect.xMax, regionScreenRect.yMax),
            };
        }

        /// <summary>辺の中点のつまみ（上・下・左・右）をスクリーン座標で返す。</summary>
        public static Vector2[] EdgeHandlePositions(Rect regionScreenRect)
        {
            Vector2 c = regionScreenRect.center;
            return new[]
            {
                new Vector2(c.x, regionScreenRect.yMin),
                new Vector2(c.x, regionScreenRect.yMax),
                new Vector2(regionScreenRect.xMin, c.y),
                new Vector2(regionScreenRect.xMax, c.y),
            };
        }

        // EdgeHandlePositions と同じ順の向き（UV で右・上が +1。スクリーンの上端 = UV の上）
        private static readonly Vector2[] EdgeSigns =
        {
            new Vector2(0f, 1f), new Vector2(0f, -1f), new Vector2(-1f, 0f), new Vector2(1f, 0f),
        };

        /// <summary>
        /// mouse の下にあるサイズ変更ハンドル（四隅・辺の中点）の向き（UV で右・上が +1、辺は片方が 0）。なければ null。
        /// 小さい枠でハンドルが重なるときは、近い方を返す。
        /// </summary>
        public static Vector2? HitResizeHandle(Rect texRect, FaceMapPoint point, Vector2 size, Vector2 mouse,
                                               float pointerScale = 1f)
        {
            Rect r = RegionScreenRect(texRect, point.Uv, size);
            float best = ScaledHandleHitRadius(pointerScale);
            Vector2? hit = null;

            foreach (Vector2 h in HandlePositions(r))
            {
                float d = Vector2.Distance(h, mouse);
                if (d > best) continue;
                best = d;
                hit = new Vector2(h.x >= r.center.x ? 1f : -1f, h.y <= r.center.y ? 1f : -1f);
            }

            Vector2[] edges = EdgeHandlePositions(r);
            for (int i = 0; i < edges.Length; i++)
            {
                float d = Vector2.Distance(edges[i], mouse);
                if (d >= best && hit.HasValue) continue; // 同じ距離なら角を優先
                if (d > best) continue;
                best = d;
                hit = EdgeSigns[i];
            }
            return hit;
        }

        // ── 目の線（v0.4 §4.2）──

        // 3D ビューのマーカー（EyeLineMarkers3D）も同じ色で描く
        internal static readonly Color EyeLineColor = new Color(1f, 0.95f, 0.4f, 0.95f);
        internal static readonly Color EyeLowerLineColor = new Color(0.55f, 1f, 0.75f, 0.95f);
        internal static readonly Color MouthLineColor = new Color(1f, 0.55f, 0.85f, 0.95f);

        /// <summary>目の線のスクリーン上の y（領域の矩形の下端から高さ × line）。</summary>
        public static float EyeLineScreenY(Rect regionScreenRect, float line) =>
            regionScreenRect.yMax - regionScreenRect.height * line;

        /// <summary>目の線のつまみの中心（スクリーン座標）。中心の印と重ならないよう、線の右端に付ける。</summary>
        public static Vector2 EyeLineKnobPosition(Rect texRect, FaceMapPoint eye, Vector2 size, float line)
        {
            Rect r = RegionScreenRect(texRect, eye.Uv, size);
            return new Vector2(r.xMax, EyeLineScreenY(r, line));
        }

        /// <summary>mouse が目の線のつまみの上にあるか。</summary>
        public static bool IsOnEyeLineKnob(Rect texRect, FaceMapPoint eye, Vector2 size, float line, Vector2 mouse,
                                           float pointerScale = 1f)
        {
            return Vector2.Distance(EyeLineKnobPosition(texRect, eye, size, line), mouse) <= ScaledHandleHitRadius(pointerScale);
        }

        /// <summary>
        /// テクスチャパネル全体の描画（背景 → テクスチャ → クロスヘア → 領域 → ツールチップ）。
        /// targetText は、クリックで次に置く領域の説明（なければ null）。
        /// </summary>
        public static void DrawPanel(Rect areaRect, Rect texRect, Texture2D tex,
                                    IList<FaceMapPoint> points, IDictionary<string, Vector2> sizes,
                                    int selectedPoint, int hoverIndex,
                                    Vector2 hoverUV, bool isHovering, string targetText,
                                    GUIStyle labelStyle, GUIStyle attrStyle, GUIStyle tipStyle,
                                    float pointerScale = 1f,
                                    float? centerX = null, float overlayAlpha = 0f,
                                    ICollection<string> checkLabels = null, float? eyeLine = null,
                                    float? eyeLowerLine = null, float? mouthLine = null,
                                    Vector2[] mouthLinePoints = null,
                                    Vector2[] eyeContourUpper = null, Vector2[] eyeContourLower = null)
        {
            // 拡大中はテクスチャが欄からはみ出すので、欄の中だけに描く（§12.6）。
            // クリップ内は欄の左上が原点になるので、矩形をずらして渡す
            GUI.BeginClip(areaRect);
            try
            {
                var localArea = new Rect(0f, 0f, areaRect.width, areaRect.height);
                var localTex = new Rect(texRect.x - areaRect.x, texRect.y - areaRect.y, texRect.width, texRect.height);
                DrawPanelContent(localArea, localTex, tex, points, sizes, selectedPoint, hoverIndex,
                                 hoverUV, isHovering, targetText, labelStyle, attrStyle, tipStyle,
                                 pointerScale, centerX, overlayAlpha, checkLabels, eyeLine, eyeLowerLine, mouthLine,
                                 mouthLinePoints, eyeContourUpper, eyeContourLower);
            }
            finally
            {
                GUI.EndClip();
            }
        }

        private static void DrawPanelContent(Rect areaRect, Rect texRect, Texture2D tex,
                                             IList<FaceMapPoint> points, IDictionary<string, Vector2> sizes,
                                             int selectedPoint, int hoverIndex,
                                             Vector2 hoverUV, bool isHovering, string targetText,
                                             GUIStyle labelStyle, GUIStyle attrStyle, GUIStyle tipStyle,
                                             float pointerScale, float? centerX, float overlayAlpha,
                                             ICollection<string> checkLabels, float? eyeLine, float? eyeLowerLine,
                                             float? mouthLine, Vector2[] mouthLinePoints,
                                             Vector2[] eyeContourUpper, Vector2[] eyeContourLower)
        {
            float handleSize = HandleSize * pointerScale;
            float markerSize = MarkerSize * pointerScale;
            float hoverSize = HoverFrameSize * pointerScale;

            EditorGUI.DrawRect(areaRect, new Color(0.17f, 0.17f, 0.17f));

            if (tex == null)
            {
                DrawOutline(areaRect, Color.gray, 1f);
                GUI.Label(areaRect, "顔テクスチャを\nドラッグ＆ドロップ", labelStyle);
                return;
            }

            GUI.DrawTexture(texRect, tex, ScaleMode.StretchToFill);

            // 重ね順: テクスチャ → 反転オーバーレイ → 中心線 → 領域（§12.4）
            if (centerX.HasValue && overlayAlpha > 0f)
            {
                DrawMirrorOverlay(texRect, tex, centerX.Value, overlayAlpha);
            }

            DrawOutline(texRect, Color.white, 1f);

            if (isHovering)
            {
                DrawCrosshair(texRect, hoverUV);
            }

            if (centerX.HasValue)
            {
                DrawCenterLine(areaRect, texRect, centerX.Value, pointerScale);
            }

            for (int i = 0; i < points.Count; i++)
            {
                FaceMapPoint p = points[i];
                Vector2 screenPos = UVCoordinateConverter.UvToScreen(p.Uv, texRect);
                Color c = GetLabelColor(p.Label);
                bool selected = i == selectedPoint;

                string category = FaceTemplate.CategoryOf(p.Label);
                if (category != null && sizes != null && sizes.TryGetValue(category, out Vector2 size))
                {
                    Rect region = RegionScreenRect(texRect, p.Uv, size);
                    EditorGUI.DrawRect(region, new Color(c.r, c.g, c.b, selected ? 0.22f : 0.12f));
                    DrawOutline(region, selected ? Color.yellow : c, selected ? 2f : 1f);

                    // 目の線（黄）・目の下の線（緑）（v0.4 §4.2）。選択中の目には、線の右端に高さを変えるつまみを出す
                    if (category == FaceMapFile.EyeCategory)
                    {
                        if (eyeLine.HasValue) DrawEyeLine(region, eyeLine.Value, EyeLineColor, selected, handleSize);
                        if (eyeLowerLine.HasValue) DrawEyeLine(region, eyeLowerLine.Value, EyeLowerLineColor, selected, handleSize);
                        // 目の輪郭（水色）。選択中の目には点のつまみを出す（左右の目で共通の形を鏡写しで描く）
                        if (eyeContourUpper != null && eyeContourLower != null)
                            DrawEyeContour(region, eyeContourUpper, eyeContourLower, EyeContourEditing.InnerAtMax(p.Label), selected, handleSize);
                    }
                    // 口の線（上唇と下唇の合わせ目）。選択中の口には、線の右端に高さを変えるつまみを出す
                    // 折れ線（#25）のときは線を折れ線で描き、つまみは代表の高さ（ドラッグで全点を縦にずらす）
                    if (category == FaceMapFile.MouthCategory && mouthLine.HasValue)
                    {
                        if (MouthLineShape.IsHorizontal(mouthLinePoints))
                            DrawEyeLine(region, mouthLine.Value, MouthLineColor, selected, handleSize);
                        else
                            DrawMouthPolyline(region, mouthLinePoints, mouthLine.Value, MouthLineColor, selected, handleSize);
                    }

                    // 自動作成の要確認（自動ポインティング仕様 §11.5）: 外側にオレンジの枠
                    if (checkLabels != null && p.Label != null && checkLabels.Contains(p.Label))
                    {
                        var outer = new Rect(region.x - 3f, region.y - 3f, region.width + 6f, region.height + 6f);
                        DrawOutline(outer, CheckColor, 2f);
                        GUI.Label(new Rect(outer.x, outer.yMax + 1f, 60f, 12f), "要確認", attrStyle);
                    }

                    if (selected)
                    {
                        foreach (Vector2 h in HandlePositions(region))
                        {
                            var hr = new Rect(h.x - handleSize * 0.5f, h.y - handleSize * 0.5f, handleSize, handleSize);
                            EditorGUI.DrawRect(new Rect(hr.x - 1, hr.y - 1, hr.width + 2, hr.height + 2), Color.black);
                            EditorGUI.DrawRect(hr, Color.white);
                        }
                        // 辺の中点のつまみ（その辺だけを動かす）。角と見分けられるよう、辺に沿った細長い形にする
                        Vector2[] edges = EdgeHandlePositions(region);
                        for (int k = 0; k < edges.Length; k++)
                        {
                            bool horizontal = k < 2; // 上・下の辺
                            float w = horizontal ? handleSize * 1.4f : handleSize * 0.6f;
                            float h = horizontal ? handleSize * 0.6f : handleSize * 1.4f;
                            var er = new Rect(edges[k].x - w * 0.5f, edges[k].y - h * 0.5f, w, h);
                            EditorGUI.DrawRect(new Rect(er.x - 1, er.y - 1, er.width + 2, er.height + 2), Color.black);
                            EditorGUI.DrawRect(er, Color.white);
                        }
                    }
                }

                if (i == hoverIndex)
                {
                    DrawOutline(new Rect(screenPos.x - hoverSize * 0.5f, screenPos.y - hoverSize * 0.5f, hoverSize, hoverSize),
                                Color.white, 1f);
                }

                Color drawColor = selected ? c : Color.Lerp(c, Color.gray, 0.3f);
                EditorGUI.DrawRect(new Rect(screenPos.x - markerSize * 0.5f, screenPos.y - markerSize * 0.5f, markerSize, markerSize),
                                   drawColor);

                GUI.Label(new Rect(screenPos.x + markerSize * 0.5f + 3f, screenPos.y - 6, 140, 12), p.Label ?? "", attrStyle);
            }

            if (isHovering)
            {
                DrawCoordTooltip(areaRect, texRect, tex, hoverUV, hoverIndex, points, targetText, tipStyle);
            }
        }

        /// <summary>
        /// 中心線を軸に左右反転したテクスチャを半透明で重ねる。画面の u には、テクスチャの 2c − u を描く。
        /// 2c − u が 0〜1 を出る部分は描かない（端の引き伸ばし・繰り返しを出さない）。
        /// </summary>
        private static void DrawMirrorOverlay(Rect texRect, Texture2D tex, float c, float alpha)
        {
            if (!FaceMapMirror.OverlayRange(c, out float uMin, out float uMax)) return;

            var screen = new Rect(texRect.xMin + uMin * texRect.width, texRect.yMin,
                                  (uMax - uMin) * texRect.width, texRect.height);

            // 画面の uMin → テクスチャの 2c − uMin、画面の uMax → 2c − uMax（幅を負にして反転）
            var coords = new Rect(2f * c - uMin, 0f, -(uMax - uMin), 1f);

            Color old = GUI.color;
            GUI.color = new Color(1f, 1f, 1f, alpha);
            GUI.DrawTextureWithTexCoords(screen, tex, coords, true);
            GUI.color = old;
        }

        /// <summary>
        /// 口の線の折れ線（#25）を描く。region は口の領域の画面の矩形。knob なら、右端の代表の高さ（line）につまみを出す。
        /// </summary>
        internal static void DrawMouthPolyline(Rect region, Vector2[] points, float line, Color color, bool knob, float knobSize)
        {
            if (Event.current.type != EventType.Repaint) return;
            var screen = new Vector3[points.Length + 2];
            screen[0] = PolylineScreen(region, new Vector2(0f, points[0].y));
            for (int i = 0; i < points.Length; i++) screen[i + 1] = PolylineScreen(region, points[i]);
            screen[screen.Length - 1] = PolylineScreen(region, new Vector2(1f, points[points.Length - 1].y));

            Color old = Handles.color;
            Handles.color = new Color(0f, 0f, 0f, 0.45f);
            Handles.DrawAAPolyLine(3f, screen);
            Handles.color = color;
            Handles.DrawAAPolyLine(1.5f, screen);
            Handles.color = old;

            if (!knob) return;
            float ly = Mathf.Round(EyeLineScreenY(region, line));
            var kr = new Rect(region.xMax - knobSize * 0.5f, ly - knobSize * 0.5f, knobSize, knobSize);
            EditorGUI.DrawRect(new Rect(kr.x - 1, kr.y - 1, kr.width + 2, kr.height + 2), Color.black);
            EditorGUI.DrawRect(kr, color);
        }

        internal static readonly Color EyeContourColor = new Color(0.35f, 0.85f, 1f, 0.95f);

        /// <summary>
        /// 目の輪郭（目の輪郭リング写像の仕様 §5.1）を閉じた折れ線で描く。region は目の領域の画面の矩形。
        /// knobs なら、各点のつまみ（EyeContourEditing.Handles）を出す。
        /// </summary>
        internal static void DrawEyeContour(Rect region, Vector2[] upper, Vector2[] lower, bool innerAtMax, bool knobs, float knobSize)
        {
            if (Event.current.type != EventType.Repaint) return;
            var screen = new Vector3[upper.Length + lower.Length - 1];
            int k = 0;
            foreach (Vector2 p in upper) screen[k++] = EyeContourEditing.LocalToScreen(region, p, innerAtMax);
            for (int i = lower.Length - 2; i >= 0; i--) screen[k++] = EyeContourEditing.LocalToScreen(region, lower[i], innerAtMax);

            Color old = Handles.color;
            Handles.color = new Color(0f, 0f, 0f, 0.45f);
            Handles.DrawAAPolyLine(3f, screen);
            Handles.color = EyeContourColor;
            Handles.DrawAAPolyLine(1.5f, screen);
            Handles.color = old;

            if (!knobs) return;
            float s = knobSize * 0.8f;
            foreach (EyeContourEditing.Handle h in EyeContourEditing.Handles(upper, lower))
            {
                Vector2 c = EyeContourEditing.LocalToScreen(region, EyeContourEditing.HandlePoint(upper, lower, h), innerAtMax);
                var kr = new Rect(c.x - s * 0.5f, c.y - s * 0.5f, s, s);
                EditorGUI.DrawRect(new Rect(kr.x - 1, kr.y - 1, kr.width + 2, kr.height + 2), Color.black);
                EditorGUI.DrawRect(kr, EyeContourColor);
            }
        }

        private static Vector3 PolylineScreen(Rect region, Vector2 p) =>
            new Vector3(region.xMin + p.x * region.width, EyeLineScreenY(region, p.y), 0f);

        private static void DrawEyeLine(Rect region, float line, Color color, bool knob, float knobSize)
        {
            float ly = Mathf.Round(EyeLineScreenY(region, line));
            EditorGUI.DrawRect(new Rect(region.xMin, ly - 1f, region.width, 3f), new Color(0f, 0f, 0f, 0.45f));
            EditorGUI.DrawRect(new Rect(region.xMin, ly, region.width, 1f), color);
            if (!knob) return;
            var kr = new Rect(region.xMax - knobSize * 0.5f, ly - knobSize * 0.5f, knobSize, knobSize);
            EditorGUI.DrawRect(new Rect(kr.x - 1, kr.y - 1, kr.width + 2, kr.height + 2), Color.black);
            EditorGUI.DrawRect(kr, color);
        }

        /// <summary>中心線（縦の破線）と、上端のつまみ。</summary>
        private static void DrawCenterLine(Rect areaRect, Rect texRect, float c, float pointerScale)
        {
            float x = Mathf.Round(texRect.xMin + c * texRect.width);
            const float dash = 6f;
            const float gap = 4f;
            // 欄の外は描かない（拡大中に無駄な描画をしない）
            float yMax = Mathf.Min(texRect.yMax, areaRect.yMax);
            for (float y = texRect.yMin; y < yMax; y += dash + gap)
            {
                if (y + dash < areaRect.yMin) continue;
                float h = Mathf.Min(dash, texRect.yMax - y);
                EditorGUI.DrawRect(new Rect(x - 1f, y, 3f, h), new Color(0f, 0f, 0f, 0.5f));
                EditorGUI.DrawRect(new Rect(x, y, 1f, h), CenterLineColor);
            }

            Vector2 k = CenterKnobPosition(areaRect, texRect, c, pointerScale);
            float w = CenterKnobWidth * pointerScale;
            float hk = CenterKnobHeight * pointerScale;
            var knob = new Rect(k.x - w * 0.5f, k.y - hk * 0.5f, w, hk);
            EditorGUI.DrawRect(new Rect(knob.x - 1, knob.y - 1, knob.width + 2, knob.height + 2), Color.black);
            EditorGUI.DrawRect(knob, CenterLineColor);
        }

        private static void DrawCrosshair(Rect texRect, Vector2 hoverUV)
        {
            Vector2 p = UVCoordinateConverter.UvToScreen(hoverUV, texRect);
            Color line = new Color(1f, 1f, 1f, 0.35f);
            EditorGUI.DrawRect(new Rect(texRect.xMin, p.y, texRect.width, 1f), line);
            EditorGUI.DrawRect(new Rect(p.x, texRect.yMin, 1f, texRect.height), line);
        }

        private static void DrawCoordTooltip(Rect areaRect, Rect texRect, Texture2D tex,
                                             Vector2 hoverUV, int hoverIndex,
                                             IList<FaceMapPoint> points, string targetText, GUIStyle tipStyle)
        {
            UVCoordinateConverter.PixelFromUv(hoverUV, tex, out int px, out int py);

            string text = $"UV ({hoverUV.x:0.000}, {hoverUV.y:0.000})\nPixel ({px}, {py})";
            if (hoverIndex >= 0 && hoverIndex < points.Count)
            {
                text = $"{points[hoverIndex].Label}（ドラッグで移動）\n" + text;
            }
            else if (!string.IsNullOrEmpty(targetText))
            {
                text = $"クリックで配置: {targetText}\n" + text;
            }

            Vector2 mouse = UVCoordinateConverter.UvToScreen(hoverUV, texRect);
            Vector2 size = tipStyle.CalcSize(new GUIContent(text));
            Rect box = new Rect(mouse.x + 16f, mouse.y + 16f, size.x, size.y);

            // 端に近いときは反対側に出す
            if (box.xMax > areaRect.xMax) box.x = mouse.x - 16f - box.width;
            if (box.yMax > areaRect.yMax) box.y = mouse.y - 16f - box.height;

            EditorGUI.DrawRect(box, new Color(0f, 0f, 0f, 0.8f));
            GUI.Label(box, text, tipStyle);
        }

        public static string GetStatusText(Texture2D tex, bool isHovering, Vector2 hoverUV)
        {
            if (tex == null) return "テクスチャ未設定";
            if (!isHovering) return $"{tex.width} x {tex.height}   マウスをテクスチャ上に乗せると座標を表示します";

            UVCoordinateConverter.PixelFromUv(hoverUV, tex, out int px, out int py);
            return $"UV: ({hoverUV.x:0.000}, {hoverUV.y:0.000})    Pixel: ({px}, {py}) / {tex.width} x {tex.height}  ※左下が原点";
        }

        public static void DrawOutline(Rect r, Color c, float t)
        {
            EditorGUI.DrawRect(new Rect(r.x, r.y, r.width, t), c);
            EditorGUI.DrawRect(new Rect(r.x, r.yMax - t, r.width, t), c);
            EditorGUI.DrawRect(new Rect(r.x, r.y, t, r.height), c);
            EditorGUI.DrawRect(new Rect(r.xMax - t, r.y, t, r.height), c);
        }
    }
}
