using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 顔パレット（UI案A: ミニマル線画シルエット）。卵型の輪郭・耳・対称軸・目線のガイドを Painter2D で描き、
    /// その上にパーツのボタン（色ドット＋名前）を置く。状態は 薄い=未配置 / 点灯=配置済 / 黄枠=選択中 / 点滅=次。
    /// 左右は「画像の左右」。座標は 280×208 の仮想キャンバス（新案の SVG の viewBox）で決め、実際の大きさに合わせて縮める。
    /// </summary>
    public class FaceSilhouettePalette : VisualElement
    {
        private const float ViewW = 280f;
        private const float ViewH = 208f;

        private struct PartDef
        {
            public string Label;
            public Vector2 Pos; // 仮想キャンバス上の中心
            public bool Small;
            public bool DotAfter; // 右側のパーツはドットを名前の後ろに
        }

        // 新案の配置（% → viewBox）。目は 35%、鼻 50%、頬 57%、口 71%、顎 86% の高さ
        private static readonly PartDef[] Defs =
        {
            new PartDef { Label = "目_左", Pos = new Vector2(0.32f * ViewW, 0.35f * ViewH) },
            new PartDef { Label = "目_右", Pos = new Vector2(0.68f * ViewW, 0.35f * ViewH), DotAfter = true },
            new PartDef { Label = "鼻_中央", Pos = new Vector2(0.50f * ViewW, 0.50f * ViewH) },
            new PartDef { Label = "頬_左", Pos = new Vector2(0.27f * ViewW, 0.57f * ViewH), Small = true },
            new PartDef { Label = "頬_右", Pos = new Vector2(0.73f * ViewW, 0.57f * ViewH), Small = true, DotAfter = true },
            new PartDef { Label = "口_中央", Pos = new Vector2(0.50f * ViewW, 0.71f * ViewH) },
            new PartDef { Label = "顎_中央", Pos = new Vector2(0.50f * ViewW, 0.86f * ViewH), Small = true },
        };

        private static readonly Color Amber = new Color(0.898f, 0.663f, 0.235f);
        private static readonly Color CheckOrange = new Color(1f, 0.6f, 0.1f);

        private class PartView
        {
            public PartDef Def;
            public VisualElement Root;
            public VisualElement Dot;
            public Label Name;
            public bool Hover;
            public FaceMapEditorUi.PartVisual Visual;
        }

        private readonly List<PartView> _parts = new List<PartView>();
        private bool _pulseOn;

        /// <summary>パーツがクリックされた（label）。</summary>
        public event Action<string> PartClicked;

        public FaceSilhouettePalette()
        {
            style.flexGrow = 1;
            generateVisualContent += Draw;
            RegisterCallback<GeometryChangedEvent>(_ => Layout());

            var left = new Label("画像\nの左") { pickingMode = PickingMode.Ignore };
            left.AddToClassList("fm-side-label");
            left.style.left = 3;
            Add(left);
            var right = new Label("画像\nの右") { pickingMode = PickingMode.Ignore };
            right.AddToClassList("fm-side-label");
            right.style.right = 3;
            Add(right);

            foreach (PartDef def in Defs)
            {
                var pv = new PartView { Def = def, Root = new VisualElement() };
                pv.Root.AddToClassList("fm-part");
                if (def.Small) pv.Root.AddToClassList("fm-part--small");
                pv.Root.tooltip = FaceTemplateText.Describe(def.Label);
                pv.Dot = new VisualElement { pickingMode = PickingMode.Ignore };
                pv.Dot.AddToClassList("fm-part-dot");
                pv.Name = new Label(FaceIllustrationPalette.ShortName(def.Label)) { pickingMode = PickingMode.Ignore };
                pv.Name.AddToClassList("fm-part-label");
                if (def.DotAfter) { pv.Root.Add(pv.Name); pv.Root.Add(pv.Dot); }
                else { pv.Root.Add(pv.Dot); pv.Root.Add(pv.Name); }

                string label = def.Label;
                pv.Root.RegisterCallback<PointerDownEvent>(evt =>
                {
                    if (evt.button != 0) return;
                    PartClicked?.Invoke(label);
                    evt.StopPropagation();
                });
                pv.Root.RegisterCallback<PointerEnterEvent>(_ => { pv.Hover = true; Apply(pv); });
                pv.Root.RegisterCallback<PointerLeaveEvent>(_ => { pv.Hover = false; Apply(pv); });

                _parts.Add(pv);
                Add(pv.Root);
            }

            // 次に置くパーツの点滅（0.5 秒ごと）
            schedule.Execute(() =>
            {
                _pulseOn = !_pulseOn;
                foreach (PartView pv in _parts)
                {
                    if (pv.Visual.Pulse) Apply(pv);
                }
            }).Every(500);
        }

        /// <summary>パーツの状態を反映する。targetLabel は次に置くパーツ（null なら点滅なし）、checks は要確認の label。</summary>
        public void Refresh(Func<string, FaceMapEditorViewModel.PartState> getState, string targetLabel, HashSet<string> checks)
        {
            foreach (PartView pv in _parts)
            {
                string label = pv.Def.Label;
                pv.Visual = FaceMapEditorUi.PaletteVisual(getState(label),
                    string.Equals(label, targetLabel, StringComparison.Ordinal),
                    checks != null && checks.Contains(label));
                Apply(pv);
            }
        }

        private void Apply(PartView pv)
        {
            Color c = FaceMapTextureRenderer.GetLabelColor(pv.Def.Label);
            FaceMapEditorUi.PartVisual v = pv.Visual;
            float hover = pv.Hover ? 0.1f : 0f;

            pv.Root.style.backgroundColor = new Color(c.r, c.g, c.b, v.Fill + hover);
            Color border = new Color(c.r, c.g, c.b, Mathf.Min(1f, v.Border + hover));
            bool ring = v.Ring != FaceMapEditorUi.PartRing.None;
            if (v.Ring == FaceMapEditorUi.PartRing.Selected) border = Amber;
            else if (v.Ring == FaceMapEditorUi.PartRing.Check) border = CheckOrange;
            if (v.Pulse && v.Ring == FaceMapEditorUi.PartRing.None)
                border = new Color(Amber.r, Amber.g, Amber.b, _pulseOn ? 0.95f : 0.4f);
            else if (v.Pulse)
                border = Color.Lerp(border, Color.white, _pulseOn ? 0.35f : 0f);
            pv.Root.style.borderTopColor = border;
            pv.Root.style.borderBottomColor = border;
            pv.Root.style.borderLeftColor = border;
            pv.Root.style.borderRightColor = border;
            pv.Root.EnableInClassList("fm-part--ring", ring || v.Pulse);

            pv.Dot.style.backgroundColor = new Color(c.r, c.g, c.b, v.Fill > 0.2f ? 1f : 0.5f);
            Color text = Color.Lerp(c, Color.white, 0.72f);
            text.a = v.Text;
            pv.Name.style.color = text;
        }

        private void Scale(out float s, out Vector2 origin)
        {
            Rect r = contentRect;
            s = Mathf.Max(0.01f, Mathf.Min(r.width / ViewW, r.height / ViewH));
            origin = new Vector2(r.x + (r.width - ViewW * s) * 0.5f, r.y + (r.height - ViewH * s) * 0.5f);
        }

        private void Layout()
        {
            Scale(out float s, out Vector2 o);
            foreach (PartView pv in _parts)
            {
                pv.Root.style.left = o.x + pv.Def.Pos.x * s;
                pv.Root.style.top = o.y + pv.Def.Pos.y * s;
            }
            MarkDirtyRepaint();
        }

        // ── 線画（新案 A の SVG を Painter2D で）──

        private void Draw(MeshGenerationContext ctx)
        {
            Painter2D p = ctx.painter2D;
            Rect r = contentRect;
            Scale(out float s, out Vector2 o);
            Vector2 P(float x, float y) => new Vector2(o.x + x * s, o.y + y * s);

            // 薄いグリッド（24px / 120px）
            p.lineWidth = 1f;
            for (float x = 0f; x <= r.width; x += 24f)
            {
                p.strokeColor = new Color(1f, 1f, 1f, Mathf.Repeat(x, 120f) < 0.5f ? 0.04f : 0.015f);
                p.BeginPath(); p.MoveTo(new Vector2(x, 0f)); p.LineTo(new Vector2(x, r.height)); p.Stroke();
            }
            for (float y = 0f; y <= r.height; y += 24f)
            {
                p.strokeColor = new Color(1f, 1f, 1f, Mathf.Repeat(y, 120f) < 0.5f ? 0.04f : 0.015f);
                p.BeginPath(); p.MoveTo(new Vector2(0f, y)); p.LineTo(new Vector2(r.width, y)); p.Stroke();
            }

            // 耳
            p.strokeColor = new Color(0.322f, 0.322f, 0.322f, 1f);
            p.lineWidth = 1.2f;
            p.lineCap = LineCap.Round;
            p.BeginPath(); p.MoveTo(P(65, 88)); p.BezierCurveTo(P(56, 88), P(55, 112), P(65, 116)); p.Stroke();
            p.BeginPath(); p.MoveTo(P(215, 88)); p.BezierCurveTo(P(224, 88), P(225, 112), P(215, 116)); p.Stroke();

            // 輪郭（卵型・あご細め）
            p.BeginPath();
            p.MoveTo(P(140, 16));
            p.BezierCurveTo(P(188, 16), P(216, 44), P(215, 92));
            p.BezierCurveTo(P(214, 134), P(194, 168), P(162, 186));
            p.BezierCurveTo(P(151, 192), P(129, 192), P(118, 186));
            p.BezierCurveTo(P(86, 168), P(66, 134), P(65, 92));
            p.BezierCurveTo(P(64, 44), P(92, 16), P(140, 16));
            p.ClosePath();
            p.fillColor = new Color(0.173f, 0.173f, 0.173f, 1f);
            p.Fill();
            p.strokeColor = new Color(0.353f, 0.353f, 0.353f, 1f);
            p.lineWidth = 1.4f;
            p.Stroke();

            // 内側の輪郭
            p.BeginPath();
            p.MoveTo(P(140, 24));
            p.BezierCurveTo(P(182, 24), P(207, 49), P(206, 92));
            p.BezierCurveTo(P(205, 130), P(187, 161), P(158, 178));
            p.BezierCurveTo(P(149, 183), P(131, 183), P(122, 178));
            p.BezierCurveTo(P(93, 161), P(75, 130), P(74, 92));
            p.BezierCurveTo(P(73, 49), P(98, 24), P(140, 24));
            p.ClosePath();
            p.strokeColor = new Color(0.40f, 0.40f, 0.40f, 0.10f);
            p.lineWidth = 1f;
            p.Stroke();

            // 縦の対称軸（破線）と目線（破線）
            Dashed(p, P(140, 10), P(140, 198), 3f * s, 3f * s, new Color(0.784f, 0.604f, 0.259f, 0.45f));
            Dashed(p, P(68, 74), P(212, 74), 2f * s, 3f * s, new Color(0.40f, 0.40f, 0.40f, 0.30f));

            // 中心の印
            p.fillColor = new Color(0.784f, 0.604f, 0.259f, 0.45f);
            p.BeginPath(); p.Arc(P(140, 74), 2f * s, 0f, 360f); p.Fill();
        }

        private static void Dashed(Painter2D p, Vector2 a, Vector2 b, float dash, float gap, Color color)
        {
            p.strokeColor = color;
            p.lineWidth = 1f;
            float len = Vector2.Distance(a, b);
            if (len <= 0f) return;
            Vector2 dir = (b - a) / len;
            for (float t = 0f; t < len; t += dash + gap)
            {
                p.BeginPath();
                p.MoveTo(a + dir * t);
                p.LineTo(a + dir * Mathf.Min(t + dash, len));
                p.Stroke();
            }
        }
    }
}
