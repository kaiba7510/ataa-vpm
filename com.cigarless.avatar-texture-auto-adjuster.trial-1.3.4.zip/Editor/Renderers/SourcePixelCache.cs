// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Renderers/SourcePixelCache.cs
using System.Collections.Generic;
using System.Globalization;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 元のテクスチャから読んだ画素（FaceTextureReader.ReadSource）のキャッシュ。最近使った capacity 個だけ残す。
    /// 4096 の 2 枚（対象とメイク元）を読むのに Unity の上で 0.4〜0.65 秒かかり、同じテクスチャで適用し直すたびに読み直していた。
    /// キーはファイル・インポート設定・読み方（Key）。読んだ画素は誰も書き換えないこと（合成は読むだけ）。メインスレッド専用。
    /// </summary>
    internal sealed class SourcePixelCache<T> where T : class
    {
        private readonly int _capacity;
        // 先頭が一番最近使ったもの（数個しか持たないので線形に探す）
        private readonly List<KeyValuePair<string, T>> _items = new List<KeyValuePair<string, T>>();

        public SourcePixelCache(int capacity)
        {
            _capacity = capacity < 1 ? 1 : capacity;
        }

        public int Count => _items.Count;

        /// <summary>
        /// 同じ画素になる読み方のキー。assetPath が無ければ null（キャッシュしない）。
        /// dependencyHash（AssetDatabase.GetAssetDependencyHash）はインポート設定と取り込んだ中身で変わる。
        /// ファイルの更新日時・大きさも入れる（書き直してまだ取り込んでいない元のファイルも、ReadSource は直接読むため）。
        /// </summary>
        public static string Key(string assetPath, string dependencyHash, long fileTicks, long fileLength, int maxSide, bool linear)
        {
            if (string.IsNullOrEmpty(assetPath)) return null;
            return string.Join("|", assetPath, dependencyHash ?? "",
                fileTicks.ToString(CultureInfo.InvariantCulture), fileLength.ToString(CultureInfo.InvariantCulture),
                maxSide.ToString(CultureInfo.InvariantCulture), linear ? "linear" : "srgb");
        }

        public bool TryGet(string key, out T value)
        {
            value = null;
            if (key == null) return false;
            for (int i = 0; i < _items.Count; i++)
            {
                if (_items[i].Key != key) continue;
                KeyValuePair<string, T> item = _items[i];
                _items.RemoveAt(i);
                _items.Insert(0, item);
                value = item.Value;
                return true;
            }
            return false;
        }

        public void Put(string key, T value)
        {
            if (key == null || value == null) return;
            for (int i = 0; i < _items.Count; i++)
            {
                if (_items[i].Key != key) continue;
                _items.RemoveAt(i);
                break;
            }
            _items.Insert(0, new KeyValuePair<string, T>(key, value));
            while (_items.Count > _capacity) _items.RemoveAt(_items.Count - 1);
        }

        public void Clear() => _items.Clear();
    }
}
