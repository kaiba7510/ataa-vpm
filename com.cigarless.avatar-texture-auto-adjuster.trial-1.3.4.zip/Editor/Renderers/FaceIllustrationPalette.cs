// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Renderers/FaceIllustrationPalette.cs
using System;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 顔パレットのパーツの短い名前（Issue #16 §2「FaceIllustrationPalette」）。
    /// パレットの描画は UI Toolkit の <see cref="FaceSilhouettePalette"/>（UI案A）が行う。左右は「画像の左右」。
    /// </summary>
    public static class FaceIllustrationPalette
    {
        private static readonly (string Label, string ShortName)[] Names =
        {
            ("目_左", "左目"),
            ("目_右", "右目"),
            ("鼻_中央", "鼻"),
            ("口_中央", "口"),
            ("頬_左", "左頬"),
            ("頬_右", "右頬"),
            ("顎_中央", "顎"),
        };

        /// <summary>パーツの短い名前（左目・鼻 など）。テンプレートに無ければ label。</summary>
        public static string ShortName(string label)
        {
            foreach ((string l, string shortName) in Names)
            {
                if (string.Equals(l, label, StringComparison.Ordinal)) return shortName;
            }
            return label;
        }
    }
}
