// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Renderers/FaceTextureReader.cs
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 合成に使う画素をテクスチャから読む（メインスレッド専用）。合成の計算（FaceCompositor）はコア、
    /// アセット・ファイル・RenderTexture を使う読み込みはここ（docs~/コアとUIの分割_設計メモ.md 手順 3）。
    /// </summary>
    public static class FaceTextureReader
    {
        /// <summary>テクスチャが線形（sRGB でない）扱いか。インポート設定が分からなければ sRGB 扱い。</summary>
        public static bool IsLinear(Texture tex)
        {
            string path = AssetDatabase.GetAssetPath(tex);
            if (string.IsNullOrEmpty(path)) return false;
            var importer = AssetImporter.GetAtPath(path) as TextureImporter;
            return importer != null && !importer.sRGBTexture;
        }

        /// <summary>
        /// 書き出し用に、できるだけ劣化のない画素を読む（長辺は maxSide 以下）。メインスレッド専用。
        /// 元のファイルが PNG / JPG なら、ファイルそのものを読む（インポート後の圧縮ノイズや Max Size による縮小を
        /// 生成 PNG に焼き込まないため）。それ以外・読めないときは、インポート後のテクスチャを読む（Read）。
        /// 元のファイルを読んだときは、大きさが tex.width / height と違うことがある（戻り値の Width / Height を使うこと）。
        /// ファイル・インポート設定・読み方が前と同じなら、前に読んだ画素を返す（SourcePixelCache。書き換えないこと）。
        /// </summary>
        public static FacePixels ReadSource(Texture2D tex, int maxSide, bool linear)
        {
            string key = SourceKey(tex, maxSide, linear);
            if (SourceCache.TryGet(key, out FacePixels cached)) return cached;

            Texture2D source = LoadSourceFile(tex, linear);
            try
            {
                Texture from = source != null ? (Texture)source : tex;
                FaceMapPreview.FitSize(from.width, from.height, maxSide, out int w, out int h);
                FacePixels px = Read(from, w, h, linear);
                SourceCache.Put(key, px);
                return px;
            }
            finally
            {
                if (source != null) UnityEngine.Object.DestroyImmediate(source);
            }
        }

        /// <summary>
        /// ReadSource で読んだ画素。対象とメイク元の 2 枚（4096 で 1 枚 64 MB）。メイクフィックスのウィンドウを閉じたら捨てる。
        /// </summary>
        private static readonly SourcePixelCache<FacePixels> SourceCache = new SourcePixelCache<FacePixels>(2);

        /// <summary>ReadSource のキャッシュを捨てる（メモリを返す）。</summary>
        public static void ClearSourceCache() => SourceCache.Clear();

        private static string SourceKey(Texture tex, int maxSide, bool linear)
        {
            string path = tex != null ? AssetDatabase.GetAssetPath(tex) : null;
            if (string.IsNullOrEmpty(path)) return null;
            long ticks = 0, length = 0;
            try
            {
                var file = new FileInfo(FaceMapFolder.ToAbsolute(path));
                if (file.Exists)
                {
                    ticks = file.LastWriteTimeUtc.Ticks;
                    length = file.Length;
                }
            }
            catch (Exception)
            {
                return null; // ファイルを確かめられなければキャッシュしない
            }
            return SourcePixelCache<FacePixels>.Key(path, AssetDatabase.GetAssetDependencyHash(path).ToString(),
                ticks, length, maxSide, linear);
        }

        /// <summary>
        /// tex の元のファイル（PNG / JPG）を、圧縮なしのテクスチャとして読む。使えなければ null。
        /// インポート設定が画素の意味を変える場合（種類が Default 以外・アルファを入力以外から作る）は、
        /// プレビュー（インポート後のテクスチャ）と結果が変わるので使わない。呼び出し側が破棄すること。
        /// </summary>
        private static Texture2D LoadSourceFile(Texture tex, bool linear)
        {
            string path = AssetDatabase.GetAssetPath(tex);
            if (string.IsNullOrEmpty(path)) return null;

            string ext = Path.GetExtension(path).ToLowerInvariant();
            if (ext != ".png" && ext != ".jpg" && ext != ".jpeg") return null;

            var importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null || importer.textureType != TextureImporterType.Default ||
                importer.alphaSource != TextureImporterAlphaSource.FromInput)
                return null;

            Texture2D loaded = null;
            try
            {
                byte[] bytes = File.ReadAllBytes(FaceMapFolder.ToAbsolute(path));
                loaded = new Texture2D(2, 2, TextureFormat.RGBA32, false, linear)
                {
                    hideFlags = HideFlags.HideAndDontSave,
                    wrapMode = TextureWrapMode.Clamp
                };
                if (loaded.LoadImage(bytes, false)) return loaded;
            }
            catch (Exception)
            {
                // 読めなければ、インポート後のテクスチャを使う
            }

            if (loaded != null) UnityEngine.Object.DestroyImmediate(loaded);
            return null;
        }

        /// <summary>
        /// 読み取り不可・圧縮テクスチャでも読めるよう、RenderTexture 経由で w×h に読む。メインスレッド専用。
        /// </summary>
        public static FacePixels Read(Texture tex, int w, int h, bool linear)
        {
            RenderTexture rt = RenderTexture.GetTemporary(w, h, 0, RenderTextureFormat.ARGB32,
                linear ? RenderTextureReadWrite.Linear : RenderTextureReadWrite.sRGB);
            RenderTexture previous = RenderTexture.active;
            Texture2D readable = null;
            try
            {
                Graphics.Blit(tex, rt);
                RenderTexture.active = rt;

                readable = new Texture2D(w, h, TextureFormat.RGBA32, false, linear);
                readable.ReadPixels(new Rect(0, 0, w, h), 0, 0);
                return new FacePixels(readable.GetPixels32(), w, h);
            }
            finally
            {
                RenderTexture.active = previous;
                RenderTexture.ReleaseTemporary(rt);
                if (readable != null) UnityEngine.Object.DestroyImmediate(readable);
            }
        }
    }
}
