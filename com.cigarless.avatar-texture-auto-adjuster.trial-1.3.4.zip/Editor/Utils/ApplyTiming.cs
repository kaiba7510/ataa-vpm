// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/ApplyTiming.cs
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メイク適用の段階ごとの所要時間（高速化の検討用の計測ログ）。Lap で前の区切りからの時間を記録し、
    /// ワーカースレッドで測った内訳は Detail で直前の区切りに付ける（合計には足さない）。
    /// ログに出すかは Enabled（開発用メニュー「Cigarless/診断/メイク適用の所要時間をログに出す」。リリースには入らないので常に false）。
    /// メインスレッドから使う（ワーカーで測った値は、終わってから Detail で渡す）。
    /// </summary>
    internal sealed class ApplyTiming
    {
        /// <summary>適用が終わったら Console に所要時間を出すか。</summary>
        public static bool Enabled;

        public readonly struct Item
        {
            public readonly string Name;
            public readonly double Ms;

            public Item(string name, double ms)
            {
                Name = name;
                Ms = ms;
            }
        }

        public sealed class LapItem
        {
            public string Name;
            public double Ms;
            public readonly List<Item> Details = new List<Item>();
        }

        private readonly Func<double> _clockMs;
        private readonly List<LapItem> _laps = new List<LapItem>();
        private readonly List<KeyValuePair<string, string>> _notes = new List<KeyValuePair<string, string>>();
        private double _last;

        /// <param name="clockMs">今の時刻（ミリ秒）。null なら Stopwatch。テストで差し替える。</param>
        public ApplyTiming(Func<double> clockMs = null)
        {
            _clockMs = clockMs ?? (() => Stopwatch.GetTimestamp() * 1000.0 / Stopwatch.Frequency);
            _last = _clockMs();
        }

        public IReadOnlyList<LapItem> Laps => _laps;

        public bool HasLaps => _laps.Count > 0;

        /// <summary>区切りの合計（最初から最後の区切りまで）。</summary>
        public double TotalMs
        {
            get
            {
                double sum = 0.0;
                foreach (LapItem lap in _laps) sum += lap.Ms;
                return sum;
            }
        }

        /// <summary>前の区切り（無ければ作ったとき）から今までを name として記録する。</summary>
        public void Lap(string name)
        {
            double now = _clockMs();
            _laps.Add(new LapItem { Name = name, Ms = now - _last });
            _last = now;
        }

        /// <summary>直前の区切りの内訳（別に測った時間）。区切りが無ければ無視する。</summary>
        public void Detail(string name, double ms)
        {
            if (_laps.Count == 0) return;
            _laps[_laps.Count - 1].Details.Add(new Item(name, ms));
        }

        /// <summary>時間でない補足（解像度・ファイルの大きさなど）。最後の行にまとめて出す。</summary>
        public void Note(string name, string value)
        {
            _notes.Add(new KeyValuePair<string, string>(name, value));
        }

        /// <summary>Console に出す文字列（1 行目が見出しと合計、区切りごとに 1 行、内訳は字下げ、補足は最後の 1 行）。</summary>
        public string Format(string title)
        {
            double total = TotalMs;
            var sb = new StringBuilder();
            sb.Append("[ATAA] ").Append(title).Append("の所要時間: 合計 ").Append(Ms(total));
            foreach (LapItem lap in _laps)
            {
                double percent = total > 0.0 ? lap.Ms / total * 100.0 : 0.0;
                sb.Append('\n').Append("  ").Append(lap.Name).Append(": ").Append(Ms(lap.Ms))
                  .Append(" (").Append(percent.ToString("0", CultureInfo.InvariantCulture)).Append("%)");
                foreach (Item d in lap.Details)
                    sb.Append('\n').Append("    - ").Append(d.Name).Append(": ").Append(Ms(d.Ms));
            }

            if (_notes.Count > 0)
            {
                sb.Append('\n').Append("  ");
                for (int i = 0; i < _notes.Count; i++)
                {
                    if (i > 0) sb.Append(" / ");
                    sb.Append(_notes[i].Key).Append(": ").Append(_notes[i].Value);
                }
            }
            return sb.ToString();
        }

        /// <summary>バイト数を「4.3 MB」の形にする（1 MB = 1000 × 1000 バイト）。</summary>
        public static string MegaBytes(long bytes)
        {
            return (bytes / 1e6).ToString("0.0", CultureInfo.InvariantCulture) + " MB";
        }

        private static string Ms(double ms) => ms.ToString("0", CultureInfo.InvariantCulture) + " ms";
    }
}
