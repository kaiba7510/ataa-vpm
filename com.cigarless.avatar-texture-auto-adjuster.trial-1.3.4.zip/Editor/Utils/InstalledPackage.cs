using UnityEditor.PackageManager;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>このツールが実際に入っている場所（Unity に問い合わせる。判断は PackageLocation の純粋ヘルパーで行う）。</summary>
    public static class InstalledPackage
    {
        private static bool _resolved;
        private static string _root;

        /// <summary>VPM で入っていれば "Packages/&lt;名前&gt;"、Assets に入っていれば null。</summary>
        public static string Root
        {
            get
            {
                if (!_resolved)
                {
                    _resolved = true;
                    var info = PackageInfo.FindForAssembly(typeof(InstalledPackage).Assembly);
                    _root = info != null ? info.assetPath : null;
                }
                return _root;
            }
        }

        public static bool IsVpm => PackageLocation.IsVpmRoot(Root);
    }
}
