using UnityEngine;
using UnityEngine.UIElements;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// UI Toolkit の Slider 初期化補助。メイクフィックス画面と FaceMap エディターで共通。
    /// </summary>
    public static class UiSlider
    {
        /// <summary>
        /// ChangeEvent を発火させずに Slider の lowValue / highValue を設定する。
        /// 既定の Slider は lowValue=0, highValue=10, value=0 で生成されるため、lowValue に正の値を直接代入すると
        /// 内部の ClampValue() が 0 → lowValue の ChangeEvent を EventDispatcher に積み、CreateGUI 完了後に
        /// 登録済みコールバックが発火して読み込み済みの値（目の線・口の線など）を下限値で上書きしてしまう。
        /// 先に包含範囲へ広げて SetValueWithoutNotify してから縮めることで、クランプによる値変化を起こさない。
        /// </summary>
        public static void SetRange(Slider slider, float low, float high)
        {
            if (slider == null) return;
            if (low > high) (low, high) = (high, low);

            slider.SetValueWithoutNotify(slider.value);
            float clamped = Mathf.Clamp(slider.value, low, high);
            if (low < slider.lowValue) slider.lowValue = low;
            if (high > slider.highValue) slider.highValue = high;
            slider.SetValueWithoutNotify(clamped);
            slider.lowValue = low;
            slider.highValue = high;
        }
    }
}
