using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>ズーム・パンの計算（ウィンドウから切り出した純粋関数）。</summary>
    public static class ViewportMath
    {
        public const float MinZoom = 1f;
        public const float MaxZoom = 8f;

        /// <summary>パンを「拡大後サイズの半分」の範囲に収める。fit は等倍時にテクスチャが収まる矩形。</summary>
        public static Vector2 ClampPan(Rect fit, float zoom, Vector2 pan)
        {
            float mx = fit.width * zoom * 0.5f, my = fit.height * zoom * 0.5f;
            return new Vector2(Mathf.Clamp(pan.x, -mx, mx), Mathf.Clamp(pan.y, -my, my));
        }

        /// <summary>
        /// カーソル位置の UV が動かないように拡大・縮小する。倍率が変わらなければ false。
        /// texRect は現在のテクスチャ表示矩形、mouse は同じ座標系のカーソル位置。
        /// </summary>
        public static bool TryZoomAt(Rect fit, Rect texRect, float zoom, Vector2 pan, Vector2 mouse, float factor,
            out float newZoom, out Vector2 newPan)
        {
            newZoom = Mathf.Clamp(zoom * factor, MinZoom, MaxZoom);
            newPan = pan;
            if (Mathf.Approximately(newZoom, zoom)) return false;

            Vector2 uv = new Vector2((mouse.x - texRect.x) / texRect.width, 1f - (mouse.y - texRect.y) / texRect.height);
            float w = fit.width * newZoom, h = fit.height * newZoom;
            var topLeft = new Vector2(mouse.x - uv.x * w, mouse.y - (1f - uv.y) * h);
            Vector2 center = topLeft + new Vector2(w * 0.5f, h * 0.5f);

            newPan = newZoom <= MinZoom ? Vector2.zero : ClampPan(fit, newZoom, center - fit.center);
            return true;
        }
    }
}
