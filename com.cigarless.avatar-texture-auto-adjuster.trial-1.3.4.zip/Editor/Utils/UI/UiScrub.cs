using System;
using UnityEngine;
using UnityEngine.UIElements;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// UI Toolkit のドラッグスクラブ（NudgePad の UI Toolkit 版）。クリックで 1 ステップ、押したままドラッグで連続して動かす。
    /// メイクフィックス画面と FaceMap エディターで共通。
    /// </summary>
    public static class UiScrub
    {
        /// <summary>1 イベントのドラッグ量の上限（ピクセル）。これを超える移動はマウスの回り込みとみなして捨てる。</summary>
        public const float MaxDragDelta = 150f;

        /// <summary>
        /// 十字ボタンのドラッグ量（画面のピクセル）を UV の変化量に直す。画面の下向きは v の負。
        /// 上下・左右のボタンはその軸だけ（clickDir が zero の中央ボタンは自由に）動く。
        /// </summary>
        public static Vector2 Drag2D(Vector2 pointerDelta, Vector2 clickDir, float step)
        {
            if (pointerDelta.sqrMagnitude > MaxDragDelta * MaxDragDelta) return Vector2.zero;
            var d = new Vector2(pointerDelta.x, -pointerDelta.y);
            if (clickDir != Vector2.zero) d = Vector2.Dot(d, clickDir) * clickDir;
            return d * (step * NudgePad.ScrubPerPixel);
        }

        /// <summary>±ボタンの横ドラッグ量（ピクセル）をステップ数に直す。</summary>
        public static float Drag1D(float dx) => Mathf.Abs(dx) > MaxDragDelta ? 0f : dx * NudgePad.ScrubPerPixel;

        private const string DisabledHint = "今は動かせません";

        /// <summary>
        /// 十字ボタンにカーソルを置いたときの案内。中央は自在に、上下・左右のボタンはその軸だけ動くことを伝える。
        /// 使えないときは disabledReason（null なら既定の文）。
        /// </summary>
        public static string HoverHint2D(Vector2 clickDir, bool enabled, string disabledReason)
        {
            if (!enabled) return disabledReason ?? DisabledHint;
            if (clickDir == Vector2.zero) return "押したままドラッグで、上下左右に自在に動かせます";
            bool vertical = Mathf.Abs(clickDir.y) > Mathf.Abs(clickDir.x);
            return vertical
                ? "クリックで 1 ステップ／ドラッグは上下だけ（自在に動かすのは中央のボタン）"
                : "クリックで 1 ステップ／ドラッグは左右だけ（自在に動かすのは中央のボタン）";
        }

        /// <summary>±ボタンにカーソルを置いたときの案内。</summary>
        public static string HoverHint1D(bool enabled, string disabledReason)
        {
            if (!enabled) return disabledReason ?? DisabledHint;
            return "クリックで 1 ステップ／押したまま左右にドラッグで連続して変わります";
        }

        /// <summary>
        /// カーソルを置くと hint() の文をポップアップ（ツールチップ）で出す。
        /// 文は出すたびに作り直すので、使える / 使えない（理由）の切り替わりにも追従する。
        /// </summary>
        public static void BindHoverTooltip(VisualElement el, Func<string> hint)
        {
            if (el == null) return;
            el.RegisterCallback<TooltipEvent>(evt =>
            {
                evt.tooltip = hint();
                evt.rect = el.worldBound;
                evt.StopPropagation();
            });
        }

        /// <summary>
        /// 十字ボタンの 1 つにスクラブを付ける。onDelta は UV の変化量と、押している修飾キー（Alt で片側だけ、など）。
        /// onHeld は押し始め（true）と離したとき（false）。
        /// </summary>
        public static void Bind2D(VisualElement el, Vector2 clickDir, string activeClass, Func<bool> canEdit, Func<float> step,
                                  Action<Vector2, EventModifiers> onDelta, Action<bool> onHeld)
        {
            bool held = false;
            Vector2 lastPos = Vector2.zero;
            int pointerId = -1;

            el.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || !canEdit()) return;
                held = true;
                pointerId = evt.pointerId;
                lastPos = evt.position;
                onHeld?.Invoke(true);
                el.CapturePointer(pointerId);
                el.AddToClassList(activeClass);
                if (clickDir != Vector2.zero) onDelta(clickDir * step(), evt.modifiers);
                evt.StopPropagation();
            });

            el.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (!held || evt.pointerId != pointerId) return;
                Vector2 delta = (Vector2)evt.position - lastPos;
                lastPos = evt.position;
                Vector2 d = Drag2D(delta, clickDir, step());
                if (d.sqrMagnitude > 0f) onDelta(d, evt.modifiers);
                evt.StopPropagation();
            });

            Action release = () =>
            {
                if (!held) return;
                held = false;
                el.RemoveFromClassList(activeClass);
                if (pointerId >= 0 && el.HasPointerCapture(pointerId)) el.ReleasePointer(pointerId);
                pointerId = -1;
                onHeld?.Invoke(false);
            };

            el.RegisterCallback<PointerUpEvent>(evt => { if (evt.pointerId == pointerId) release(); });
            el.RegisterCallback<PointerCaptureOutEvent>(_ => release());
        }

        /// <summary>±ボタンにスクラブを付ける。onSteps はステップ数（クリックで clickSign、ドラッグで右が正）。</summary>
        public static void Bind1D(VisualElement el, float clickSign, string activeClass, Func<bool> canEdit,
                                  Action<float, EventModifiers> onSteps, Action<bool> onHeld)
        {
            bool held = false;
            float lastX = 0f;
            int pointerId = -1;

            el.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || !canEdit()) return;
                held = true;
                pointerId = evt.pointerId;
                lastX = evt.position.x;
                onHeld?.Invoke(true);
                el.CapturePointer(pointerId);
                el.AddToClassList(activeClass);
                onSteps(clickSign, evt.modifiers);
                evt.StopPropagation();
            });

            el.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (!held || evt.pointerId != pointerId) return;
                float dx = evt.position.x - lastX;
                lastX = evt.position.x;
                float steps = Drag1D(dx);
                if (!Mathf.Approximately(steps, 0f)) onSteps(steps, evt.modifiers);
                evt.StopPropagation();
            });

            Action release = () =>
            {
                if (!held) return;
                held = false;
                el.RemoveFromClassList(activeClass);
                if (pointerId >= 0 && el.HasPointerCapture(pointerId)) el.ReleasePointer(pointerId);
                pointerId = -1;
                onHeld?.Invoke(false);
            };

            el.RegisterCallback<PointerUpEvent>(evt => { if (evt.pointerId == pointerId) release(); });
            el.RegisterCallback<PointerCaptureOutEvent>(_ => release());
        }
    }
}
