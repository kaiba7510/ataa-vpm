using UnityEditor;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// UI Toolkit の画面（UXML/USS）を読む。実際に入っている場所 → VPM（Packages/）→ 旧 Assets の順に探し（PackageLocation）、
    /// どこにも無ければ（フォルダを移したとき）名前で探す。
    /// </summary>
    public static class UiAssets
    {
        /// <param name="assetName">拡張子なしの名前（例 MakeFixWindow）</param>
        /// <param name="extension">".uxml" / ".uss"</param>
        public static T Load<T>(string assetName, string extension) where T : UnityEngine.Object
        {
            foreach (string path in PackageLocation.UiAssetCandidates(assetName + extension, InstalledPackage.Root))
            {
                T direct = AssetDatabase.LoadAssetAtPath<T>(path);
                if (direct != null) return direct;
            }

            string typeFilter = typeof(T) == typeof(UnityEngine.UIElements.VisualTreeAsset) ? "t:VisualTreeAsset" : "t:StyleSheet";
            // Packages/ の下も探す（既定の FindAssets は Assets だけのことがある）
            foreach (string guid in AssetDatabase.FindAssets(assetName + " " + typeFilter, new[] { "Assets", "Packages" }))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (System.IO.Path.GetFileNameWithoutExtension(path) == assetName)
                {
                    T loaded = AssetDatabase.LoadAssetAtPath<T>(path);
                    if (loaded != null) return loaded;
                }
            }
            return null;
        }
    }
}
