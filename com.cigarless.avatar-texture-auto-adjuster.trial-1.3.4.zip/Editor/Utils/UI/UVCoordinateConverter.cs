// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Windows/UVCoordinateConverter.cs
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// UV / スクリーン / ピクセル 座標変換の純関数。副作用なし。
    /// </summary>
    public static class UVCoordinateConverter
    {
        /// <summary>
        /// テクスチャ表示 Rect 内のスクリーン座標を UV に変換。
        /// </summary>
        public static Vector2 ScreenToUv(Vector2 screenPos, Rect texRect)
        {
            if (texRect.width <= 0f || texRect.height <= 0f) return Vector2.zero;

            float u = (screenPos.x - texRect.min.x) / texRect.width;
            float v = 1f - (screenPos.y - texRect.min.y) / texRect.height;
            return new Vector2(Mathf.Clamp01(u), Mathf.Clamp01(v));
        }

        /// <summary>
        /// UV を テクスチャ表示 Rect 内のスクリーン座標に変換。
        /// </summary>
        public static Vector2 UvToScreen(Vector2 uv, Rect texRect)
        {
            return new Vector2(
                texRect.min.x + uv.x * texRect.width,
                texRect.min.y + (1f - uv.y) * texRect.height);
        }

        /// <summary>
        /// UV からピクセル座標を算出 (左下が原点)。
        /// </summary>
        public static void PixelFromUv(Vector2 uv, Texture2D tex, out int px, out int py)
        {
            px = Mathf.Clamp(Mathf.FloorToInt(uv.x * tex.width), 0, tex.width - 1);
            py = Mathf.Clamp(Mathf.FloorToInt(uv.y * tex.height), 0, tex.height - 1);
        }

        /// <summary>
        /// 領域にアスペクト比を保って収めた Rect を返す。
        /// </summary>
        public static Rect FitRect(Rect area, float aspect)
        {
            if (area.width <= 0f || area.height <= 0f || aspect <= 0f) return area;

            float w, h;
            if (area.width / area.height > aspect)
            {
                h = area.height;
                w = h * aspect;
            }
            else
            {
                w = area.width;
                h = w / aspect;
            }
            return new Rect(area.x + (area.width - w) * 0.5f, area.y + (area.height - h) * 0.5f, w, h);
        }
    }
}