// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/TexturePickerPopup.cs
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// テクスチャの候補をサムネイルで並べて選ぶポップアップ（メイクフィックス画面の「候補から選ぶ」）。
    /// 名前だけでは見分けにくいので、画像を見て選べるようにする。候補は呼び出し側が対象アバターのマテリアルから集める。
    /// クリックで選んで閉じる。Esc・外側のクリックで何もせず閉じる。
    /// </summary>
    internal sealed class TexturePickerPopup : PopupWindowContent
    {
        public struct Section
        {
            public string Title;
            public List<Texture2D> Textures;
        }

        private const float Thumb = 96f;
        private const float CellWidth = Thumb + 8f;
        private const float CellHeight = Thumb + 30f;
        private const int Columns = 4;
        private const float Padding = 8f;
        private const float HeaderHeight = 20f;
        private const float MaxHeight = 520f;

        private readonly List<Section> _sections;
        private readonly Texture2D _current;
        private readonly Action<Texture2D> _onPick;
        private readonly EditorWindow _owner;
        private Vector2 _scroll;

        private static GUIStyle _nameStyle;
        private static GUIStyle _sizeStyle;

        public TexturePickerPopup(List<Section> sections, Texture2D current, Action<Texture2D> onPick, EditorWindow owner)
        {
            _sections = sections;
            _current = current;
            _onPick = onPick;
            _owner = owner;
        }

        private float ContentHeight()
        {
            float h = Padding;
            foreach (Section s in _sections)
            {
                if (s.Textures == null || s.Textures.Count == 0) continue;
                int rows = (s.Textures.Count + Columns - 1) / Columns;
                h += HeaderHeight + rows * CellHeight + 4f;
            }
            return Mathf.Max(h + Padding, 60f);
        }

        public override Vector2 GetWindowSize()
        {
            float w = Padding * 2f + CellWidth * Columns + 14f; // 14: 縦スクロールバーの分
            return new Vector2(w, Mathf.Min(ContentHeight(), MaxHeight));
        }

        public override void OnGUI(Rect rect)
        {
            EnsureStyles();
            Event e = Event.current;
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                editorWindow.Close();
                e.Use();
                return;
            }
            if (e.type == EventType.MouseMove) editorWindow.Repaint();

            bool any = false;
            foreach (Section s in _sections) any |= s.Textures != null && s.Textures.Count > 0;
            if (!any)
            {
                GUI.Label(rect, "テクスチャが見つかりません", EditorStyles.centeredGreyMiniLabel);
                return;
            }

            float contentHeight = ContentHeight();
            var view = new Rect(0f, 0f, rect.width - 14f, contentHeight);
            _scroll = GUI.BeginScrollView(rect, _scroll, view);

            float y = Padding;
            foreach (Section s in _sections)
            {
                if (s.Textures == null || s.Textures.Count == 0) continue;
                GUI.Label(new Rect(Padding, y, view.width - Padding * 2f, HeaderHeight), s.Title, EditorStyles.boldLabel);
                y += HeaderHeight;
                for (int i = 0; i < s.Textures.Count; i++)
                {
                    var cell = new Rect(Padding + (i % Columns) * CellWidth, y + (i / Columns) * CellHeight, CellWidth, CellHeight);
                    if (DrawCell(cell, s.Textures[i]))
                    {
                        Texture2D picked = s.Textures[i];
                        GUI.EndScrollView();
                        _onPick?.Invoke(picked);
                        if (_owner != null) _owner.Repaint();
                        editorWindow.Close();
                        GUIUtility.ExitGUI();
                        return;
                    }
                }
                y += ((s.Textures.Count + Columns - 1) / Columns) * CellHeight + 4f;
            }

            GUI.EndScrollView();
        }

        /// <summary>1 つの候補（サムネイル・名前・大きさ）。クリックされたら true。</summary>
        private bool DrawCell(Rect cell, Texture2D tex)
        {
            Event e = Event.current;
            bool hover = cell.Contains(e.mousePosition);
            bool selected = tex == _current;
            var thumb = new Rect(cell.x + 4f, cell.y + 2f, Thumb, Thumb);

            if (e.type == EventType.Repaint)
            {
                if (selected) EditorGUI.DrawRect(cell, MakeFixGui.RowSelected);
                else if (hover) EditorGUI.DrawRect(cell, MakeFixGui.RowHover);

                EditorGUI.DrawRect(thumb, new Color(0.12f, 0.12f, 0.12f));
                if (tex != null) GUI.DrawTexture(thumb, tex, ScaleMode.ScaleToFit, true);
                if (selected)
                {
                    Color c = MakeFixGui.Accent;
                    EditorGUI.DrawRect(new Rect(thumb.x - 2f, thumb.y - 2f, thumb.width + 4f, 2f), c);
                    EditorGUI.DrawRect(new Rect(thumb.x - 2f, thumb.yMax, thumb.width + 4f, 2f), c);
                    EditorGUI.DrawRect(new Rect(thumb.x - 2f, thumb.y, 2f, thumb.height), c);
                    EditorGUI.DrawRect(new Rect(thumb.xMax, thumb.y, 2f, thumb.height), c);
                }
            }

            string name = tex != null ? tex.name : "-";
            GUI.Label(new Rect(cell.x + 2f, thumb.yMax + 2f, cell.width - 4f, 14f), new GUIContent(name, name), _nameStyle);
            GUI.Label(new Rect(cell.x + 2f, thumb.yMax + 14f, cell.width - 4f, 12f),
                tex != null ? $"{tex.width} x {tex.height}" : "", _sizeStyle);

            if (e.type == EventType.MouseDown && e.button == 0 && hover)
            {
                e.Use();
                return true;
            }
            return false;
        }

        private static void EnsureStyles()
        {
            if (_nameStyle != null) return;
            _nameStyle = new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleCenter, clipping = TextClipping.Clip };
            _sizeStyle = new GUIStyle(EditorStyles.centeredGreyMiniLabel) { alignment = TextAnchor.MiddleCenter };
        }
    }
}
