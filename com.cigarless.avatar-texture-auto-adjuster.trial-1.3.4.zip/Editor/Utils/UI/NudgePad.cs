// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/NudgePad.cs
using UnityEditor;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 微調整ステップ（移動量）の設定キー・候補値とドラッグスクラブ係数。
    /// UI Toolkit の操作（MakeFixWindow・FaceMap エディター・UiScrub）で共有する。
    /// </summary>
    public static class NudgePad
    {
        public const string MakeFixStepKey = "ATAA.MakeFix.NudgeStep";
        public const string FaceMapEditorStepKey = "ATAA.FaceMapEditor.NudgeStep";

        public static readonly float[] Steps = { 0.001f, 0.005f, 0.01f, 0.05f };
        private const int DefaultStepIndex = 1;

        /// <summary>ドラッグ 1 ピクセルあたりの変化量（ステップに対する比）。5 ピクセルで 1 ステップ。</summary>
        public const float ScrubPerPixel = 0.2f;

        /// <summary>移動量の選択で選んでいるステップ（UV）。</summary>
        public static float CurrentStep(string stepPrefsKey)
        {
            int i = EditorPrefs.GetInt(stepPrefsKey, DefaultStepIndex);
            return Steps[i >= 0 && i < Steps.Length ? i : DefaultStepIndex];
        }
    }
}
