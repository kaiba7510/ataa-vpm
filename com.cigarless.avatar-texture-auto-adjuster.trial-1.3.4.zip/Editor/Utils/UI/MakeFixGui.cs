// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/MakeFixGui.cs
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// ステップ状態と、IMGUI 補助ウィンドウ（TexturePickerPopup・NameInputDialog）で共有する色・テキストスタイル。
    /// 色はエディターのスキン（Personal / Pro）に合わせる。
    /// </summary>
    internal static class MakeFixGui
    {
        public enum StepState
        {
            Pending,
            Current,
            Done,
            Problem
        }

        // ── 色 ──

        private static bool Pro => EditorGUIUtility.isProSkin;

        public static Color Accent => Pro ? new Color(0.30f, 0.58f, 0.93f) : new Color(0.17f, 0.42f, 0.82f);
        public static Color Warning => Pro ? new Color(0.95f, 0.68f, 0.22f) : new Color(0.78f, 0.49f, 0.04f);
        public static Color SubText => Pro ? new Color(0.62f, 0.62f, 0.62f) : new Color(0.36f, 0.36f, 0.36f);
        public static Color RowHover => Pro ? new Color(1f, 1f, 1f, 0.05f) : new Color(0f, 0f, 0f, 0.05f);
        public static Color RowSelected => new Color(Accent.r, Accent.g, Accent.b, Pro ? 0.35f : 0.25f);

        // ── スタイル（スキンが変わったら作り直す）──

        private static bool _stylesPro;
        private static GUIStyle _subtle, _warnText;

        public static GUIStyle Subtle { get { Ensure(); return _subtle; } }
        public static GUIStyle WarnText { get { Ensure(); return _warnText; } }

        private static void Ensure()
        {
            if (_subtle != null && _stylesPro == Pro) return;
            _stylesPro = Pro;

            _subtle = new GUIStyle(EditorStyles.miniLabel) { normal = { textColor = SubText }, clipping = TextClipping.Clip };
            _warnText = new GUIStyle(EditorStyles.miniLabel) { normal = { textColor = Warning }, clipping = TextClipping.Clip };
        }
    }
}
