// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/MakeFixTrialPreview.cs
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 体験版プレビューの高画質長押し確認ボタン（2048px）の表示条件・状態・文言を決める純粋ヘルパー。
    /// 通常プレビュー（512px）は斜線なし、ボタンを押し続けている間だけ 2048px（コア側で細い斜線を焼き込み）を表示する。
    /// </summary>
    public static class MakeFixTrialPreview
    {
        public const string ButtonTooltip =
            "押している間だけ 2048px の高画質（透かし入り）で細部を確認できます。離すと通常プレビュー（512px）に戻ります。";

        public readonly struct StatusInfo
        {
            public readonly string Text;
            public readonly string Tooltip;

            public StatusInfo(string text, string tooltip)
            {
                Text = text;
                Tooltip = tooltip;
            }
        }

        public static bool ShouldShowButton(CoreEdition edition, bool showPreview) =>
            edition == CoreEdition.Trial && showPreview;

        public static bool IsActive(CoreEdition edition, bool showPreview, bool held, bool comparing) =>
            edition == CoreEdition.Trial && showPreview && held && !comparing;

        public static bool ShouldUseHighResTexture(bool active, bool highReady) => active && highReady;

        public static string ButtonLabel(bool active, bool highReady)
        {
            if (!active) return $"押している間: 高画質 ({FaceMapPreview.TrialHighResolution})";
            return highReady
                ? $"高画質を表示中 ({FaceMapPreview.TrialHighResolution})"
                : "高画質を作成中…";
        }

        public static StatusInfo StatusPill(bool active, bool highReady)
        {
            int normalRes = FaceMapPreview.LowResolution;
            int highRes = FaceMapPreview.TrialHighResolution;
            if (active && highReady)
            {
                return new StatusInfo(
                    $"体験版 高画質プレビュー ({highRes})",
                    $"ボタンを押している間だけ {highRes}×{highRes}（透かし入り）で細部を表示しています。離すと通常プレビュー（{normalRes}px）に戻ります。");
            }
            if (active)
            {
                return new StatusInfo(
                    $"体験版 高画質を作成中… ({highRes})",
                    $"{highRes}×{highRes} の高画質プレビュー（透かし入り）を作成しています。");
            }
            return new StatusInfo(
                $"体験版プレビュー ({normalRes})",
                $"体験版の通常プレビュー（{normalRes}×{normalRes}）です。右下の高画質ボタンを押し続けると {highRes}×{highRes}（透かし入り）で細部を確認できます。\n" +
                "製品版はプレビューが最大 4096、メイク適用で書き出すテクスチャは元の解像度（最大 8192）です。");
        }
    }
}
