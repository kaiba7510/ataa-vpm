using System;
using System.Collections.Generic;
using System.IO;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メインウィンドウの「⑤ メイク元」の判断ロジック。UI やシーンには触れず、値だけを受け取る。
    /// （メイク基準ドロップダウンの構築・テクスチャ/基準の連動・作成ボックス展開・履歴・外部画像判定）
    /// </summary>
    public static class MakeFixMakeupSource
    {
        public const int DefaultMaxHistory = 12;
        public const string SceneChoicePrefix = "ATAA-SceneAvatar:";

        private static readonly string[] SupportedImageExtensions =
        {
            ".png", ".psd", ".jpg", ".jpeg", ".tga", ".tif", ".tiff", ".bmp", ".exr"
        };

        private static readonly string[] InMemoryImageExtensions =
        {
            ".png", ".jpg", ".jpeg"
        };

        // ── メイク基準ドロップダウン ──

        public struct MapEntry
        {
            public string Path;
            public string DisplayName;
            public string FileName;
            public bool IsDraft;
        }

        public struct SceneAvatarEntry
        {
            public string Key;
            public string Name;
        }

        public sealed class DropdownChoice
        {
            public string Label;
            /// <summary>FaceMap のパス、未選択なら null、未解析シーンアバターなら SceneChoicePrefix + Key。</summary>
            public string Value;
            public bool IsSceneAvatar;
            public string SceneAvatarKey;
            public bool IsSameAsTarget;
        }

        /// <summary>
        /// メイク基準のドロップダウン一覧を組み立てる。
        /// 先頭は「（未選択）」、通常の FaceMap → 未解析のシーン内アバター → 対象アバターと同じ FaceMap（末尾）の順。
        /// </summary>
        public static List<DropdownChoice> BuildDropdownEntries(
            IList<MapEntry> maps,
            IList<SceneAvatarEntry> unmappedSceneAvatars,
            string targetAvatarMapPath)
        {
            var result = new List<DropdownChoice>
            {
                new DropdownChoice { Label = "（未選択）", Value = null }
            };

            var usedLabels = new HashSet<string>(StringComparer.Ordinal) { "（未選択）" };
            var nameCounts = new Dictionary<string, int>(StringComparer.Ordinal);
            if (maps != null)
            {
                foreach (MapEntry m in maps)
                {
                    string key = m.DisplayName ?? "";
                    nameCounts[key] = nameCounts.TryGetValue(key, out int c) ? c + 1 : 1;
                }
            }

            var targetMaps = new List<MapEntry>();
            if (maps != null)
            {
                foreach (MapEntry m in maps)
                {
                    if (PathsEqual(m.Path, targetAvatarMapPath))
                    {
                        targetMaps.Add(m);
                        continue;
                    }
                    bool dup = nameCounts.TryGetValue(m.DisplayName ?? "", out int c) && c > 1;
                    string shown = MakeFixAutoSetup.DisplayLabel(m.DisplayName ?? "", m.IsDraft);
                    string raw = (dup ? $"{shown} ({m.FileName})" : shown).Replace('/', '／');
                    result.Add(new DropdownChoice
                    {
                        Label = MakeUniqueLabel(raw, usedLabels),
                        Value = m.Path,
                    });
                }
            }

            if (unmappedSceneAvatars != null)
            {
                foreach (SceneAvatarEntry av in unmappedSceneAvatars)
                {
                    if (string.IsNullOrEmpty(av.Key)) continue;
                    string raw = ((av.Name ?? "Avatar") + "（選ぶと自動作成）").Replace('/', '／');
                    result.Add(new DropdownChoice
                    {
                        Label = MakeUniqueLabel(raw, usedLabels),
                        Value = SceneChoicePrefix + av.Key,
                        IsSceneAvatar = true,
                        SceneAvatarKey = av.Key,
                    });
                }
            }

            foreach (MapEntry m in targetMaps)
            {
                bool dup = nameCounts.TryGetValue(m.DisplayName ?? "", out int c) && c > 1;
                string suffix = m.IsDraft ? "（自動・対象と同じ）" : "（対象と同じ）";
                string shown = (m.DisplayName ?? "") + suffix;
                string raw = (dup ? $"{shown} ({m.FileName})" : shown).Replace('/', '／');
                result.Add(new DropdownChoice
                {
                    Label = MakeUniqueLabel(raw, usedLabels),
                    Value = m.Path,
                    IsSameAsTarget = true,
                });
            }

            return result;
        }

        private static string MakeUniqueLabel(string baseLabel, HashSet<string> used)
        {
            string label = baseLabel;
            int suffix = 2;
            while (!used.Add(label)) label = $"{baseLabel} [{suffix++}]";
            return label;
        }

        public static bool PathsEqual(string a, string b)
        {
            if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b)) return false;
            return string.Equals(a.Replace('\\', '/'), b.Replace('\\', '/'), StringComparison.OrdinalIgnoreCase);
        }

        // ── テクスチャ選択時のメイク基準解決 ──

        public enum MapResolutionKind
        {
            /// <summary>確実な紐づけが無い。今選んでいるメイク基準を維持する（色違い PNG 試着など）。</summary>
            KeepCurrent,
            /// <summary>既存の FaceMap（シーン一致・過去記憶）へ切り替える。</summary>
            SelectMap,
            /// <summary>シーン内の未解析アバターに一致したため、そのアバターから自動生成して選ぶ。</summary>
            GenerateForSceneAvatar,
        }

        public struct MapResolution
        {
            public MapResolutionKind Kind;
            public string MapPath;
            public string SceneAvatarKey;
        }

        /// <summary>
        /// メイクテクスチャが選ばれたとき、100% 確実な紐づけ（シーン内アバター参照一致・過去使用履歴）から
        /// メイク基準をどうするか決める。ファイル名からの推測は行わない。
        /// </summary>
        public static MapResolution ResolveMapOnTextureChanged(
            string currentMapPath,
            string sceneMatchedMapPath,
            string sceneMatchedAvatarKey,
            string rememberedMapPath)
        {
            if (!string.IsNullOrEmpty(sceneMatchedMapPath))
            {
                return new MapResolution { Kind = MapResolutionKind.SelectMap, MapPath = sceneMatchedMapPath };
            }
            if (!string.IsNullOrEmpty(sceneMatchedAvatarKey))
            {
                return new MapResolution { Kind = MapResolutionKind.GenerateForSceneAvatar, SceneAvatarKey = sceneMatchedAvatarKey };
            }
            if (!string.IsNullOrEmpty(rememberedMapPath))
            {
                return new MapResolution { Kind = MapResolutionKind.SelectMap, MapPath = rememberedMapPath };
            }
            return new MapResolution { Kind = MapResolutionKind.KeepCurrent, MapPath = currentMapPath };
        }

        // ── メイク基準変更時のメイクテクスチャ補完 ──

        /// <summary>
        /// メイク基準を選んだときに自動補完するメイクテクスチャの GUID。
        /// すでにテクスチャが入っている場合は勝手に上書きせず null を返す。
        /// 未選択のときだけ「ペア記憶 → 基準単体の直近メイク → 基準の顔テクスチャ」の順で補完する。
        /// </summary>
        /// <summary>
        /// メイク基準を選んだときに自動補完するメイクテクスチャ GUID の候補一覧（優先順・重複なし）。
        /// すでにテクスチャが入っている場合は空リストを返す。
        /// </summary>
        public static List<string> FallbackTextureGuids(
            bool hasCurrentTexture,
            string pairMemoryGuid,
            string mapMemoryGuid,
            string faceHintGuid)
        {
            var result = new List<string>(3);
            if (hasCurrentTexture) return result;
            void Add(string guid)
            {
                if (!string.IsNullOrEmpty(guid) && !result.Contains(guid)) result.Add(guid);
            }
            Add(pairMemoryGuid);
            Add(mapMemoryGuid);
            Add(faceHintGuid);
            return result;
        }

        public static string PickFallbackTextureGuid(
            bool hasCurrentTexture,
            string pairMemoryGuid,
            string mapMemoryGuid,
            string faceHintGuid)
        {
            List<string> guids = FallbackTextureGuids(hasCurrentTexture, pairMemoryGuid, mapMemoryGuid, faceHintGuid);
            return guids.Count > 0 ? guids[0] : null;
        }

        // ── 作成ボックスの段階的開示・文言 ──

        /// <summary>基準が未選択のとき（または右上メニューから明示的に開いたとき）だけ作成ボックスを出す。</summary>
        public static bool ShouldShowCreateBox(bool hasMakeupFaceMap, bool manualOpen) =>
            !hasMakeupFaceMap || manualOpen;

        public static string ManualCreateButtonLabel(bool hasMakeupTexture) =>
            hasMakeupTexture ? "この画像で手動作成" : "画像から手動作成";

        // ── 最近使ったメイク履歴 ──

        public static List<string> RecordHistory(IList<string> current, string newGuid, int maxCount = DefaultMaxHistory)
        {
            var result = new List<string>();
            if (!string.IsNullOrWhiteSpace(newGuid)) result.Add(newGuid.Trim());
            if (current != null)
            {
                foreach (string g in current)
                {
                    if (string.IsNullOrWhiteSpace(g)) continue;
                    string trimmed = g.Trim();
                    if (!result.Contains(trimmed)) result.Add(trimmed);
                }
            }
            if (maxCount > 0 && result.Count > maxCount) result.RemoveRange(maxCount, result.Count - maxCount);
            return result;
        }

        public static List<string> ParseHistory(string raw)
        {
            var result = new List<string>();
            if (string.IsNullOrEmpty(raw)) return result;
            foreach (string part in raw.Split('|'))
            {
                if (string.IsNullOrWhiteSpace(part)) continue;
                string trimmed = part.Trim();
                if (!result.Contains(trimmed)) result.Add(trimmed);
            }
            return result;
        }

        public static string FormatHistory(IList<string> guids)
        {
            if (guids == null || guids.Count == 0) return "";
            var valid = new List<string>();
            foreach (string g in guids)
            {
                if (!string.IsNullOrWhiteSpace(g)) valid.Add(g.Trim());
            }
            return string.Join("|", valid);
        }

        // ── 画像拡張子・外部ファイルインポート判定 ──

        public static bool IsSupportedImageExtension(string path) => HasExtension(path, SupportedImageExtensions);

        /// <summary>Texture2D.LoadImage でメモリ上だけに読み込める形式（体験版の外部画像用）。</summary>
        public static bool CanLoadInMemory(string path) => HasExtension(path, InMemoryImageExtensions);

        private static bool HasExtension(string path, string[] allowed)
        {
            if (string.IsNullOrWhiteSpace(path)) return false;
            string ext = Path.GetExtension(path);
            if (string.IsNullOrEmpty(ext)) return false;
            for (int i = 0; i < allowed.Length; i++)
            {
                if (string.Equals(ext, allowed[i], StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        /// <summary>ATAA が生成した出力フォルダ（FaceMaps/Generated/ 配下）のアセットパスか。</summary>
        public static bool IsGeneratedAssetPath(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath)) return false;
            return assetPath.Replace('\\', '/').IndexOf("/FaceMaps/Generated/", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>filePath が folderPath の配下にあるか（区切り文字と大小の違いを吸収し、ディレクトリ境界も確認）。</summary>
        public static bool IsUnderFolder(string filePath, string folderPath)
        {
            if (string.IsNullOrWhiteSpace(filePath) || string.IsNullOrWhiteSpace(folderPath)) return false;
            string file = filePath.Replace('\\', '/');
            string folder = folderPath.Replace('\\', '/').TrimEnd('/') + "/";
            return file.StartsWith(folder, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>同名ファイルが既にあるときは「名前 (2).ext」…のように衝突しないファイル名を返す。</summary>
        public static string NextAvailableFileName(string desiredFileName, Func<string, bool> exists)
        {
            if (string.IsNullOrWhiteSpace(desiredFileName)) return "makeup.png";
            if (exists == null || !exists(desiredFileName)) return desiredFileName;

            string stem = Path.GetFileNameWithoutExtension(desiredFileName);
            string ext = Path.GetExtension(desiredFileName);
            for (int n = 2; n < 10000; n++)
            {
                string candidate = $"{stem} ({n}){ext}";
                if (!exists(candidate)) return candidate;
            }
            return desiredFileName;
        }
    }
}
