using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 仕上げカード（メイクの濃さ・肌色合わせ・合成範囲）の「調整済み」の判定と「自動に戻す」。
    /// 位置・大きさ・目や口の調整・パーツの ON/OFF には触れない。
    /// </summary>
    public static class MakeFixFinish
    {
        public static bool IsAdjusted(FaceMapAdjustment adj, float opacity)
        {
            if (adj == null) return false;
            return !Mathf.Approximately(opacity, MyVrcToolState.DefaultPreviewMakeupOpacity) ||
                   !adj.MatchSkinTone ||
                   !Mathf.Approximately(adj.MaskMargin, FaceMapAdjustment.DefaultMaskMargin) ||
                   !Mathf.Approximately(adj.MaskFeather, FaceMapAdjustment.DefaultMaskFeather) ||
                   !Mathf.Approximately(adj.ExcludeFeather, FaceMapAdjustment.DefaultExcludeFeather);
        }

        public static void Reset(FaceMapAdjustment adj, ref float opacity)
        {
            opacity = MyVrcToolState.DefaultPreviewMakeupOpacity;
            if (adj == null) return;
            adj.MatchSkinTone = true;
            adj.MaskMargin = FaceMapAdjustment.DefaultMaskMargin;
            adj.MaskFeather = FaceMapAdjustment.DefaultMaskFeather;
            adj.ExcludeFeather = FaceMapAdjustment.DefaultExcludeFeather;
        }
    }
}
