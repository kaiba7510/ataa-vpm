namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 元に戻す 1 回分のまとめ方。操作中（ドラッグ・スライダー・押し続け）の変更は、同じ操作の間 1 回にまとめる。
    /// 操作が終わったら（EndGesture）次の変更は別の 1 回。操作中でない変更は毎回別の 1 回。
    /// </summary>
    public class MakeFixHistoryMerge
    {
        private bool _gestureOpen;

        /// <summary>変更を記録するときに呼ぶ。前の変更にまとめるなら true。</summary>
        public bool Next(bool interacting)
        {
            bool merge = interacting && _gestureOpen;
            _gestureOpen = interacting;
            return merge;
        }

        /// <summary>操作（ドラッグなど）が終わったときに呼ぶ。</summary>
        public void EndGesture() => _gestureOpen = false;

        public void Reset() => _gestureOpen = false;
    }
}
