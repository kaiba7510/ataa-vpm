namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 手順が途中で止まっている（ユーザーの設定待ち）とき、次に設定が必要なカードを点滅させる判定。
    /// </summary>
    public static class MakeFixAttentionBlink
    {
        /// <summary>点滅の周期（秒）。明 0.6 秒 → 暗 0.6 秒。</summary>
        public const double HalfPeriodSeconds = 0.6;

        /// <summary>次にやるカードで、準備が終わっておらず、処理中でもないときだけ点滅する。</summary>
        public static bool ShouldBlink(bool isCurrentCard, bool allOk, bool busy) =>
            isCurrentCard && !allOk && !busy;

        /// <summary>経過時間から、点滅の「明」の側かどうか。</summary>
        public static bool IsBright(double seconds) =>
            (long)(seconds / HalfPeriodSeconds) % 2 == 0;
    }
}
