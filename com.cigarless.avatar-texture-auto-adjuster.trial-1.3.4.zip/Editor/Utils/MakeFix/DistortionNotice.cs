// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/DistortionNotice.cs
using System;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 「パーツの周りで変形が折り返しています」の警告を出すかどうかの判断。
    /// 調整なしでも、顔の組み合わせの違いで数十〜数百セルの裏返りが残る素体が多い（Chocolat 344・Kipfel 88〜228・Moko 22〜62）。
    /// 残った数そのもので出すとほぼ毎回出て意味がなくなるので、利用者の調整で増えた分だけで判断する。
    /// </summary>
    internal static class DistortionNotice
    {
        /// <summary>
        /// 調整で増えた裏返りのセル数（減ったときは 0）。baseline は調整なしのときに残る数。
        /// 基準が分からないとき（null）は、残った数をそのまま増えた数として扱う。
        /// </summary>
        public static int Increase(int remaining, int? baseline) =>
            Math.Max(0, remaining - (baseline ?? 0));

        /// <summary>調整で増えた裏返りが、目に見えるほど（NegligibleInvertedCells を超えて）あるか。</summary>
        public static bool HasVisibleIncrease(int remaining, int? baseline) =>
            Increase(remaining, baseline) > DistortionReport.NegligibleInvertedCells;
    }
}
