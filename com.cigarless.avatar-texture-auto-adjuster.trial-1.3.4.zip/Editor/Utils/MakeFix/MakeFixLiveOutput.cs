namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// プレビューの合成結果を、今の組み合わせ（メイク元 × アバター基準）の結果として出してよいか。
    /// 合成は非同期なので、アバターを切り替えた直後は前のアバターの基準で作った結果が残っている。
    /// 顔テクスチャが同じアバター同士だとテクスチャの一致だけでは見分けられず、新しいアバターに一瞬ずれて映っていた。
    /// </summary>
    public static class MakeFixLiveOutput
    {
        /// <summary>
        /// 合成結果を見分けるキー（FaceMap のファイルの組み合わせ）。更新日時は含めない
        /// （同じ組み合わせで中身だけ書き直したときは、作り直すまで前の結果を出し続けてちらつかせない）。
        /// どちらかが未選択なら null。
        /// </summary>
        public static string Key(string makeupFaceMapPath, string avatarFaceMapPath)
        {
            if (string.IsNullOrEmpty(makeupFaceMapPath) || string.IsNullOrEmpty(avatarFaceMapPath)) return null;
            return makeupFaceMapPath + "|" + avatarFaceMapPath;
        }

        /// <param name="hasOutput">合成結果がある。</param>
        /// <param name="sourceMatches">合成に使った顔テクスチャが、今選んでいる顔テクスチャと同じ。</param>
        /// <param name="outputKey">合成結果を作ったときの <see cref="Key"/>。</param>
        /// <param name="currentKey">今の <see cref="Key"/>。</param>
        public static bool IsReady(bool hasOutput, bool sourceMatches, string outputKey, string currentKey)
        {
            return hasOutput && sourceMatches && outputKey != null && outputKey == currentKey;
        }

        /// <summary>
        /// 適用を解除したときに「調整を表示」を OFF にするべきか。
        /// プレビュー表示中に解除したときだけ OFF にして元の見た目へ戻す（未表示状態の解除では OFF にしない）。
        /// </summary>
        public static bool ShouldDisableLiveOnRevert(int revertedSlots, bool liveEnabled, bool hadLivePreview)
        {
            return revertedSlots > 0 && liveEnabled && hadLivePreview;
        }
    }
}
