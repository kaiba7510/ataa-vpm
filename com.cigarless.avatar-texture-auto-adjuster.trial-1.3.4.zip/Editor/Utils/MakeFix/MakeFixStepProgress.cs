namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 右パネル上部の「ステップ N / 6」見出しと進捗バーの表示。UI の状態は読まない（値だけを受け取る）。
    /// </summary>
    public static class MakeFixStepProgress
    {
        public static string Kicker(int done, int total, bool allOk) =>
            allOk ? "準備完了" : $"ステップ {done} / {total}";

        /// <summary>進捗バーの幅（0〜100 %）。</summary>
        public static float FillPercent(int done, int total)
        {
            if (total <= 0) return 0f;
            float p = (float)done / total * 100f;
            return p < 0f ? 0f : p > 100f ? 100f : p;
        }
    }
}
