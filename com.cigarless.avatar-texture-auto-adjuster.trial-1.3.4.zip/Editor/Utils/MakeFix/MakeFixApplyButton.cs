namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 「メイク適用」ボタンの表示（押せるか・文言・ツールチップ）。
    /// 再生モード中（一時停止を含む）は押せない: 一時停止中は非同期の待ちが進まず、
    /// また再生モードでのマテリアル変更は再生を止めると元に戻るため。理由はボタン自体に出す。
    /// </summary>
    public static class MakeFixApplyButton
    {
        public const string ReadyLabel = "メイク適用";
        public const string ApplyingLabel = "適用中...";
        public const string PlayModeLabel = "再生中は適用できません";

        public readonly struct State
        {
            public readonly bool Enabled;
            public readonly string Label;
            public readonly string Tooltip;

            public State(bool enabled, string label, string tooltip)
            {
                Enabled = enabled;
                Label = label;
                Tooltip = tooltip;
            }
        }

        public static State Evaluate(bool allOk, bool applying, bool isPlaying, string firstFailedMessage)
        {
            if (applying)
                return new State(false, ApplyingLabel, "合成して、顔のマテリアルに適用しています。");
            if (isPlaying)
                return new State(false, PlayModeLabel,
                    "再生モード中（一時停止を含む）は適用できません。再生を止めてから「メイク適用」を押してください。");
            if (!allOk)
                return new State(false, ReadyLabel, firstFailedMessage ?? "");
            return new State(true, ReadyLabel, "合成したテクスチャを作り、顔のマテリアルに適用します。");
        }
    }
}
