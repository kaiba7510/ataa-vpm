namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メイクフィックス画面が「操作中」か（ドラッグ・スクラブ中は低解像度プレビュー＆保存を遅らせる）。
    /// EditorApplication.update からも呼ぶので、GUIUtility.hotControl などの IMGUI の状態は読まない
    /// （IMGUI の外で読むと「the GUIStateObj is deleted, but is accessed」が毎フレーム出る）。
    /// </summary>
    public static class MakeFixInteraction
    {
        public static bool IsInteracting(bool previewDragging, bool panning, bool orbitDragging, bool uiScrubbing)
        {
            return previewDragging || panning || orbitDragging || uiScrubbing;
        }
    }
}
