// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/SkinToneNotice.cs
using System.Globalization;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 「肌色を合わせる」の下に出す状態の 1 行（統合仕様書 §6.6）。合わせていないときは理由と直し方を出す。
    /// 重ねるだけのメイクで、メイク元 FaceMap の顔テクスチャがメイクそのものだと、何も出ずに合わせが飛ばされ、
    /// 「効いている感じがしない」になった（sinano ← make only.png）。
    /// </summary>
    internal static class SkinToneNotice
    {
        internal readonly struct Line
        {
            public readonly bool IsWarning;
            public readonly string Text;
            public readonly string Tooltip;

            public Line(bool isWarning, string text, string tooltip)
            {
                IsWarning = isWarning;
                Text = text;
                Tooltip = tooltip;
            }
        }

        /// <summary>比のずれ（どのチャンネルも）がこれ未満なら、見た目はほとんど変わらないと添える。</summary>
        public const float NoticeableRatio = 0.03f;

        private const string HowItWorks = "メイクの色に「対象の肌色 ÷ メイク元の素体の肌色」の比を掛けてから重ねます（肌の浮きを防ぐ）。";

        /// <summary>
        /// 状態の 1 行。合わせない設定（Off）なら null。
        /// tint は掛けた比（AtaaCore.EvaluateSkinTone）、lookup・faceTextureName はメイク元 FaceMap の顔テクスチャの状態と名前。
        /// </summary>
        public static Line? Describe(SkinToneStatus status, Color tint, BaseSkinLookup lookup, string faceTextureName)
        {
            switch (status)
            {
                case SkinToneStatus.Off:
                    return null;
                case SkinToneStatus.Matched:
                {
                    string ratio = Ratio(tint);
                    bool small = Mathf.Abs(tint.r - 1f) < NoticeableRatio && Mathf.Abs(tint.g - 1f) < NoticeableRatio &&
                                 Mathf.Abs(tint.b - 1f) < NoticeableRatio;
                    string text = small
                        ? $"肌色を合わせています（{ratio}）。肌色の差が小さいため、見た目はほとんど変わりません"
                        : $"対象の肌色に合わせています（{ratio}）";
                    return new Line(false, text, HowItWorks);
                }
                case SkinToneStatus.SameSkin:
                    return new Line(false, "メイク元と対象の肌色がほぼ同じため、色は変えていません", HowItWorks);
                case SkinToneStatus.NoAvatarSkin:
                    return new Line(true, "対象の顔テクスチャから肌色を測れないため、肌色を合わせていません",
                        "対象の顔テクスチャの、パーツの外の顔の範囲に不透明な画素がありません。\n" + HowItWorks);
                default:
                    return new Line(true, NoMakeupSkinText(lookup, Quoted(faceTextureName)), NoMakeupSkinTooltip);
            }
        }

        private static string NoMakeupSkinText(BaseSkinLookup lookup, string name)
        {
            const string tail = "肌色を合わせていません";
            switch (lookup)
            {
                case BaseSkinLookup.SameAsMakeup:
                    return $"メイク元 FaceMap の顔テクスチャ{name}がメイクそのもので、素体の肌色がわからないため、{tail}";
                case BaseSkinLookup.NotRecorded:
                    return $"メイク元 FaceMap に顔テクスチャが記録されていないため、{tail}";
                case BaseSkinLookup.Missing:
                    return $"メイク元 FaceMap の顔テクスチャ{name}がプロジェクトに無いため、{tail}";
                case BaseSkinLookup.Unreadable:
                    return $"メイク元 FaceMap の顔テクスチャ{name}が大きすぎて読めないため、{tail}";
                case BaseSkinLookup.NoOpaqueSkin:
                    return $"メイク元 FaceMap の顔テクスチャ{name}に不透明な肌が無いため、{tail}";
                default:
                    return $"メイク元の素体の肌色がわからないため、{tail}";
            }
        }

        private const string NoMakeupSkinTooltip =
            "このメイクは肌の部分が透明な「重ねるだけ」のメイクなので、メイク元の素体の肌色を、" +
            "メイク元 FaceMap に記録された顔テクスチャから測ります。\n" +
            "メイク元の素体の顔テクスチャ（メイクを塗る前のもの）を FaceMap エディターで開き、メイク元 FaceMap を保存し直すと記録されます。\n" +
            HowItWorks;

        private static string Quoted(string name) => string.IsNullOrEmpty(name) ? "" : $"「{name}」";

        private static string Ratio(Color tint) =>
            string.Format(CultureInfo.InvariantCulture, "R×{0:0.00} G×{1:0.00} B×{2:0.00}", tint.r, tint.g, tint.b);
    }
}
