using System.IO;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 「場所を表示」を押したときにウィンドウ内へ出す知らせの文言。
    /// Project ウィンドウでの選択だけでは、押せたのか・見つからなかったのかがツール側から分からない。
    /// </summary>
    public static class MakeFixLocateFeedback
    {
        public static string Message(string assetPath, bool found)
        {
            if (string.IsNullOrEmpty(assetPath)) return "生成したテクスチャの場所が分かりません";
            string name = Path.GetFileName(assetPath);
            return found
                ? $"Project ウィンドウで「{name}」を選択しました"
                : $"「{name}」が見つかりません（移動または削除された可能性があります）";
        }
    }
}
