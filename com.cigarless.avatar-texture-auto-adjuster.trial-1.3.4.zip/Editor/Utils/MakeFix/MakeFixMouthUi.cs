using System.Globalization;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メイン画面「口の調整」カードの表示文言・パーセント表記・バイポーラスライダーの塗り範囲計算。
    /// </summary>
    public static class MakeFixMouthUi
    {
        public const string CardTooltip =
            "この組み合わせだけの調整です。アバター基準（FaceMap）は変わりません。";

        public const string ResetAllTooltip =
            "口角の上下・中央の折れを 0% に戻します（口の位置・大きさは変わりません）。";

        public const string BendLabel = "口角の上下（弧）";
        public const string BendTooltip =
            "口の両端（口角）を上下して、唇全体をゆるい弧に曲げます（左で下がる ⌒・右で上がる ‿。0% = まっすぐ）。口の真ん中は動きません。";

        public const string FoldLabel = "中央の折れ（v / ^）";
        public const string FoldTooltip =
            "唇の合わせ目の真ん中だけを上下して v / ^ に折ります（左で下がる v・右で上がる ^。0% = 折らない）。唇の厚みが中央で伸び縮みし、口の両端と枠の上下は動きません。";

        public const string FoldUnavailableText =
            "中央の折れは、メイク元と対象の両方の FaceMap に口の線があるときだけ使えます。";

        public readonly struct BipolarFill
        {
            public readonly float LeftPercent;
            public readonly float WidthPercent;

            public BipolarFill(float leftPercent, float widthPercent)
            {
                LeftPercent = leftPercent;
                WidthPercent = widthPercent;
            }
        }

        /// <summary>0 から離れているか（FaceMapAdjustment.HasMouthAdjustment と同じ判定）。</summary>
        public static bool IsNonZero(float value) => !Mathf.Approximately(value, 0f);

        /// <summary>最大絶対値に対する割合を符号付きパーセント表記にする（-100% 〜 +100%、0 は "0%"）。</summary>
        public static string FormatPercent(float value, float maxAbs)
        {
            if (maxAbs <= 0f || float.IsNaN(value) || float.IsInfinity(value)) return "0%";
            float ratio = Mathf.Clamp(value / maxAbs, -1f, 1f);
            int pct = Mathf.RoundToInt(ratio * 100f);
            if (pct == 0) return "0%";
            return pct > 0
                ? "+" + pct.ToString(CultureInfo.InvariantCulture) + "%"
                : pct.ToString(CultureInfo.InvariantCulture) + "%";
        }

        /// <summary>値ラベルのツールチップ用（従来の内部比率と範囲を確認したいとき用）。</summary>
        public static string FormatRawTooltip(float value, float maxAbs)
        {
            float v = Mathf.Approximately(value, 0f) ? 0f : value;
            string sign = v > 0f ? "+" : "";
            return string.Format(
                CultureInfo.InvariantCulture,
                "現在値: {0}{1:0.000}（範囲 -{2:0.000} 〜 +{2:0.000}）",
                sign, v, Mathf.Max(0f, maxAbs));
        }

        /// <summary>バイポーラスライダーの中央（50%）から左右へ伸ばす塗りバーの位置と幅（%）。</summary>
        public static BipolarFill ComputeBipolarFill(float value, float maxAbs)
        {
            if (maxAbs <= 0f || float.IsNaN(value) || float.IsInfinity(value))
                return new BipolarFill(50f, 0f);

            float ratio = Mathf.Clamp(value / maxAbs, -1f, 1f);
            float width = Mathf.Abs(ratio) * 50f;
            if (width < 1e-4f) return new BipolarFill(50f, 0f);

            return ratio >= 0f
                ? new BipolarFill(50f, width)
                : new BipolarFill(50f - width, width);
        }
    }
}
