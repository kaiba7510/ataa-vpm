using System.Collections.Generic;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メインウィンドウの「自動セットアップ」の判断。UI やシーンは読まず、値だけを受け取る。
    /// （②〜④カードの展開・1 体時の自動選択・一括生成の対象と順番・顔メッシュ変更時の再生成・表記）
    /// </summary>
    public static class MakeFixAutoSetup
    {
        /// <summary>左ペイン②〜④カードを開く理由になる状態。</summary>
        public struct CardState
        {
            /// <summary>「おかしい場合は手動変更」を開いている。</summary>
            public bool ManualOpen;
            /// <summary>ヘッダーの「あと N ステップ」から左ペインへ飛んできた。</summary>
            public bool FocusJump;
            /// <summary>顔メッシュ未設定・自動生成に失敗した。</summary>
            public bool FaceMeshMissing;
            /// <summary>目の線の要確認（EyeLineIssue）。</summary>
            public bool EyeLineIssue;
            /// <summary>アバター基準が未設定。</summary>
            public bool BaseMissing;
            /// <summary>アバター基準に警告がある。</summary>
            public bool BaseWarning;
            /// <summary>顔テクスチャ未設定・アバターで使われていない。</summary>
            public bool FaceTextureProblem;
        }

        /// <summary>1 つでも当てはまれば②〜④をまとめて開く。全部正常で手動でも開いていなければサマリーだけ。</summary>
        public static bool ShouldExpandCards(CardState s) =>
            s.ManualOpen || s.FocusJump || s.FaceMeshMissing || s.EyeLineIssue
            || s.BaseMissing || s.BaseWarning || s.FaceTextureProblem;

        /// <summary>未選択でアクティブなアバターがちょうど 1 体なら、それを自動で選ぶ。</summary>
        public static bool ShouldAutoSelectSingle(int activeCount, bool hasSelection) =>
            !hasSelection && activeCount == 1;

        /// <summary>一括生成の候補 1 体分。</summary>
        public struct Candidate
        {
            public string Key;
            public bool Active;
            /// <summary>保存済みの既存 FaceMap がある（上書きしない）。</summary>
            public bool HasSavedFaceMap;
            /// <summary>解析済み（自動生成済み・失敗の記録あり）。</summary>
            public bool Analyzed;
        }

        /// <summary>
        /// 生成する順番（Key）。対象は「アクティブ・既存 FaceMap なし・未解析」。
        /// 選択中のアバターは非アクティブでも対象にして先頭へ置く（オンデマンド）。
        /// </summary>
        public static List<string> BuildQueue(IList<Candidate> candidates, string selectedKey)
        {
            var queue = new List<string>();
            if (candidates == null) return queue;

            string first = null;
            foreach (Candidate c in candidates)
            {
                if (c.HasSavedFaceMap || c.Analyzed) continue;
                bool isSelected = selectedKey != null && c.Key == selectedKey;
                if (isSelected) { first = c.Key; continue; }
                if (c.Active) queue.Add(c.Key);
            }
            if (first != null) queue.Insert(0, first);
            return queue;
        }

        public enum MeshChangeAction
        {
            /// <summary>何もしない（基準が無い）。</summary>
            None,
            /// <summary>基準とテクスチャを自動で作り直す（一時生成の基準だけ）。</summary>
            Regenerate,
            /// <summary>保存済みの基準は上書きせず、「このメッシュで自動生成し直す」案内を出す。</summary>
            Offer,
        }

        /// <summary>②で顔メッシュを選び直したときの動き。</summary>
        public static MeshChangeAction OnFaceMeshChanged(bool hasBase, bool baseIsDraft)
        {
            if (!hasBase) return MeshChangeAction.None;
            return baseIsDraft ? MeshChangeAction.Regenerate : MeshChangeAction.Offer;
        }

        public enum AvatarStatus
        {
            /// <summary>灰: 未解析。</summary>
            Unknown,
            /// <summary>緑: 準備 OK。</summary>
            Ready,
            /// <summary>橙: 要確認（自動認識の失敗・目の線・基準の警告）。</summary>
            NeedsCheck,
        }

        /// <summary>アバター一覧の状態ドット。problem は目の線の要確認・基準の警告など。</summary>
        public static AvatarStatus StatusOf(bool hasMap, bool analyzed, bool problem)
        {
            if (problem) return AvatarStatus.NeedsCheck;
            if (hasMap) return AvatarStatus.Ready;
            return analyzed ? AvatarStatus.NeedsCheck : AvatarStatus.Unknown;
        }

        /// <summary>ドロップダウンの名前。一時生成なら「（自動）」を付ける。</summary>
        public static string DisplayLabel(string name, bool isDraft) => isDraft ? name + "（自動）" : name;

        /// <summary>左ペイン上部の解析進行表示。対象が無ければ空。</summary>
        public static string ProgressText(int done, int total) =>
            total <= 0 ? "" : $"自動解析中 {done}/{total}...";
    }
}
