using System.Collections.Generic;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// ツールの置き場所。.unitypackage 版は Assets/Cigarless/AvatarTextureAutoAdjuster、
    /// VPM（VCC）版は Packages/&lt;パッケージ名&gt;（本リリースと体験版で名前が違う）。
    /// パッケージ名は tools~/release/build_release.py の VPM_PACKAGE_NAMES と同じにする。
    /// </summary>
    public static class PackageLocation
    {
        public const string PackageName = "com.cigarless.avatar-texture-auto-adjuster";
        public const string TrialPackageName = PackageName + ".trial";
        public const string LegacyRoot = "Assets/Cigarless/AvatarTextureAutoAdjuster";
        public const string UiFolder = "Editor/Windows/UI";

        /// <summary>
        /// ツールのルートの候補を、試す順に返す。detectedRoot（実際に入っている場所。分からなければ null）を先頭に、
        /// 次に VPM の本リリース・体験版、最後に旧 Assets の場所。重複は除く。
        /// </summary>
        public static string[] CandidateRoots(string detectedRoot)
        {
            var roots = new List<string>();
            void Add(string root)
            {
                if (string.IsNullOrEmpty(root)) return;
                root = root.Replace('\\', '/').TrimEnd('/');
                if (root.Length > 0 && !roots.Contains(root)) roots.Add(root);
            }
            Add(detectedRoot);
            Add("Packages/" + PackageName);
            Add("Packages/" + TrialPackageName);
            Add(LegacyRoot);
            return roots.ToArray();
        }

        /// <summary>UI Toolkit の画面ファイル（例 MakeFixWindow.uxml）を探すパスの候補。</summary>
        public static string[] UiAssetCandidates(string fileName, string detectedRoot)
        {
            string[] roots = CandidateRoots(detectedRoot);
            var paths = new string[roots.Length];
            for (int i = 0; i < roots.Length; i++) paths[i] = roots[i] + "/" + UiFolder + "/" + fileName;
            return paths;
        }

        /// <summary>
        /// 以前の版が FaceMaps を置いていた場所の候補（今のツールのルートの下と、旧 Assets の場所）。
        /// VPM へ移るとき VCC はツールのファイルだけを消し、旧フォルダの FaceMaps は残すので、そこからも移す。
        /// </summary>
        public static string[] LegacyFaceMapFolders(string toolRoot)
        {
            var folders = new List<string>();
            foreach (string root in new[] { toolRoot, LegacyRoot })
            {
                if (string.IsNullOrEmpty(root)) continue;
                string path = root.Replace('\\', '/').TrimEnd('/') + "/FaceMaps";
                if (!folders.Contains(path)) folders.Add(path);
            }
            return folders.ToArray();
        }

        /// <summary>VPM（Packages/ の下）で入っているか。</summary>
        public static bool IsVpmRoot(string root) =>
            !string.IsNullOrEmpty(root) && root.Replace('\\', '/').StartsWith("Packages/");
    }
}
