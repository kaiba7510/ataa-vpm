using System;
using System.Collections.Concurrent;
using System.Threading;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// EditorApplication.update で回す同期コンテキスト。
    /// Unity 標準の UnitySynchronizationContext はプレイヤーループで処理されるため、編集モードでエディターが
    /// アイドルの間は回らないことがあり、await の続きが実行されずに止まる（「メイク適用」が「適用中...」のまま終わらなかった）。
    /// メインスレッドで続きを受け取りたい非同期処理は、<see cref="Enter"/> の中で開始する。
    /// </summary>
    public sealed class EditorMainThreadContext : SynchronizationContext
    {
        /// <summary>EditorApplication.update で回る既定のインスタンス。</summary>
        public static EditorMainThreadContext Instance { get; } = new EditorMainThreadContext();

        /// <summary>既定のインスタンスが EditorApplication.update に登録されているか。</summary>
        public static bool IsPumpRegistered { get; private set; }

        [InitializeOnLoadMethod]
        private static void RegisterPump()
        {
            EditorApplication.update -= PumpInstance;
            EditorApplication.update += PumpInstance;
            IsPumpRegistered = true;
        }

        private static void PumpInstance() => Instance.Pump();

        private readonly ConcurrentQueue<(SendOrPostCallback callback, object state)> _queue =
            new ConcurrentQueue<(SendOrPostCallback, object)>();

        public override void Post(SendOrPostCallback d, object state)
        {
            if (d == null) throw new ArgumentNullException(nameof(d));
            _queue.Enqueue((d, state));
        }

        public override void Send(SendOrPostCallback d, object state)
        {
            // メインスレッド以外から同期実行を待つと、Pump がメインスレッドなのでデッドロックし得る。使わない
            throw new NotSupportedException("EditorMainThreadContext は Send をサポートしません。Post を使ってください。");
        }

        public override SynchronizationContext CreateCopy() => this;

        /// <summary>
        /// 積まれている処理を実行する（メインスレッドから呼ぶ）。実行中に積まれた処理は次回に回す（無限ループしない）。
        /// 実行した件数を返す。
        /// </summary>
        public int Pump()
        {
            int count = _queue.Count;
            if (count == 0) return 0;

            SynchronizationContext prior = Current;
            SetSynchronizationContext(this);
            int ran = 0;
            try
            {
                for (int i = 0; i < count && _queue.TryDequeue(out var item); i++)
                {
                    ran++;
                    try
                    {
                        item.callback(item.state);
                    }
                    catch (Exception ex)
                    {
                        Debug.LogException(ex);
                    }
                }
            }
            finally
            {
                SetSynchronizationContext(prior);
            }
            return ran;
        }

        /// <summary>このコンテキストを Current にし、Dispose で元に戻す。この中で始めた await の続きは Pump で実行される。</summary>
        public IDisposable Enter() => new Scope(this);

        private sealed class Scope : IDisposable
        {
            private readonly SynchronizationContext _prior;
            private bool _disposed;

            public Scope(SynchronizationContext context)
            {
                _prior = Current;
                SetSynchronizationContext(context);
            }

            public void Dispose()
            {
                if (_disposed) return;
                _disposed = true;
                SetSynchronizationContext(_prior);
            }
        }
    }
}
