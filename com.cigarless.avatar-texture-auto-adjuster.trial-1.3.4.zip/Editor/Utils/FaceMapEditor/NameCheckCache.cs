// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/NameCheckCache.cs
using System;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// <see cref="NameInputDialog"/> の確かめ結果を、入力が変わるまで使い回す。
    /// OnGUI は描画・マウス移動・キー入力のたびに何度も呼ばれる。そのたびにファイル名の整形とファイルの有無の確認を
    /// 走らせると、名前の入力が重くなる。
    /// </summary>
    internal sealed class NameCheckCache
    {
        private readonly Func<string, NameInputDialog.NameCheck> _check;
        private string _lastValue;
        private NameInputDialog.NameCheck _lastResult;
        private bool _hasLast;

        public NameCheckCache(Func<string, NameInputDialog.NameCheck> check)
        {
            _check = check;
        }

        public NameInputDialog.NameCheck Get(string value)
        {
            if (_hasLast && string.Equals(_lastValue, value, StringComparison.Ordinal)) return _lastResult;

            _lastValue = value;
            _lastResult = Compute(value);
            _hasLast = true;
            return _lastResult;
        }

        private NameInputDialog.NameCheck Compute(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return new NameInputDialog.NameCheck { Error = "名前を入れてください。" };
            return _check != null ? _check(value.Trim()) : default;
        }
    }
}
