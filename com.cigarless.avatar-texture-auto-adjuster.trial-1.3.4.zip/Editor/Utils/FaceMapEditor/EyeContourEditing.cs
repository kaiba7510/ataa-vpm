// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/EyeContourEditing.cs
using System.Collections.Generic;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディターでの目の輪郭（FaceMapFile.EyeContourUpper / Lower）の編集の計算（docs~/目の輪郭リング写像_仕様_草案.md §5.1）。
    /// 輪郭は目の枠の中の割合（x は目頭 0 → 目尻 1、y は下端 0 → 上端 1）で、左右の目で共通。画像の左の目は目頭が右（u が大きい）側。
    /// 画面の描画・入力は持たない（ウィンドウ側が呼ぶ）。
    /// </summary>
    internal static class EyeContourEditing
    {
        /// <summary>初期の輪郭の点の数（両端を含む）。</summary>
        public const int DefaultUpperPoints = 5, DefaultLowerPoints = 4;

        /// <summary>目の線が無いときの、初期の輪郭の上の縁の高さ。</summary>
        public const float DefaultTop = 0.6f;

        /// <summary>目の下の線が無いときの、上の縁からの下がり。</summary>
        public const float DefaultDepth = 0.4f;

        /// <summary>点を動かせる範囲（EyeContour の検証と同じ。目尻の跳ねで枠から少しはみ出してよい）。</summary>
        public const float MinCoord = -0.2f, MaxCoord = 1.2f;

        /// <summary>弧のふくらみの形（sin の指数。1 より小さいほど角ばる）。</summary>
        private const float BulgeExponent = 0.6f;

        /// <summary>
        /// 目の線・目の下の線から初期の輪郭を作る。目頭・目尻は枠の左右の端の、2 本の線の真ん中の高さ。
        /// 上の縁のいちばん高い所を目の線、下の縁のいちばん低い所を目の下の線に合わせる。
        /// </summary>
        public static void CreateDefault(float? eyeLine, float? lowerLine, out Vector2[] upper, out Vector2[] lower)
        {
            float top = eyeLine ?? DefaultTop;
            float bottom = lowerLine ?? Mathf.Max(0f, top - DefaultDepth);
            if (bottom >= top) bottom = Mathf.Max(0f, top - DefaultDepth);
            float corner = (top + bottom) * 0.5f;
            upper = Arc(DefaultUpperPoints, corner, top);
            lower = Arc(DefaultLowerPoints, corner, bottom);
        }

        /// <summary>両端が corner、内側の点のいちばん外が peak になる弧（x は 0〜1 を等分）。</summary>
        private static Vector2[] Arc(int n, float corner, float peak)
        {
            var pts = new Vector2[n];
            float max = 0f;
            for (int i = 1; i < n - 1; i++) max = Mathf.Max(max, Bulge(i / (float)(n - 1)));
            for (int i = 0; i < n; i++)
            {
                float x = i / (float)(n - 1);
                float b = i == 0 || i == n - 1 || max <= 0f ? 0f : Bulge(x) / max;
                pts[i] = new Vector2(x, corner + (peak - corner) * b);
            }
            return pts;
        }

        private static float Bulge(float x) => Mathf.Pow(Mathf.Max(0f, Mathf.Sin(Mathf.PI * x)), BulgeExponent);

        /// <summary>画像の左の目（目_左）は目頭が右側にある。</summary>
        public static bool InnerAtMax(string eyeLabel) => FaceMapMirror.IsLeft(eyeLabel);

        /// <summary>枠の中の割合 → UV（center・size は目の領域）。</summary>
        public static Vector2 LocalToUv(Vector2 local, Vector2 center, Vector2 size, bool innerAtMax)
        {
            float xMin = center.x - size.x * 0.5f, yMin = center.y - size.y * 0.5f;
            float x = innerAtMax ? xMin + size.x - local.x * size.x : xMin + local.x * size.x;
            return new Vector2(x, yMin + local.y * size.y);
        }

        /// <summary>UV → 枠の中の割合（LocalToUv の逆）。</summary>
        public static Vector2 UvToLocal(Vector2 uv, Vector2 center, Vector2 size, bool innerAtMax)
        {
            if (size.x <= 0f || size.y <= 0f) return Vector2.zero;
            float xMin = center.x - size.x * 0.5f, yMin = center.y - size.y * 0.5f;
            float fx = (uv.x - xMin) / size.x;
            return new Vector2(innerAtMax ? 1f - fx : fx, (uv.y - yMin) / size.y);
        }

        /// <summary>枠の中の割合 → 画面の位置（region は目の領域の画面の矩形。画面の y は下向き）。</summary>
        public static Vector2 LocalToScreen(Rect region, Vector2 local, bool innerAtMax)
        {
            float x = innerAtMax ? region.xMax - local.x * region.width : region.xMin + local.x * region.width;
            return new Vector2(x, region.yMax - local.y * region.height);
        }

        /// <summary>輪郭の点のつまみ 1 つ（上の縁か下の縁か、その中の番号）。</summary>
        public readonly struct Handle
        {
            public readonly bool OnUpper;
            public readonly int Index;

            public Handle(bool onUpper, int index)
            {
                OnUpper = onUpper;
                Index = index;
            }
        }

        /// <summary>つまみの一覧。上の縁の全点と、下の縁の両端を除く点（目頭・目尻は上の縁のつまみで動かす）。</summary>
        public static Handle[] Handles(Vector2[] upper, Vector2[] lower)
        {
            if (upper == null || lower == null) return new Handle[0];
            var list = new List<Handle>(upper.Length + lower.Length);
            for (int i = 0; i < upper.Length; i++) list.Add(new Handle(true, i));
            for (int i = 1; i < lower.Length - 1; i++) list.Add(new Handle(false, i));
            return list.ToArray();
        }

        /// <summary>つまみの点（枠の中の割合）。</summary>
        public static Vector2 HandlePoint(Vector2[] upper, Vector2[] lower, Handle h) => h.OnUpper ? upper[h.Index] : lower[h.Index];

        /// <summary>screen のうち mouse に最も近く、radius 以内の番号。無ければ -1。</summary>
        public static int HitHandle(IList<Vector2> screen, Vector2 mouse, float radius)
        {
            int best = -1;
            float bestDist = radius;
            for (int i = 0; i < screen.Count; i++)
            {
                float d = Vector2.Distance(screen[i], mouse);
                if (d <= bestDist)
                {
                    bestDist = d;
                    best = i;
                }
            }
            return best;
        }

        /// <summary>
        /// 輪郭の 1 点を local へ動かした写しを作る。目頭・目尻（両端）は上下の両方を動かす。座標は MinCoord〜MaxCoord に詰める。
        /// 動かした結果が輪郭として成り立たなければ false（どちらも null。ドラッグは直前の正しい形で止まる）。元の配列は変えない。
        /// </summary>
        public static bool TryMovePoint(Vector2[] upper, Vector2[] lower, bool onUpper, int index, Vector2 local,
                                        out Vector2[] newUpper, out Vector2[] newLower)
        {
            newUpper = null;
            newLower = null;
            if (upper == null || lower == null) return false;
            Vector2[] target = onUpper ? upper : lower;
            if (index < 0 || index >= target.Length) return false;

            var p = new Vector2(Mathf.Clamp(local.x, MinCoord, MaxCoord), Mathf.Clamp(local.y, MinCoord, MaxCoord));
            var u = (Vector2[])upper.Clone();
            var l = (Vector2[])lower.Clone();
            if (index == 0)
            {
                u[0] = p;
                l[0] = p;
            }
            else if (index == target.Length - 1)
            {
                u[u.Length - 1] = p;
                l[l.Length - 1] = p;
            }
            else if (onUpper) u[index] = p;
            else l[index] = p;

            if (AtaaCore.ValidateEyeContour(u, l) != null) return false;
            newUpper = u;
            newLower = l;
            return true;
        }
    }
}
