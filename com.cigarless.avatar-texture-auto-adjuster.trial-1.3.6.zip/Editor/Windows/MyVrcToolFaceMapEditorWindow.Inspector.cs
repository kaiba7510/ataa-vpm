using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MyVrcToolFaceMapEditorWindow
    {
        // ── 右: インスペクター（顔パレット・選択中パーツ・折りたたみ・保存して完了）──

        private static readonly List<string> StyleNames = new List<string> { "自動", "標準アニメ", "デフォルメ", "ちび" };
        private static readonly AvatarStyle[] StyleValues =
            { AvatarStyle.Auto, AvatarStyle.Standard, AvatarStyle.Deformed, AvatarStyle.Chibi };
        private static readonly List<string> StepChoiceLabels = new List<string> { "0.001", "0.005", "0.01", "0.05" };

        private ScrollView _inspectorScroll;
        private FaceSilhouettePalette _palette;
        private Button _btnMirror;

        // 選択中パーツ
        private VisualElement _partDot;
        private Label _lblPartTitle;
        private Button _btnRemoveAll;
        private VisualElement _checkBanner;
        private Label _lblCheck;
        private Button _btnCheckNext;
        private VisualElement _guideBanner;
        private Label _lblGuide;
        private Button _btnDisarm;
        private VisualElement _partDetail;
        private DropdownField _dropdownStep;
        private VisualElement _rowSizeW, _rowSizeH, _rowGap, _rowSnapCenter, _rowSizeNum;
        private Button _btnSnapCenter;
        private VisualElement _eyeSection, _mouthSection;
        private Toggle _toggleNoOpening, _toggleEyeLine, _toggleEyeLower, _toggleMouthLine, _toggleEyeContour;
        private Slider _sliderEyeLine, _sliderEyeLower, _sliderMouthLine;
        private FloatField _floatU, _floatV, _floatW, _floatH;
        private Label _lblSharedNote, _lblUvPercent;

        // 左右対称の軸
        private Foldout _foldMirror;
        private TextField _txtCenter;
        private VisualElement _scrubCenterMinus, _scrubCenterPlus;
        private Button _btnSnapNose, _btnAlignMirror;
        private Toggle _toggleOverlay;
        private Slider _sliderOverlay;
        private Label _lblMirrorNote;

        // アバターから自動作成
        private Foldout _foldAuto;
        private ObjectField _objAutoAvatar, _objAutoRenderer;
        private DropdownField _dropdownBlink, _dropdownMouth, _dropdownStyle;
        private Mesh _blendShapeMesh;
        private bool _blendShapeListBuilt;
        private Label _lblAutoFace, _lblAutoNote;
        private Slider _sliderBias;
        private Button _btnRunAuto;

        // メイク基準の情報・表示
        private TextField _txtName, _txtAvatarName, _txtFileName;
        private ObjectField _objInfoAvatar;
        private Label _lblSavePath;
        private Slider _sliderPointer;

        // 保存して完了
        private Button _btnSaveFinish;
        private Label _lblSaveHint;

        private int SelectedIndex => _vm.PanelSelected;
        private bool HasSelection => SelectedIndex >= 0 && SelectedIndex < _vm.State.Points.Count;
        private FaceMapPoint SelectedPointData => HasSelection ? _vm.State.Points[SelectedIndex] : null;
        private string SelectedCategory => HasSelection ? FaceTemplate.CategoryOf(_vm.State.Points[SelectedIndex].Label) : null;
        private static float Step => NudgePad.CurrentStep(NudgePad.FaceMapEditorStepKey);

        private void BindInspectorUi()
        {
            _inspectorScroll = _root.Q<ScrollView>("insp-scroll");

            // ── パレット ──
            _btnMirror = _root.Q<Button>("btn-mirror");
            _btnMirror.tooltip = "ON: 目・頬は片方を置くと反対側にも置かれ、動かすと相方も逆向きに動きます。非対称なメイクでは OFF にします。";
            _btnMirror.clicked += () =>
            {
                _vm.MirrorEnabled = !_vm.MirrorEnabled;
                MarkUiDirty();
            };

            _palette = new FaceSilhouettePalette();
            _root.Q<VisualElement>("palette-host").Add(_palette);
            _palette.PartClicked += label =>
            {
                _vm.PickPart(label);
                _viewImgui?.Focus(); // 選んだらすぐ矢印キーで動かせるように
                MarkUiDirty();
            };

            BindPartSection();
            BindMirrorFoldout();
            BindAutoFoldout();
            BindInfoFoldout();

            // ── 保存して完了 ──
            _btnSaveFinish = _root.Q<Button>("btn-save-finish");
            if (AtaaCore.Edition == CoreEdition.Trial) _btnSaveFinish.text = "✓ 一時保存して完了";
            _btnSaveFinish.tooltip = "開いているメイク基準に保存します（まだ保存先が無ければ名前を聞きます）。上書き保存と同じです。";
            _btnSaveFinish.clicked += SaveOverwriteAndNotify;
            _lblSaveHint = _root.Q<Label>("lbl-save-hint");
        }

        private void BindPartSection()
        {
            _partDot = _root.Q<VisualElement>("part-dot");
            _lblPartTitle = _root.Q<Label>("lbl-part-title");

            _btnRemoveAll = _root.Q<Button>("btn-remove-all");
            _btnRemoveAll.tooltip = "置いたパーツをすべて削除します（確認あり）。";
            _btnRemoveAll.clicked += () =>
            {
                if (_vm.State.Points.Count == 0) return;
                if (EditorUtility.DisplayDialog("すべて削除", "置いたパーツをすべて削除しますか?", "削除する", "キャンセル"))
                    _vm.RemoveAll();
                MarkUiDirty();
            };

            _checkBanner = _root.Q<VisualElement>("check-banner");
            _lblCheck = _root.Q<Label>("lbl-check");
            _btnCheckNext = _root.Q<Button>("btn-check-next");
            _btnCheckNext.clicked += () =>
            {
                if (_panelNextCheck != null) _vm.SelectCheckLabel(_panelNextCheck);
                MarkUiDirty();
            };

            _guideBanner = _root.Q<VisualElement>("guide-banner");
            _lblGuide = _root.Q<Label>("lbl-guide");
            _btnDisarm = _root.Q<Button>("btn-disarm");
            _btnDisarm.clicked += () =>
            {
                _vm.Disarm();
                MarkUiDirty();
            };

            _partDetail = _root.Q<VisualElement>("part-detail");
            _root.Q<Button>("btn-rearm").clicked += () =>
            {
                FaceMapPoint p = SelectedPointData;
                if (p == null) return;
                _vm.Arm(p.Label);
                _vm.ClearSelection();
                MarkUiDirty();
            };
            _root.Q<Button>("btn-remove").clicked += () =>
            {
                FaceMapPoint p = SelectedPointData;
                if (p == null) return;
                _vm.Remove(p.Label);
                MarkUiDirty();
            };

            // 移動量（微調整 PAD・矢印キー・±ボタンで共通）
            _dropdownStep = _root.Q<DropdownField>("dropdown-step");
            _dropdownStep.choices = StepChoiceLabels;
            int stepIdx = Mathf.Clamp(EditorPrefs.GetInt(NudgePad.FaceMapEditorStepKey, 1), 0, StepChoiceLabels.Count - 1);
            _dropdownStep.SetValueWithoutNotify(StepChoiceLabels[stepIdx]);
            _dropdownStep.RegisterValueChangedCallback(evt =>
            {
                int idx = StepChoiceLabels.IndexOf(evt.newValue);
                if (idx >= 0) EditorPrefs.SetInt(NudgePad.FaceMapEditorStepKey, idx);
            });

            // 位置の微調整（ドラッグスクラブ）。Alt を押しながらなら片側だけ動かす（§12.4）
            Func<bool> canMove = () => HasSelection;
            Action<Vector2, EventModifiers> move = (d, mods) =>
            {
                if (!HasSelection) return;
                _vm.Nudge(SelectedIndex, d, (mods & EventModifiers.Alt) != 0);
                MarkUiDirty();
            };
            UiScrub.Bind2D(_root.Q("dpad-up"), Vector2.up, "fm-dpad-btn--active", canMove, () => Step, move, OnScrubHeld);
            UiScrub.Bind2D(_root.Q("dpad-down"), Vector2.down, "fm-dpad-btn--active", canMove, () => Step, move, OnScrubHeld);
            UiScrub.Bind2D(_root.Q("dpad-left"), Vector2.left, "fm-dpad-btn--active", canMove, () => Step, move, OnScrubHeld);
            UiScrub.Bind2D(_root.Q("dpad-right"), Vector2.right, "fm-dpad-btn--active", canMove, () => Step, move, OnScrubHeld);
            UiScrub.Bind2D(_root.Q("dpad-center"), Vector2.zero, "fm-dpad-btn--active", canMove, () => Step, move, OnScrubHeld);

            // 横幅・高さ
            _rowSizeW = _root.Q("row-size-w");
            _rowSizeH = _root.Q("row-size-h");
            Func<bool> canSize = () => SelectedCategory != null;
            Action<Vector2> resize = steps =>
            {
                string category = SelectedCategory;
                if (category == null) return;
                _vm.SetSize(category, _vm.Service.GetSize(category) + steps * Step);
                MarkUiDirty();
            };
            UiScrub.Bind1D(_root.Q("scrub-w-minus"), -1f, "fm-stepper-btn--active", canSize, (s, _) => resize(new Vector2(s, 0f)), OnScrubHeld);
            UiScrub.Bind1D(_root.Q("scrub-w-plus"), 1f, "fm-stepper-btn--active", canSize, (s, _) => resize(new Vector2(s, 0f)), OnScrubHeld);
            UiScrub.Bind1D(_root.Q("scrub-h-minus"), -1f, "fm-stepper-btn--active", canSize, (s, _) => resize(new Vector2(0f, s)), OnScrubHeld);
            UiScrub.Bind1D(_root.Q("scrub-h-plus"), 1f, "fm-stepper-btn--active", canSize, (s, _) => resize(new Vector2(0f, s)), OnScrubHeld);

            // 左右の間隔（§12.4）。←→（+）は広げる、→←（−）は狭める
            _rowGap = _root.Q("row-gap");
            Func<bool> canGap = () =>
            {
                FaceMapPoint p = SelectedPointData;
                return p != null && FaceMapMirror.IsPair(p.Label) && _placedSnapshot.Contains(FaceMapMirror.PartnerLabel(p.Label));
            };
            Action<float, EventModifiers> gap = (s, _) =>
            {
                string category = SelectedCategory;
                if (category == null) return;
                _vm.ChangePairGap(category, -s * Step);
                MarkUiDirty();
            };
            UiScrub.Bind1D(_root.Q("scrub-gap-minus"), -1f, "fm-stepper-btn--active", canGap, gap, OnScrubHeld);
            UiScrub.Bind1D(_root.Q("scrub-gap-plus"), 1f, "fm-stepper-btn--active", canGap, gap, OnScrubHeld);

            _rowSnapCenter = _root.Q("row-snap-center");
            _btnSnapCenter = _root.Q<Button>("btn-snap-center");
            _btnSnapCenter.clicked += () =>
            {
                if (!HasSelection) return;
                _vm.SnapToCenter(SelectedIndex);
                MarkUiDirty();
            };

            // 目の線・目の下の線（v0.4 §4.2）・目の開いていない素体（統合仕様書 §3.5）
            _eyeSection = _root.Q("eye-section");
            _toggleNoOpening = _root.Q<Toggle>("toggle-no-opening");
            _toggleNoOpening.tooltip = "顔のテクスチャに目の開いた部分（白目・瞳）が無く、目の部分がメッシュの穴になっている素体（Lapwing など）。" +
                                       "上下のまぶたの縁が UV 上でほぼ重なるので、目の線と目の下の線はくっついていて構いません。\n" +
                                       "この素体のメイクを目の開いた素体に写すときは、目の開いた部分に対象の元の目を残します。";
            _toggleNoOpening.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || SelectedCategory != FaceMapFile.EyeCategory) return;
                _vm.SetNoEyeOpening(evt.newValue);
                MarkUiDirty();
            });

            _toggleEyeLine = _root.Q<Toggle>("toggle-eyeline");
            _toggleEyeLine.tooltip = "目の領域の中の、目の線の高さ。メイクを写すとき、まぶたと目を別々に合わせます。左右の目で共通です。";
            _toggleEyeLine.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || SelectedCategory != FaceMapFile.EyeCategory) return;
                _vm.SetEyeLine(evt.newValue ? FaceMapEditorViewModel.DefaultEyeLine : (float?)null);
                MarkUiDirty();
            });
            _sliderEyeLine = _root.Q<Slider>("slider-eyeline");
            _sliderEyeLine.tooltip = "0 = 目の領域の下端、1 = 上端。テクスチャ上の目の線の右端のつまみでも動かせます。";
            UiSlider.SetRange(_sliderEyeLine, FaceMapFile.MinEyeLine, FaceMapFile.MaxEyeLine);
            _sliderEyeLine.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || !FaceMapEditorUi.AcceptsEyeLineChange(SelectedCategory, _vm.State.EyeLine.HasValue)) return;
                _vm.SetEyeLine(evt.newValue);
                MarkUiDirty();
            });

            _toggleEyeLower = _root.Q<Toggle>("toggle-eyelower");
            _toggleEyeLower.tooltip = "目の開いた部分の下の縁。目の下の肌と目を別々に合わせます（下まつげ・涙袋のメイクがずれにくくなる）。";
            _toggleEyeLower.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || SelectedCategory != FaceMapFile.EyeCategory) return;
                float line = _vm.State.EyeLine ?? FaceMapEditorViewModel.DefaultEyeLine;
                _vm.SetEyeLowerLine(evt.newValue
                    ? Mathf.Max(FaceMapFile.MinEyeLine, line - FaceMapEditorViewModel.DefaultEyeLowerGap)
                    : (float?)null);
                MarkUiDirty();
            });
            _sliderEyeLower = _root.Q<Slider>("slider-eyelower");
            _sliderEyeLower.tooltip = "0 = 目の領域の下端。目の線より下";
            UiSlider.SetRange(_sliderEyeLower, FaceMapFile.MinEyeLine, FaceMapFile.MaxEyeLine);
            _sliderEyeLower.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || !FaceMapEditorUi.AcceptsEyeLowerLineChange(SelectedCategory, _vm.State.EyeLine.HasValue, _vm.State.EyeLowerLine.HasValue)) return;
                _vm.SetEyeLowerLine(evt.newValue);
                MarkUiDirty();
            });

            // 目の輪郭（目の輪郭リング写像の仕様 §5.1）
            _toggleEyeContour = _root.Q<Toggle>("toggle-eyecontour");
            _toggleEyeContour.tooltip = "目の開いた部分の縁を点でなぞります。メイク元・対象の両方にあると、目を囲むライン・目尻の跳ね上げ・" +
                                        "下まつげを、目の縁に沿って写します（丸い目と切れ長の目のように形が違っても縁に乗る）。\n" +
                                        "目の線・目の下の線から初めの形を作るので、テクスチャ上の水色の点をドラッグして縁に合わせてください。左右の目で共通です。";
            _toggleEyeContour.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || SelectedCategory != FaceMapFile.EyeCategory) return;
                _vm.SetEyeContourEnabled(evt.newValue);
                MarkUiDirty();
            });

            // 口の線（上唇と下唇の合わせ目）
            _mouthSection = _root.Q("mouth-section");
            _toggleMouthLine = _root.Q<Toggle>("toggle-mouthline");
            _toggleMouthLine.tooltip = "口の領域の中の、上唇と下唇の合わせ目の高さ。メイク元・対象の両方にあれば、上唇と下唇を別々に合わせて写します。";
            _toggleMouthLine.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || SelectedCategory != FaceMapFile.MouthCategory) return;
                _vm.SetMouthLine(evt.newValue ? FaceMapEditorViewModel.DefaultMouthLine : (float?)null);
                MarkUiDirty();
            });
            _sliderMouthLine = _root.Q<Slider>("slider-mouthline");
            _sliderMouthLine.tooltip = "0 = 口の領域の下端、1 = 上端。テクスチャ上の口の線の右端のつまみでも動かせます。";
            UiSlider.SetRange(_sliderMouthLine, FaceMapFile.MinMouthLine, FaceMapFile.MaxMouthLine);
            _sliderMouthLine.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || !FaceMapEditorUi.AcceptsMouthLineChange(SelectedCategory, _vm.State.MouthLine.HasValue)) return;
                _vm.SetMouthLine(evt.newValue);
                MarkUiDirty();
            });

            // ▶ 詳細設定: UV の数値は初心者には出さない（Progressive Disclosure）
            _floatU = _root.Q<FloatField>("float-u");
            _floatV = _root.Q<FloatField>("float-v");
            _floatW = _root.Q<FloatField>("float-w");
            _floatH = _root.Q<FloatField>("float-h");
            _rowSizeNum = _root.Q("row-size-num");
            foreach (FloatField f in new[] { _floatU, _floatV, _floatW, _floatH }) f.isDelayed = true;
            EventCallback<ChangeEvent<float>> setPos = _ =>
            {
                if (_suppressUiEvents || !HasSelection) return;
                _vm.SetPosition(SelectedIndex, new Vector2(_floatU.value, _floatV.value));
                MarkUiDirty();
            };
            _floatU.RegisterValueChangedCallback(setPos);
            _floatV.RegisterValueChangedCallback(setPos);
            EventCallback<ChangeEvent<float>> setSize = _ =>
            {
                if (_suppressUiEvents) return;
                string category = SelectedCategory;
                if (category == null) return;
                _vm.SetSize(category, new Vector2(_floatW.value, _floatH.value));
                MarkUiDirty();
            };
            _floatW.RegisterValueChangedCallback(setSize);
            _floatH.RegisterValueChangedCallback(setSize);
            _lblSharedNote = _root.Q<Label>("lbl-shared-note");
            _lblUvPercent = _root.Q<Label>("lbl-uv-percent");
        }

        /// <summary>左右対称の詳細（中心線・反転オーバーレイ）。中心線の位置は FaceMap に保存し、ON/OFF とオーバーレイは表示設定。</summary>
        private void BindMirrorFoldout()
        {
            _foldMirror = _root.Q<Foldout>("foldout-mirror");
            _txtCenter = _root.Q<TextField>("txt-center");
            _txtCenter.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                if (float.TryParse(evt.newValue, NumberStyles.Float, CultureInfo.InvariantCulture, out float c)) _vm.SetCenter(c);
                MarkUiDirty();
            });

            _scrubCenterMinus = _root.Q("scrub-center-minus");
            _scrubCenterPlus = _root.Q("scrub-center-plus");
            Func<bool> canCenter = () => _vm.State.CenterX.HasValue;
            Action<float, EventModifiers> moveCenter = (s, _) =>
            {
                if (!_vm.State.CenterX.HasValue) return;
                _vm.SetCenter(_vm.State.CenterX.Value + s * Step);
                MarkUiDirty();
            };
            UiScrub.Bind1D(_scrubCenterMinus, -1f, "fm-stepper-btn--active", canCenter, moveCenter, OnScrubHeld);
            UiScrub.Bind1D(_scrubCenterPlus, 1f, "fm-stepper-btn--active", canCenter, moveCenter, OnScrubHeld);

            _btnSnapNose = _root.Q<Button>("btn-snap-nose");
            _btnSnapNose.clicked += () => { _vm.SnapCenterToNose(); MarkUiDirty(); };
            _btnAlignMirror = _root.Q<Button>("btn-align-mirror");
            _btnAlignMirror.clicked += () => { _vm.AlignMirror(); MarkUiDirty(); };

            _toggleOverlay = _root.Q<Toggle>("toggle-overlay");
            _toggleOverlay.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _vm.OverlayEnabled = evt.newValue;
                MarkUiDirty();
            });
            _sliderOverlay = _root.Q<Slider>("slider-overlay");
            UiSlider.SetRange(_sliderOverlay, FaceMapEditorViewModel.MinOverlayAlpha, FaceMapEditorViewModel.MaxOverlayAlpha);
            _sliderOverlay.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _vm.OverlayAlpha = evt.newValue;
                MarkUiDirty();
            });
            _lblMirrorNote = _root.Q<Label>("lbl-mirror-note");
        }

        /// <summary>「アバターから自動作成」欄（自動ポインティング仕様 §11.3）。既定で折りたたむ。</summary>
        private void BindAutoFoldout()
        {
            _foldAuto = _root.Q<Foldout>("foldout-auto");

            _objAutoAvatar = _root.Q<ObjectField>("obj-auto-avatar");
            _objAutoAvatar.objectType = typeof(GameObject);
            _objAutoAvatar.allowSceneObjects = true;
            _objAutoAvatar.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                SetAvatar(evt.newValue as GameObject);
            });

            _objAutoRenderer = _root.Q<ObjectField>("obj-auto-renderer");
            _objAutoRenderer.objectType = typeof(SkinnedMeshRenderer);
            _objAutoRenderer.allowSceneObjects = true;
            _objAutoRenderer.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _vm.SetAutoRenderer(evt.newValue as SkinnedMeshRenderer);
                MarkUiDirty();
            });

            _dropdownBlink = _root.Q<DropdownField>("dropdown-blink");
            _dropdownBlink.RegisterValueChangedCallback(_ =>
            {
                if (_suppressUiEvents) return;
                _vm.AutoBlink = _dropdownBlink.index - 1;
                _vm.UpdateAutoFaceText();
                MarkUiDirty();
            });
            _dropdownMouth = _root.Q<DropdownField>("dropdown-mouth");
            _dropdownMouth.RegisterValueChangedCallback(_ =>
            {
                if (_suppressUiEvents) return;
                // 口のシェイプは顔のマテリアルの特定にも使う（§11.10）ので、変えたら表示を更新する
                _vm.AutoMouth = _dropdownMouth.index - 1;
                _vm.UpdateAutoFaceText();
                MarkUiDirty();
            });
            _lblAutoFace = _root.Q<Label>("lbl-auto-face");

            // スタイルの上書きと検出感度（§12.6）
            _dropdownStyle = _root.Q<DropdownField>("dropdown-style");
            _dropdownStyle.choices = StyleNames;
            _dropdownStyle.RegisterValueChangedCallback(_ =>
            {
                if (_suppressUiEvents) return;
                int i = _dropdownStyle.index;
                if (i >= 0 && i < StyleValues.Length) _vm.AutoStyle = StyleValues[i];
                MarkUiDirty();
            });
            _sliderBias = _root.Q<Slider>("slider-bias");
            UiSlider.SetRange(_sliderBias, GenerationOptions.MinBias, GenerationOptions.MaxBias);
            _sliderBias.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _vm.AutoBias = Mathf.Abs(evt.newValue) < 0.03f ? 0f : evt.newValue;
                MarkUiDirty();
            });

            _btnRunAuto = _root.Q<Button>("btn-run-auto");
            _btnRunAuto.clicked += () =>
            {
                _vm.RunAutoGenerate();
                MarkUiDirty();
            };
            _lblAutoNote = _root.Q<Label>("lbl-auto-note");
        }

        /// <summary>メイク基準の情報（名前・対象アバター・ファイル名・表示設定）。既定で畳む。</summary>
        private void BindInfoFoldout()
        {
            _txtName = _root.Q<TextField>("txt-name");
            _txtName.isDelayed = true;
            _txtName.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || FaceMapEditorUi.IsSameText(evt.newValue, _vm.State.Name)) return; // 同じ値なら未保存にしない
                _vm.State.Name = evt.newValue;
                _vm.State.Dirty = true;
                MarkUiDirty();
            });

            _objInfoAvatar = _root.Q<ObjectField>("obj-info-avatar");
            _objInfoAvatar.objectType = typeof(GameObject);
            _objInfoAvatar.allowSceneObjects = true;
            _objInfoAvatar.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                SetAvatar(evt.newValue as GameObject);
            });

            _txtAvatarName = _root.Q<TextField>("txt-avatar-name");
            _txtAvatarName.isDelayed = true;
            _txtAvatarName.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || FaceMapEditorUi.IsSameText(evt.newValue, _vm.State.TargetAvatarName)) return;
                _vm.State.TargetAvatarName = evt.newValue;
                _vm.State.Dirty = true;
                MarkUiDirty();
            });

            _txtFileName = _root.Q<TextField>("txt-file-name");
            _txtFileName.isDelayed = true;
            _txtFileName.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _vm.State.FileNameOverride = evt.newValue;
                MarkUiDirty();
            });
            _lblSavePath = _root.Q<Label>("lbl-save-path");

            _sliderPointer = _root.Q<Slider>("slider-pointer");
            UiSlider.SetRange(_sliderPointer, FaceMapTextureRenderer.MinPointerScale, FaceMapTextureRenderer.MaxPointerScale);
            _sliderPointer.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _vm.PointerScale = evt.newValue;
                MarkUiDirty();
            });
        }

        /// <summary>対象アバターを変える（自動作成欄と情報欄で共通）。</summary>
        private void SetAvatar(GameObject avatar)
        {
            FaceMapEditorState st = _vm.State;
            if (avatar == st.TargetAvatarObject) return;
            st.TargetAvatarObject = avatar;
            if (avatar != null) st.TargetAvatarName = avatar.name;
            st.Dirty = true;
            _vm.RefreshAutoInputs();
            MarkUiDirty();
        }

        private void OnScrubHeld(bool held)
        {
            _scrubbing = held;
            MarkUiDirty();
        }

        private void OpenAutoFoldout()
        {
            if (_foldAuto == null) return;
            _foldAuto.value = true;
            _inspectorScroll?.schedule.Execute(() => _inspectorScroll.ScrollTo(_foldAuto)).StartingIn(50);
        }

        // ── 同期 ──

        private void RefreshInspectorUi()
        {
            _btnMirror.text = _vm.MirrorEnabled ? "左右対称: ON" : "左右対称: OFF";
            _palette.Refresh(_vm.GetPartState, _hasTexture ? _targetLabel : null, _activeChecks);

            RefreshPartSection();
            RefreshMirrorFoldout();
            RefreshAutoFoldout();
            RefreshInfoFoldout();

            int required = FaceMapEditorService.RequiredCount();
            _btnSaveFinish.SetEnabled(FaceMapEditorUi.CanSave(_placedRequired, required));
            _lblSaveHint.text = FaceMapEditorUi.SaveHint(_placedRequired, required);
        }

        private void RefreshPartSection()
        {
            _btnRemoveAll.SetEnabled(_vm.State.Points.Count > 0);

            // 自動作成の要確認の案内（§12.6）。選択中が要確認なら合わせ方を、ほかに残っていれば次へ進むボタンを出す
            bool showCheck = _panelSelectedIsCheck || _panelNextCheck != null;
            _checkBanner.EnableInClassList("hidden", !showCheck);
            if (showCheck)
            {
                _lblCheck.text = _panelSelectedIsCheck
                    ? "▲ 要確認: 位置と範囲を確かめてください。十字ボタン・矢印キー・ドラッグで動かすと確認済みになります。"
                    : $"▲ 要確認が残っています（{_activeChecks.Count} か所）。";
                _btnCheckNext.EnableInClassList("hidden", _panelNextCheck == null);
                _btnCheckNext.text = _panelSelectedIsCheck ? "次へ" : "選ぶ";
                _btnCheckNext.tooltip = _panelNextCheck != null ? $"次の要確認の領域「{_panelNextCheck}」を選択します。" : "";
            }

            FaceMapPoint point = SelectedPointData;
            _partDetail.EnableInClassList("hidden", point == null);
            _guideBanner.EnableInClassList("hidden", point != null);
            if (point == null)
            {
                _lblPartTitle.text = "パーツ";
                _partDot.style.backgroundColor = new StyleColor(StyleKeyword.Null);
                bool armed = false;
                if (!_hasTexture)
                {
                    _lblGuide.text = "まず顔テクスチャを左のビューにドラッグ＆ドロップしてください。パーツ選択後はここに微調整パッドが表示されます。";
                }
                else if (_targetText != null)
                {
                    _lblGuide.text = $"テクスチャ上をクリック → {_targetText} を置きます。\n置いたパーツはパレットか枠をクリックして選ぶと、ここで微調整できます。";
                    armed = !string.IsNullOrEmpty(_vm.ArmedLabel);
                }
                else
                {
                    _lblGuide.text = "パレットかテクスチャ上の枠をクリックすると、そのパーツを微調整できます。";
                }
                _btnDisarm.EnableInClassList("hidden", !armed);
                return;
            }

            string category = FaceTemplate.CategoryOf(point.Label);
            FaceTemplateEntry entry = FaceTemplate.Find(point.Label);
            _lblPartTitle.text = $"{FaceIllustrationPalette.ShortName(point.Label)}（{FaceTemplateText.Describe(entry?.Label)}）";
            _partDot.style.backgroundColor = FaceMapTextureRenderer.GetLabelColor(point.Label);

            bool hasCategory = category != null;
            _rowSizeW.EnableInClassList("hidden", !hasCategory);
            _rowSizeH.EnableInClassList("hidden", !hasCategory);
            _rowSizeNum.EnableInClassList("hidden", !hasCategory);

            // 左右の間隔・中心線に合わせる（§12.4）
            bool pair = FaceMapMirror.IsPair(point.Label);
            _rowGap.EnableInClassList("hidden", !pair);
            if (pair)
            {
                bool bothPlaced = _placedSnapshot.Contains(FaceMapMirror.PartnerLabel(point.Label));
                _rowGap.Query(className: "fm-stepper-btn").ForEach(b => b.EnableInClassList("fm-stepper-btn--disabled", !bothPlaced));
            }
            bool center = !pair && FaceMapMirror.IsCenterPart(point.Label);
            _rowSnapCenter.EnableInClassList("hidden", !center);
            _btnSnapCenter.SetEnabled(_panelCenter.HasValue);
            _btnSnapCenter.tooltip = _panelCenter.HasValue ? "左右の位置を顔の中心線に合わせます。" : "中心線が未確定です。";

            // 目の線・目の下の線（v0.4 §4.2）。テクスチャ上の目の枠のつまみでも動かせる
            bool eye = category == FaceMapFile.EyeCategory;
            _eyeSection.EnableInClassList("hidden", !eye);
            if (eye)
            {
                float? line = _vm.State.EyeLine;
                float? lower = _vm.State.EyeLowerLine;
                _toggleNoOpening.SetValueWithoutNotify(_vm.State.NoEyeOpening);
                _toggleEyeLine.SetValueWithoutNotify(line.HasValue);
                _sliderEyeLine.EnableInClassList("hidden", !line.HasValue);
                if (line.HasValue) _sliderEyeLine.SetValueWithoutNotify(line.Value);
                // 目の下の線（下まつげの生え際）。目の線があるときだけ置ける
                _toggleEyeLower.EnableInClassList("hidden", !line.HasValue);
                _toggleEyeLower.SetValueWithoutNotify(lower.HasValue);
                _sliderEyeLower.EnableInClassList("hidden", !(line.HasValue && lower.HasValue));
                if (lower.HasValue) _sliderEyeLower.SetValueWithoutNotify(lower.Value);
                // 目の輪郭。目の開いていない素体では使わない
                _toggleEyeContour.EnableInClassList("hidden", _vm.State.NoEyeOpening);
                _toggleEyeContour.SetValueWithoutNotify(_vm.State.EyeContourUpper != null);
            }

            bool mouth = category == FaceMapFile.MouthCategory;
            _mouthSection.EnableInClassList("hidden", !mouth);
            if (mouth)
            {
                float? line = _vm.State.MouthLine;
                _toggleMouthLine.SetValueWithoutNotify(line.HasValue);
                _sliderMouthLine.EnableInClassList("hidden", !line.HasValue);
                if (line.HasValue) _sliderMouthLine.SetValueWithoutNotify(line.Value);
            }

            // 詳細設定（数値）。入力中の欄は上書きしない
            if (!IsFocused(_floatU)) _floatU.SetValueWithoutNotify(point.X);
            if (!IsFocused(_floatV)) _floatV.SetValueWithoutNotify(point.Y);
            if (hasCategory)
            {
                Vector2 size = _vm.Service.GetSize(category);
                if (!IsFocused(_floatW)) _floatW.SetValueWithoutNotify(size.x);
                if (!IsFocused(_floatH)) _floatH.SetValueWithoutNotify(size.y);
            }
            bool shared = category == "目" || category == "頬";
            _lblSharedNote.EnableInClassList("hidden", !shared);
            _lblSharedNote.text = shared ? $"※ {category}の範囲は左右で共通です。" : "";
            _lblUvPercent.text = $"u: {point.X * 100:0.0}%  v: {point.Y * 100:0.0}%";
        }

        private void RefreshMirrorFoldout()
        {
            _foldMirror.text = _panelCenter.HasValue
                ? string.Format(CultureInfo.InvariantCulture, "左右対称の軸（中心 u = {0:0.000}）", _panelCenter.Value)
                : "左右対称の軸（未確定）";

            if (!IsFocused(_txtCenter))
                _txtCenter.SetValueWithoutNotify(_panelCenter.HasValue
                    ? _panelCenter.Value.ToString("0.000", CultureInfo.InvariantCulture)
                    : "");
            _txtCenter.tooltip = _panelCenter.HasValue ? "顔の中心線の u。" : "未確定。鼻を置くか、値を入力すると決まります。";

            foreach (VisualElement b in new[] { _scrubCenterMinus, _scrubCenterPlus })
                b.EnableInClassList("fm-stepper-btn--disabled", !_panelCenter.HasValue);
            _btnSnapNose.SetEnabled(_placedSnapshot.Contains(FaceTemplate.NoseLabel));
            _btnAlignMirror.SetEnabled(_panelMirror && _panelCenter.HasValue);

            bool overlayOk = _panelMirror && _panelCenter.HasValue && _hasTexture;
            _toggleOverlay.SetEnabled(overlayOk);
            _sliderOverlay.SetEnabled(overlayOk);
            _toggleOverlay.SetValueWithoutNotify(_vm.OverlayEnabled);
            _sliderOverlay.SetValueWithoutNotify(_vm.OverlayAlpha);

            _lblMirrorNote.EnableInClassList("hidden", !_panelMirror);
            _lblMirrorNote.text = _panelCenter.HasValue
                ? "Alt を押しながら操作すると片側だけ動きます。"
                : "中心線が未確定です。まず鼻を置いてください。";
        }

        private void RefreshAutoFoldout()
        {
            FaceMapEditorState st = _vm.State;
            _vm.RefreshAutoInputs();
            bool ready = st.TargetAvatarObject != null && _vm.AutoRenderer != null && _vm.AutoBlink >= 0;
            _foldAuto.text = ready ? "アバターから自動作成（利用可能）" : "アバターから自動作成";

            _objAutoAvatar.SetValueWithoutNotify(st.TargetAvatarObject);
            _objAutoRenderer.SetValueWithoutNotify(_vm.AutoRenderer);

            // ブレンドシェイプの一覧は、顔のメッシュが変わったときだけ作り直す
            Mesh mesh = _vm.AutoRenderer != null ? _vm.AutoRenderer.sharedMesh : null;
            if (!_blendShapeListBuilt || mesh != _blendShapeMesh)
            {
                _blendShapeListBuilt = true;
                _blendShapeMesh = mesh;
                int count = mesh != null ? mesh.blendShapeCount : 0;
                var blink = new List<string>(count + 1) { "（選んでください）" };
                var mouthNames = new List<string>(count + 1) { "なし" };
                for (int i = 0; i < count; i++)
                {
                    string n = mesh.GetBlendShapeName(i);
                    blink.Add(n);
                    mouthNames.Add(n);
                }
                _dropdownBlink.choices = blink;
                _dropdownMouth.choices = mouthNames;
            }
            bool hasShapes = _dropdownBlink.choices.Count > 1;
            _dropdownBlink.SetEnabled(hasShapes);
            _dropdownMouth.SetEnabled(hasShapes);
            _dropdownBlink.SetValueWithoutNotify(ChoiceAt(_dropdownBlink, _vm.AutoBlink + 1));
            _dropdownMouth.SetValueWithoutNotify(ChoiceAt(_dropdownMouth, _vm.AutoMouth + 1));

            _lblAutoFace.text = _vm.AutoFaceText ?? "顔のマテリアル: （まばたきを選ぶと表示）";

            int styleIndex = Mathf.Max(0, Array.IndexOf(StyleValues, _vm.AutoStyle));
            _dropdownStyle.SetValueWithoutNotify(StyleNames[styleIndex]);
            _sliderBias.SetValueWithoutNotify(_vm.AutoBias);

            _btnRunAuto.SetEnabled(ready);
            _lblAutoNote.text =
                (_panelStyleText != null ? $"前回のスタイル: {_panelStyleText}\n" : "") +
                "目・口はブレンドシェイプの動きから、鼻・頬は目と口から置きます。確かでない領域はオレンジの枠（要確認）になり、最初の 1 つを選択します。";
        }

        private static string ChoiceAt(DropdownField field, int index)
        {
            List<string> choices = field.choices;
            if (choices == null || choices.Count == 0) return "";
            return choices[Mathf.Clamp(index, 0, choices.Count - 1)];
        }

        private void RefreshInfoFoldout()
        {
            FaceMapEditorState st = _vm.State;
            if (!IsFocused(_txtName)) _txtName.SetValueWithoutNotify(st.Name ?? "");
            _objInfoAvatar.SetValueWithoutNotify(st.TargetAvatarObject);
            if (!IsFocused(_txtAvatarName)) _txtAvatarName.SetValueWithoutNotify(st.TargetAvatarName ?? "");
            if (!IsFocused(_txtFileName)) _txtFileName.SetValueWithoutNotify(st.FileNameOverride ?? "");
            _lblSavePath.text = _panelBound
                ? $"保存先: {System.IO.Path.GetFileName(st.BoundPath)}"
                : $"新規保存名: {_vm.ResolveFileName()}.json";
            _sliderPointer.SetValueWithoutNotify(_vm.PointerScale);
        }

        /// <summary>その欄（の中の入力）にフォーカスがあるか。入力中の値を同期で上書きしないため。</summary>
        private bool IsFocused(VisualElement field)
        {
            if (field == null) return false;
            for (var e = rootVisualElement.focusController?.focusedElement as VisualElement; e != null; e = e.parent)
            {
                if (e == field) return true;
            }
            return false;
        }
    }
}
