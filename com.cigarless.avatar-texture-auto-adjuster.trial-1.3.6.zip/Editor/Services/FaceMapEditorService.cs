// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/FaceMapEditorService.cs
using System;
using System.Collections.Generic;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディターの領域の配置・削除・移動・サイズ変更。
    /// label はテンプレートのものに限る。座標は 0〜1 にクランプする（仕様書 D15）。
    /// </summary>
    public class FaceMapEditorService
    {
        public const float MinSize = 0.003f; // 小さい口の高さ（0.004 前後）を手で直せるように
        public const float MaxSize = 1f;

        private readonly FaceMapEditorState _state;

        public FaceMapEditorService(FaceMapEditorState state)
        {
            _state = state ?? throw new ArgumentNullException(nameof(state));
        }

        public int IndexOf(string label)
        {
            for (int i = 0; i < _state.Points.Count; i++)
            {
                if (string.Equals(_state.Points[i].Label, label, StringComparison.Ordinal)) return i;
            }
            return -1;
        }

        public bool IsPlaced(string label) => IndexOf(label) >= 0;

        public HashSet<string> PlacedLabels()
        {
            var set = new HashSet<string>(StringComparer.Ordinal);
            foreach (FaceMapPoint p in _state.Points) set.Add(p.Label);
            return set;
        }

        /// <summary>置いた必須領域の数。</summary>
        public int PlacedRequiredCount()
        {
            int n = 0;
            foreach (FaceTemplateEntry e in FaceTemplate.Entries)
            {
                if (e.Required && IsPlaced(e.Label)) n++;
            }
            return n;
        }

        public static int RequiredCount()
        {
            int n = 0;
            foreach (FaceTemplateEntry e in FaceTemplate.Entries)
            {
                if (e.Required) n++;
            }
            return n;
        }

        public bool IsComplete() => PlacedRequiredCount() == RequiredCount();

        /// <summary>
        /// テンプレートの領域を uv に置く。既に置いてあれば移動する。
        /// その分類のサイズが未設定なら、既定サイズを入れる。置いた点の index を返す。
        /// </summary>
        public int Place(FaceTemplateEntry entry, Vector2 uv)
        {
            Vector2 clamped = new Vector2(Mathf.Clamp01(uv.x), Mathf.Clamp01(uv.y));

            int index = IndexOf(entry.Label);
            if (index >= 0)
            {
                SetPosition(index, clamped);
                return index;
            }

            _state.Points.Add(new FaceMapPoint(clamped.x, clamped.y, entry.Label));
            EnsureSize(entry.Category);
            _state.Dirty = true;
            return _state.Points.Count - 1;
        }

        public Vector2 GetSize(string category)
        {
            return _state.Sizes.TryGetValue(category, out Vector2 s) ? s : FaceTemplate.GetDefaultSize(category);
        }

        public void EnsureSize(string category)
        {
            if (!_state.Sizes.ContainsKey(category))
                _state.Sizes[category] = FaceTemplate.GetDefaultSize(category);
        }

        /// <summary>分類のサイズを変える。左右ペアの片方を変えれば、もう片方も同じサイズになる。</summary>
        public void SetSize(string category, Vector2 size)
        {
            Vector2 s = new Vector2(
                Mathf.Clamp(size.x, MinSize, MaxSize),
                Mathf.Clamp(size.y, MinSize, MaxSize));

            if (_state.Sizes.TryGetValue(category, out Vector2 old) && old == s) return;

            _state.Sizes[category] = s;
            _state.Dirty = true;
        }

        /// <summary>目の線の高さ（目の領域の下端 0〜上端 1。v0.4 §4.2）を変える。null で目の線を無くす。</summary>
        public void SetEyeLine(float? line)
        {
            // 目の下の線があれば、それより MinEyeBand 以上上に保つ
            float min = _state.EyeLowerLine.HasValue
                ? Mathf.Max(FaceMapFile.MinEyeLine, _state.EyeLowerLine.Value + FaceMapFile.MinEyeBand)
                : FaceMapFile.MinEyeLine;
            float? v = line.HasValue ? Mathf.Clamp(line.Value, min, FaceMapFile.MaxEyeLine) : (float?)null;
            if (Nullable.Equals(_state.EyeLine, v)) return;
            float? oldLine = _state.EyeLine, oldLower = _state.EyeLowerLine;
            _state.EyeLine = v;
            if (!v.HasValue) _state.EyeLowerLine = null; // 目の下の線は目の線があるときだけ使う
            FollowEyeContour(oldLine, oldLower);
            _state.Dirty = true;
        }

        /// <summary>
        /// 目の線・目の下の線が変わった後に、目の輪郭を縦に写し直して線に追従させる（EyeContourEditing.TryFollowEyeLines）。
        /// 線を消したとき・写し直すと輪郭として成り立たないときは、輪郭は直前の形のまま。
        /// </summary>
        private void FollowEyeContour(float? oldLine, float? oldLower)
        {
            if (EyeContourEditing.TryFollowEyeLines(_state.EyeContourUpper, _state.EyeContourLower,
                                                    oldLine, oldLower, _state.EyeLine, _state.EyeLowerLine,
                                                    out Vector2[] upper, out Vector2[] lower))
            {
                _state.EyeContourUpper = upper;
                _state.EyeContourLower = lower;
            }
        }

        /// <summary>目の下の線の高さを変える（目の線より MinEyeBand 以上下）。目の線が無ければ置かない。null で無くす。</summary>
        public void SetEyeLowerLine(float? line)
        {
            if (line.HasValue && !_state.EyeLine.HasValue) return;
            float? v = line.HasValue
                ? Mathf.Clamp(line.Value, FaceMapFile.MinEyeLine,
                    Mathf.Max(FaceMapFile.MinEyeLine, _state.EyeLine.Value - FaceMapFile.MinEyeBand))
                : (float?)null;
            if (Nullable.Equals(_state.EyeLowerLine, v)) return;
            float? oldLower = _state.EyeLowerLine;
            _state.EyeLowerLine = v;
            FollowEyeContour(_state.EyeLine, oldLower);
            _state.Dirty = true;
        }

        /// <summary>
        /// 口の線の高さ（口の領域の下端 0〜上端 1）を変える。null で口の線を無くす（折れ線も消す）。
        /// 折れ線（#25）があるときは、形を保ったまま全点を縦にずらし、代表の高さ（MouthLineShape.Mean）を line に近づける。
        /// </summary>
        public void SetMouthLine(float? line)
        {
            float? v = line.HasValue ? Mathf.Clamp(line.Value, FaceMapFile.MinMouthLine, FaceMapFile.MaxMouthLine) : (float?)null;
            if (!v.HasValue)
            {
                if (!_state.MouthLine.HasValue && _state.MouthLinePoints == null) return;
                _state.MouthLine = null;
                _state.MouthLinePoints = null;
                _state.Dirty = true;
                return;
            }
            if (_state.MouthLinePoints != null && _state.MouthLine.HasValue)
            {
                Vector2[] shifted = MouthLineShape.Shift(_state.MouthLinePoints, v.Value - _state.MouthLine.Value,
                                                         FaceMapFile.MinMouthLine, FaceMapFile.MaxMouthLine);
                if (MouthLineShape.Equal(shifted, _state.MouthLinePoints)) return;
                _state.MouthLinePoints = shifted;
                _state.MouthLine = MouthLineShape.Mean(shifted, v.Value);
                _state.Dirty = true;
                return;
            }
            if (Nullable.Equals(_state.MouthLine, v)) return;
            _state.MouthLine = v;
            _state.Dirty = true;
        }

        /// <summary>
        /// 口の線を折れ線で置き換える（#25。自動作成・3D ビューでの配置用）。点は MouthLineShape の決まり
        /// （u の昇順、v は MinMouthLine〜MaxMouthLine）に収める。水平なら折れ線を持たず、その高さの line にする。
        /// </summary>
        public void SetMouthLinePoints(Vector2[] points)
        {
            if (points == null || points.Length < MouthLineShape.MinPoints)
            {
                SetMouthLine(null);
                return;
            }
            var clamped = new Vector2[points.Length];
            for (int i = 0; i < points.Length; i++)
                clamped[i] = new Vector2(Mathf.Clamp01(points[i].x),
                                         Mathf.Clamp(points[i].y, FaceMapFile.MinMouthLine, FaceMapFile.MaxMouthLine));
            System.Array.Sort(clamped, (a, b) => a.x.CompareTo(b.x));
            Vector2[] next = MouthLineShape.IsHorizontal(clamped) ? null : clamped;
            float line = MouthLineShape.Mean(clamped, clamped[0].y);
            if (MouthLineShape.Equal(next, _state.MouthLinePoints) && Nullable.Equals(_state.MouthLine, line)) return;
            _state.MouthLinePoints = next;
            _state.MouthLine = line;
            _state.Dirty = true;
        }

        /// <summary>目の開いていない素体か（FaceMapFile.NoEyeOpening）を変える。</summary>
        public void SetNoEyeOpening(bool value)
        {
            if (_state.NoEyeOpening == value) return;
            _state.NoEyeOpening = value;
            _state.Dirty = true;
        }

        /// <summary>
        /// 目の輪郭（FaceMapFile.EyeContourUpper / Lower）を変える。両方 null なら消す。
        /// 輪郭として成り立たない（AtaaCore.ValidateEyeContour）・片方だけのときは変えずに false。写しを持つ。
        /// </summary>
        public bool SetEyeContour(Vector2[] upper, Vector2[] lower)
        {
            if (upper == null && lower == null)
            {
                if (_state.EyeContourUpper == null && _state.EyeContourLower == null) return true;
                _state.EyeContourUpper = null;
                _state.EyeContourLower = null;
                _state.Dirty = true;
                return true;
            }
            if (AtaaCore.ValidateEyeContour(upper, lower) != null) return false;
            if (SamePoints(upper, _state.EyeContourUpper) && SamePoints(lower, _state.EyeContourLower)) return true;
            _state.EyeContourUpper = (Vector2[])upper.Clone();
            _state.EyeContourLower = (Vector2[])lower.Clone();
            _state.Dirty = true;
            return true;
        }

        private static bool SamePoints(Vector2[] a, Vector2[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++)
                if (a[i] != b[i]) return false;
            return true;
        }

        public void RemoveControlPoint(int index)
        {
            if (index < 0 || index >= _state.Points.Count) return;

            string category = FaceTemplate.CategoryOf(_state.Points[index].Label);
            _state.Points.RemoveAt(index);

            // その分類の領域が 1 つもなくなったら、サイズも捨てる（保存しないので意味がない）
            if (category != null && !_state.Points.Exists(p => FaceTemplate.CategoryOf(p.Label) == category))
            {
                _state.Sizes.Remove(category);
                if (category == FaceMapFile.EyeCategory)
                {
                    _state.EyeLine = null;
                    _state.EyeLowerLine = null;
                    _state.NoEyeOpening = false;
                }
                if (category == FaceMapFile.MouthCategory)
                {
                    _state.MouthLine = null;
                    _state.MouthLinePoints = null;
                }
            }

            _state.Dirty = true;
        }

        public void ResetControlPoints()
        {
            _state.Points.Clear();
            _state.Sizes.Clear();
            _state.EyeLine = null;
            _state.EyeLowerLine = null;
            _state.NoEyeOpening = false;
            _state.MouthLine = null;
            _state.MouthLinePoints = null;
            _state.Dirty = true;
        }

        public void SetPosition(int index, Vector2 uv)
        {
            if (index < 0 || index >= _state.Points.Count) return;

            FaceMapPoint p = _state.Points[index];
            float x = Mathf.Clamp01(uv.x);
            float y = Mathf.Clamp01(uv.y);
            if (p.X == x && p.Y == y) return;

            p.X = x;
            p.Y = y;
            _state.Dirty = true;

            // 鼻から仮に決めた中心線は、鼻に追従する
            if (_state.CenterXFromNose && string.Equals(p.Label, FaceTemplate.NoseLabel, StringComparison.Ordinal))
                _state.CenterX = x;
        }

        // ── 中心線とミラー配置（FaceMap 仕様 v0.4 §12.4）──

        /// <summary>この差より小さい変化は「動いていない」とみなす（揃える操作で Dirty にしないため）。</summary>
        private const float PositionEpsilon = 1e-6f;

        /// <summary>中心線を c にする（0〜1 に収める）。点は動かさない。</summary>
        public void SetCenterX(float c)
        {
            float v = Mathf.Clamp01(c);

            // 明示的に決めた中心線は確定値として保存する（値が同じでも、仮の値から確定に変わる）
            bool wasProvisional = _state.CenterXFromNose;
            _state.CenterXFromNose = false;
            if (_state.CenterX.HasValue && Mathf.Abs(_state.CenterX.Value - v) < PositionEpsilon)
            {
                if (wasProvisional) _state.Dirty = true;
                return;
            }

            _state.CenterX = v;
            _state.Dirty = true;
        }

        /// <summary>
        /// 中心線（確定済みが前提）に対して、左右ペアをクリック位置の側で置く。withPartner なら相方を鏡像に置く
        /// （既にあれば鏡像の位置へ移す）。置いた点（相方ではない方）の index を返す。置けなければ -1。
        /// </summary>
        public int PlacePair(string category, Vector2 click, bool withPartner)
        {
            if (!_state.CenterX.HasValue) return -1;
            float c = _state.CenterX.Value;

            if (!FaceMapMirror.ResolvePairPlacement(category, click, c, withPartner, out string label, out Vector2 pos))
                return -1;

            FaceTemplateEntry entry = FaceTemplate.Find(label);
            if (entry == null) return -1;

            Place(entry, pos);

            if (withPartner)
            {
                FaceTemplateEntry partner = FaceTemplate.Find(FaceMapMirror.PartnerLabel(label));
                if (partner != null) Place(partner, FaceMapMirror.Mirror(pos, c));
            }

            // 相方の追加で index は変わらない（末尾に追加される）が、念のため label で引き直す
            return IndexOf(label);
        }

        /// <summary>
        /// 相対ミラーの移動。index の点を from から delta 動かし、相方を partnerFrom から (−dx, dy) 動かす。
        /// partnerFrom が null なら相方は動かさない（片側のみ・相方なし）。中心線は確定済みが前提。
        /// </summary>
        public void MoveRelative(int index, Vector2 from, Vector2? partnerFrom, Vector2 delta)
        {
            if (index < 0 || index >= _state.Points.Count || !_state.CenterX.HasValue) return;

            FaceMapPoint p = _state.Points[index];
            int partnerIndex = partnerFrom.HasValue ? IndexOf(FaceMapMirror.PartnerLabel(p.Label)) : -1;
            Vector2? q = partnerIndex >= 0 ? partnerFrom : null;

            FaceMapMirror.RelativeMove(from, FaceMapMirror.IsLeft(p.Label), q, _state.CenterX.Value, delta,
                                       out Vector2 newP, out Vector2 newQ);

            SetPosition(index, newP);
            if (partnerIndex >= 0) SetPosition(partnerIndex, newQ);
        }

        /// <summary>
        /// 「ミラーで揃える」。左右ペアは対称に、片方だけなら相方を鏡像に置き、中央パーツは x = c にする。
        /// 1 つでも点が動いたら true。中心線が未確定なら何もしない。
        /// </summary>
        public bool AlignMirror()
        {
            if (!_state.CenterX.HasValue) return false;
            float c = _state.CenterX.Value;
            bool changed = false;

            foreach (FaceTemplateEntry entry in FaceTemplate.Entries)
            {
                if (FaceMapMirror.IsCenterPart(entry.Label))
                {
                    int i = IndexOf(entry.Label);
                    if (i >= 0) changed |= SetIfMoved(i, new Vector2(c, _state.Points[i].Y));
                    continue;
                }

                // 左右ペアは左側の項目で 1 回だけ処理する
                if (!FaceMapMirror.IsPair(entry.Label) || !FaceMapMirror.IsLeft(entry.Label)) continue;

                string rightLabel = FaceMapMirror.PartnerLabel(entry.Label);
                int li = IndexOf(entry.Label);
                int ri = IndexOf(rightLabel);

                if (li >= 0 && ri >= 0)
                {
                    if (FaceMapMirror.AlignPair(_state.Points[li].Uv, _state.Points[ri].Uv, c,
                                                out Vector2 nl, out Vector2 nr))
                    {
                        changed |= SetIfMoved(li, nl);
                        changed |= SetIfMoved(ri, nr);
                    }
                }
                else if (li >= 0 || ri >= 0)
                {
                    // 片方だけ: 両方あるときと同じ規則（半幅を最小半幅〜はみ出さない範囲に収め、左右を正しい側に置く）
                    int existing = li >= 0 ? li : ri;
                    bool existingIsLeft = li >= 0;
                    FaceTemplateEntry missing = FaceTemplate.Find(existingIsLeft ? rightLabel : entry.Label);
                    Vector2 p = _state.Points[existing].Uv;
                    if (missing != null && FaceMapMirror.AlignPair(p, p, c, out Vector2 nl, out Vector2 nr))
                    {
                        changed |= SetIfMoved(existing, existingIsLeft ? nl : nr);
                        Place(missing, existingIsLeft ? nr : nl);
                        changed = true;
                    }
                }
            }

            return changed;
        }

        /// <summary>
        /// 左右ペアの間隔を変える（§12.4「左右の間隔」）。amount &gt; 0 で狭める（左を右へ、右を左へ）、&lt; 0 で広げる。
        /// 中心線が確定していればそれを、なければペアの中点を基準にし、中心線を越えない・0〜1 に収める
        /// （相対ミラーと同じ制約。上下の位置は変えない）。両方置いてあるときだけ動く。
        /// </summary>
        public bool ChangePairGap(string category, float amount)
        {
            int li = IndexOf(FaceMapMirror.PairLabel(category, true));
            int ri = IndexOf(FaceMapMirror.PairLabel(category, false));
            if (li < 0 || ri < 0) return false;

            Vector2 l = _state.Points[li].Uv, r = _state.Points[ri].Uv;
            float c = _state.CenterX ?? (l.x + r.x) * 0.5f;

            FaceMapMirror.RelativeMove(l, true, r, c, new Vector2(amount, 0f), out Vector2 nl, out Vector2 nr);
            bool changed = SetIfMoved(li, nl);
            changed |= SetIfMoved(ri, nr);
            return changed;
        }

        /// <summary>中央パーツの x を中心線に合わせる（中心線が未確定なら何もしない）。</summary>
        public bool SnapToCenter(int index)
        {
            if (index < 0 || index >= _state.Points.Count || !_state.CenterX.HasValue) return false;
            return SetIfMoved(index, new Vector2(_state.CenterX.Value, _state.Points[index].Y));
        }

        private bool SetIfMoved(int index, Vector2 uv)
        {
            FaceMapPoint p = _state.Points[index];
            if (Mathf.Abs(p.X - uv.x) < PositionEpsilon && Mathf.Abs(p.Y - uv.y) < PositionEpsilon) return false;

            SetPosition(index, uv);
            return true;
        }
    }
}
