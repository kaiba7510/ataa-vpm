using System.Globalization;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディター（UI Toolkit 版）の表示の判断。ウィンドウの外に出して、EditMode テストで確かめられるようにする。
    /// IMGUI・UI Toolkit の状態は読まない（値だけを受け取る）。
    /// </summary>
    public static class FaceMapEditorUi
    {
        // ── ツールバー・保存 ──

        public static bool CanSave(int placedRequired, int requiredCount) => placedRequired >= requiredCount;

        public static string SaveBlockedTip(int placedRequired, int requiredCount) =>
            CanSave(placedRequired, requiredCount) ? "" : $"必須の領域があと {requiredCount - placedRequired} 個です。";

        /// <summary>入力欄の値が今の値と同じか（null と空は同じ扱い）。同じなら未保存にしない。</summary>
        public static bool IsSameText(string newValue, string current) => (newValue ?? "") == (current ?? "");

        /// <summary>閉じる・破棄の前に「未保存の変更」を確認するか。変更があり、かつ点を置いた・アバターを指定したときだけ。</summary>
        public static bool NeedsSavePrompt(bool dirty, int pointCount, bool hasAvatar) =>
            dirty && (pointCount > 0 || hasAvatar);

        /// <summary>今どのメイク基準を編集しているか（ファイル名、未保存なら「新規・未保存」）と、変更ありの「 *」。</summary>
        public static string FileLabel(string boundPath, bool dirty)
        {
            string file = string.IsNullOrEmpty(boundPath) ? "（新規・未保存）" : System.IO.Path.GetFileName(boundPath);
            return dirty ? file + " *" : file;
        }

        /// <summary>
        /// 新規保存時の既定ファイル名（拡張子なし）。
        /// ファイル名欄 → 名前 → 対応アバター名 → 顔テクスチャ名 → "facemap" の順に採用する。
        /// </summary>
        public static string ResolveFileName(string fileNameOverride, string name, string targetAvatarName, string textureName)
        {
            string resolved = FaceMapSerializer.SanitizeFileName(fileNameOverride);
            if (resolved.Length == 0) resolved = FaceMapSerializer.SanitizeFileName(name);
            if (resolved.Length == 0) resolved = FaceMapSerializer.SanitizeFileName(targetAvatarName);
            if (resolved.Length == 0) resolved = FaceMapSerializer.SanitizeFileName(textureName);
            return resolved.Length > 0 ? resolved : "facemap";
        }

        public static string RequiredPill(int placed, int required) => $"{placed} / {required}";

        /// <summary>「保存して完了」の下の案内。</summary>
        public static string SaveHint(int placed, int required) =>
            CanSave(placed, required)
                ? "必須の領域がそろいました。保存できます。"
                : $"必須 {required} 箇所（目・頬・鼻・口）を配置すると保存できます（あと {required - placed}）";

        // ── ビュー上のオーバーレイ ──

        public static bool ShowDropCard(bool hasTexture) => !hasTexture;

        /// <summary>倍率（全体表示を 100% とする）。</summary>
        public static string ZoomText(float zoom) => $"{Mathf.RoundToInt(zoom * 100f)}%";

        public static string UvText(Vector2 uv) =>
            string.Format(CultureInfo.InvariantCulture, "UV ({0:0.000}, {1:0.000})", uv.x, uv.y);

        /// <summary>u の目盛りの x（ビューの座標）。ビュー（clip）の外なら null。</summary>
        public static float? RulerX(float u, Rect texRect, Rect clip)
        {
            float x = texRect.x + u * texRect.width;
            return x < clip.xMin || x > clip.xMax ? (float?)null : x;
        }

        /// <summary>v の目盛りの y（ビューの座標。v は左下が原点なので上下が逆）。ビューの外なら null。</summary>
        public static float? RulerY(float v, Rect texRect, Rect clip)
        {
            float y = texRect.y + (1f - v) * texRect.height;
            return y < clip.yMin || y > clip.yMax ? (float?)null : y;
        }

        // ── 矢印キーの微調整 ──

        public static Vector2? NudgeDirection(KeyCode key)
        {
            switch (key)
            {
                case KeyCode.UpArrow: return Vector2.up;
                case KeyCode.DownArrow: return Vector2.down;
                case KeyCode.LeftArrow: return Vector2.left;
                case KeyCode.RightArrow: return Vector2.right;
                default: return null;
            }
        }

        public static bool AcceptsNudgeKey(bool ctrlOrCommand, bool textInputFocused, bool dragging, int selected, int pointCount) =>
            !ctrlOrCommand && !textInputFocused && !dragging && selected >= 0 && selected < pointCount;

        // ── 目の線・口の線スライダーの受け付け条件 ──

        /// <summary>目の線スライダーの変更を受け付けるか（目を選択中で、目の線が ON のときだけ）。</summary>
        public static bool AcceptsEyeLineChange(string selectedCategory, bool hasEyeLine) =>
            selectedCategory == FaceMapFile.EyeCategory && hasEyeLine;

        /// <summary>目の下の線スライダーの変更を受け付けるか（目を選択中で、目の線と目の下の線の両方が ON のときだけ）。</summary>
        public static bool AcceptsEyeLowerLineChange(string selectedCategory, bool hasEyeLine, bool hasEyeLowerLine) =>
            selectedCategory == FaceMapFile.EyeCategory && hasEyeLine && hasEyeLowerLine;

        /// <summary>口の線スライダーの変更を受け付けるか（口を選択中で、口の線が ON のときだけ）。</summary>
        public static bool AcceptsMouthLineChange(string selectedCategory, bool hasMouthLine) =>
            selectedCategory == FaceMapFile.MouthCategory && hasMouthLine;

        // ── 顔パレット ──

        public enum PartRing
        {
            None,
            Selected,
            Check
        }

        /// <summary>パレットのパーツボタンの見た目。Fill/Border/Text はパーツ色の不透明度。</summary>
        public struct PartVisual
        {
            public float Fill;
            public float Border;
            public float Text;
            public PartRing Ring;

            /// <summary>次に置くパーツ（黄色く点滅）。</summary>
            public bool Pulse;
        }

        public static PartVisual PaletteVisual(FaceMapEditorViewModel.PartState state, bool isNext, bool isCheck)
        {
            bool lit = state != FaceMapEditorViewModel.PartState.Unplaced;
            var v = new PartVisual
            {
                Fill = lit ? 0.25f : 0.10f,
                Border = lit ? 0.75f : 0.35f,
                Text = lit ? 1f : 0.7f,
                Pulse = isNext,
                Ring = state == FaceMapEditorViewModel.PartState.Selected ? PartRing.Selected
                    : isCheck ? PartRing.Check
                    : PartRing.None,
            };
            return v;
        }
    }
}
