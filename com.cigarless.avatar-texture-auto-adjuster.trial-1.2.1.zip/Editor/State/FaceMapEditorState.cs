// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/State/FaceMapEditorState.cs
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap エディターが編集中のデータ。メイクフィックス画面の状態とは独立している。
    /// </summary>
    public class FaceMapEditorState
    {
        /// <summary>領域を置くときの背景に表示する顔テクスチャ（FaceMap には保存しない）。</summary>
        public Texture2D Texture;

        /// <summary>targetAvatar の入力補助。アバターを指定すると名前が TargetAvatarName に入る。</summary>
        public GameObject TargetAvatarObject;
        public string TargetAvatarName = "";

        public string Name = "";

        /// <summary>新規保存時のファイル名（拡張子なし）。空なら Name から自動生成。</summary>
        public string FileNameOverride = "";

        /// <summary>置いた領域の中心点。label はテンプレートのものだけ。</summary>
        public List<FaceMapPoint> Points = new List<FaceMapPoint>();

        /// <summary>分類ごとの領域サイズ（x = 全幅, y = 全高。UV）。左右ペアは共有。</summary>
        public Dictionary<string, Vector2> Sizes = new Dictionary<string, Vector2>(StringComparer.Ordinal);

        /// <summary>
        /// 顔の中心線の u（ミラー配置用。FaceMap 仕様 v0.4 §12.4）。null なら未確定。
        /// 「すべて削除」では消さず、「新規」で未確定に戻る。
        /// </summary>
        public float? CenterX;

        /// <summary>
        /// CenterX が、読み込んだファイルの centerX ではなく鼻_中央の x から仮に決めた値か。
        /// 仮の値はファイルに書かず、鼻を動かすと追従する。中心線を明示的に決めると false になる。
        /// </summary>
        public bool CenterXFromNose;

        /// <summary>目の線の高さ（目の領域の下端 0〜上端 1。FaceMap 仕様 v0.4 §4.2）。null なら無し。</summary>
        public float? EyeLine;

        /// <summary>目の下の線の高さ（v0.4 §4.2）。null なら無し。</summary>
        public float? EyeLowerLine;

        /// <summary>目の開いていない素体か（FaceMapFile.NoEyeOpening）。</summary>
        public bool NoEyeOpening;

        /// <summary>口の線（上唇と下唇の合わせ目）の高さ（口の領域の下端 0〜上端 1）。null なら無し。</summary>
        public float? MouthLine;

        /// <summary>口の線の折れ線（FaceMapFile.MouthLinePoints。水平なら null。MouthLine が null なら必ず null）。</summary>
        public Vector2[] MouthLinePoints;

        /// <summary>読み込み元の meta（JSON。FaceMapFile.MetaJson）。上書き保存で消えないよう保持する。</summary>
        public string MetaJson;

        /// <summary>読み込み元（または前回保存先）の絶対パス。null なら未保存の新規データ。</summary>
        public string BoundPath;

        public bool Dirty;

        public string Warning = "";
        public MessageType WarningType = MessageType.Info;

        public FaceMapFile ToFile()
        {
            var file = new FaceMapFile
            {
                Name = Name,
                TargetAvatar = TargetAvatarName,
                MetaJson = MetaJson,
                // 鼻から仮に決めた中心線は保存しない（確定させたものだけ centerX に書く）
                CenterX = CenterXFromNose ? null : CenterX,
                EyeLine = EyeLine,
                EyeLowerLine = EyeLowerLine,
                NoEyeOpening = NoEyeOpening,
                MouthLine = MouthLine,
                MouthLinePoints = MouthLine.HasValue ? MouthLineShape.Clone(MouthLinePoints) : null
            };

            // テンプレートの定義順に並べて保存する（ファイルの差分が安定する）
            foreach (FaceTemplateEntry entry in FaceTemplate.Entries)
            {
                FaceMapPoint p = Points.Find(pt => string.Equals(pt.Label, entry.Label, StringComparison.Ordinal));
                if (p != null) file.Points.Add(new FaceMapPoint(p.X, p.Y, p.Label));
            }
            foreach (var kv in Sizes) file.Sizes[kv.Key] = kv.Value;
            return file;
        }

        public void LoadFrom(FaceMapFile file, string path)
        {
            Name = file.Name ?? "";
            TargetAvatarName = file.TargetAvatar ?? "";
            TargetAvatarObject = null;
            MetaJson = file.MetaJson;
            Points = new List<FaceMapPoint>();
            foreach (FaceMapPoint p in file.Points)
                Points.Add(new FaceMapPoint(p.X, p.Y, p.Label));
            Sizes = new Dictionary<string, Vector2>(file.Sizes, StringComparer.Ordinal);
            EyeLine = file.EyeLine;
            EyeLowerLine = file.EyeLowerLine;
            NoEyeOpening = file.NoEyeOpening;
            MouthLine = file.MouthLine;
            MouthLinePoints = MouthLineShape.Clone(file.MouthLinePoints);

            // 中心線の初期値: centerX → 鼻_中央の x → 未確定（0.5 は仮定しない）
            CenterX = file.CenterX;
            CenterXFromNose = false;
            if (!CenterX.HasValue)
            {
                FaceMapPoint nose = Points.Find(pt => string.Equals(pt.Label, FaceTemplate.NoseLabel, StringComparison.Ordinal));
                if (nose != null)
                {
                    CenterX = nose.X;
                    CenterXFromNose = true;
                }
            }

            BoundPath = path;
            FileNameOverride = "";
            Dirty = false;
        }

        public void Clear()
        {
            Name = "";
            TargetAvatarName = "";
            TargetAvatarObject = null;
            FileNameOverride = "";
            MetaJson = null;
            Points = new List<FaceMapPoint>();
            Sizes = new Dictionary<string, Vector2>(StringComparer.Ordinal);
            CenterX = null;
            CenterXFromNose = false;
            EyeLine = null;
            EyeLowerLine = null;
            NoEyeOpening = false;
            MouthLine = null;
            MouthLinePoints = null;
            BoundPath = null;
            Dirty = false;
        }

    }
}
