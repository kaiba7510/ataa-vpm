using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── 中央ペイン (UI Toolkit + IMGUIContainer 3D/2D ステージ) ──

        private IMGUIContainer _viewportImgui;
        private Button _btnMode3D;
        private Button _btnMode2D;
        private VisualElement _vpControls3D;
        private VisualElement _vpControls2D;
        private Button _btnToggleDeco;
        private Button _btnToggleLight;
        private Button _btnCycleBackground;
        private Button _btnResetFront;
        private Button[] _btn2DModes;
        private Label _lbl2DZoom;
        private Button _btn2DResetZoom;
        private Button _btnToggleLive;

        private VisualElement _vpStatusPill;
        private Label _lblVpStatus;
        private VisualElement _viewportHints;

        private VisualElement _btnTrialHighRes;
        private Label _lblTrialHighResText;
        private VisualElement _btnCompare;
        private Label _lblCompareText;

        private VisualElement _vpHints3D;
        private VisualElement _vpHints2D;
        private Label _lblVpMeta;

        private string _lastHintsSig;
        private bool _pointerOverViewport;

        private void BindCenterUi()
        {
            _viewportImgui = _root.Q<IMGUIContainer>("viewport-imgui");
            _viewportImgui.onGUIHandler = OnViewportImgui;
            _viewportImgui.RegisterCallback<PointerEnterEvent>(_ => _pointerOverViewport = true);
            _viewportImgui.RegisterCallback<PointerLeaveEvent>(_ => _pointerOverViewport = false);
            _viewportImgui.RegisterCallback<PointerDownEvent>(_ =>
            {
                _centerFocused = true;
                rootVisualElement.Focus();
            }, TrickleDown.TrickleDown);

            _btnMode3D = _root.Q<Button>("btn-mode-3d");
            _btnMode2D = _root.Q<Button>("btn-mode-2d");
            _vpControls3D = _root.Q<VisualElement>("vp-controls-3d");
            _vpControls2D = _root.Q<VisualElement>("vp-controls-2d");

            _btnToggleDeco = _root.Q<Button>("btn-toggle-deco");
            _btnToggleLight = _root.Q<Button>("btn-toggle-light");
            _btnCycleBackground = _root.Q<Button>("btn-cycle-background");
            _btnResetFront = _root.Q<Button>("btn-reset-front");

            _btn2DModes = new[]
            {
                _root.Q<Button>("btn-2d-result"),
                _root.Q<Button>("btn-2d-before"),
                _root.Q<Button>("btn-2d-makeup"),
                _root.Q<Button>("btn-2d-mask")
            };
            _lbl2DZoom = _root.Q<Label>("lbl-2d-zoom");
            _btn2DResetZoom = _root.Q<Button>("btn-2d-reset-zoom");
            _btnToggleLive = _root.Q<Button>("btn-toggle-live");

            _vpStatusPill = _root.Q<VisualElement>("vp-status-pill");
            _lblVpStatus = _root.Q<Label>("lbl-vp-status");
            _viewportHints = _root.Q<VisualElement>("viewport-hints");

            _btnTrialHighRes = _root.Q<VisualElement>("btn-trial-highres");
            _lblTrialHighResText = _root.Q<Label>("lbl-trial-highres-text");
            _btnCompare = _root.Q<VisualElement>("btn-compare");
            _lblCompareText = _root.Q<Label>("lbl-compare-text");

            _vpHints3D = _root.Q<VisualElement>("vp-hints-3d");
            _vpHints2D = _root.Q<VisualElement>("vp-hints-2d");
            _lblVpMeta = _root.Q<Label>("lbl-vp-meta");

            _btnMode3D.clicked += () => SwitchCenterMode(CenterMode.View3D);
            _btnMode2D.clicked += () => SwitchCenterMode(CenterMode.Uv2D);

            _btnToggleDeco.tooltip = "前髪・メガネなどを一時的に隠して、顔メッシュだけを映します（H キー）。シーンには保存されません。";
            _btnToggleDeco.clicked += () =>
            {
                SetHideDecorations(!(_orbit != null && _orbit.HideDecorations));
                MarkUiDirty();
            };

            _btnToggleLight.tooltip = "カメラに追従するライトで照らします（暗いワールドでも発色と境界を確認できます）。";
            _btnToggleLight.clicked += () =>
            {
                if (_orbit == null) return;
                bool next = !_orbit.AuxiliaryLight;
                _orbit.AuxiliaryLight = next;
                EditorPrefs.SetBool(AuxLightKey, next);
                MarkUiDirty();
            };

            _btnCycleBackground.tooltip = BackgroundTooltip;
            _btnCycleBackground.clicked += () =>
            {
                CycleBackground();
                MarkUiDirty();
            };

            _btnResetFront.tooltip = "カメラを顔の正面・既定の距離に戻します。";
            _btnResetFront.clicked += () =>
            {
                _orbit?.ResetToFront();
                MarkUiDirty();
            };

            for (int i = 0; i < _btn2DModes.Length; i++)
            {
                int idx = i;
                _btn2DModes[i].clicked += () =>
                {
                    _viewMode = (FaceMapPreview.ViewMode)idx;
                    MarkUiDirty();
                };
            }

            _btn2DResetZoom.clicked += () =>
            {
                ResetZoom();
                MarkUiDirty();
            };

            _btnToggleLive.tooltip = "調整中の結果を、シーン上のアバター（と 3D 顔ビュー）に一時的に表示します（保存されません）。";
            _btnToggleLive.clicked += () =>
            {
                LiveEnabled = !LiveEnabled;
                SyncLive();
                MarkUiDirty();
            };

            // Floating Hold-to-HighRes Button (Trial only)
            int highResPointer = -1;
            if (_btnTrialHighRes != null)
            {
                _btnTrialHighRes.tooltip = MakeFixTrialPreview.ButtonTooltip;
                _btnTrialHighRes.RegisterCallback<PointerDownEvent>(evt =>
                {
                    if (evt.button != 0 || !MakeFixTrialPreview.ShouldShowButton(AtaaCore.Edition, _showPreview)) return;
                    highResPointer = evt.pointerId;
                    _btnTrialHighRes.CapturePointer(highResPointer);
                    _trialHighResHeld = true;
                    UpdateTrialHighRes();
                    MarkUiDirty();
                    evt.StopPropagation();
                });
                Action releaseHighRes = () =>
                {
                    if (highResPointer >= 0 && _btnTrialHighRes.HasPointerCapture(highResPointer))
                        _btnTrialHighRes.ReleasePointer(highResPointer);
                    highResPointer = -1;
                    if (_trialHighResHeld)
                    {
                        _trialHighResHeld = false;
                        UpdateTrialHighRes();
                        MarkUiDirty();
                    }
                };
                _btnTrialHighRes.RegisterCallback<PointerUpEvent>(_ => releaseHighRes());
                _btnTrialHighRes.RegisterCallback<PointerCaptureOutEvent>(_ => releaseHighRes());
            }

            // Floating Hold-to-Compare Button
            int comparePointer = -1;
            _btnCompare.tooltip = "押している間（または C キーを押している間）だけ、最初の顔テクスチャ（メイク前）を表示します。";
            _btnCompare.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || !_showPreview) return;
                comparePointer = evt.pointerId;
                _btnCompare.CapturePointer(comparePointer);
                _compareMouseHeld = true;
                UpdateComparing();
                MarkUiDirty();
                evt.StopPropagation();
            });
            Action releaseCompare = () =>
            {
                if (comparePointer >= 0 && _btnCompare.HasPointerCapture(comparePointer))
                    _btnCompare.ReleasePointer(comparePointer);
                comparePointer = -1;
                if (_compareMouseHeld)
                {
                    _compareMouseHeld = false;
                    UpdateComparing();
                    MarkUiDirty();
                }
            };
            _btnCompare.RegisterCallback<PointerUpEvent>(_ => releaseCompare());
            _btnCompare.RegisterCallback<PointerCaptureOutEvent>(_ => releaseCompare());

            _lastHintsSig = null;
        }

        private void SwitchCenterMode(CenterMode next)
        {
            if (_centerMode == next) return;
            _centerMode = next;
            EditorPrefs.SetInt(CenterModeKey, (int)next);
            if (_orbit != null) _orbit.SoloRenderer = _centerMode == CenterMode.View3D ? _hoveredFaceRenderer : null;
            _panning = false;
            ReleasePreviewHotControl();
            _orbit?.CancelDrag();
            if (_previewDrag != PreviewDrag.None) EndPreviewDrag();
            _orbit?.MarkDirty();
            MarkUiDirty();
        }

        private void OnViewportImgui()
        {
            InitStyles();
            Rect area = _viewportImgui.contentRect;
            if (area.width <= 1f || area.height <= 1f) return;

            _centerRect = area;
            RecoverLostPreviewDrag();

            if (_centerMode == CenterMode.View3D)
            {
                Draw3DCanvasForUiToolkit(area);
            }
            else
            {
                Draw2DCanvasForUiToolkit(area);
            }
        }

        private void Draw3DCanvasForUiToolkit(Rect area)
        {
            if (_orbit == null || !_orbit.HasTarget)
            {
                if (Event.current.type == EventType.Repaint)
                {
                    EditorGUI.DrawRect(area, new Color(0.125f, 0.125f, 0.125f));
                    GUI.Label(area, "左のアバター管理でシーン上のアバターを選ぶと、顔がここに映ります", _emptyViewStyle);
                }
                return;
            }

            if (_orbit.HandleInput(area)) _viewportImgui.MarkDirtyRepaint();
            if (Event.current.type == EventType.Repaint) _orbit.Draw(area);
        }

        private void Draw2DCanvasForUiToolkit(Rect area)
        {
            if (_showPreview)
            {
                Rect texRect = PreviewTexRect(area);
                ProcessPreviewEvents(area, texRect);
                if (Event.current.type == EventType.Repaint)
                {
                    DrawPreview(area, PreviewTexRect(area));
                }
            }
            else if (Event.current.type == EventType.Repaint)
            {
                EditorGUI.DrawRect(area, new Color(0.125f, 0.125f, 0.125f));
                string text = _state.PairMatch == null && _state.PairError == null && _state.HasPair
                    ? "読み込み中..."
                    : "準備が揃うと、ここにプレビューが出ます";
                GUI.Label(area, text, _emptyViewStyle);
            }
        }

        private void RefreshCenterUi()
        {
            bool is3D = _centerMode == CenterMode.View3D;
            _btnMode3D.EnableInClassList("vp-tab-btn--active", is3D);
            _btnMode2D.EnableInClassList("vp-tab-btn--active", !is3D);

            _vpControls3D.EnableInClassList("hidden", !is3D);
            _vpControls2D.EnableInClassList("hidden", is3D);
            _vpHints3D.EnableInClassList("hidden", !is3D);
            _vpHints2D.EnableInClassList("hidden", is3D);

            if (is3D)
            {
                bool hide = _orbit != null && _orbit.HideDecorations;
                _btnToggleDeco.text = hide ? "装飾品: 非表示" : "装飾品: 表示";
                _btnToggleDeco.EnableInClassList("vp-toggle-btn--on", !hide);

                bool aux = _orbit != null && _orbit.AuxiliaryLight;
                _btnToggleLight.text = aux ? "補助ライト: ON" : "補助ライト: OFF";
                _btnToggleLight.EnableInClassList("vp-toggle-btn--on", aux);

                _btnCycleBackground.text = ViewportBackground.Label(_orbit != null ? _orbit.Background : ViewportBackground.Default);

                _btnResetFront.SetEnabled(_orbit != null && _orbit.HasTarget);
                _lblVpMeta.text = "3D Orbit • Interactive";
            }
            else
            {
                for (int i = 0; i < _btn2DModes.Length; i++)
                {
                    _btn2DModes[i].SetEnabled(_showPreview);
                    _btn2DModes[i].EnableInClassList("vp-sub-btn--active", (int)_viewMode == i);
                }
                int pct = Mathf.RoundToInt(_zoom * 100f);
                _lbl2DZoom.text = $"{pct}%";
                _btn2DResetZoom.SetEnabled(_showPreview);
                _lblVpMeta.text = $"2D UV • Zoom: {pct}%";
            }

            _btnToggleLive.text = LiveEnabled ? "調整を表示: ON" : "調整を表示: OFF";
            _btnToggleLive.EnableInClassList("vp-live-btn--on", LiveEnabled);
            _btnToggleLive.EnableInClassList("vp-live-btn--off", !LiveEnabled);

            RefreshViewportStatusPill(is3D);
            RefreshTrialHighResButton();
            RefreshCompareButton();
            RefreshViewportHints(is3D);
        }

        private void RefreshViewportStatusPill(bool is3D)
        {
            bool showingResult = is3D
                ? (_live != null && _live.IsAttached)
                : (_showPreview && _viewMode == FaceMapPreview.ViewMode.Result);

            ApplyState apply = CurrentApplyState();
            string text, tip, cls;

            if (_comparing && _showPreview)
            {
                text = "比較中: メイク前";
                tip = "「比較」を押している間は、メイク前の顔テクスチャを表示しています。";
                cls = "vp-status-pill--warn";
            }
            else if (showingResult)
            {
                switch (apply)
                {
                    case ApplyState.Current:
                        text = "適用済み";
                        tip = "アバターにメイクが適用されています。映っているのは調整中の結果で、適用した内容と同じです。";
                        cls = "vp-status-pill--ok";
                        break;
                    case ApplyState.Stale:
                        text = "プレビュー中 (変更は未適用)";
                        tip = "適用した後に調整を変えました。「メイク適用」で反映します。";
                        cls = "vp-status-pill--warn";
                        break;
                    default:
                        if (AtaaCore.Edition == CoreEdition.Trial)
                        {
                            MakeFixTrialPreview.StatusInfo info =
                                MakeFixTrialPreview.StatusPill(IsTrialHighResActive, TrialHighOutputReady);
                            text = info.Text;
                            tip = info.Tooltip;
                        }
                        else
                        {
                            text = "プレビュー中 (未適用)";
                            tip = "調整中の結果を一時的に表示しています。アバターのマテリアルはまだ変わっていません。";
                        }
                        cls = "vp-status-pill--accent";
                        break;
                }
            }
            else if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                // 再生中はライブプレビューも適用もしない。ツールチップだけだと気づけないので、表示自体に出す
                text = "再生中のため停止中";
                tip = "再生モード中（一時停止を含む）は、調整中のメイクの表示と適用を止めています。再生を止めると再開します。";
                cls = "vp-status-pill--warn";
            }
            else
            {
                string why = !LiveEnabled ? "「調整を表示」が OFF です。" : (_liveReason ?? "調整中の結果はまだ映せません。");
                switch (apply)
                {
                    case ApplyState.Current:
                        text = "適用済み";
                        tip = why + "\n映っているのは、アバターに適用したメイクです。";
                        cls = "vp-status-pill--ok";
                        break;
                    case ApplyState.Stale:
                        text = "適用済み (変更は未反映)";
                        tip = why + "\n調整の変更は「メイク適用」で反映します。";
                        cls = "vp-status-pill--warn";
                        break;
                    default:
                        text = "元の見た目";
                        tip = why + "\nアバターにはメイクが適用されていません。";
                        cls = "vp-status-pill--muted";
                        break;
                }
            }

            _lblVpStatus.text = text;
            _vpStatusPill.tooltip = tip;
            _vpStatusPill.RemoveFromClassList("vp-status-pill--accent");
            _vpStatusPill.RemoveFromClassList("vp-status-pill--ok");
            _vpStatusPill.RemoveFromClassList("vp-status-pill--warn");
            _vpStatusPill.RemoveFromClassList("vp-status-pill--muted");
            _vpStatusPill.AddToClassList(cls);
        }

        private void UpdateTrialHighRes()
        {
            if (IsTrialHighResActive) EnsureTrialHighPreview();
            else _preview.CancelTrialHigh();
            SyncLive();
            _orbit?.MarkDirty();
            Repaint();
        }

        private void RefreshTrialHighResButton()
        {
            if (_btnTrialHighRes == null) return;
            bool show = MakeFixTrialPreview.ShouldShowButton(AtaaCore.Edition, _showPreview);
            _btnTrialHighRes.EnableInClassList("hidden", !show);
            if (!show) return;

            bool active = IsTrialHighResActive;
            bool ready = TrialHighOutputReady;
            _btnTrialHighRes.EnableInClassList("trial-highres-btn--active", active);
            if (_lblTrialHighResText != null)
                _lblTrialHighResText.text = MakeFixTrialPreview.ButtonLabel(active, ready);
        }

        private void RefreshCompareButton()
        {
            _btnCompare.EnableInClassList("hidden", !_showPreview);
            _btnCompare.EnableInClassList("compare-btn--active", _comparing);
            _lblCompareText.text = _comparing ? "メイク前を表示中" : "押している間: メイク前";
        }

        private struct ViewportHintItem
        {
            public string Kind; // "ok", "info", "warn"
            public string Text;
            public string Tooltip;
            public string ActionLabel;
            public Action Action;
        }

        private void RefreshViewportHints(bool is3D)
        {
            var items = new List<ViewportHintItem>();

            if (is3D && _orbit != null && _orbit.HasTarget)
            {
                if (_orbit.SoloRenderer != null)
                {
                    items.Add(new ViewportHintItem
                    {
                        Kind = "info",
                        Text = $"メッシュ候補を表示中: {_orbit.SoloRenderer.name}（一覧から外すと戻ります）"
                    });
                }
                else if (_orbit.HideDecorations)
                {
                    items.Add(new ViewportHintItem { Kind = "info", Text = "装飾品: 非表示" });
                }
            }

            if (_setupOk)
            {
                ReadinessItem problem = MakeFixReadiness.FirstFailed(_readiness, 7, 8);
                if (problem != null)
                {
                    items.Add(BuildProblemHint(problem));
                }
                else if (!string.IsNullOrEmpty(_previewError))
                {
                    items.Add(new ViewportHintItem { Kind = "warn", Text = MakeFixReadiness.FirstLine(_previewError), Tooltip = _previewError });
                }
                else if (!string.IsNullOrEmpty(_preview.LastError))
                {
                    items.Add(new ViewportHintItem { Kind = "warn", Text = "プレビューを作れませんでした", Tooltip = _preview.LastError });
                }
                else if (_preview.Output != null && _preview.Distortion.HasFold)
                {
                    items.Add(BuildDistortionHint(_preview.Distortion, _state.PairMatch));
                }
                else if (IsCrossStyle(_state.PairMatch, out string from, out string to, out string styleDetail))
                {
                    items.Add(new ViewportHintItem
                    {
                        Kind = "info",
                        Text = $"顔立ちの系統が違う組み合わせです（{from} → {to}）。口の周りなどが崩れやすくなります",
                        Tooltip = styleDetail
                    });
                }

                if (_lowerLineNote != null)
                {
                    if (_lowerLineAvatarMissing)
                    {
                        items.Add(new ViewportHintItem
                        {
                            Kind = "warn",
                            Text = _lowerLineNote,
                            Tooltip = "「線を置く」で目の線のすぐ下に置きます（.adjust.json に保存され、FaceMap は変わりません）。",
                            ActionLabel = "線を置く",
                            Action = () => { PlaceAvatarLowerLine(); MarkUiDirty(); }
                        });
                    }
                    else
                    {
                        items.Add(new ViewportHintItem
                        {
                            Kind = "warn",
                            Text = _lowerLineNote,
                            Tooltip = "FaceMap エディターで、メイク元の FaceMap の目の領域に「目の下の線」を置いてください。",
                            ActionLabel = "FaceMap エディター",
                            Action = () => MyVrcToolFaceMapEditorWindow.ShowWindow()
                        });
                    }
                }

                FaceMapAdjustment pairAdj = _state.Adjustment;
                if (pairAdj != null && pairAdj.IsEnabled(FaceMapFile.MouthCategory) && AtaaCore.IsExtremeMouthScale(_state.PairMatch))
                {
                    items.Add(new ViewportHintItem
                    {
                        Kind = "warn",
                        Text = $"口の大きさがメイク元と大きく違います（約 {AtaaCore.RelativeMouthScale(_state.PairMatch):0.#} 倍）。唇が崩れることがあります",
                        ActionLabel = "口を合成しない",
                        Action = () =>
                        {
                            pairAdj.SetEnabled(FaceMapFile.MouthCategory, false);
                            MarkAdjustmentChanged();
                            MarkUiDirty();
                        }
                    });
                }

                if (_keepsAvatarEye)
                {
                    items.Add(new ViewportHintItem
                    {
                        Kind = "info",
                        Text = "メイク元は目の開いていない素体のため、目の開いた部分は対象の元の目を残します",
                        Tooltip = "メイク元の顔テクスチャには目の開いた部分が無く、上下のまぶたの縁が UV 上で重なっています。"
                    });
                }
            }

            string sig = "";
            for (int i = 0; i < items.Count; i++)
                sig += items[i].Kind + "|" + items[i].Text + "|" + items[i].ActionLabel + ";";
            if (sig == _lastHintsSig) return;
            _lastHintsSig = sig;

            _viewportHints.Clear();
            foreach (ViewportHintItem h in items)
            {
                var card = new VisualElement();
                card.AddToClassList("vp-hint-card");
                if (h.Kind == "warn") card.AddToClassList("vp-hint-card--warn");
                else if (h.Kind == "ok") card.AddToClassList("vp-hint-card--ok");
                card.tooltip = h.Tooltip ?? "";
                // カード自体にアクションが無いときはクリックを背面ビューへ通す
                card.pickingMode = h.Action != null ? PickingMode.Position : PickingMode.Ignore;

                var icon = new Label(h.Kind == "warn" ? "!" : h.Kind == "ok" ? "OK" : "i");
                icon.AddToClassList("vp-hint-icon");
                icon.pickingMode = PickingMode.Ignore;
                card.Add(icon);

                var lbl = new Label(h.Text);
                lbl.AddToClassList("vp-hint-text");
                lbl.pickingMode = PickingMode.Ignore;
                card.Add(lbl);

                if (!string.IsNullOrEmpty(h.ActionLabel) && h.Action != null)
                {
                    Action act = h.Action;
                    var btn = new Button(act) { text = h.ActionLabel };
                    btn.AddToClassList("mini-action-btn");
                    card.Add(btn);
                }

                _viewportHints.Add(card);
            }
        }

        private ViewportHintItem BuildProblemHint(ReadinessItem item)
        {
            switch (item.Fix)
            {
                case ReadinessFix.OpenFaceMapEditor:
                    return new ViewportHintItem
                    {
                        Kind = "warn",
                        Text = item.Message,
                        Tooltip = item.Detail,
                        ActionLabel = "FaceMap エディター",
                        Action = () => MyVrcToolFaceMapEditorWindow.ShowWindow()
                    };
                case ReadinessFix.EnableAllParts:
                    return new ViewportHintItem
                    {
                        Kind = "warn",
                        Text = item.Message,
                        Tooltip = item.Detail,
                        ActionLabel = "すべて ON",
                        Action = () => { EnableAllParts(); MarkUiDirty(); }
                    };
                default:
                    return new ViewportHintItem { Kind = "warn", Text = item.Message, Tooltip = item.Detail };
            }
        }

        private ViewportHintItem BuildDistortionHint(DistortionReport report, FaceMapMatch match)
        {
            if (report.HasVisibleInversion)
            {
                if (IsCrossStyle(match, out string from, out string to, out string styleDetail))
                {
                    return new ViewportHintItem
                    {
                        Kind = "info",
                        Text = $"顔立ちの系統が違う組み合わせ（{from} → {to}）のため、口の周りなどで補正しきれない箇所があります",
                        Tooltip = styleDetail
                    };
                }
                if (InvolvesDeformed(match))
                {
                    return new ViewportHintItem
                    {
                        Kind = "info",
                        Text = "デフォルメ寄りの顔立ちのため、口の周りなどで補正しきれない箇所があります"
                    };
                }
                return new ViewportHintItem
                {
                    Kind = "warn",
                    Text = $"パーツの周りで変形が折り返しています（{report.RemainingInvertedCells} か所）"
                };
            }

            return new ViewportHintItem
            {
                Kind = "ok",
                Text = $"パーツの周りの歪みを自動で補正しました (縁のずれ 最大 {report.MaxLockShift * 100f:0.0}%)"
            };
        }
    }
}
