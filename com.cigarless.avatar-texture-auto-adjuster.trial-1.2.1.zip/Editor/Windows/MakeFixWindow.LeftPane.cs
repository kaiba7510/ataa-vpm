using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── 左ペイン: アバター管理（3ペイン仕様 §3）──

        private void DrawLeftPane()
        {
            EditorGUILayout.BeginVertical(MakeFixGui.Pane, GUILayout.Width(LeftPanelWidth), GUILayout.ExpandHeight(true));
            float oldLabelWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = 90f;

            MakeFixGui.PaneHeader("アバター管理", "対象アバターと、その顔の基準を揃えます");
            _leftScroll = EditorGUILayout.BeginScrollView(_leftScroll);

            GameObject target = _state.TargetAvatar;
            bool avatarIsAsset = target != null && EditorUtility.IsPersistent(target);
            bool avatarOk = target != null && !avatarIsAsset;
            bool faceOk = avatarOk && _state.FaceRenderer != null;
            bool mapOk = _state.AvatarFaceMap != null && _state.AvatarFaceMap.IsValid;
            bool texOk = _state.PreviewAvatarTexture != null;

            // 1. アバター
            MakeFixGui.BeginCard("アバター", "シーン上のアバターをドラッグ＆ドロップ、または一覧から選びます。", 1,
                avatarIsAsset ? MakeFixGui.StepState.Problem : StepStateOf(FocusCard.Avatar, avatarOk),
                avatarIsAsset ? "プレハブ" : null, MakeFixGui.Warning);
            // D&D スロット（ObjectField 自体がヒエラルキーからのドラッグ＆ドロップを受け付ける）
            GameObject picked = (GameObject)EditorGUILayout.ObjectField(GUIContent.none, target, typeof(GameObject), true);
            if (picked != _state.TargetAvatar) SelectAvatar(picked);
            if (avatarIsAsset)
                MakeFixGui.MessageLine(MessageType.Warning, "シーン上のアバターを選んでください", "プロジェクトのプレハブには適用できません。");

            // シーン内のアバター（VRCAvatarDescriptor か Humanoid の Animator を持つもの）
            // 探し直しは上部ツールバーの「更新」（FaceMap の読み直しも兼ねる）に一本化
            GUILayout.Label(new GUIContent($"シーン内  {_sceneAvatars.Count} 体", "見つからないときは、上部の「更新」で探し直せます。"),
                MakeFixGui.Subtle);

            EditorGUILayout.BeginVertical(MakeFixGui.Inset);
            _avatarListScroll = EditorGUILayout.BeginScrollView(_avatarListScroll, GUILayout.Height(92f));
            if (_sceneAvatars.Count == 0) GUILayout.Label("アバターが見つかりません", EditorStyles.centeredGreyMiniLabel);
            foreach (GameObject avatar in _sceneAvatars)
            {
                if (avatar == null) continue;
                bool on = avatar == target;
                if (MakeFixGui.SelectableRow(new GUIContent(avatar.name, AvatarTooltip(avatar)), avatar.scene.IsValid() ? avatar.scene.name : null, on) && !on)
                    SelectAvatar(avatar);
            }
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
            EndFocusCard(FocusCard.Avatar);

            // ②〜④はアバターを選ぶまで、見出しと 1 行だけにたたむ（開閉は Layout 時点の _avatarReady で決める）
            if (!_avatarReady)
            {
                SetHoveredFaceRenderer(null);
                _faceListScreenRect = default;
                DrawCollapsedCard("顔メッシュ", 2);
                DrawCollapsedCard("アバター基準", 3);
                DrawCollapsedCard("顔テクスチャ", 4);
                EditorGUILayout.EndScrollView();
                DrawLeftPaneFooter(oldLabelWidth);
                return;
            }

            // 2. 顔メッシュ（SkinnedMeshRenderer）の候補
            MakeFixGui.BeginCard("顔メッシュ", "3D 顔ビューのピボット・装飾品の非表示で残すメッシュ・自動生成に使います。", 2,
                faceOk ? MakeFixGui.StepState.Done : MakeFixGui.StepState.Pending);
            EditorGUILayout.BeginVertical(MakeFixGui.Inset);
            _faceListScroll = EditorGUILayout.BeginScrollView(_faceListScroll, GUILayout.Height(72f));
            if (target == null) GUILayout.Label("アバターを選ぶと候補が出ます", EditorStyles.centeredGreyMiniLabel);
            else if (_faceCandidates.Count == 0) GUILayout.Label("SkinnedMeshRenderer がありません", EditorStyles.centeredGreyMiniLabel);
            SkinnedMeshRenderer hovered = null;
            foreach (SkinnedMeshRenderer smr in _faceCandidates)
            {
                if (smr == null) continue;
                bool on = smr == _state.FaceRenderer;
                Mesh m = smr.sharedMesh;
                string sub = m != null ? $"BS {m.blendShapeCount}" : null;
                if (MakeFixGui.SelectableRow(new GUIContent(smr.name,
                            $"メッシュ: {(m != null ? m.name : "-")}\nマウスを乗せている間、3D 顔ビューにこのメッシュだけを映します。"), sub, on) && !on)
                    SelectFaceRenderer(smr);
                if (Event.current.type == EventType.Repaint && GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition))
                    hovered = smr;
            }
            EditorGUILayout.EndScrollView();
            // 一覧の見えている範囲の外（スクロールで隠れた行）は乗せていない扱い
            if (Event.current.type == EventType.Repaint)
            {
                Rect list = GUILayoutUtility.GetLastRect();
                Vector2 min = GUIUtility.GUIToScreenPoint(list.min);
                _faceListScreenRect = new Rect(min, list.size);
                if (!list.Contains(Event.current.mousePosition) || !_mouseInWindow) hovered = null;
                SetHoveredFaceRenderer(hovered);
            }
            EditorGUILayout.EndVertical();
            // 案内の有無は Layout 時点の値で決める（Repaint 中にホバーが変わってもコントロール数を揃える）
            if (_hoverHintRenderer != null)
            {
                GUILayout.Label(_centerMode == CenterMode.View3D
                        ? $"3D 顔ビューに「{_hoverHintRenderer.name}」だけを映しています"
                        : "3D ビューに切り替えると、乗せたメッシュだけを映して確かめられます",
                    MakeFixGui.Subtle);
            }
            MakeFixGui.EndCard();

            // 3. アバター基準（FaceMap）。Read-Only: ここでは選ぶか自動生成するだけで、調整値は書き戻さない
            // 「読み取り専用」は基準を選んでから出す（何も選んでいないうちは意味が伝わらない）
            MakeFixGui.BeginCard("アバター基準", "対象アバターの顔の基準位置（FaceMap）。フィッティング調整では変更しません。", 3,
                StepStateOf(FocusCard.AvatarFaceMap, mapOk),
                mapOk ? "読み取り専用" : null, MakeFixGui.Muted);
            _state.AvatarFaceMapPath = DrawFaceMapPopup("", _state.AvatarFaceMapPath);
            DrawNotesLine(_avatarNotes);
            if (_state.AvatarFaceMap == null && !_state.IsScanning)
            {
                MakeFixGui.MessageLine(MessageType.Info,
                    "アバター基準がありません。顔メッシュから自動生成できます",
                    null);
            }
            using (new EditorGUI.DisabledScope(!avatarOk))
            {
                var content = new GUIContent(_state.AvatarFaceMap == null ? "アバター基準を自動生成" : "自動生成し直す（上書きの確認あり）",
                    "顔メッシュのまばたき・口のブレンドシェイプから、目・鼻・口・頬の位置と目の線を推定して FaceMap を作ります。");
                bool clicked = _state.AvatarFaceMap == null
                    ? GUILayout.Button(content, GUILayout.Height(24f))
                    : GUILayout.Button(content, EditorStyles.miniButton);
                if (clicked)
                {
                    GenerateAvatarFaceMap();
                    GUIUtility.ExitGUI();
                }
            }
            EndFocusCard(FocusCard.AvatarFaceMap);

            // 4. 対象の顔テクスチャ
            MakeFixGui.BeginCard("顔テクスチャ", "対象アバターの顔のマテリアルが使っているテクスチャ。選んだものはアバター基準に記録され、次回の第一候補になります。", 4,
                StepStateOf(FocusCard.AvatarTexture, texOk && ItemsOk(6)));
            EditorGUILayout.BeginHorizontal();
            _state.PreviewAvatarTexture = (Texture2D)EditorGUILayout.ObjectField(_state.PreviewAvatarTexture, typeof(Texture2D), false,
                GUILayout.Width(56f), GUILayout.Height(56f));
            EditorGUILayout.BeginVertical();
            Texture2D faceTex = _state.PreviewAvatarTexture;
            GUILayout.Label(faceTex != null ? faceTex.name : "未選択", faceTex != null ? MakeFixGui.RowLabel : MakeFixGui.Subtle);
            GUILayout.Label(faceTex != null ? $"{faceTex.width} x {faceTex.height}" : "候補から選べます", MakeFixGui.Subtle);
            using (new EditorGUI.DisabledScope(target == null))
            {
                if (GUILayout.Button(new GUIContent("候補から選ぶ", "対象アバターのマテリアルが使っているテクスチャを、画像を見て選びます。"), EditorStyles.miniButton))
                    ShowAvatarTextureMenu(GUILayoutUtility.GetLastRect());
            }
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();
            // 選んだテクスチャを、このアバターが使っていない（項目 6）。上で選び直せるので、ボタンは付けない
            if (avatarOk && texOk)
            {
                ReadinessItem slotProblem = FirstFailedOf(6);
                if (slotProblem != null) DrawWarnLine("アバターがこのテクスチャを使っていません", slotProblem.Detail, null, null);
            }
            EndFocusCard(FocusCard.AvatarTexture);

            EditorGUILayout.EndScrollView();
            DrawLeftPaneFooter(oldLabelWidth);
        }

        /// <summary>左ペインの下端（FaceMaps フォルダのパス）と、ペインを閉じる。</summary>
        private void DrawLeftPaneFooter(float oldLabelWidth)
        {
            GUILayout.Label(new GUIContent(_state.IsScanning ? "FaceMap 読み込み中..." : (_state.FaceMapFolderPath ?? ""), _state.FaceMapFolderPath),
                MakeFixGui.Subtle, GUILayout.ExpandWidth(true));

            EditorGUIUtility.labelWidth = oldLabelWidth;
            EditorGUILayout.EndVertical();
        }

        /// <summary>まだ使えないカード（アバターを選ぶ前の②〜④）。灰色の番号・見出しと 1 行だけ。</summary>
        private static void DrawCollapsedCard(string title, int step)
        {
            using (new EditorGUI.DisabledScope(true)) // 見出しも薄く
            {
                MakeFixGui.BeginCard(title, null, step, MakeFixGui.StepState.Pending);
                GUILayout.Label("①でアバターを選ぶと使えます", MakeFixGui.Subtle);
                MakeFixGui.EndCard();
            }
        }

        private static string AvatarTooltip(GameObject avatar)
        {
            string path = avatar.scene.IsValid() ? avatar.scene.name : "";
            return string.IsNullOrEmpty(path) ? avatar.name : $"{path} / {avatar.name}";
        }

        private void SelectAvatar(GameObject avatar)
        {
            _state.TargetAvatar = avatar;
            GUI.FocusControl(null);
            Repaint();
        }

        // 顔メッシュの一覧でマウスを乗せている候補（3D 顔ビューにそれだけを映す）
        private SkinnedMeshRenderer _hoveredFaceRenderer;
        private bool _mouseInWindow = true;
        private Rect _faceListScreenRect; // 顔メッシュの一覧の、画面上の矩形（マウスが動いたら描き直すかの判定）

        private void SetHoveredFaceRenderer(SkinnedMeshRenderer smr)
        {
            if (ReferenceEquals(smr, _hoveredFaceRenderer)) return;
            _hoveredFaceRenderer = smr;
            if (_orbit != null) _orbit.SoloRenderer = _centerMode == CenterMode.View3D ? smr : null;
            Repaint();
        }

        private void SelectFaceRenderer(SkinnedMeshRenderer smr)
        {
            _state.FaceRenderer = smr;
            _slotsDirty = true;
            OnFaceRendererChangedByUser();
            _orbit?.MarkDirty();
            GUI.FocusControl(null);
            Repaint();
        }

        /// <summary>
        /// Layout のときに、シーン内のアバター一覧・顔メッシュの候補を更新し、アバターが変わったら
        /// 顔メッシュ・アバター基準・顔テクスチャの既定を選ぶ（未設定のものだけ）。
        /// </summary>
        private void SyncAvatarSelection()
        {
            if (_avatarsDirty)
            {
                _avatarsDirty = false;
                _sceneAvatars = FindSceneAvatars();
                MarkAutoQueueDirty();
                TryAutoSelectSingleAvatar();
            }

            // シーンを切り替えるなどでアバターが消えたら、未選択に戻す（下で前のアバターの選択を消す）
            if (!ReferenceEquals(_state.TargetAvatar, null) && _state.TargetAvatar == null) _state.TargetAvatar = null;

            GameObject avatar = _state.TargetAvatar;
            bool avatarChanged = !ReferenceEquals(avatar, _lastAvatar);
            if (avatarChanged)
            {
                // 別のアバターに切り替えた（ウィンドウを開いた直後・再コンパイル後の最初の 1 回は除く）なら、
                // 前のアバター用のアバター基準・顔テクスチャ・顔メッシュを残さない
                bool switched = !ReferenceEquals(_lastAvatar, null);
                _lastAvatar = avatar;
                _slotsDirty = true;
                MeshChangeOffer = false;
                MarkAutoQueueDirty();
                if (switched)
                {
                    _state.AvatarFaceMapPath = null;
                    _state.PreviewAvatarTexture = null;
                    _state.FaceRenderer = null;
                }
                if (avatar != null)
                {
                    // アバター基準: 未選択なら、このアバター（名前・プレハブ名）のものを選ぶ
                    if (_state.AvatarFaceMap == null)
                    {
                        FaceMapMeta match = FindAvatarFaceMap(avatar);
                        if (match != null) _state.AvatarFaceMapPath = match.FilePath;
                    }
                    // 顔テクスチャ: 未選択なら、アバター基準の JSON に残した前回のテクスチャを第一候補にする
                    if (_state.PreviewAvatarTexture == null)
                        _state.PreviewAvatarTexture = ResolveHintTexture(_state.AvatarFaceMap, avatar);
                }
            }

            if (_faceCandidatesDirty || !ReferenceEquals(avatar, _faceCandidatesFor))
            {
                _faceCandidatesDirty = false;
                _faceCandidatesFor = avatar;
                _faceCandidates = FindFaceRendererCandidates(avatar);
            }

            if (_state.FaceRenderer != null && !_faceCandidates.Contains(_state.FaceRenderer)) _state.FaceRenderer = null;
            if (_state.FaceRenderer == null && avatar != null && _faceCandidates.Count > 0)
            {
                _state.FaceRenderer = AvatarFaceMapGenerator.GuessRenderer(avatar, _state.PreviewAvatarTexture);
                if (_state.FaceRenderer == null || !_faceCandidates.Contains(_state.FaceRenderer))
                    _state.FaceRenderer = _faceCandidates[0];
                _slotsDirty = true;
            }

            // 顔テクスチャ: JSON に記録が無ければ、顔メッシュのマテリアルのメインテクスチャ
            if (avatarChanged && avatar != null && _state.PreviewAvatarTexture == null)
                _state.PreviewAvatarTexture = GuessFaceTexture(_state.FaceRenderer);
        }

        /// <summary>アバターの名前と、プレハブのインスタンスならプレハブ名（重複なし）。</summary>
        private static List<string> AvatarNames(GameObject avatar)
        {
            var names = new List<string>();
            if (avatar == null) return names;
            names.Add(avatar.name);
            GameObject source = PrefabUtility.IsPartOfPrefabInstance(avatar)
                ? PrefabUtility.GetCorrespondingObjectFromOriginalSource(avatar)
                : null;
            if (source != null && !names.Contains(source.name)) names.Add(source.name);
            return names;
        }

        /// <summary>
        /// このアバターのアバター基準を探す。targetAvatar がアバター名 → プレハブ名、
        /// 無ければファイル名がそれらと同じもの（番号付きの "_2" なども含め、新しいものを優先）。
        /// </summary>
        private FaceMapMeta FindAvatarFaceMap(GameObject avatar)
        {
            List<string> names = AvatarNames(avatar);
            List<FaceMapMeta> valid = _state.FaceMaps.Where(m => m.IsValid).OrderByDescending(m => m.LastWriteTicks).ToList();
            foreach (string n in names)
            {
                FaceMapMeta byTarget = valid.FirstOrDefault(m => m.TargetAvatar == n);
                if (byTarget != null) return byTarget;
            }
            foreach (string n in names)
            {
                string baseName = FaceMapSerializer.SanitizeFileName(n);
                if (string.IsNullOrEmpty(baseName)) continue;
                FaceMapMeta byFile = valid.FirstOrDefault(m =>
                {
                    string f = System.IO.Path.GetFileNameWithoutExtension(m.FileName);
                    return f == baseName || (f.StartsWith(baseName + "_") && int.TryParse(f.Substring(baseName.Length + 1), out _));
                });
                if (byFile != null) return byFile;
            }
            return null;
        }

        private static string AssetGuid(Object asset)
        {
            if (asset == null) return null;
            string path = AssetDatabase.GetAssetPath(asset);
            return string.IsNullOrEmpty(path) ? null : AssetDatabase.AssetPathToGUID(path);
        }

        /// <summary>
        /// アバター基準の JSON に残した前回の顔テクスチャ。GUID で見つかればそれ、無ければ（別プロジェクトなど）
        /// 同じ名前のテクスチャを、アバターのマテリアルが使っているもの優先で探す。見つからなければ null。
        /// </summary>
        private static Texture2D ResolveHintTexture(FaceMapMeta map, GameObject avatar)
        {
            if (map == null || !map.IsValid) return null;
            if (!string.IsNullOrEmpty(map.FaceTextureGuid))
            {
                string p = AssetDatabase.GUIDToAssetPath(map.FaceTextureGuid);
                Texture2D byGuid = string.IsNullOrEmpty(p) ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(p);
                if (byGuid != null) return byGuid;
            }
            if (string.IsNullOrEmpty(map.FaceTextureName)) return null;

            if (avatar != null)
            {
                foreach (Renderer r in avatar.GetComponentsInChildren<Renderer>(true))
                {
                    foreach (Material mat in r.sharedMaterials)
                    {
                        Material original = FaceMaterialApplier.ResolveOriginal(mat);
                        if (original == null) continue;
                        foreach (string prop in original.GetTexturePropertyNames())
                        {
                            if (original.GetTexture(prop) is Texture2D t && t.name == map.FaceTextureName) return t;
                        }
                    }
                }
            }
            foreach (string guid in AssetDatabase.FindAssets(map.FaceTextureName + " t:Texture2D"))
            {
                Texture2D t = AssetDatabase.LoadAssetAtPath<Texture2D>(AssetDatabase.GUIDToAssetPath(guid));
                if (t != null && t.name == map.FaceTextureName) return t;
            }
            return null;
        }

        /// <summary>
        /// 選んでいる顔テクスチャを、アバター基準の JSON（meta.faceTexture）に残す。次にこのアバターを選んだとき・
        /// シーンを変えたときに第一候補として出す。記録と同じなら書かない（点・サイズなどの中身は変えない）。
        /// </summary>
        private void SyncFaceTextureHint()
        {
            FaceMapMeta map = _state.AvatarFaceMap;
            Texture2D tex = _state.PreviewAvatarTexture;
            if (map == null || !map.IsValid || tex == null || _previewDrag != PreviewDrag.None) return;

            string guid = AssetGuid(tex);
            if (guid == null) return;
            if (map.FaceTextureGuid == guid && map.FaceTextureName == tex.name) return;

            string attempt = map.FilePath + "|" + guid;
            if (attempt == _hintAttempt) return; // 失敗したものを毎フレーム書き直さない
            _hintAttempt = attempt;

            // 体験版はメモリの FaceMap にだけ残す（ファイルの FaceMap は書き換えない）
            if (!FaceMapStorage.CanWrite(map.FilePath)) return;
            if (!FaceMapRepository.TryLoadFile(map.FilePath, out FaceMapFile file, out _)) return;
            file.MetaJson = FaceTextureHint.With(file.MetaJson, tex.name, guid);
            if (!FaceMapStorage.TrySave(map.FilePath, file, out _)) return;

            map.FaceTextureName = tex.name;
            map.FaceTextureGuid = guid;
            map.LastWriteTicks = FaceMapStorage.LastWriteTicks(map.FilePath);
        }

        /// <summary>シーン内のアバターのルート（VRCAvatarDescriptor か Humanoid の Animator を持つもの）。入れ子は外側だけ。</summary>
        private static List<GameObject> FindSceneAvatars()
        {
            var found = new List<GameObject>();
            foreach (MonoBehaviour mb in Object.FindObjectsOfType<MonoBehaviour>(true))
            {
                if (mb == null || EditorUtility.IsPersistent(mb)) continue;
                if (mb.GetType().Name == "VRCAvatarDescriptor" && !found.Contains(mb.gameObject)) found.Add(mb.gameObject);
            }
            foreach (Animator a in Object.FindObjectsOfType<Animator>(true))
            {
                if (a == null || EditorUtility.IsPersistent(a) || !a.isHuman) continue;
                if (!found.Contains(a.gameObject)) found.Add(a.gameObject);
            }

            // 他のアバターの中にあるもの（衣装の Animator など）は除く
            var roots = found.Where(go => !found.Any(other => other != go && go.transform.IsChildOf(other.transform))).ToList();
            roots.Sort((x, y) => string.CompareOrdinal(x.name, y.name));
            return roots;
        }

        /// <summary>顔メッシュの候補（まばたきのブレンドシェイプを持つもの → ブレンドシェイプの多いもの → 名前の順）。</summary>
        private static List<SkinnedMeshRenderer> FindFaceRendererCandidates(GameObject avatar)
        {
            if (avatar == null) return new List<SkinnedMeshRenderer>();
            return avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true)
                .Where(r => r.sharedMesh != null && r.sharedMesh.vertexCount > 0)
                .OrderByDescending(r => AvatarFaceMapGenerator.GuessBlink(r.sharedMesh) >= 0)
                .ThenByDescending(r => r.sharedMesh.blendShapeCount)
                .ThenBy(r => r.name)
                .ToList();
        }

        /// <summary>顔メッシュのマテリアルのうち、名前に face を含むもの（無ければ最初のもの）のメインテクスチャ。</summary>
        private static Texture2D GuessFaceTexture(Renderer face)
        {
            if (face == null) return null;
            Texture2D first = null;
            foreach (Material mat in face.sharedMaterials)
            {
                Material original = FaceMaterialApplier.ResolveOriginal(mat);
                if (original == null || !original.HasProperty("_MainTex")) continue;
                if (!(original.mainTexture is Texture2D tex)) continue;
                string n = original.name.ToLowerInvariant();
                if (n.Contains("face") || n.Contains("顔") || n.Contains("head")) return tex;
                if (first == null) first = tex;
            }
            return first;
        }

        /// <summary>
        /// 顔メッシュからアバター基準（FaceMap）を自動生成し、FaceMaps フォルダに保存して選ぶ。
        /// このアバター（名前・プレハブ名）のアバター基準がすでにあれば、黙って番号付きの別ファイルを増やさず、
        /// 「既存のものを使う / 上書きして作り直す / キャンセル」を確認する。
        /// </summary>
        /// <summary>
        /// アバター基準の自動生成に使う入力（顔のレンダラー・まばたき・口）。選んだ顔メッシュがなければ推測する。
        /// テストリリースの診断も同じ入力を使う（自動生成の結果と診断の中身がずれないように）。
        /// </summary>
        private void ResolveAutoGenerateInputs(GameObject avatar, out SkinnedMeshRenderer smr, out int blink, out int mouth)
        {
            smr = _state.FaceRenderer != null
                ? _state.FaceRenderer
                : AvatarFaceMapGenerator.GuessRenderer(avatar, _state.PreviewAvatarTexture);
            Mesh mesh = smr != null ? smr.sharedMesh : null;
            blink = AvatarFaceMapGenerator.GuessBlink(mesh);
            mouth = AvatarFaceMapGenerator.GuessMouth(mesh);
        }

#if ATAA_DIAGNOSTICS
        /// <summary>
        /// テストリリースだけ: アバター基準の自動生成と同じ入力で診断し、結果のウィンドウに出す。
        /// メッシュ・マテリアル・ブレンドシェイプのウェイト・ツールの状態は変えない。
        /// </summary>
        internal void RunDiagnostics()
        {
            GameObject avatar = _state.TargetAvatar;
            if (avatar == null) return;
            ResolveAutoGenerateInputs(avatar, out SkinnedMeshRenderer smr, out int blink, out int mouth);
            string report = AutoGenerateDiagnosticsReport.Build(avatar, smr, blink, mouth, new GenerationOptions());
            AutoGenerateDiagnosticsWindow.Open(avatar.name, report);
        }
#endif

        /// <summary>自動生成の結果から FaceMap ファイルの中身を組み立てる（明示生成と自動生成で共通）。</summary>
        private static FaceMapFile BuildAutoFaceMapFile(GameObject avatar, FaceMapAutoGenerator.Result result, FaceMapFile previous, Texture2D usedTex)
        {
            var file = new FaceMapFile { Name = avatar.name, TargetAvatar = avatar.name };
            foreach (FaceTemplateEntry entry in FaceTemplate.Entries)
            {
                if (result.Centers.TryGetValue(entry.Label, out Vector2 c)) file.Points.Add(new FaceMapPoint(c.x, c.y, entry.Label));
            }
            foreach (KeyValuePair<string, Vector2> kv in result.Sizes) file.Sizes[kv.Key] = kv.Value;
            file.CenterX = result.CenterX;
            file.EyeLine = result.EyeLine;
            file.EyeLowerLine = result.EyeLowerLine;
            file.NoEyeOpening = result.NoEyeOpening;
            file.MouthLine = result.MouthLine;
            file.MouthLinePoints = result.MouthLine.HasValue ? MouthLineShape.Clone(result.MouthLinePoints) : null;

            // 上書きでも meta（前回の顔テクスチャなど）は引き継ぎ、今の顔テクスチャを記録する
            if (previous != null) file.MetaJson = previous.MetaJson;
            if (usedTex != null) file.MetaJson = FaceTextureHint.With(file.MetaJson, usedTex.name, AssetGuid(usedTex));
            return file;
        }

        private void GenerateAvatarFaceMap()
        {
            GameObject avatar = _state.TargetAvatar;
            if (avatar == null) return;

            if (!FaceMapStorage.TryGetSaveFolder(out string folder, out string folderError))
            {
                _state.Warning = folderError;
                _state.WarningType = MessageType.Error;
                return;
            }

            string baseName = FaceMapSerializer.SanitizeFileName(avatar.name);
            if (string.IsNullOrEmpty(baseName)) baseName = "avatar";
            string path = System.IO.Path.Combine(folder, baseName + ".json");

            // 既存のアバター基準（同じファイル名、または targetAvatar・ファイル名がこのアバター / プレハブの名前のもの）
            string existingPath = FaceMapStorage.Exists(path) ? path : FindAvatarFaceMap(avatar)?.FilePath;
            FaceMapFile previous = null;
            if (existingPath != null)
            {
                int choice = EditorUtility.DisplayDialogComplex(
                    "アバター基準の自動生成",
                    $"「{avatar.name}」のアバター基準はすでにあります。\n\n{System.IO.Path.GetFileName(existingPath)}\n\n" +
                    "既存のものを使うか、上書きして作り直すかを選んでください。\n（番号付きの別ファイルは作りません）",
                    "既存のものを使う", "キャンセル", "上書きして作り直す");
                if (choice == 1) return;
                if (choice == 0)
                {
                    _state.AvatarFaceMapPath = existingPath;
                    _state.Warning = $"既存のアバター基準を選びました: {System.IO.Path.GetFileName(existingPath)}";
                    _state.WarningType = MessageType.Info;
                    RequestRefresh();
                    return;
                }
                // 体験版でファイルの FaceMap を作り直すときは、ファイルはそのままにしてメモリに作る
                if (FaceMapStorage.CanWrite(existingPath)) path = existingPath;
                FaceMapRepository.TryLoadFile(existingPath, out previous, out _);
            }

            ResolveAutoGenerateInputs(avatar, out SkinnedMeshRenderer smr, out int blink, out int mouth);
            if (smr == null || blink < 0)
            {
                _state.Warning = "アバター基準を自動生成できませんでした: 顔メッシュにまばたきのブレンドシェイプが見つかりません。" +
                                 "FaceMap エディターの「自動作成」でブレンドシェイプを指定して作成してください。";
                _state.WarningType = MessageType.Warning;
                return;
            }

            AvatarFaceMapGenerator.AvatarResult result = AvatarFaceMapGenerator.Generate(smr, blink, mouth);
            if (!result.Success)
            {
                _state.Warning = "アバター基準を自動生成できませんでした: " + result.Error;
                _state.WarningType = MessageType.Warning;
                return;
            }

            Texture2D usedTex = _state.PreviewAvatarTexture != null ? _state.PreviewAvatarTexture : result.FaceTexture as Texture2D;
            FaceMapFile file = BuildAutoFaceMapFile(avatar, result, previous, usedTex);

            if (!FaceMapStorage.TrySave(path, file, out string saveError))
            {
                _state.Warning = "アバター基準を保存できませんでした: " + saveError;
                _state.WarningType = MessageType.Error;
                return;
            }

            if (_faceCandidates.Contains(smr)) _state.FaceRenderer = smr;
            if (_state.PreviewAvatarTexture == null && result.FaceTexture is Texture2D faceTex) _state.PreviewAvatarTexture = faceTex;
            _state.AvatarFaceMapPath = path;
            string check = result.CheckLabels.Count > 0 ? $"\n要確認: {string.Join("・", result.CheckLabels)}（FaceMap エディターで確かめてください）" : "";
            _state.Warning = $"アバター基準を自動生成しました: {System.IO.Path.GetFileName(path)}{check}\n" + string.Join("\n", result.Notes);
            _state.WarningType = result.EyeLineIssue != null ? MessageType.Warning : MessageType.Info;
            if (AtaaCore.Edition == CoreEdition.Trial)
                _state.Warning += "\n体験版のため、メモリに一時保存しました（Unity を閉じると消えます。製品版では保存して使い回せます）。";
            FaceMapStorage.RefreshAssets();
            RequestRefresh();

            // 目の線を自動で決められなかったら、FaceMap エディターで合わせるよう案内する（自動ポインティング仕様 §11.22）
            if (result.EyeLineIssue != null)
            {
                _state.Warning += $"\n目の線を自動で決められませんでした: {result.EyeLineIssue}";
                if (EditorUtility.DisplayDialog("目の線を合わせてください",
                        result.EyeLineIssue + "\n\n" +
                        "目の線（上まつげの生え際）と目の下の線（下まつげの生え際）は、メイクの目の部分を写す基準です。\n" +
                        "FaceMap エディターでこのアバター基準を開き、3D ビューで線が顔のどこに当たるかを見ながら合わせてください。",
                        "FaceMap エディターで合わせる", "あとで"))
                {
                    MyVrcToolFaceMapEditorWindow.OpenForEyeLineReview(path, avatar, smr, usedTex, result.EyeLineIssue);
                }
            }
        }

        private string DrawFaceMapPopup(string label, string currentPath)
        {
            var names = new string[_validMaps.Count + 1];
            names[0] = "（未選択）";
            int current = 0;
            for (int i = 0; i < _validMaps.Count; i++)
            {
                FaceMapMeta m = _validMaps[i];
                bool dup = _validMaps.Count(x => x.DisplayName == m.DisplayName) > 1;
                string labelText = dup ? $"{m.DisplayName} ({m.FileName})" : m.DisplayName;
                // "/" はメニューの階層区切りとして扱われるため置き換える
                names[i + 1] = labelText.Replace('/', '／');
                if (m.FilePath == currentPath) current = i + 1;
            }

            int next = string.IsNullOrEmpty(label)
                ? EditorGUILayout.Popup(current, names)
                : EditorGUILayout.Popup(label, current, names);
            return next == 0 ? null : _validMaps[next - 1].FilePath;
        }

        /// <summary>FaceMap の警告を 1 行で。全文はツールチップ。</summary>
        private void DrawNotesLine(List<string> notes)
        {
            if (notes.Count == 0) return;
            string first = notes[0];
            string more = notes.Count > 1 ? $"（他 {notes.Count - 1} 件）" : "";
            MakeFixGui.MessageLine(MessageType.Warning, first + more, string.Join("\n", notes));
        }

        /// <summary>お知らせの 1 行（情報アイコン付き）。全文はツールチップ。</summary>
        private static void DrawInfoLine(string message, string detail)
        {
            MakeFixGui.MessageLine(MessageType.Info, message, detail);
        }

        /// <summary>対象アバターのマテリアルが参照しているテクスチャから選ぶ（§13.8 の「候補から選ぶ」）。</summary>
        /// <summary>対象アバターのマテリアルが使っているテクスチャを、サムネイルで並べて選ぶ（activator はポップアップを出す位置）。</summary>
        private void ShowAvatarTextureMenu(Rect activator)
        {
            GameObject avatar = _state.TargetAvatar;
            if (avatar == null) return;

            var textures = new List<Texture2D>();
            var renderers = new List<Renderer>();
            if (_state.FaceRenderer != null) renderers.Add(_state.FaceRenderer);
            foreach (Renderer r in avatar.GetComponentsInChildren<Renderer>(true))
            {
                if (!renderers.Contains(r)) renderers.Add(r);
            }
            int faceTextureCount = 0;
            foreach (Renderer r in renderers)
            {
                foreach (Material mat in r.sharedMaterials)
                {
                    Material original = FaceMaterialApplier.ResolveOriginal(mat);
                    if (original == null) continue;
                    foreach (string prop in original.GetTexturePropertyNames())
                    {
                        if (original.GetTexture(prop) is Texture2D t && !textures.Contains(t)) textures.Add(t);
                    }
                }
                if (r == _state.FaceRenderer) faceTextureCount = textures.Count;
            }

            // 前回使ったテクスチャ（アバター基準の JSON に残したもの）・顔メッシュのテクスチャ・その他、の順にサムネイルで並べる
            var sections = new List<TexturePickerPopup.Section>();
            Texture2D hint = ResolveHintTexture(_state.AvatarFaceMap, avatar);
            if (hint != null)
                sections.Add(new TexturePickerPopup.Section { Title = "前回使ったテクスチャ", Textures = new List<Texture2D> { hint } });
            List<Texture2D> faceTextures = textures.Take(faceTextureCount).OrderBy(t => t.name).ToList();
            List<Texture2D> others = textures.Skip(faceTextureCount).OrderBy(t => t.name).ToList();
            if (faceTextures.Count > 0)
            {
                string meshName = _state.FaceRenderer != null ? _state.FaceRenderer.name : "";
                sections.Add(new TexturePickerPopup.Section { Title = $"顔メッシュ（{meshName}）のテクスチャ", Textures = faceTextures });
            }
            if (others.Count > 0)
                sections.Add(new TexturePickerPopup.Section { Title = faceTextures.Count > 0 ? "その他" : "アバターのテクスチャ", Textures = others });

            PopupWindow.Show(activator, new TexturePickerPopup(sections, _state.PreviewAvatarTexture, picked =>
            {
                _state.PreviewAvatarTexture = picked;
                MarkUiDirty();
                Repaint();
            }, this));
        }
    }
}
