using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 右ペイン「⑤ メイク元」の導線（メイクテクスチャの D&amp;D・ファイルダイアログ・候補ポップアップ、
    /// シーン内アバター／プレハブからのメイク基準自動生成、FaceMap エディターとの往復連携）。
    /// 判断ロジックは MakeFixMakeupSource に切り出す。
    /// </summary>
    public partial class MakeFixWindow
    {
        private Texture2D _transientMakeupTexture;
        private bool _makeupCreateManualOpen;
        private bool _makeupAvatarPickerOpen;
        private string _makeupAutoError;
        private string _makeupAutoEyeLineIssue;
        private string _makeupAutoPath;

        private readonly Dictionary<string, MakeFixMakeupSource.DropdownChoice> _makeupChoiceByLabel =
            new Dictionary<string, MakeFixMakeupSource.DropdownChoice>();

        private void DisposeTransientMakeupTexture()
        {
            if (_transientMakeupTexture != null)
            {
                DestroyImmediate(_transientMakeupTexture);
                _transientMakeupTexture = null;
            }
        }

        // ── メイクテクスチャの設定・取り込み ──

        /// <summary>メイクテクスチャを設定する。ユーザー操作なら履歴記録と確実な基準連動も行う。</summary>
        private void SetMakeupTexture(Texture2D tex, bool fromUser, bool isTransient = false)
        {
            if (_transientMakeupTexture != null && !ReferenceEquals(_transientMakeupTexture, tex))
                DisposeTransientMakeupTexture();
            if (isTransient) _transientMakeupTexture = tex;

            _state.PreviewMakeupTexture = tex;

            if (fromUser && tex != null)
            {
                MakeFixTextureMemory.RecordMakeupHistory(tex);
                TryLinkMakeupMapFromTexture(tex);
                if (!string.IsNullOrEmpty(_state.MakeupFaceMapPath))
                    MakeFixTextureMemory.SaveMakeupLink(tex, _state.MakeupFaceMapPath);
            }

            InvalidatePreview();
            MarkUiDirty();
        }

        /// <summary>
        /// メイクテクスチャから 100% 確実な紐づけ（シーン内他アバターの顔マテリアル参照一致・過去使用履歴）だけで
        /// メイク基準を自動選択する。ファイル名からの推測は行わない。
        /// </summary>
        private void TryLinkMakeupMapFromTexture(Texture2D tex)
        {
            GameObject matchedAvatar = FindSceneAvatarUsingFaceTexture(tex);
            string sceneMapPath = null;
            string sceneAvatarKey = null;
            if (matchedAvatar != null)
            {
                FaceMapMeta existing = FindAvatarFaceMap(matchedAvatar);
                if (existing != null && existing.IsValid) sceneMapPath = existing.FilePath;
                else sceneAvatarKey = AutoKey(matchedAvatar);
            }

            string rememberedMapPath = null;
            string rememberedKey = MakeFixTextureMemory.LoadMapKeyForTexture(tex);
            if (!string.IsNullOrEmpty(rememberedKey))
            {
                FaceMapMeta found = _validMaps.FirstOrDefault(m =>
                    string.Equals(MakeFixTextureMemory.MapKey(m.FilePath), rememberedKey, System.StringComparison.OrdinalIgnoreCase));
                if (found != null) rememberedMapPath = found.FilePath;
            }

            MakeFixMakeupSource.MapResolution res = MakeFixMakeupSource.ResolveMapOnTextureChanged(
                _state.MakeupFaceMapPath, sceneMapPath, sceneAvatarKey, rememberedMapPath);

            if (res.Kind == MakeFixMakeupSource.MapResolutionKind.SelectMap)
            {
                _state.MakeupFaceMapPath = res.MapPath;
                _makeupCreateManualOpen = false;
                _makeupAvatarPickerOpen = false;
                _makeupAutoError = null;
            }
            else if (res.Kind == MakeFixMakeupSource.MapResolutionKind.GenerateForSceneAvatar)
            {
                GameObject avatar = _sceneAvatars.Find(a => a != null && AutoKey(a) == res.SceneAvatarKey);
                if (avatar != null) GenerateMakeupFaceMapFromAvatar(avatar, allowAutoFillTexture: false);
            }
        }

        /// <summary>OS のファイル選択ダイアログで画像を選ぶ（プロジェクト外なら自動インポート／体験版はメモリ読込）。</summary>
        private void PickMakeupTextureFromFile()
        {
            ApplyImportedMakeupTexture(MakeupTextureImporter.OpenFileDialog("メイクテクスチャを選択"));
        }

        private void ApplyImportedMakeupTexture(MakeupTextureImporter.LoadResult result)
        {
            if (result.Canceled) return;
            if (!string.IsNullOrEmpty(result.Error) || result.Texture == null)
            {
                SetAutoWarning(result.Error ?? "メイク画像を読み込めませんでした。", MessageType.Warning);
                MarkUiDirty();
                return;
            }

            SetMakeupTexture(result.Texture, fromUser: true, isTransient: result.IsTransient);
            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                if (result.IsTransient)
                    SetAutoWarning("外部のメイク画像をプレビュー用に読み込みました（ファイル保存なし）。", MessageType.Info);
            }
            else if (result.Imported)
            {
                SetAutoWarning("メイク画像をインポートしました: " + result.AssetPath, MessageType.Info);
            }
        }

        /// <summary>メイクテクスチャの候補ポップアップ（選択中基準の顔／シーン内他アバターの顔／最近使ったメイク）。</summary>
        private void ShowMakeupTextureMenu(Rect activator)
        {
            var sections = new List<TexturePickerPopup.Section>();
            var shown = new HashSet<Texture2D>();

            // 1. 選択中メイク基準の顔テクスチャ
            Texture2D currentBaseFace = ResolveFaceTextureForMakeupMap(_state.MakeupFaceMap);
            if (currentBaseFace != null && shown.Add(currentBaseFace))
            {
                string baseName = _state.MakeupFaceMap != null ? _state.MakeupFaceMap.DisplayName : "メイク基準";
                sections.Add(new TexturePickerPopup.Section
                {
                    Title = $"メイク基準（{baseName}）の顔テクスチャ",
                    Textures = new List<Texture2D> { currentBaseFace }
                });
            }

            // 2. シーン内の他アバターの顔テクスチャ
            var otherSceneFaces = new List<Texture2D>();
            foreach (GameObject avatar in _sceneAvatars)
            {
                if (avatar == null || ReferenceEquals(avatar, _state.TargetAvatar)) continue;
                SkinnedMeshRenderer faceSmr = AvatarFaceMapGenerator.GuessRenderer(avatar, null);
                Texture2D faceTex = GuessFaceTexture(faceSmr);
                if (faceTex != null && shown.Add(faceTex)) otherSceneFaces.Add(faceTex);
            }
            if (otherSceneFaces.Count > 0)
            {
                sections.Add(new TexturePickerPopup.Section
                {
                    Title = "シーン内の他アバターの顔テクスチャ",
                    Textures = otherSceneFaces
                });
            }

            // 3. 最近使ったメイクテクスチャ
            var history = new List<Texture2D>();
            foreach (Texture2D t in MakeFixTextureMemory.LoadMakeupHistory())
            {
                if (t != null && shown.Add(t)) history.Add(t);
            }
            if (history.Count > 0)
            {
                sections.Add(new TexturePickerPopup.Section
                {
                    Title = "最近使ったメイク",
                    Textures = history
                });
            }

            PopupWindow.Show(activator, new TexturePickerPopup(sections, _state.PreviewMakeupTexture, picked =>
            {
                SetMakeupTexture(picked, fromUser: true);
                Repaint();
            }, this));
        }

        // ── メイク基準の選択・自動作成・手動作成 ──

        /// <summary>メイク基準のドロップダウンで項目を選んだときの処理。</summary>
        private void SelectMakeupFaceMapChoice(MakeFixMakeupSource.DropdownChoice choice)
        {
            _makeupAutoError = null;
            if (choice == null || string.IsNullOrEmpty(choice.Value))
            {
                _state.MakeupFaceMapPath = null;
                _makeupAutoEyeLineIssue = null;
                _makeupAutoPath = null;
                MarkUiDirty();
                return;
            }

            if (choice.IsSceneAvatar)
            {
                GameObject avatar = _sceneAvatars.Find(a => a != null && AutoKey(a) == choice.SceneAvatarKey);
                if (avatar != null) GenerateMakeupFaceMapFromAvatar(avatar, allowAutoFillTexture: _state.PreviewMakeupTexture == null);
                return;
            }

            _state.MakeupFaceMapPath = choice.Value;
            _makeupCreateManualOpen = false;
            _makeupAvatarPickerOpen = false;
            if (!MakeFixMakeupSource.PathsEqual(_makeupAutoPath, choice.Value))
            {
                _makeupAutoEyeLineIssue = null;
                _makeupAutoPath = null;
            }

            TryAutoFillMakeupTextureForCurrentMap();
            if (_state.PreviewMakeupTexture != null)
                MakeFixTextureMemory.SaveMakeupLink(_state.PreviewMakeupTexture, _state.MakeupFaceMapPath);
            MarkUiDirty();
        }

        /// <summary>メイクテクスチャが未選択のときだけ、ペア記憶 → 基準単体記憶 → 基準の顔テクスチャ の順で補完する。</summary>
        private void TryAutoFillMakeupTextureForCurrentMap()
        {
            if (_state.PreviewMakeupTexture != null || string.IsNullOrEmpty(_state.MakeupFaceMapPath)) return;

            string pairKey = MakeFixTextureMemory.Key(_state.MakeupFaceMapPath, _state.AvatarFaceMapPath);
            string pairGuid = MakeFixTextureMemory.LoadPairMakeupGuid(pairKey);
            string mapGuid = MakeFixTextureMemory.LoadTextureGuidForMap(_state.MakeupFaceMapPath);
            Texture2D hintTex = ResolveFaceTextureForMakeupMap(_state.MakeupFaceMap);
            string hintGuid = AssetGuid(hintTex);

            string chosenGuid = MakeFixMakeupSource.PickFallbackTextureGuid(
                hasCurrentTexture: false, pairGuid, mapGuid, hintGuid);
            Texture2D loaded = MakeFixTextureMemory.LoadTextureByGuid(chosenGuid) ?? (string.IsNullOrEmpty(chosenGuid) ? hintTex : null);
            if (loaded != null) SetMakeupTexture(loaded, fromUser: false);
        }

        /// <summary>
        /// シーン内のアバター、または Project のプレハブからメイク基準（FaceMap）を用意して選択する。
        /// 既存の保存済み FaceMap があれば上書きせずそれを使い、無ければ ATAA-Auto/ に一時生成する。
        /// プレハブはシーンを汚さない一時インスタンス（HideAndDontSave）で解析し、確実に破棄する。
        /// </summary>
        private void GenerateMakeupFaceMapFromAvatar(GameObject avatarOrPrefab, bool allowAutoFillTexture)
        {
            if (avatarOrPrefab == null) return;
            _makeupAutoError = null;
            _makeupAutoEyeLineIssue = null;
            _makeupAutoPath = null;

            bool isPrefab = EditorUtility.IsPersistent(avatarOrPrefab);
            FaceMapMeta existing = isPrefab ? FindSavedFaceMapByAvatarName(avatarOrPrefab.name) : FindAvatarFaceMap(avatarOrPrefab);
            if (existing != null && existing.IsValid && !FaceMapStorage.IsDraft(existing.FilePath))
            {
                _state.MakeupFaceMapPath = existing.FilePath;
                _makeupCreateManualOpen = false;
                _makeupAvatarPickerOpen = false;
                SetAutoWarning($"既存のメイク基準を選びました: {existing.DisplayName}", MessageType.Info);
                if (allowAutoFillTexture) TryAutoFillMakeupTextureForCurrentMap();
                MarkUiDirty();
                return;
            }

            if (!isPrefab)
            {
                AutoResult r = AutoGenerate(avatarOrPrefab);
                if (r == null || string.IsNullOrEmpty(r.Path))
                {
                    _makeupAutoError = r != null && !string.IsNullOrEmpty(r.Error)
                        ? r.Error
                        : "メイク基準を自動作成できませんでした。";
                    SetAutoWarning("メイク基準を自動作成できませんでした: " + _makeupAutoError, MessageType.Warning);
                    MarkUiDirty();
                    return;
                }

                _state.MakeupFaceMapPath = r.Path;
                _makeupAutoPath = r.Path;
                _makeupAutoEyeLineIssue = r.EyeLineIssue;
                _makeupCreateManualOpen = false;
                _makeupAvatarPickerOpen = false;
                if (allowAutoFillTexture && _state.PreviewMakeupTexture == null)
                {
                    SkinnedMeshRenderer smr = AvatarFaceMapGenerator.GuessRenderer(avatarOrPrefab, null);
                    Texture2D faceTex = GuessFaceTexture(smr);
                    if (faceTex != null) SetMakeupTexture(faceTex, fromUser: false);
                }
                MarkUiDirty();
                return;
            }

            // Project のプレハブ: シーンを汚さない一時インスタンスを作って解析し、必ず破棄する
            GameObject temp = null;
            try
            {
                temp = Object.Instantiate(avatarOrPrefab);
                temp.name = avatarOrPrefab.name;
                temp.hideFlags = HideFlags.HideAndDontSave;
                temp.SetActive(false);

                SkinnedMeshRenderer smr = AvatarFaceMapGenerator.GuessRenderer(temp, null);
                Mesh mesh = smr != null ? smr.sharedMesh : null;
                int blink = AvatarFaceMapGenerator.GuessBlink(mesh);
                int mouth = AvatarFaceMapGenerator.GuessMouth(mesh);
                if (smr == null || blink < 0)
                {
                    _makeupAutoError = "顔メッシュにまばたきのブレンドシェイプが見つかりません。FaceMap エディターから作成してください。";
                    SetAutoWarning("メイク基準を自動作成できませんでした: " + _makeupAutoError, MessageType.Warning);
                    MarkUiDirty();
                    return;
                }

                AvatarFaceMapGenerator.AvatarResult result = AvatarFaceMapGenerator.Generate(smr, blink, mouth);
                if (!result.Success)
                {
                    _makeupAutoError = result.Error;
                    SetAutoWarning("メイク基準を自動作成できませんでした: " + result.Error, MessageType.Warning);
                    MarkUiDirty();
                    return;
                }

                Texture2D usedTex = (result.FaceTexture as Texture2D) ?? GuessFaceTexture(smr);
                FaceMapFile file = BuildAutoFaceMapFile(temp, result, null, usedTex);

                string baseName = FaceMapSerializer.SanitizeFileName(avatarOrPrefab.name);
                if (string.IsNullOrEmpty(baseName)) baseName = "makeup";
                string path = FaceMapStorage.AutoSaveFolder + "/" + baseName + ".json";
                if (!FaceMapStorage.TrySave(path, file, out string saveError))
                {
                    _makeupAutoError = saveError;
                    SetAutoWarning("メイク基準を保存できませんでした: " + saveError, MessageType.Error);
                    MarkUiDirty();
                    return;
                }

                _state.MakeupFaceMapPath = path;
                _makeupAutoPath = path;
                _makeupAutoEyeLineIssue = result.EyeLineIssue;
                _makeupCreateManualOpen = false;
                _makeupAvatarPickerOpen = false;
                RequestRefresh();

                if (allowAutoFillTexture && _state.PreviewMakeupTexture == null && usedTex != null)
                    SetMakeupTexture(usedTex, fromUser: false);

                if (result.EyeLineIssue != null)
                    SetAutoWarning($"メイク基準を自動作成しました（目の線 要確認）: {result.EyeLineIssue}", MessageType.Warning);
                else
                    SetAutoWarning($"プレハブ「{avatarOrPrefab.name}」からメイク基準を自動作成しました。", MessageType.Info);
                MarkUiDirty();
            }
            finally
            {
                if (temp != null) Object.DestroyImmediate(temp);
            }
        }

        /// <summary>「この画像で手動作成」: 現在のメイクテクスチャを引き継いで FaceMap エディターを新規作成で開く。</summary>
        private void OpenFaceMapEditorForNewMakeup()
        {
            MyVrcToolFaceMapEditorWindow.OpenForNewMakeup(_state.PreviewMakeupTexture, OnMakeupFaceMapCreated);
        }

        /// <summary>FaceMap エディターで新規保存されたメイク基準をメインウィンドウへ自動反映する。</summary>
        private void OnMakeupFaceMapCreated(string savedPath)
        {
            if (this == null || string.IsNullOrEmpty(savedPath)) return;
            _state.MakeupFaceMapPath = savedPath;
            _makeupCreateManualOpen = false;
            _makeupAvatarPickerOpen = false;
            _makeupAutoError = null;
            _makeupAutoEyeLineIssue = null;
            _makeupAutoPath = null;
            if (_state.PreviewMakeupTexture != null)
                MakeFixTextureMemory.SaveMakeupLink(_state.PreviewMakeupTexture, savedPath);
            RequestRefresh();
            MarkUiDirty();
            Focus();
        }

        /// <summary>選択中のメイク基準を FaceMap エディターで微調整する（一致するシーン内アバターがあれば引き継ぐ）。</summary>
        private void OpenFaceMapEditorForMakeupRefinement()
        {
            FaceMapMeta map = _state.MakeupFaceMap;
            if (map == null) return;

            GameObject avatar = FindSceneAvatarForFaceMap(map);
            SkinnedMeshRenderer smr = avatar != null ? AvatarFaceMapGenerator.GuessRenderer(avatar, _state.PreviewMakeupTexture) : null;
            Texture2D tex = _state.PreviewMakeupTexture ?? ResolveFaceTextureForMakeupMap(map);
            if (_makeupAutoEyeLineIssue != null && MakeFixMakeupSource.PathsEqual(_makeupAutoPath, map.FilePath))
                MyVrcToolFaceMapEditorWindow.OpenForEyeLineReview(map.FilePath, avatar, smr, tex, _makeupAutoEyeLineIssue);
            else
                MyVrcToolFaceMapEditorWindow.OpenForRefinement(map.FilePath, avatar, smr, tex);
        }

        /// <summary>カード右上の「作成 / 微調整 ▾」メニュー。</summary>
        private void ShowMakeupActionMenu()
        {
            var menu = new GenericMenu();
            if (_state.MakeupFaceMap != null)
                menu.AddItem(new GUIContent("選択中のメイク基準を微調整（FaceMap エディター）"), false, OpenFaceMapEditorForMakeupRefinement);
            else
                menu.AddDisabledItem(new GUIContent("選択中のメイク基準を微調整（FaceMap エディター）"));

            menu.AddSeparator("");
            menu.AddItem(new GUIContent("元アバターから自動作成..."), false, () =>
            {
                _makeupCreateManualOpen = true;
                _makeupAvatarPickerOpen = true;
                MarkUiDirty();
            });
            menu.AddItem(new GUIContent(MakeFixMakeupSource.ManualCreateButtonLabel(_state.PreviewMakeupTexture != null) + "（FaceMap エディター）"),
                false, OpenFaceMapEditorForNewMakeup);

            if (_state.PreviewMakeupTexture != null)
            {
                menu.AddSeparator("");
                menu.AddItem(new GUIContent("メイクテクスチャをクリア"), false, () => SetMakeupTexture(null, fromUser: false));
            }
            menu.ShowAsContext();
        }

        // ── ヘルパー（シーン内アバター・顔テクスチャの確実な照合）──

        private FaceMapMeta FindSavedFaceMapByAvatarName(string avatarName)
        {
            if (string.IsNullOrEmpty(avatarName)) return null;
            List<FaceMapMeta> saved = _state.FaceMaps
                .Where(m => m.IsValid && !FaceMapStorage.IsDraft(m.FilePath))
                .OrderByDescending(m => m.LastWriteTicks)
                .ToList();
            FaceMapMeta byTarget = saved.FirstOrDefault(m => m.TargetAvatar == avatarName);
            if (byTarget != null) return byTarget;
            string sanitized = FaceMapSerializer.SanitizeFileName(avatarName);
            if (string.IsNullOrEmpty(sanitized)) return null;
            return saved.FirstOrDefault(m =>
                string.Equals(System.IO.Path.GetFileNameWithoutExtension(m.FileName), sanitized, System.StringComparison.OrdinalIgnoreCase));
        }

        private GameObject FindSceneAvatarForFaceMap(FaceMapMeta map)
        {
            if (map == null) return null;
            foreach (GameObject avatar in _sceneAvatars)
            {
                if (avatar == null) continue;
                FaceMapMeta found = FindAvatarFaceMap(avatar);
                if (found != null && MakeFixMakeupSource.PathsEqual(found.FilePath, map.FilePath)) return avatar;
            }
            return null;
        }

        /// <summary>指定テクスチャを顔マテリアルのメインテクスチャとして使っているシーン内アバター（対象アバター以外を優先）。</summary>
        private GameObject FindSceneAvatarUsingFaceTexture(Texture2D tex)
        {
            if (tex == null) return null;
            foreach (GameObject avatar in _sceneAvatars)
            {
                if (avatar == null || ReferenceEquals(avatar, _state.TargetAvatar)) continue;
                if (AvatarUsesMainTexture(avatar, tex)) return avatar;
            }
            return null;
        }

        private static bool AvatarUsesMainTexture(GameObject avatar, Texture2D tex)
        {
            foreach (SkinnedMeshRenderer r in avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                foreach (Material mat in r.sharedMaterials)
                {
                    Material original = FaceMaterialApplier.ResolveOriginal(mat);
                    if (original == null) continue;
                    if (original.HasProperty("_MainTex") && ReferenceEquals(original.mainTexture, tex)) return true;
                    if (original.HasProperty("_BaseMap") && ReferenceEquals(original.GetTexture("_BaseMap"), tex)) return true;
                }
            }
            return false;
        }

        private Texture2D ResolveFaceTextureForMakeupMap(FaceMapMeta map)
        {
            if (map == null || !map.IsValid) return null;
            GameObject avatar = FindSceneAvatarForFaceMap(map);
            Texture2D hint = ResolveHintTexture(map, avatar);
            if (hint != null) return hint;
            if (avatar != null)
            {
                SkinnedMeshRenderer smr = AvatarFaceMapGenerator.GuessRenderer(avatar, null);
                return GuessFaceTexture(smr);
            }
            return null;
        }

        /// <summary>ドロップダウン用の「既存 FaceMap がまだ無いシーン内アバター」一覧（対象アバターは除外）。</summary>
        private List<MakeFixMakeupSource.SceneAvatarEntry> BuildUnmappedSceneAvatarsForMakeup()
        {
            var list = new List<MakeFixMakeupSource.SceneAvatarEntry>();
            foreach (GameObject avatar in _sceneAvatars)
            {
                if (avatar == null || ReferenceEquals(avatar, _state.TargetAvatar)) continue;
                if (FindAvatarFaceMap(avatar) != null) continue;
                list.Add(new MakeFixMakeupSource.SceneAvatarEntry
                {
                    Key = AutoKey(avatar),
                    Name = avatar.name,
                });
            }
            return list;
        }

        private static GameObject DraggedAvatarOrPrefab()
        {
            foreach (Object obj in DragAndDrop.objectReferences)
            {
                if (!(obj is GameObject go)) continue;
                if (go.GetComponentInChildren<SkinnedMeshRenderer>(true) != null) return go;
            }
            return null;
        }

        private static Texture2D DraggedTextureAsset()
        {
            foreach (Object obj in DragAndDrop.objectReferences)
            {
                if (obj is Texture2D tex) return tex;
            }
            return null;
        }
    }
}
