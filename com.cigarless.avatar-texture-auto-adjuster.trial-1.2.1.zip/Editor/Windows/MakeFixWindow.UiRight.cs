using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── 右ペイン (UI Toolkit) ──

        private ScrollView _rightScrollView;

        // Card 5: Makeup Source
        private VisualElement _cardMakeupSource;
        private VisualElement _dotMakeupSource;
        private Button _btnMakeupMenu;
        private VisualElement _makeupTexDropZone;
        private VisualElement _thumbMakeupTexWrap;
        private Image _imgMakeupTex;
        private Label _lblMakeupTexName;
        private Label _lblMakeupTexRes;
        private Button _btnPickMakeupFile;
        private Button _btnPickMakeupCandidate;
        private VisualElement _warnMakeupSameTex;
        private VisualElement _rowMakeupFaceMap;
        private DropdownField _dropdownMakeupFaceMap;
        private VisualElement _warnMakeupNotes;
        private Label _lblMakeupNotes;
        private VisualElement _warnMakeupAuto;
        private Label _lblMakeupAuto;
        private Button _btnMakeupAutoFix;
        private VisualElement _boxMakeupCreate;
        private Button _btnMakeupCreateClose;
        private Button _btnMakeupAutoFromAvatar;
        private Button _btnMakeupManualCreate;
        private VisualElement _boxMakeupAvatarPicker;
        private ObjectField _fieldMakeupSourceAvatar;
        private VisualElement _warnMakeupMissing;
        private Label _lblMakeupMissing;
        private Button _btnMakeupMissingFix;
        private Action _makeupMissingAction;
        private VisualElement _warnInvalidMaps;
        private Label _lblInvalidMaps;
        private Button _btnInvalidMapsDetail;
        private VisualElement _boxInvalidMapsDetail;

        // Adjustment Cards
        private VisualElement _cardAdjustLocked;
        private VisualElement _adjustCardsContainer;

        // Card 6: Parts
        private VisualElement _cardParts;
        private VisualElement _dotParts;
        private Button _btnResetAll;
        private VisualElement _partTabStrip;
        private Toggle _togglePartEnabled;

        // Transform Matrix & D-Pad
        private Label _chipEditTarget;
        private Label _chipLayerAdjusted;
        private Button _btnResetLayer;
        private DropdownField _dropdownStep;
        private Label _lblRotationVal;
        private Toggle _toggleLocalPart;
        private VisualElement _rowPairGap;
        private VisualElement _scrubGapMinus, _scrubGapPlus;
        private VisualElement _rowCenterAlign;
        private Button _btnCenterAlign;
        private Foldout _foldoutDetail;
        private Vector2Field _numOffset;
        private Vector2Field _numScale;
        private FloatField _numRotation;
        private FloatField _numGap;

        // Eye Settings
        private VisualElement _cardEyeSettings;
        private Label _chipEyeAdjusted;
        private Button _btnResetEye;
        private VisualElement _groupEyeBand;
        private Slider _sliderLowerEyeWidth;
        private Label _valLowerEyeWidth;
        private Slider _sliderLowerEyeFlare;
        private Label _valLowerEyeFlare;
        private Label _lblEyeBandMissing;
        private VisualElement _groupEyeLines;
        private Slider _sliderEyeUpperLine;
        private Label _valEyeUpperLine;
        private VisualElement _blockEyeLowerLine;
        private Slider _sliderEyeLowerLine;
        private Label _valEyeLowerLine;
        private Label _lblMakeupEyeLineMissing;
        private Label _lblAvatarEyeLineMissing;

        // Mouth Settings
        private VisualElement _cardMouthSettings;
        private Label _chipMouthAdjusted;
        private Button _btnResetMouth;
        private Label _lblMouthBend;
        private Slider _sliderMouthBend;
        private Label _valMouthBend;
        private Button _btnResetMouthBend;
        private VisualElement _fillMouthBend;
        private VisualElement _groupMouthFold;
        private Label _lblMouthFold;
        private Slider _sliderMouthFold;
        private Label _valMouthFold;
        private Button _btnResetMouthFold;
        private VisualElement _fillMouthFold;
        private Label _lblMouthFoldUnavailable;

        // Finish
        private Label _chipFinishAdjusted;
        private Button _btnResetFinish;
        private Slider _sliderOpacity;
        private Label _valOpacity;
        private Toggle _toggleSkinTone;
        private Foldout _foldoutMask;
        private Slider _sliderMaskMargin;
        private Label _valMaskMargin;
        private Slider _sliderMaskFeather;
        private Label _valMaskFeather;
        private Slider _sliderExcludeFeather;
        private Label _valExcludeFeather;

        // Bottom Apply Commit Area
        private VisualElement _progressBlock;
        private Label _lblStepProgress;
        private Label _lblApplyingHint;
        private VisualElement _progressFill;
        private Label _lblHeaderStep;
        private VisualElement _headerProgressFill;
        private Button _btnNextStep;
        private VisualElement _applyStatusBox;
        private Label _lblApplyStatusTitle;
        private Label _lblApplyStatusSub;
        private Button _btnLocateApplied;
        private Button _btnApplyMakeup;
        private Button _btnRevertMakeup;

        private string _lastMakeupMapChoicesSig;
        private string _lastPartTabsSig;
        private string _lastInvalidMapsSig;

        private static readonly List<string> StepChoiceLabels = new List<string> { "0.001", "0.005", "0.01", "0.05" };

        private void BindRightUi()
        {
            _rightScrollView = _root.Q<ScrollView>("right-scroll");

            // Card 5: Makeup Source
            _cardMakeupSource = _root.Q<VisualElement>("card-makeup-source");
            _dotMakeupSource = _root.Q<VisualElement>("dot-makeup-source");
            _btnMakeupMenu = _root.Q<Button>("btn-makeup-menu");
            _makeupTexDropZone = _root.Q<VisualElement>("makeup-tex-drop-zone");
            _thumbMakeupTexWrap = _root.Q<VisualElement>("thumb-makeup-tex-wrap");
            _imgMakeupTex = _root.Q<Image>("img-makeup-tex");
            _lblMakeupTexName = _root.Q<Label>("lbl-makeup-tex-name");
            _lblMakeupTexRes = _root.Q<Label>("lbl-makeup-tex-res");
            _btnPickMakeupFile = _root.Q<Button>("btn-pick-makeup-file");
            _btnPickMakeupCandidate = _root.Q<Button>("btn-pick-makeup-candidate");
            _warnMakeupSameTex = _root.Q<VisualElement>("warn-makeup-same-tex");
            _rowMakeupFaceMap = _root.Q<VisualElement>("row-makeup-facemap");
            _dropdownMakeupFaceMap = _root.Q<DropdownField>("dropdown-makeup-facemap");
            _warnMakeupNotes = _root.Q<VisualElement>("warn-makeup-notes");
            _lblMakeupNotes = _root.Q<Label>("lbl-makeup-notes");
            _warnMakeupAuto = _root.Q<VisualElement>("warn-makeup-auto");
            _lblMakeupAuto = _root.Q<Label>("lbl-makeup-auto");
            _btnMakeupAutoFix = _root.Q<Button>("btn-makeup-auto-fix");
            _boxMakeupCreate = _root.Q<VisualElement>("box-makeup-create");
            _btnMakeupCreateClose = _root.Q<Button>("btn-makeup-create-close");
            _btnMakeupAutoFromAvatar = _root.Q<Button>("btn-makeup-auto-from-avatar");
            _btnMakeupManualCreate = _root.Q<Button>("btn-makeup-manual-create");
            _boxMakeupAvatarPicker = _root.Q<VisualElement>("box-makeup-avatar-picker");
            _fieldMakeupSourceAvatar = _root.Q<ObjectField>("field-makeup-source-avatar");
            _warnMakeupMissing = _root.Q<VisualElement>("warn-makeup-missing");
            _lblMakeupMissing = _root.Q<Label>("lbl-makeup-missing");
            _btnMakeupMissingFix = _root.Q<Button>("btn-makeup-missing-fix");
            _warnInvalidMaps = _root.Q<VisualElement>("warn-invalid-maps");
            _lblInvalidMaps = _root.Q<Label>("lbl-invalid-maps");
            _btnInvalidMapsDetail = _root.Q<Button>("btn-invalid-maps-detail");
            _boxInvalidMapsDetail = _root.Q<VisualElement>("box-invalid-maps-detail");
            _cardElements[FocusCard.MakeupSource] = _cardMakeupSource;

            _btnMakeupMenu.tooltip = "メイク基準の新規作成・FaceMap エディターでの微調整などを行います。";
            _btnMakeupMenu.clicked += ShowMakeupActionMenu;

            // メイクテクスチャカード全体で D&D を受付（Project のアセット & OS の画像ファイル）
            _makeupTexDropZone.RegisterCallback<DragUpdatedEvent>(_ =>
            {
                bool ok = DraggedTextureAsset() != null || MakeupTextureImporter.FindDraggedImagePath(DragAndDrop.paths) != null;
                DragAndDrop.visualMode = ok ? DragAndDropVisualMode.Copy : DragAndDropVisualMode.Rejected;
                _makeupTexDropZone.EnableInClassList("makeup-drop-zone--hover", ok);
            });
            _makeupTexDropZone.RegisterCallback<DragLeaveEvent>(_ => _makeupTexDropZone.RemoveFromClassList("makeup-drop-zone--hover"));
            _makeupTexDropZone.RegisterCallback<DragExitedEvent>(_ => _makeupTexDropZone.RemoveFromClassList("makeup-drop-zone--hover"));
            _makeupTexDropZone.RegisterCallback<DragPerformEvent>(_ =>
            {
                _makeupTexDropZone.RemoveFromClassList("makeup-drop-zone--hover");
                Texture2D dropped = DraggedTextureAsset();
                if (dropped != null)
                {
                    DragAndDrop.AcceptDrag();
                    SetMakeupTexture(dropped, fromUser: true);
                    return;
                }
                string filePath = MakeupTextureImporter.FindDraggedImagePath(DragAndDrop.paths);
                if (filePath != null)
                {
                    DragAndDrop.AcceptDrag();
                    ApplyImportedMakeupTexture(MakeupTextureImporter.ImportOrLoad(filePath));
                }
            });

            _thumbMakeupTexWrap.tooltip = "クリックで画像ファイルを選びます（D&D にも対応）。";
            _thumbMakeupTexWrap.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button != 0) return;
                PickMakeupTextureFromFile();
            });

            _btnPickMakeupFile.tooltip = "ファイルダイアログから画像（PNG / PSD 等）を選びます。プロジェクト外の画像も自動で取り込めます。";
            _btnPickMakeupFile.clicked += PickMakeupTextureFromFile;

            _btnPickMakeupCandidate.tooltip = "シーン内の他アバターの顔テクスチャや、最近使ったメイクから選びます。";
            _btnPickMakeupCandidate.clicked += () =>
            {
                Rect wb = _btnPickMakeupCandidate.worldBound;
                ShowMakeupTextureMenu(new Rect(wb.x, wb.y, wb.width, wb.height));
            };

            _dropdownMakeupFaceMap.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _makeupChoiceByLabel.TryGetValue(evt.newValue ?? "", out MakeFixMakeupSource.DropdownChoice choice);
                SelectMakeupFaceMapChoice(choice);
            });

            // メイク基準行へのシーン内アバター／プレハブ直接 D&D に対応
            _rowMakeupFaceMap.tooltip = "メイク基準（FaceMap）を選びます。元アバターやプレハブをここへ D&D して自動作成もできます。";
            _rowMakeupFaceMap.RegisterCallback<DragUpdatedEvent>(_ =>
            {
                bool ok = DraggedAvatarOrPrefab() != null;
                if (!ok) return;
                DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                _rowMakeupFaceMap.AddToClassList("makeup-drop-zone--hover");
            });
            _rowMakeupFaceMap.RegisterCallback<DragLeaveEvent>(_ => _rowMakeupFaceMap.RemoveFromClassList("makeup-drop-zone--hover"));
            _rowMakeupFaceMap.RegisterCallback<DragExitedEvent>(_ => _rowMakeupFaceMap.RemoveFromClassList("makeup-drop-zone--hover"));
            _rowMakeupFaceMap.RegisterCallback<DragPerformEvent>(_ =>
            {
                _rowMakeupFaceMap.RemoveFromClassList("makeup-drop-zone--hover");
                GameObject dropped = DraggedAvatarOrPrefab();
                if (dropped == null) return;
                DragAndDrop.AcceptDrag();
                GenerateMakeupFaceMapFromAvatar(dropped, allowAutoFillTexture: _state.PreviewMakeupTexture == null);
            });

            _btnMakeupAutoFix.clicked += OpenFaceMapEditorForMakeupRefinement;

            _btnMakeupCreateClose.clicked += () =>
            {
                _makeupCreateManualOpen = false;
                _makeupAvatarPickerOpen = false;
                MarkUiDirty();
            };

            _btnMakeupAutoFromAvatar.tooltip = "メイク元アバター（シーン内または Project のプレハブ）から FaceMap を自動作成します。";
            _btnMakeupAutoFromAvatar.clicked += () =>
            {
                _makeupAvatarPickerOpen = !_makeupAvatarPickerOpen;
                MarkUiDirty();
            };

            _btnMakeupManualCreate.tooltip = "現在のメイクテクスチャを引き継いで FaceMap エディターを開き、保存すると自動でここへ反映されます。";
            _btnMakeupManualCreate.clicked += OpenFaceMapEditorForNewMakeup;

            _fieldMakeupSourceAvatar.objectType = typeof(GameObject);
            _fieldMakeupSourceAvatar.allowSceneObjects = true;
            _fieldMakeupSourceAvatar.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                var go = evt.newValue as GameObject;
                _suppressUiEvents = true;
                _fieldMakeupSourceAvatar.SetValueWithoutNotify(null);
                _suppressUiEvents = false;
                if (go != null)
                    GenerateMakeupFaceMapFromAvatar(go, allowAutoFillTexture: _state.PreviewMakeupTexture == null);
            });

            _btnMakeupMissingFix.clicked += () => _makeupMissingAction?.Invoke();
            _btnInvalidMapsDetail.clicked += () =>
            {
                _showInvalidDetail = !_showInvalidDetail;
                MarkUiDirty();
            };

            // Adjustment Containers
            _cardAdjustLocked = _root.Q<VisualElement>("card-adjust-locked");
            _adjustCardsContainer = _root.Q<VisualElement>("adjust-cards-container");

            // Card 6: Parts
            _cardParts = _root.Q<VisualElement>("card-parts");
            _dotParts = _root.Q<VisualElement>("dot-parts");
            _btnResetAll = _root.Q<Button>("btn-reset-all");
            _partTabStrip = _root.Q<VisualElement>("part-tab-strip");
            _togglePartEnabled = _root.Q<Toggle>("toggle-part-enabled");
            _cardElements[FocusCard.Parts] = _cardParts;

            _btnResetAll.clicked += () =>
            {
                FaceMapAdjustment adj = _state.Adjustment;
                if (adj == null || adj.IsIdentity || _previewDrag != PreviewDrag.None) return;
                if (EditorUtility.DisplayDialog("調整をすべてリセット",
                        "位置・大きさ・目や口の調整・合成範囲など、この組み合わせの調整をすべて自動の状態に戻しますか？\n（メイクの濃さは変わりません）",
                        "リセットする", "キャンセル"))
                {
                    adj.Reset();
                    MarkAdjustmentChanged();
                    MarkUiDirty();
                }
            };

            _togglePartEnabled.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _editTarget == null || _state.Adjustment == null) return;
                _state.Adjustment.SetEnabled(_editTarget, evt.newValue);
                MarkAdjustmentChanged();
                MarkUiDirty();
            });

            // Transform Matrix & D-Pad
            _chipEditTarget = _root.Q<Label>("chip-edit-target");
            _chipLayerAdjusted = _root.Q<Label>("chip-layer-adjusted");
            _btnResetLayer = _root.Q<Button>("btn-reset-layer");
            _dropdownStep = _root.Q<DropdownField>("dropdown-step");
            _lblRotationVal = _root.Q<Label>("lbl-rotation-val");
            _toggleLocalPart = _root.Q<Toggle>("toggle-local-part");
            _rowPairGap = _root.Q<VisualElement>("row-pair-gap");
            _rowCenterAlign = _root.Q<VisualElement>("row-center-align");
            _btnCenterAlign = _root.Q<Button>("btn-center-align");
            _foldoutDetail = _root.Q<Foldout>("foldout-detail");
            _numOffset = _root.Q<Vector2Field>("num-offset");
            _numScale = _root.Q<Vector2Field>("num-scale");
            _numRotation = _root.Q<FloatField>("num-rotation");
            _numGap = _root.Q<FloatField>("num-gap");

            // 入力途中の値で ClampScale / 保存が走らないよう遅延入力にする
            _numOffset.Query<FloatField>().ForEach(f => f.isDelayed = true);
            _numScale.Query<FloatField>().ForEach(f => f.isDelayed = true);
            _numRotation.isDelayed = true;
            _numGap.isDelayed = true;

            _btnResetLayer.clicked += () =>
            {
                if (_state.Adjustment == null || _previewDrag != PreviewDrag.None) return;
                FaceMapTransform current = _editTarget == null ? _state.Adjustment.Global : _state.Adjustment.FindPart(_editTarget);
                if (current == null || current.IsIdentity) return;
                current.Reset();
                MarkAdjustmentChanged();
                MarkUiDirty();
            };

            // Step Dropdown
            int stepIdx = Mathf.Clamp(EditorPrefs.GetInt(NudgePad.MakeFixStepKey, 1), 0, StepChoiceLabels.Count - 1);
            _dropdownStep.choices = StepChoiceLabels;
            _dropdownStep.SetValueWithoutNotify(StepChoiceLabels[stepIdx]);
            _dropdownStep.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                int idx = StepChoiceLabels.IndexOf(evt.newValue);
                if (idx >= 0) EditorPrefs.SetInt(NudgePad.MakeFixStepKey, idx);
            });

            // Bind D-Pad Scrubbers
            Func<bool> canEdit = () => _showPreview && _previewDrag == PreviewDrag.None && _state.Adjustment != null;
            Action<Vector2> applyMove = move =>
            {
                FaceMapAdjustment adj = _state.Adjustment;
                FaceMapTransform layer = EditLayer(adj);
                Vector2 outer = OuterScale(adj);
                layer.Offset += new Vector2(move.x / outer.x, move.y / outer.y);
                MarkAdjustmentChanged();
                MarkUiDirty();
            };

            BindScrub2D(_root.Q<VisualElement>("dpad-up"), Vector2.up, "dpad-btn--active", canEdit, applyMove);
            BindScrub2D(_root.Q<VisualElement>("dpad-down"), Vector2.down, "dpad-btn--active", canEdit, applyMove);
            BindScrub2D(_root.Q<VisualElement>("dpad-left"), Vector2.left, "dpad-btn--active", canEdit, applyMove);
            BindScrub2D(_root.Q<VisualElement>("dpad-right"), Vector2.right, "dpad-btn--active", canEdit, applyMove);
            BindScrub2D(_root.Q<VisualElement>("dpad-center"), Vector2.zero, "dpad-btn--active", canEdit, applyMove);

            // Bind Width / Height / Rotation Scrubbers
            Action<float> applyScaleX = sx =>
            {
                FaceMapAdjustment adj = _state.Adjustment;
                FaceMapTransform layer = EditLayer(adj);
                Rect bounds = AtaaCore.GetAvatarBounds(_state.PairMatch, _editTarget);
                float step = NudgePad.CurrentStep(NudgePad.MakeFixStepKey);
                Vector2 outer = OuterScale(adj);
                layer.Scale += new Vector2(sx * step / Mathf.Max(bounds.width * outer.x, 1e-3f), 0f);
                layer.ClampScale();
                MarkAdjustmentChanged();
                MarkUiDirty();
            };
            Action<float> applyScaleY = sy =>
            {
                FaceMapAdjustment adj = _state.Adjustment;
                FaceMapTransform layer = EditLayer(adj);
                Rect bounds = AtaaCore.GetAvatarBounds(_state.PairMatch, _editTarget);
                float step = NudgePad.CurrentStep(NudgePad.MakeFixStepKey);
                Vector2 outer = OuterScale(adj);
                layer.Scale += new Vector2(0f, sy * step / Mathf.Max(bounds.height * outer.y, 1e-3f));
                layer.ClampScale();
                MarkAdjustmentChanged();
                MarkUiDirty();
            };
            Func<bool> canRotate = () => canEdit() && _state.Adjustment.LocalPartAdjust;
            Action<float> applyRot = rot =>
            {
                FaceMapTransform layer = EditLayer(_state.Adjustment);
                layer.Rotation += rot * RotationStep;
                layer.ClampScale();
                MarkAdjustmentChanged();
                MarkUiDirty();
            };

            BindScrub1D(_root.Q<VisualElement>("scrub-sx-minus"), -1f, "stepper-btn--active", canEdit, applyScaleX);
            BindScrub1D(_root.Q<VisualElement>("scrub-sx-plus"), 1f, "stepper-btn--active", canEdit, applyScaleX);
            BindScrub1D(_root.Q<VisualElement>("scrub-sy-minus"), -1f, "stepper-btn--active", canEdit, applyScaleY);
            BindScrub1D(_root.Q<VisualElement>("scrub-sy-plus"), 1f, "stepper-btn--active", canEdit, applyScaleY);
            Func<string> rotateOff = () => canEdit() ? "下の「パーツのまわりだけ動かす」が ON のときだけ回せます" : null;
            BindScrub1D(_root.Q<VisualElement>("scrub-rot-cw"), -1f, "stepper-btn--active", canRotate, applyRot, rotateOff);
            BindScrub1D(_root.Q<VisualElement>("scrub-rot-ccw"), 1f, "stepper-btn--active", canRotate, applyRot, rotateOff);

            // Pair Gap Scrubbers
            Func<bool> canGap = () => canEdit() && IsPairCategory(_editTarget) && AtaaCore.MinGap(_state.PairMatch, _state.Adjustment, _editTarget).HasValue;
            Action<float> applyGap = steps =>
            {
                FaceMapAdjustment adj = _state.Adjustment;
                float? minGap = AtaaCore.MinGap(_state.PairMatch, adj, _editTarget);
                if (!minGap.HasValue) return;
                FaceMapTransform layer = EditLayer(adj);
                float step = NudgePad.CurrentStep(NudgePad.MakeFixStepKey);
                SetGap(layer, AtaaCore.NudgeGap(layer.Gap, minGap.Value, steps * step / OuterScale(adj).x), minGap.Value);
                MarkUiDirty();
            };
            Func<string> gapOff = () => canEdit() ? "左右の領域が両方そろっていないため、間隔は変えられません" : null;
            _scrubGapMinus = _root.Q<VisualElement>("scrub-gap-minus");
            _scrubGapPlus = _root.Q<VisualElement>("scrub-gap-plus");
            BindScrub1D(_scrubGapMinus, -1f, "pill-scrub-btn--active", canGap, applyGap, gapOff);
            BindScrub1D(_scrubGapPlus, 1f, "pill-scrub-btn--active", canGap, applyGap, gapOff);

            // Center Align
            _btnCenterAlign.clicked += () =>
            {
                if (!canEdit()) return;
                float? centerX = _state.PairMatch?.AvatarCenterX;
                if (!centerX.HasValue) return;
                FaceMapAdjustment adj = _state.Adjustment;
                FaceMapTransform layer = EditLayer(adj);
                GetEditBox(_state.PairMatch, adj, out Rect bounds, out Vector2 globalPivot, out Vector2 boxCenter, out _);
                Vector2 inner = OuterInverse(adj, new Vector2(centerX.Value, boxCenter.y), globalPivot);
                float offsetX = inner.x - bounds.center.x;
                if (!Mathf.Approximately(offsetX, layer.Offset.x))
                {
                    layer.Offset = new Vector2(offsetX, layer.Offset.y);
                    MarkAdjustmentChanged();
                    MarkUiDirty();
                }
            };

            _toggleLocalPart.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.LocalPartAdjust = evt.newValue;
                MarkAdjustmentChanged();
                MarkUiDirty();
            });

            // Numeric Foldout Callbacks
            _numOffset.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                EditLayer(_state.Adjustment).Offset = evt.newValue;
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _numScale.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                FaceMapTransform layer = EditLayer(_state.Adjustment);
                layer.Scale = evt.newValue;
                layer.ClampScale();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _numRotation.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null || !_state.Adjustment.LocalPartAdjust) return;
                FaceMapTransform layer = EditLayer(_state.Adjustment);
                layer.Rotation = evt.newValue;
                layer.ClampScale();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _numGap.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                float? minGap = AtaaCore.MinGap(_state.PairMatch, _state.Adjustment, _editTarget);
                if (!minGap.HasValue) return;
                SetGap(EditLayer(_state.Adjustment), evt.newValue, minGap.Value);
                MarkUiDirty();
            });

            // Eye Settings
            _cardEyeSettings = _root.Q<VisualElement>("card-eye-settings");
            _chipEyeAdjusted = _root.Q<Label>("chip-eye-adjusted");
            _btnResetEye = _root.Q<Button>("btn-reset-eye");
            _groupEyeBand = _root.Q<VisualElement>("group-eye-band");
            _sliderLowerEyeWidth = _root.Q<Slider>("slider-lower-eye-width");
            _valLowerEyeWidth = _root.Q<Label>("val-lower-eye-width");
            _sliderLowerEyeFlare = _root.Q<Slider>("slider-lower-eye-flare");
            _valLowerEyeFlare = _root.Q<Label>("val-lower-eye-flare");
            _lblEyeBandMissing = _root.Q<Label>("lbl-eye-band-missing");
            _groupEyeLines = _root.Q<VisualElement>("group-eye-lines");
            _sliderEyeUpperLine = _root.Q<Slider>("slider-eye-upper-line");
            _valEyeUpperLine = _root.Q<Label>("val-eye-upper-line");
            _blockEyeLowerLine = _root.Q<VisualElement>("block-eye-lower-line");
            _sliderEyeLowerLine = _root.Q<Slider>("slider-eye-lower-line");
            _valEyeLowerLine = _root.Q<Label>("val-eye-lower-line");
            _lblMakeupEyeLineMissing = _root.Q<Label>("lbl-makeup-eyeline-missing");
            _lblAvatarEyeLineMissing = _root.Q<Label>("lbl-avatar-eyeline-missing");

            _sliderLowerEyeWidth.lowValue = FaceMapAdjustment.MinLowerEyeWidthScale;
            _sliderLowerEyeWidth.highValue = FaceMapAdjustment.MaxLowerEyeWidthScale;
            _sliderLowerEyeFlare.lowValue = 0f;
            _sliderLowerEyeFlare.highValue = FaceMapAdjustment.MaxLowerEyeOuterFlare;
            _sliderEyeUpperLine.lowValue = FaceMapFile.MinEyeLine;
            _sliderEyeUpperLine.highValue = FaceMapFile.MaxEyeLine;
            _sliderEyeLowerLine.lowValue = FaceMapFile.MinEyeLine;
            _sliderEyeLowerLine.highValue = FaceMapFile.MaxEyeLine;

            RegisterSliderInteraction(_sliderLowerEyeWidth);
            RegisterSliderInteraction(_sliderLowerEyeFlare);
            RegisterSliderInteraction(_sliderEyeUpperLine);
            RegisterSliderInteraction(_sliderEyeLowerLine);

            _btnResetEye.clicked += () =>
            {
                if (_state.Adjustment == null || !_state.Adjustment.HasEyeAdjustment) return;
                _state.Adjustment.ResetEye();
                MarkAdjustmentChanged();
                MarkUiDirty();
            };

            _sliderLowerEyeWidth.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.LowerEyeWidthScale = evt.newValue;
                _state.Adjustment.ClampEye();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _sliderLowerEyeFlare.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.LowerEyeOuterFlare = evt.newValue;
                _state.Adjustment.ClampEye();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _sliderEyeUpperLine.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.PairMatch == null) return;
                SetEyeLineOverrides(evt.newValue, _state.PairMatch.AvatarEyeLowerLine);
                MarkUiDirty();
            });
            _sliderEyeLowerLine.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.PairMatch == null || !_state.PairMatch.AvatarEyeLine.HasValue) return;
                SetEyeLineOverrides(_state.PairMatch.AvatarEyeLine.Value, evt.newValue);
                MarkUiDirty();
            });

            // Mouth Settings
            _cardMouthSettings = _root.Q<VisualElement>("card-mouth-settings");
            _chipMouthAdjusted = _root.Q<Label>("chip-mouth-adjusted");
            _btnResetMouth = _root.Q<Button>("btn-reset-mouth");
            _lblMouthBend = _root.Q<Label>("lbl-mouth-bend");
            _sliderMouthBend = _root.Q<Slider>("slider-mouth-bend");
            _valMouthBend = _root.Q<Label>("val-mouth-bend");
            _btnResetMouthBend = _root.Q<Button>("btn-reset-mouth-bend");
            _sliderMouthBend.lowValue = -FaceMapAdjustment.MaxMouthBend;
            _sliderMouthBend.highValue = FaceMapAdjustment.MaxMouthBend;
            _lblMouthBend.tooltip = MakeFixMouthUi.BendTooltip;
            _sliderMouthBend.tooltip = MakeFixMouthUi.BendTooltip;
            _fillMouthBend = AttachBipolarOverlay(_sliderMouthBend);
            RegisterSliderInteraction(_sliderMouthBend);

            _groupMouthFold = _root.Q<VisualElement>("group-mouth-fold");
            _lblMouthFold = _root.Q<Label>("lbl-mouth-fold");
            _sliderMouthFold = _root.Q<Slider>("slider-mouth-fold");
            _valMouthFold = _root.Q<Label>("val-mouth-fold");
            _btnResetMouthFold = _root.Q<Button>("btn-reset-mouth-fold");
            _lblMouthFoldUnavailable = _root.Q<Label>("lbl-mouth-fold-unavailable");
            _sliderMouthFold.lowValue = -FaceMapAdjustment.MaxMouthFold;
            _sliderMouthFold.highValue = FaceMapAdjustment.MaxMouthFold;
            _lblMouthFold.tooltip = MakeFixMouthUi.FoldTooltip;
            _sliderMouthFold.tooltip = MakeFixMouthUi.FoldTooltip;
            _fillMouthFold = AttachBipolarOverlay(_sliderMouthFold);
            RegisterSliderInteraction(_sliderMouthFold);

            _btnResetMouth.clicked += () =>
            {
                if (_state.Adjustment == null || !_state.Adjustment.HasMouthAdjustment) return;
                _state.Adjustment.ResetMouth();
                MarkAdjustmentChanged("口の調整を自動に戻す");
                MarkUiDirty();
            };
            _btnResetMouthBend.clicked += () =>
            {
                if (_state.Adjustment == null || !MakeFixMouthUi.IsNonZero(_state.Adjustment.MouthBend)) return;
                _state.Adjustment.MouthBend = 0f;
                MarkAdjustmentChanged("口角の上下を自動に戻す");
                MarkUiDirty();
            };
            _btnResetMouthFold.clicked += () =>
            {
                if (_state.Adjustment == null || !MakeFixMouthUi.IsNonZero(_state.Adjustment.MouthFold)) return;
                _state.Adjustment.MouthFold = 0f;
                MarkAdjustmentChanged("中央の折れを自動に戻す");
                MarkUiDirty();
            };
            _sliderMouthBend.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.MouthBend = evt.newValue;
                _state.Adjustment.ClampMouth();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _sliderMouthFold.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.MouthFold = evt.newValue;
                _state.Adjustment.ClampMouth();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });

            // Finish Settings
            _sliderOpacity = _root.Q<Slider>("slider-opacity");
            _valOpacity = _root.Q<Label>("val-opacity");
            _toggleSkinTone = _root.Q<Toggle>("toggle-skin-tone");
            _foldoutMask = _root.Q<Foldout>("foldout-mask");
            _sliderMaskMargin = _root.Q<Slider>("slider-mask-margin");
            _valMaskMargin = _root.Q<Label>("val-mask-margin");
            _sliderMaskFeather = _root.Q<Slider>("slider-mask-feather");
            _valMaskFeather = _root.Q<Label>("val-mask-feather");
            _sliderExcludeFeather = _root.Q<Slider>("slider-exclude-feather");
            _valExcludeFeather = _root.Q<Label>("val-exclude-feather");

            _sliderMaskMargin.lowValue = 0f;
            _sliderMaskMargin.highValue = FaceMapAdjustment.MaxMaskExtent;
            _sliderMaskFeather.lowValue = 0f;
            _sliderMaskFeather.highValue = FaceMapAdjustment.MaxMaskExtent;
            _sliderExcludeFeather.lowValue = 0f;
            _sliderExcludeFeather.highValue = FaceMapAdjustment.MaxMaskExtent;

            RegisterSliderInteraction(_sliderOpacity);

            _chipFinishAdjusted = _root.Q<Label>("chip-finish-adjusted");
            _btnResetFinish = _root.Q<Button>("btn-reset-finish");
            _btnResetFinish.clicked += () =>
            {
                if (!MakeFixFinish.IsAdjusted(_state.Adjustment, _state.PreviewMakeupOpacity)) return;
                MakeFixFinish.Reset(_state.Adjustment, ref _state.PreviewMakeupOpacity);
                MarkAdjustmentChanged("仕上げを自動に戻す");
                MarkUiDirty();
            };
            RegisterSliderInteraction(_sliderMaskMargin);
            RegisterSliderInteraction(_sliderMaskFeather);
            RegisterSliderInteraction(_sliderExcludeFeather);

            _sliderOpacity.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                _state.PreviewMakeupOpacity = evt.newValue;
                RecordHistory("メイクの濃さを変更");
                MarkUiDirty();
            });
            _toggleSkinTone.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.MatchSkinTone = evt.newValue;
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _sliderMaskMargin.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.MaskMargin = evt.newValue;
                _state.Adjustment.ClampMask();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _sliderMaskFeather.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.MaskFeather = evt.newValue;
                _state.Adjustment.ClampMask();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });
            _sliderExcludeFeather.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents || _state.Adjustment == null) return;
                _state.Adjustment.ExcludeFeather = evt.newValue;
                _state.Adjustment.ClampMask();
                MarkAdjustmentChanged();
                MarkUiDirty();
            });

            // Bottom Apply Commit Area
            _progressBlock = _root.Q<VisualElement>("progress-block");
            _lblStepProgress = _root.Q<Label>("lbl-step-progress");
            _lblApplyingHint = _root.Q<Label>("lbl-applying-hint");
            _progressFill = _root.Q<VisualElement>("progress-fill");
            _lblHeaderStep = _root.Q<Label>("lbl-header-step");
            _headerProgressFill = _root.Q<VisualElement>("header-progress-fill");
            _btnNextStep = _root.Q<Button>("btn-next-step");
            _applyStatusBox = _root.Q<VisualElement>("apply-status-box");
            _lblApplyStatusTitle = _root.Q<Label>("lbl-apply-status-title");
            _lblApplyStatusSub = _root.Q<Label>("lbl-apply-status-sub");
            _btnLocateApplied = _root.Q<Button>("btn-locate-applied");
            _btnApplyMakeup = _root.Q<Button>("btn-apply-makeup");
            _btnRevertMakeup = _root.Q<Button>("btn-revert-makeup");

            _btnNextStep.clicked += () =>
            {
                ReadinessItem firstFailed = NextItem();
                if (firstFailed != null) FocusCardUi(CardFor(firstFailed));
            };

            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                // 体験版は適用できない（出力は体験版コアの透かし・低解像度。ボタンも使えなくする）
                _btnApplyMakeup.text = "メイク適用（製品版のみ）";
                _btnApplyMakeup.SetEnabled(false);
                _btnRevertMakeup.AddToClassList("hidden");
            }
            else
            {
                _btnLocateApplied.clicked += LocateAppliedTexture;
                _btnApplyMakeup.clicked += () =>
                {
                    if (!_allOk || _applying || EditorApplication.isPlayingOrWillChangePlaymode) return;
                    ApplyMakeup();
                    MarkUiDirty();
                };
                _btnRevertMakeup.clicked += () =>
                {
                    if (_state.TargetAvatar == null || _applying) return;
                    RevertMakeup();
                    MarkUiDirty();
                };
            }

            _lastMakeupMapChoicesSig = null;
            _lastPartTabsSig = null;
            _lastInvalidMapsSig = null;
        }

        private void RefreshRightUi()
        {
            // Card 5: Makeup Source
            bool hasMakeupMap = _state.MakeupFaceMap != null && _state.MakeupFaceMap.IsValid;
            SetStepDot(_dotMakeupSource, StepStateOf(FocusCard.MakeupSource, ItemsOk(1, 5)));
            ApplyCardHighlight(FocusCard.MakeupSource, _cardMakeupSource);
            _btnMakeupMenu.EnableInClassList("hidden", !hasMakeupMap);

            // 上段: メイクテクスチャ
            Texture2D makeupTex = _state.PreviewMakeupTexture;
            _imgMakeupTex.image = makeupTex;
            _lblMakeupTexName.text = makeupTex != null ? makeupTex.name : "未選択";
            _lblMakeupTexRes.text = makeupTex != null
                ? $"{makeupTex.width} × {makeupTex.height} {makeupTex.format}"
                : "PNG 等をここへ D&D、または下で選択";

            bool sameTexAsAvatar = makeupTex != null && ReferenceEquals(makeupTex, _state.PreviewAvatarTexture);
            _warnMakeupSameTex.EnableInClassList("hidden", !sameTexAsAvatar);

            // 下段: メイク基準ドロップダウン（未解析シーンアバター含む・対象と同じ基準は末尾）
            SyncMakeupFaceMapDropdown();

            if (_makeupNotes.Count > 0)
            {
                _warnMakeupNotes.RemoveFromClassList("hidden");
                string more = _makeupNotes.Count > 1 ? $"（他 {_makeupNotes.Count - 1} 件）" : "";
                _lblMakeupNotes.text = "! " + _makeupNotes[0] + more;
                _warnMakeupNotes.tooltip = string.Join("\n", _makeupNotes);
            }
            else
            {
                _warnMakeupNotes.AddToClassList("hidden");
            }

            // 元アバター自動作成のエラー／目の線要確認
            bool hasEyeIssue = _makeupAutoEyeLineIssue != null && MakeFixMakeupSource.PathsEqual(_makeupAutoPath, _state.MakeupFaceMapPath);
            if (!string.IsNullOrEmpty(_makeupAutoError))
            {
                _warnMakeupAuto.RemoveFromClassList("hidden");
                _lblMakeupAuto.text = "! " + _makeupAutoError;
                _warnMakeupAuto.tooltip = _makeupAutoError;
                _btnMakeupAutoFix.AddToClassList("hidden");
            }
            else if (hasEyeIssue)
            {
                _warnMakeupAuto.RemoveFromClassList("hidden");
                _lblMakeupAuto.text = "! 目の線を自動で決められませんでした";
                _warnMakeupAuto.tooltip = _makeupAutoEyeLineIssue;
                _btnMakeupAutoFix.RemoveFromClassList("hidden");
            }
            else
            {
                _warnMakeupAuto.AddToClassList("hidden");
            }

            // 基準が一覧にない場合の作成ボックス（基準未選択時のみ自動展開）
            bool showCreateBox = MakeFixMakeupSource.ShouldShowCreateBox(hasMakeupMap, _makeupCreateManualOpen);
            _boxMakeupCreate.EnableInClassList("hidden", !showCreateBox);
            if (showCreateBox)
            {
                _btnMakeupCreateClose.EnableInClassList("hidden", !hasMakeupMap);
                _btnMakeupManualCreate.text = MakeFixMakeupSource.ManualCreateButtonLabel(makeupTex != null);
                _boxMakeupAvatarPicker.EnableInClassList("hidden", !_makeupAvatarPickerOpen);
            }

            // 準備不足の 1 行（テクスチャ → 基準 の順で案内）
            ReadinessItem missing = FirstFailedOf(5) ?? FirstFailedOf(1);
            if (missing != null)
            {
                _warnMakeupMissing.RemoveFromClassList("hidden");
                _lblMakeupMissing.text = "! " + missing.Message;
                _warnMakeupMissing.tooltip = missing.Detail;
                if (missing.Fix == ReadinessFix.OpenFaceMapEditor)
                {
                    _btnMakeupMissingFix.RemoveFromClassList("hidden");
                    _btnMakeupMissingFix.text = "FaceMap エディター";
                    _makeupMissingAction = OpenFaceMapEditorForNewMakeup;
                }
                else
                {
                    _btnMakeupMissingFix.AddToClassList("hidden");
                    _makeupMissingAction = null;
                }
            }
            else
            {
                _warnMakeupMissing.AddToClassList("hidden");
            }

            if (_invalidMaps.Count > 0)
            {
                _warnInvalidMaps.RemoveFromClassList("hidden");
                _lblInvalidMaps.text = $"! 読み込めない FaceMap が {_invalidMaps.Count} 個";
                _btnInvalidMapsDetail.text = _showInvalidDetail ? "閉じる" : "詳細";
                _boxInvalidMapsDetail.EnableInClassList("hidden", !_showInvalidDetail);
                if (_showInvalidDetail)
                {
                    string sig = string.Join("|", _invalidMaps.Select(m => m.FileName + ":" + string.Join("/", m.Errors)));
                    if (sig != _lastInvalidMapsSig)
                    {
                        _lastInvalidMapsSig = sig;
                        _boxInvalidMapsDetail.Clear();
                        foreach (FaceMapMeta m in _invalidMaps)
                        {
                            var lbl = new Label($"{m.FileName}: {string.Join(" / ", m.Errors)}");
                            lbl.AddToClassList("invalid-detail-row");
                            _boxInvalidMapsDetail.Add(lbl);
                        }
                    }
                }
            }
            else
            {
                _warnInvalidMaps.AddToClassList("hidden");
                _boxInvalidMapsDetail.AddToClassList("hidden");
            }

            // Adjustment Cards visibility
            _cardAdjustLocked.EnableInClassList("hidden", _showPreview);
            _adjustCardsContainer.EnableInClassList("hidden", !_showPreview);

            if (_showPreview && _state.Adjustment != null)
            {
                RefreshAdjustmentCards(_state.Adjustment);
            }

            RefreshApplyCommitArea();
        }

        private void SyncMakeupFaceMapDropdown()
        {
            if (_dropdownMakeupFaceMap == null) return;

            var mapEntries = new List<MakeFixMakeupSource.MapEntry>(_validMaps.Count);
            for (int i = 0; i < _validMaps.Count; i++)
            {
                FaceMapMeta m = _validMaps[i];
                mapEntries.Add(new MakeFixMakeupSource.MapEntry
                {
                    Path = m.FilePath,
                    DisplayName = m.DisplayName,
                    FileName = m.FileName,
                    IsDraft = FaceMapStorage.IsDraft(m.FilePath),
                });
            }

            List<MakeFixMakeupSource.SceneAvatarEntry> unmapped = BuildUnmappedSceneAvatarsForMakeup();
            List<MakeFixMakeupSource.DropdownChoice> entries =
                MakeFixMakeupSource.BuildDropdownEntries(mapEntries, unmapped, _state.AvatarFaceMapPath);

            var choices = new List<string>(entries.Count);
            string currentLabel = entries[0].Label;
            _makeupChoiceByLabel.Clear();
            foreach (MakeFixMakeupSource.DropdownChoice c in entries)
            {
                choices.Add(c.Label);
                _makeupChoiceByLabel[c.Label] = c;
                if (!c.IsSceneAvatar && MakeFixMakeupSource.PathsEqual(c.Value, _state.MakeupFaceMapPath))
                    currentLabel = c.Label;
            }

            string sig = string.Join("|", choices);
            bool choicesChanged = sig != _lastMakeupMapChoicesSig;
            if (choicesChanged)
            {
                _lastMakeupMapChoicesSig = sig;
                _dropdownMakeupFaceMap.choices = choices;
            }
            if (choicesChanged || _dropdownMakeupFaceMap.value != currentLabel)
                _dropdownMakeupFaceMap.SetValueWithoutNotify(currentLabel);
        }

        private void RefreshAdjustmentCards(FaceMapAdjustment adj)
        {
            SetStepDot(_dotParts, StepStateOf(FocusCard.Parts, _allOk));
            ApplyCardHighlight(FocusCard.Parts, _cardParts);
            _btnResetAll.SetEnabled(!adj.IsIdentity && _previewDrag == PreviewDrag.None);

            // Part Tabs
            string tabSig = (_editTarget ?? "<ALL>") + "#" + string.Join("|", _categories.Select(c =>
            {
                bool en = adj.IsEnabled(c);
                FaceMapTransform t = adj.FindPart(c);
                bool ad = (t != null && !t.IsIdentity) ||
                          (c == FaceMapFile.EyeCategory && adj.HasEyeAdjustment) ||
                          (c == FaceMapFile.MouthCategory && adj.HasMouthAdjustment);
                return $"{c}:{en}:{ad}";
            })) + "#G:" + !adj.Global.IsIdentity;

            if (tabSig != _lastPartTabsSig)
            {
                _lastPartTabsSig = tabSig;
                RebuildPartTabs(adj);
            }

            if (_editTarget != null)
            {
                _togglePartEnabled.RemoveFromClassList("hidden");
                _togglePartEnabled.SetValueWithoutNotify(adj.IsEnabled(_editTarget));
            }
            else
            {
                _togglePartEnabled.AddToClassList("hidden");
            }

            // Transform Matrix
            FaceMapTransform current = _editTarget == null ? adj.Global : adj.FindPart(_editTarget);
            bool layerAdjusted = current != null && !current.IsIdentity;
            _chipEditTarget.text = EditTargetName;
            _chipLayerAdjusted.EnableInClassList("hidden", !layerAdjusted);
            _btnResetLayer.SetEnabled(layerAdjusted && _previewDrag == PreviewDrag.None);

            FaceMapTransform layer = EditLayer(adj);
            _lblRotationVal.text = $"{layer.Rotation:0.#}°";
            _toggleLocalPart.SetValueWithoutNotify(adj.LocalPartAdjust);

            bool isPair = IsPairCategory(_editTarget);
            bool isCenter = !isPair && IsCenterCategory(_editTarget);
            _rowPairGap.EnableInClassList("hidden", !isPair);
            _rowCenterAlign.EnableInClassList("hidden", !isCenter);
            if (isCenter)
                _btnCenterAlign.SetEnabled(_state.PairMatch != null && _state.PairMatch.AvatarCenterX.HasValue && _previewDrag == PreviewDrag.None);

            // Detail Numeric Fields（フォーカス中は入力文字を上書きしない）
            if (!IsFieldFocused(_numOffset)) _numOffset.SetValueWithoutNotify(layer.Offset);
            if (!IsFieldFocused(_numScale)) _numScale.SetValueWithoutNotify(layer.Scale);
            if (!IsFieldFocused(_numRotation)) _numRotation.SetValueWithoutNotify(layer.Rotation);
            _numRotation.SetEnabled(adj.LocalPartAdjust);
            _numGap.EnableInClassList("hidden", !isPair);
            if (isPair)
            {
                float? minGap = AtaaCore.MinGap(_state.PairMatch, adj, _editTarget);
                bool gapEnabled = minGap.HasValue && _previewDrag == PreviewDrag.None;
                _numGap.SetEnabled(gapEnabled);
                _scrubGapMinus?.EnableInClassList("scrub-btn--disabled", !gapEnabled);
                _scrubGapPlus?.EnableInClassList("scrub-btn--disabled", !gapEnabled);
                if (!IsFieldFocused(_numGap)) _numGap.SetValueWithoutNotify(layer.Gap);
            }

            // Eye Settings
            bool isEye = _editTarget == FaceMapFile.EyeCategory;
            _cardEyeSettings.EnableInClassList("hidden", !isEye);
            if (isEye)
            {
                FaceMapMatch match = _state.PairMatch;
                _chipEyeAdjusted.EnableInClassList("hidden", !adj.HasEyeAdjustment);
                _btnResetEye.SetEnabled(adj.HasEyeAdjustment);

                bool band = match != null && match.MakeupHasEyeLowerLine && match.AvatarHasEyeLowerLine;
                _groupEyeBand.SetEnabled(band);
                _lblEyeBandMissing.EnableInClassList("hidden", band);

                _sliderLowerEyeWidth.SetValueWithoutNotify(adj.LowerEyeWidthScale);
                _valLowerEyeWidth.text = adj.LowerEyeWidthScale.ToString("0.000");
                _sliderLowerEyeFlare.SetValueWithoutNotify(adj.LowerEyeOuterFlare);
                _valLowerEyeFlare.text = adj.LowerEyeOuterFlare.ToString("0.000");

                bool hasAvatarEyeLine = match != null && match.AvatarEyeLine.HasValue;
                _groupEyeLines.EnableInClassList("hidden", !hasAvatarEyeLine);
                _lblAvatarEyeLineMissing.EnableInClassList("hidden", hasAvatarEyeLine);
                if (hasAvatarEyeLine)
                {
                    _sliderEyeUpperLine.SetValueWithoutNotify(match.AvatarEyeLine.Value);
                    _valEyeUpperLine.text = match.AvatarEyeLine.Value.ToString("0.0000");

                    bool hasLower = match.AvatarEyeLowerLine.HasValue;
                    _blockEyeLowerLine.EnableInClassList("hidden", !hasLower);
                    if (hasLower)
                    {
                        _sliderEyeLowerLine.SetValueWithoutNotify(match.AvatarEyeLowerLine.Value);
                        _valEyeLowerLine.text = match.AvatarEyeLowerLine.Value.ToString("0.0000");
                    }
                    _lblMakeupEyeLineMissing.EnableInClassList("hidden", match.MakeupEyeLine.HasValue);
                }
            }

            // Mouth Settings
            bool isMouth = _editTarget == FaceMapFile.MouthCategory;
            _cardMouthSettings.EnableInClassList("hidden", !isMouth);
            if (isMouth)
            {
                _chipMouthAdjusted.EnableInClassList("hidden", !adj.HasMouthAdjustment);
                _btnResetMouth.SetEnabled(adj.HasMouthAdjustment);
                _sliderMouthBend.SetValueWithoutNotify(adj.MouthBend);
                UpdateMouthSliderVisual(_valMouthBend, _btnResetMouthBend, _fillMouthBend,
                    adj.MouthBend, FaceMapAdjustment.MaxMouthBend, true);

                bool canFold = AtaaCore.CanFoldMouth(_state.PairMatch);
                _groupMouthFold.SetEnabled(canFold);
                _lblMouthFoldUnavailable.EnableInClassList("hidden", canFold);
                _sliderMouthFold.SetValueWithoutNotify(adj.MouthFold);
                UpdateMouthSliderVisual(_valMouthFold, _btnResetMouthFold, _fillMouthFold,
                    adj.MouthFold, FaceMapAdjustment.MaxMouthFold, canFold);
            }

            // Finish
            bool finishAdjusted = MakeFixFinish.IsAdjusted(adj, _state.PreviewMakeupOpacity);
            _chipFinishAdjusted.EnableInClassList("hidden", !finishAdjusted);
            _btnResetFinish.SetEnabled(finishAdjusted);
            _sliderOpacity.SetValueWithoutNotify(_state.PreviewMakeupOpacity);
            _valOpacity.text = _state.PreviewMakeupOpacity.ToString("0.00");
            _toggleSkinTone.SetValueWithoutNotify(adj.MatchSkinTone);
            _foldoutMask.text = $"合成範囲  広げ {adj.MaskMargin:0.###} / ぼかし {adj.MaskFeather:0.###}";
            _sliderMaskMargin.SetValueWithoutNotify(adj.MaskMargin);
            _valMaskMargin.text = adj.MaskMargin.ToString("0.000");
            _sliderMaskFeather.SetValueWithoutNotify(adj.MaskFeather);
            _valMaskFeather.text = adj.MaskFeather.ToString("0.000");
            _sliderExcludeFeather.SetValueWithoutNotify(adj.ExcludeFeather);
            _valExcludeFeather.text = adj.ExcludeFeather.ToString("0.000");
        }

        private void RebuildPartTabs(FaceMapAdjustment adj)
        {
            _partTabStrip.Clear();
            int count = _categories.Count + 1;
            for (int i = 0; i < count; i++)
            {
                string c = i == 0 ? null : _categories[i - 1];
                string name = c ?? AllTargetName;
                bool enabled = c == null || adj.IsEnabled(c);
                FaceMapTransform t = c == null ? adj.Global : adj.FindPart(c);
                bool adjusted = (t != null && !t.IsIdentity) ||
                                (c == FaceMapFile.EyeCategory && adj.HasEyeAdjustment) ||
                                (c == FaceMapFile.MouthCategory && adj.HasMouthAdjustment);
                bool selected = c == _editTarget;

                string label = adjusted ? name + " ★" : name;
                string captured = c;
                var btn = new Button(() =>
                {
                    if (_previewDrag != PreviewDrag.None) return;
                    _editTarget = captured;
                    MarkUiDirty();
                })
                {
                    text = label,
                    tooltip = (enabled ? "" : "合成しない（OFF）") + (adjusted ? (enabled ? "" : "・") + "調整済み" : "")
                };
                btn.AddToClassList("part-tab");
                if (selected) btn.AddToClassList("part-tab--selected");
                if (!enabled) btn.AddToClassList("part-tab--disabled");
                _partTabStrip.Add(btn);
            }
        }

        private void RefreshApplyCommitArea()
        {
            int done = _allOk ? TotalSteps : CountDoneSteps();
            ReadinessItem firstFailed = NextItem();

            float fill = MakeFixStepProgress.FillPercent(done, TotalSteps);
            _lblHeaderStep.text = MakeFixStepProgress.Kicker(done, TotalSteps, _allOk);
            _lblHeaderStep.EnableInClassList("panel-step-kicker--ok", _allOk);
            _headerProgressFill.style.width = new Length(fill, LengthUnit.Percent);
            _headerProgressFill.EnableInClassList("progress-fill--ok", _allOk);

            bool showProgress = !_allOk;
            _progressBlock.EnableInClassList("hidden", !showProgress);
            if (showProgress)
            {
                _lblStepProgress.text = MakeFixStepProgress.Kicker(done, TotalSteps, false);
                _lblApplyingHint.text = _applying ? "適用中..." : "";
                _progressFill.style.width = new Length(fill, LengthUnit.Percent);
                if (firstFailed != null)
                {
                    _btnNextStep.RemoveFromClassList("hidden");
                    _btnNextStep.text = "次: " + firstFailed.Message + " ›";
                    _btnNextStep.tooltip = firstFailed.Detail;
                }
                else
                {
                    _btnNextStep.AddToClassList("hidden");
                }
            }

            if (AtaaCore.Edition == CoreEdition.Trial) return;
            bool showStatus = _state.TargetAvatar != null;
            _applyStatusBox.EnableInClassList("hidden", !showStatus);
            if (showStatus)
            {
                ApplyState state = CurrentApplyState();
                bool known = _appliedTexturePath != null;
                bool previewing = _live != null && _live.IsAttached && !_comparing;

                _applyStatusBox.RemoveFromClassList("apply-status-box--blue");
                _applyStatusBox.RemoveFromClassList("apply-status-box--ok");
                _applyStatusBox.RemoveFromClassList("apply-status-box--warn");
                _applyStatusBox.RemoveFromClassList("apply-status-box--muted");

                switch (state)
                {
                    case ApplyState.Current:
                        _lblApplyStatusTitle.text = "メイク適用済み";
                        _lblApplyStatusSub.text = known ? System.IO.Path.GetFileName(_appliedTexturePath) : "このウィンドウを開く前に適用したメイク";
                        _applyStatusBox.AddToClassList("apply-status-box--ok");
                        break;
                    case ApplyState.Stale:
                        _lblApplyStatusTitle.text = "適用済み・調整の変更は未反映";
                        _lblApplyStatusSub.text = "「メイク適用」で今の調整を反映します";
                        _applyStatusBox.AddToClassList("apply-status-box--warn");
                        break;
                    default:
                        _lblApplyStatusTitle.text = previewing ? "未適用 (プレビューモード)" : "未適用";
                        _lblApplyStatusSub.text = previewing
                            ? "シーンの表示はプレビューです（閉じると元に戻ります）"
                            : "アバターにメイクは適用されていません";
                        _applyStatusBox.AddToClassList(previewing ? "apply-status-box--blue" : "apply-status-box--muted");
                        break;
                }

                _btnLocateApplied.EnableInClassList("hidden", !(state == ApplyState.Current && known));
            }

            MakeFixApplyButton.State applyButton = MakeFixApplyButton.Evaluate(
                _allOk, _applying, EditorApplication.isPlayingOrWillChangePlaymode, firstFailed?.Message);
            _btnApplyMakeup.SetEnabled(applyButton.Enabled);
            _btnApplyMakeup.text = applyButton.Label;
            _btnApplyMakeup.tooltip = applyButton.Tooltip;
            _btnRevertMakeup.SetEnabled(_state.TargetAvatar != null && !_applying);
        }

        private static VisualElement AttachBipolarOverlay(Slider slider)
        {
            VisualElement dragContainer = slider?.Q(className: "unity-base-slider__drag-container");
            if (dragContainer == null) return null;

            var overlay = new VisualElement { pickingMode = PickingMode.Ignore };
            overlay.AddToClassList("bipolar-track-overlay");

            var fill = new VisualElement { pickingMode = PickingMode.Ignore };
            fill.AddToClassList("bipolar-fill");
            overlay.Add(fill);

            var zeroTick = new VisualElement { pickingMode = PickingMode.Ignore };
            zeroTick.AddToClassList("bipolar-zero-tick");
            overlay.Add(zeroTick);

            VisualElement dragger = dragContainer.Q(className: "unity-base-slider__dragger");
            int insertIndex = dragger != null ? dragContainer.IndexOf(dragger) : dragContainer.childCount;
            dragContainer.Insert(insertIndex, overlay);
            return fill;
        }

        private static void UpdateMouthSliderVisual(Label valLabel, Button resetBtn, VisualElement fillEl,
                                                    float value, float maxAbs, bool enabled)
        {
            valLabel.text = MakeFixMouthUi.FormatPercent(value, maxAbs);
            valLabel.tooltip = MakeFixMouthUi.FormatRawTooltip(value, maxAbs);

            bool nonZero = MakeFixMouthUi.IsNonZero(value);
            valLabel.EnableInClassList("slider-val--sky", nonZero && enabled);
            resetBtn.SetEnabled(nonZero && enabled);

            if (fillEl != null)
            {
                MakeFixMouthUi.BipolarFill fill = MakeFixMouthUi.ComputeBipolarFill(value, maxAbs);
                fillEl.style.left = new Length(fill.LeftPercent, LengthUnit.Percent);
                fillEl.style.width = new Length(fill.WidthPercent, LengthUnit.Percent);
            }
        }
    }
}
