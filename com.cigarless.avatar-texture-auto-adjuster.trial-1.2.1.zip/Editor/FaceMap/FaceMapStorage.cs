// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapStorage.cs
using System.IO;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap の保存先の窓口。製品版は FaceMaps フォルダのファイル、体験版（AtaaCore.Edition）はメモリ（TrialStore）。
    /// 保存・存在確認・読み込みをここに集めて、呼び出し側（メイクフィックス画面・FaceMap エディター）は版を意識しない。
    /// UI のソースは全エディションで 1 つ。体験版でファイルに書き込めても、出力は体験版コアの透かし・低解像度のまま。
    /// </summary>
    public static class FaceMapStorage
    {
        private static bool Trial => AtaaCore.Edition == CoreEdition.Trial;

        /// <summary>新しく保存するときのフォルダ（体験版は仮想フォルダ）。メインスレッドから呼ぶ。</summary>
        public static bool TryGetSaveFolder(out string folder, out string error)
        {
            if (Trial)
            {
                folder = TrialStore.Folder;
                error = null;
                return true;
            }
            return FaceMapFolder.TryEnsure(out _, out folder, out error);
        }

        /// <summary>自動生成した FaceMap の一時置き場（仮想フォルダ）。体験版は TrialStore、製品版は AutoFaceMapStore。</summary>
        public static string AutoSaveFolder
        {
            get { return Trial ? TrialStore.Folder : AutoFaceMapStore.Folder; }
        }

        public static bool Exists(string path)
        {
            if (string.IsNullOrEmpty(path)) return false;
            if (Trial ? TrialStore.IsVirtual(path) : AutoFaceMapStore.IsVirtual(path))
                return Trial ? TrialStore.Exists(path) : AutoFaceMapStore.Exists(path);
            return File.Exists(path);
        }

        /// <summary>この場所に保存できるか（体験版は仮想パスだけ）。</summary>
        public static bool CanWrite(string path)
        {
            return Trial ? TrialStore.IsVirtual(path) : !string.IsNullOrEmpty(path);
        }

        /// <summary>ワーカースレッドからも呼ばれる。</summary>
        public static string ReadAllText(string path)
        {
            if (Trial && TrialStore.IsVirtual(path))
            {
                if (TrialStore.TryGet(path, out string text, out _)) return text;
                throw new FileNotFoundException("体験版の一時保存に見つかりません（Unity を再起動すると消えます）", path);
            }
            if (!Trial && AutoFaceMapStore.IsVirtual(path))
            {
                if (AutoFaceMapStore.TryGet(path, out string text, out _)) return text;
                throw new FileNotFoundException("自動生成の一時データに見つかりません（Unity を再起動すると消えます）", path);
            }
            return File.ReadAllText(path);
        }

        public static long LastWriteTicks(string path)
        {
            if (Trial && TrialStore.IsVirtual(path)) return TrialStore.TryGet(path, out _, out long ticks) ? ticks : 0;
            if (!Trial && AutoFaceMapStore.IsVirtual(path)) return AutoFaceMapStore.TryGet(path, out _, out long autoTicks) ? autoTicks : 0;
            return File.GetLastWriteTimeUtc(path).Ticks;
        }

        /// <summary>保存したファイルを Project ウィンドウに反映する（体験版はファイルが無いので何もしない）。</summary>
        public static void RefreshAssets()
        {
            if (!Trial) AssetDatabase.Refresh();
        }

        /// <summary>
        /// FaceMap を保存する。製品版はファイルに保存する（AssetDatabase の更新は RefreshAssets で呼び出し側が行う）。
        /// 体験版はメモリに入れる（検証は製品版と同じ）。
        /// </summary>
        public static bool TrySave(string path, FaceMapFile file, out string error)
        {
            if (Trial && !TrialStore.IsVirtual(path))
            {
                error = "体験版ではファイルに保存できません（製品版で使えます）。";
                return false;
            }
            if (Trial || AutoFaceMapStore.IsVirtual(path))
            {
                string json = FaceMapSerializer.ToJson(file);
                FaceMapValidator.Result check = FaceMapValidator.Validate(json);
                if (!check.IsValid)
                {
                    error = "保存するデータが仕様に合っていません: " + string.Join(" / ", check.Errors);
                    return false;
                }
                if (Trial) TrialStore.Put(path, json);
                else AutoFaceMapStore.Put(path, json);
                error = null;
                return true;
            }
            return FaceMapSerializer.TrySave(path, file, out error);
        }

        /// <summary>自動生成しただけの一時データ（ATAA-Auto/）か。体験版は常に false（体験版の一時保存は昇格しない）。</summary>
        public static bool IsDraft(string path)
        {
            return !Trial && AutoFaceMapStore.IsVirtual(path);
        }

        /// <summary>昇格などでパスが変わったとき、選択中のパスを差し替える（区切り文字と大小の違いは同じとみなす）。</summary>
        public static string RemapPath(string current, string from, string to)
        {
            if (current == null || from == null) return current;
            return string.Equals(current.Replace('\\', '/'), from.Replace('\\', '/'), System.StringComparison.OrdinalIgnoreCase)
                ? to
                : current;
        }

        /// <summary>
        /// 一時データを実ファイル（folder/名前.json）へ昇格して、一時データを消す。実ファイルのパスはそのまま返す。
        /// 同名の実ファイルがあるときは上書きせず「名前 (2).json」…にする。AssetDatabase の更新は RefreshAssets で呼び出し側が行う。
        /// </summary>
        public static bool TryPromote(string path, string folder, out string newPath, out string error)
        {
            newPath = path;
            error = null;
            if (!IsDraft(path)) return true;
            if (!AutoFaceMapStore.TryGet(path, out string text, out _))
            {
                error = "自動生成の一時データが見つかりません（Unity を再起動すると消えます）。";
                return false;
            }
            if (string.IsNullOrEmpty(folder) || !Directory.Exists(folder))
            {
                error = "保存先フォルダが存在しません: " + folder;
                return false;
            }

            string name = Path.GetFileNameWithoutExtension(path);
            string target = Path.Combine(folder, name + ".json");
            for (int n = 2; File.Exists(target); n++) target = Path.Combine(folder, $"{name} ({n}).json");

            // 末尾 "~" のファイルは Unity が無視するため .meta が作られない
            string tmp = target + ".tmp~";
            try
            {
                File.WriteAllText(tmp, text, new System.Text.UTF8Encoding(false));
                File.Move(tmp, target);
            }
            catch (System.Exception ex)
            {
                error = ex.Message;
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { /* 後始末の失敗は無視 */ }
                return false;
            }

            AutoFaceMapStore.Remove(path);
            newPath = target;
            return true;
        }

        /// <summary>メッセージに出す保存先（製品版はプロジェクトからの相対パス、体験版は名前）。</summary>
        public static string Describe(string path)
        {
            if (Trial && TrialStore.IsVirtual(path)) return Path.GetFileName(path) + "（体験版の一時保存）";
            if (!Trial && AutoFaceMapStore.IsVirtual(path)) return Path.GetFileName(path) + "（自動生成・未保存）";
            string shown = FileUtil.GetProjectRelativePath(Path.GetFullPath(path).Replace('\\', '/'));
            return string.IsNullOrEmpty(shown) ? Path.GetFileName(path) : shown;
        }
    }
}
