// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapSchemaMigrator.cs
using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap / 微調整 JSON の schemaVersion 検証と、最新形式への自動変換（純粋関数。docs~/コアとUIの分割_設計メモ.md §5・手順 7）。
    /// 入力の JObject は変更せず複製を変換して返す。保存側は常に最新 schemaVersion だけを書き出し、古い形式は書き出さない。
    /// </summary>
    public static class FaceMapSchemaMigrator
    {
        public sealed class MigrationResult
        {
            public JObject Root;
            public int? OriginalVersion;
            public int TargetVersion;
            public string Error;

            public bool Succeeded => Error == null && Root != null;
            public bool WasMigrated => Succeeded && OriginalVersion.HasValue && OriginalVersion.Value < TargetVersion;
        }

        /// <summary>JSON 文字列単位の純粋変換結果（Newtonsoft の型に依存せずテスト・呼び出しができる）。</summary>
        public sealed class JsonMigrationResult
        {
            public string Json;
            public int? OriginalVersion;
            public int TargetVersion;
            public string Error;

            public bool Succeeded => Error == null && Json != null;
            public bool WasMigrated => Succeeded && OriginalVersion.HasValue && OriginalVersion.Value < TargetVersion;
        }

        /// <summary>
        /// FaceMap JSON 文字列を最新スキーマへ変換する（純粋関数）。日付らしい文字列は書き換えない。
        /// </summary>
        public static JsonMigrationResult MigrateFaceMapJson(string text)
        {
            JToken parsed;
            try
            {
                parsed = FaceMapValidator.ParseJson((text ?? string.Empty).TrimStart('﻿'));
            }
            catch (Exception ex)
            {
                return new JsonMigrationResult
                {
                    TargetVersion = FaceMapFile.CurrentSchemaVersion,
                    Error = "R1: JSON として解析できません: " + ex.Message
                };
            }

            MigrationResult r = MigrateFaceMap(parsed as JObject);
            return new JsonMigrationResult
            {
                Json = r.Succeeded ? r.Root.ToString(Formatting.None) : null,
                OriginalVersion = r.OriginalVersion,
                TargetVersion = r.TargetVersion,
                Error = r.Error
            };
        }

        /// <summary>
        /// 微調整 JSON 文字列を最新スキーマへ変換する（純粋関数）。
        /// </summary>
        public static JsonMigrationResult MigrateAdjustmentJson(string text)
        {
            JToken parsed;
            try
            {
                parsed = FaceMapValidator.ParseJson((text ?? string.Empty).TrimStart('﻿'));
            }
            catch (Exception ex)
            {
                return new JsonMigrationResult
                {
                    TargetVersion = FaceMapAdjustment.SchemaVersion,
                    Error = "JSON として解析できません: " + ex.Message
                };
            }

            MigrationResult r = MigrateAdjustment(parsed as JObject);
            return new JsonMigrationResult
            {
                Json = r.Succeeded ? r.Root.ToString(Formatting.None) : null,
                OriginalVersion = r.OriginalVersion,
                TargetVersion = r.TargetVersion,
                Error = r.Error
            };
        }

        /// <summary>
        /// FaceMap JSON（v0.4 / schemaVersion 2〜CurrentSchemaVersion）を最新スキーマへ変換する。
        /// 範囲外（v0.3 以前の 1 以下、または未対応の新しい版）は R9 エラーを返す。
        /// </summary>
        public static MigrationResult MigrateFaceMap(JObject root)
        {
            var result = new MigrationResult { TargetVersion = FaceMapFile.CurrentSchemaVersion };
            if (root == null)
            {
                result.Error = "R2: トップレベルが JSON オブジェクトではありません。";
                return result;
            }

            if (!root.TryGetValue("schemaVersion", out JToken sv) || !IsNumber(sv))
            {
                result.Error = $"R9: schemaVersion がありません（v0.4 は schemaVersion {FaceMapFile.MinSchemaVersion}〜{FaceMapFile.CurrentSchemaVersion} が必要です。v0.3 形式は非対応です）。";
                return result;
            }

            double version = (double)sv;
            if (version != Math.Floor(version)
                || version < FaceMapFile.MinSchemaVersion
                || version > FaceMapFile.CurrentSchemaVersion)
            {
                string note = version < FaceMapFile.MinSchemaVersion ? "（v0.3 形式は非対応です）"
                    : version > FaceMapFile.CurrentSchemaVersion ? "（新しい版の ATAA で作られたファイルです。ATAA を更新してください）" : "";
                result.Error = $"R9: schemaVersion は {FaceMapFile.MinSchemaVersion}〜{FaceMapFile.CurrentSchemaVersion} に対応しています（値: {sv.ToString(Formatting.None)}）{note}。";
                return result;
            }

            int original = (int)version;
            result.OriginalVersion = original;

            var migrated = (JObject)root.DeepClone();
            int current = original;
            while (current < FaceMapFile.CurrentSchemaVersion)
            {
                switch (current)
                {
                    case 2:
                        MigrateFaceMapV2ToV3(migrated);
                        current = 3;
                        break;
                    default:
                        result.Error = $"R9: schemaVersion {current} から {FaceMapFile.CurrentSchemaVersion} への変換が未定義です。";
                        return result;
                }
            }

            result.Root = migrated;
            return result;
        }

        /// <summary>
        /// v2 → v3: 口の線の折れ線（sizes.口.linePoints。#25）が導入された版へ昇格する。
        /// v2 には linePoints が無いため水平線扱いとなり、既存の points / sizes / meta / centerX をすべて保持したまま schemaVersion を 3 にする。
        /// </summary>
        private static void MigrateFaceMapV2ToV3(JObject obj)
        {
            obj["schemaVersion"] = 3;
        }

        /// <summary>
        /// 微調整 JSON（.adjust.json）を最新スキーマ（FaceMapAdjustment.SchemaVersion）へ変換する。
        /// 入力は変更せず複製を返す。
        /// </summary>
        public static MigrationResult MigrateAdjustment(JObject root)
        {
            var result = new MigrationResult { TargetVersion = FaceMapAdjustment.SchemaVersion };
            if (root == null)
            {
                result.Error = "トップレベルが JSON オブジェクトではありません。";
                return result;
            }

            int original = root["schemaVersion"] is JValue sv && sv.Type == JTokenType.Integer ? (int)sv : 0;
            result.OriginalVersion = original;

            var migrated = (JObject)root.DeepClone();
            if (original < FaceMapAdjustment.SchemaVersion)
            {
                int current = original;
                if (current < 5)
                {
                    MigrateAdjustmentPreV5ToV5(migrated);
                    current = 5;
                }
                while (current < FaceMapAdjustment.SchemaVersion)
                {
                    switch (current)
                    {
                        case 5:
                            MigrateAdjustmentV5ToV6(migrated);
                            current = 6;
                            break;
                        default:
                            current = FaceMapAdjustment.SchemaVersion;
                            migrated["schemaVersion"] = current;
                            break;
                    }
                }
            }

            result.Root = migrated;
            return result;
        }

        /// <summary>
        /// v4 以前 → v5: 旧既定値（LegacyMaskMargin / LegacyMaskFeather）のまま保存されていた合成範囲を現行既定値へ更新する。
        /// ユーザーが変更していたカスタム値はそのまま維持する。
        /// </summary>
        private static void MigrateAdjustmentPreV5ToV5(JObject obj)
        {
            bool hasMargin = TryReadFiniteNumber(obj["maskMargin"], out float margin);
            bool hasFeather = TryReadFiniteNumber(obj["maskFeather"], out float feather);
            if (hasMargin && hasFeather &&
                Mathf.Approximately(margin, FaceMapAdjustment.LegacyMaskMargin) &&
                Mathf.Approximately(feather, FaceMapAdjustment.LegacyMaskFeather))
            {
                obj["maskMargin"] = FaceMapAdjustment.DefaultMaskMargin;
                obj["maskFeather"] = FaceMapAdjustment.DefaultMaskFeather;
            }
            obj["schemaVersion"] = 5;
        }

        /// <summary>v5 → v6: 口の調整（mouth.bend）が任意項目として追加された版へ昇格する。</summary>
        private static void MigrateAdjustmentV5ToV6(JObject obj)
        {
            obj["schemaVersion"] = 6;
        }

        private static bool IsNumber(JToken t) =>
            t != null && (t.Type == JTokenType.Integer || t.Type == JTokenType.Float);

        private static bool TryReadFiniteNumber(JToken t, out float value)
        {
            value = 0f;
            if (!IsNumber(t)) return false;
            double d = (double)t;
            if (double.IsNaN(d) || double.IsInfinity(d)) return false;
            value = (float)d;
            return !float.IsInfinity(value);
        }
    }
}
