// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/FaceMap/FaceMapValidator.cs
using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// FaceMap JSON (v0.4 / schemaVersion 2〜3) の検証。構文・テンプレート・領域サイズを検査する。
    /// Unity の描画 API には依存しない（Vector2 などの値型のみ使う）ため、ワーカースレッドから呼んでよい。
    /// </summary>
    public static class FaceMapValidator
    {
        public class Result
        {
            public FaceMapFile File;
            public int? SchemaVersion;
            public bool WasMigrated;
            public readonly List<string> Errors = new List<string>();
            public readonly List<string> Warnings = new List<string>();

            public bool IsValid => Errors.Count == 0;
        }

        private static readonly HashSet<string> TopLevelKeys =
            new HashSet<string> { "schemaVersion", "points", "sizes", "name", "targetAvatar", "meta", "centerX" };

        private static readonly HashSet<string> PointKeys =
            new HashSet<string> { "x", "y", "label" };


        /// <summary>領域同士の重なりが、小さい方の面積に対してこの割合を超えたら警告。</summary>
        private const float OverlapWarnRatio = 0.5f;

        private const int MaxListedItems = 3;

        public static Result Validate(string text)
        {
            var r = new Result();

            JToken root;
            try
            {
                // BOM があれば除去してからパース
                root = ParseJson((text ?? string.Empty).TrimStart('﻿'));
            }
            catch (Exception ex)
            {
                r.Errors.Add("R1: JSON として解析できません: " + ex.Message);
                return r;
            }

            var obj = root as JObject;
            if (obj == null)
            {
                r.Errors.Add("R2: トップレベルが JSON オブジェクトではありません。");
                return r;
            }

            // schemaVersion の検証と最新形式への自動変換（純粋関数 FaceMapSchemaMigrator）
            FaceMapSchemaMigrator.MigrationResult migrated = FaceMapSchemaMigrator.MigrateFaceMap(obj);
            if (!migrated.Succeeded)
            {
                r.Errors.Add(migrated.Error);
                return r;
            }
            r.SchemaVersion = migrated.OriginalVersion;
            r.WasMigrated = migrated.WasMigrated;
            obj = migrated.Root;

            if (!obj.TryGetValue("points", out JToken pts))
            {
                r.Errors.Add("R3: points がありません。");
                return r;
            }
            if (pts.Type != JTokenType.Array)
            {
                r.Errors.Add("R4: points が配列ではありません。");
                return r;
            }
            if (!pts.HasValues)
            {
                r.Errors.Add("R5: points が空です。");
                return r;
            }

            var file = new FaceMapFile();
            var notObject = new List<string>();
            var notNumber = new List<string>();
            var notFinite = new List<string>();
            var badLabel = new List<string>();
            var duplicated = new List<string>();
            var unknownLabels = new List<string>();
            var outOfRange = new List<string>();
            var seen = new HashSet<string>(StringComparer.Ordinal);
            bool unknownInPoint = false;

            int index = 0;
            foreach (JToken item in (JArray)pts)
            {
                string at = $"points[{index}]";
                index++;

                var po = item as JObject;
                if (po == null)
                {
                    notObject.Add(at);
                    continue;
                }

                bool okX = ReadNumber(po, "x", at, notNumber, notFinite, out float x);
                bool okY = ReadNumber(po, "y", at, notNumber, notFinite, out float y);

                string label = null;
                bool okLabel = po.TryGetValue("label", out JToken lt)
                               && lt.Type == JTokenType.String
                               && !string.IsNullOrEmpty(label = (string)lt);
                if (!okLabel) badLabel.Add(at);

                if (po.Properties().Any(p => !PointKeys.Contains(p.Name)))
                    unknownInPoint = true;

                if (!(okX && okY && okLabel)) continue;

                if (!seen.Add(label) && !duplicated.Contains(label))
                    duplicated.Add(label);

                if (!FaceTemplate.IsKnown(label)) unknownLabels.Add(label);
                if (x < 0f || x > 1f || y < 0f || y > 1f) outOfRange.Add(label);

                file.Points.Add(new FaceMapPoint(x, y, label));
            }

            AddGrouped(r.Errors, "R6: points の要素がオブジェクトではありません: ", notObject);
            AddGrouped(r.Errors, "R7: x / y が数値ではありません: ", notNumber);
            AddGrouped(r.Errors, "R8: x / y が有限数ではありません: ", notFinite);
            AddGrouped(r.Errors, "R10: label がない、文字列でない、または空です: ", badLabel);
            AddGrouped(r.Errors, "R11: label が重複しています: ", duplicated);
            AddGrouped(r.Errors, "R12: テンプレートにない label です: ", unknownLabels);
            AddGrouped(r.Errors, "R16: UV 範囲（0〜1）外の点があります: ", outOfRange);

            if (r.Errors.Count > 0) return r;

            // 必須領域
            var missing = FaceTemplate.Entries
                .Where(e => e.Required && !seen.Contains(e.Label))
                .Select(e => e.Label)
                .ToList();
            AddGrouped(r.Errors, "R13: 必須の領域がありません: ", missing, int.MaxValue);

            // sizes
            ReadSizes(obj, file, r);

            // 領域の中心が近すぎる
            var tooClose = new List<string>();
            for (int i = 0; i < file.Points.Count; i++)
            {
                for (int j = i + 1; j < file.Points.Count; j++)
                {
                    if (Vector2.Distance(file.Points[i].Uv, file.Points[j].Uv) < FaceMapFile.MinCenterDistance)
                        tooClose.Add($"{file.Points[i].Label} と {file.Points[j].Label}");
                }
            }
            AddGrouped(r.Errors, "R17: 領域の中心が近すぎます: ", tooClose);

            if (r.Errors.Count > 0) return r;

            // ── 警告 ──
            if (obj.TryGetValue("name", out JToken nt) && nt.Type == JTokenType.String && !string.IsNullOrEmpty((string)nt))
                file.Name = (string)nt;
            else
                r.Warnings.Add("W1: name がありません（ファイル名を表示名にします）。");

            if (obj.TryGetValue("targetAvatar", out JToken ta) && ta.Type == JTokenType.String)
                file.TargetAvatar = (string)ta;

            if (obj.TryGetValue("meta", out JToken meta))
                file.MetaJson = meta.ToString(Formatting.None);

            ReadCenterX(obj, file, r.Warnings);

            AddRegionWarnings(file, r.Warnings);

            var unknownTop = obj.Properties().Select(p => p.Name).Where(n => !TopLevelKeys.Contains(n)).ToList();
            if (unknownTop.Count > 0 || unknownInPoint)
            {
                string detail = unknownTop.Count > 0 ? "（" + string.Join(", ", unknownTop.Take(MaxListedItems)) + "）" : "";
                r.Warnings.Add("W5: 未知のフィールドがあるため無視します" + detail + "。");
            }

            r.File = file;
            return r;
        }

        /// <summary>
        /// targetAvatar と選択中アバター名の完全一致を確認する（W2）。一致または判定不能なら null。
        /// </summary>
        public static string CheckTargetAvatar(string targetAvatar, string selectedAvatarName)
        {
            if (string.IsNullOrEmpty(targetAvatar) || string.IsNullOrEmpty(selectedAvatarName)) return null;
            if (string.Equals(targetAvatar, selectedAvatarName, StringComparison.Ordinal)) return null;
            return $"W2: この FaceMap は「{targetAvatar}」用です（選択中: 「{selectedAvatarName}」）。";
        }

        /// <summary>
        /// centerX（任意。エディターのミラー配置用）。数値でない・有限でない・0〜1 の範囲外なら警告して無視する（W9）。
        /// </summary>
        private static void ReadCenterX(JObject obj, FaceMapFile file, List<string> warnings)
        {
            if (!obj.TryGetValue("centerX", out JToken ct)) return;

            if (IsNumber(ct))
            {
                double c = (double)ct;
                if (!double.IsNaN(c) && c >= 0.0 && c <= 1.0)
                {
                    file.CenterX = (float)c;
                    return;
                }
            }

            warnings.Add($"{CenterXWarningPrefix}centerX（顔の中心線）が 0〜1 の数値ではないため無視します（値: {ct.ToString(Formatting.None)}）。");
        }

        /// <summary>centerX の警告の先頭。エディターの読み込み時にこの警告だけを表示するのに使う。</summary>
        public const string CenterXWarningPrefix = "W9: ";

        // ── sizes ──

        private static void ReadSizes(JObject obj, FaceMapFile file, Result r)
        {
            var neededCategories = file.Points
                .Select(p => FaceTemplate.CategoryOf(p.Label))
                .Distinct()
                .ToList();

            if (!obj.TryGetValue("sizes", out JToken st) || st.Type != JTokenType.Object)
            {
                r.Errors.Add("R14: sizes がない、またはオブジェクトではありません。");
                return;
            }

            var sizes = (JObject)st;
            var badSize = new List<string>();
            var missingSize = new List<string>();

            foreach (string category in neededCategories)
            {
                if (!sizes.TryGetValue(category, out JToken ct) || ct.Type != JTokenType.Object)
                {
                    missingSize.Add(category);
                    continue;
                }

                var co = (JObject)ct;
                var dummyA = new List<string>();
                var dummyB = new List<string>();
                bool okW = ReadNumber(co, "w", category, dummyA, dummyB, out float w);
                bool okH = ReadNumber(co, "h", category, dummyA, dummyB, out float h);
                if (!(okW && okH) || w <= 0f || h <= 0f)
                {
                    badSize.Add(category);
                    continue;
                }

                file.Sizes[category] = new Vector2(w, h);

                // 目の線・目の下の線（任意。v0.4 §4.2）
                if (category == FaceMapFile.EyeCategory)
                {
                    file.EyeLine = ReadEyeLine(co, "line", r);
                    file.EyeLowerLine = ReadEyeLine(co, "lowerLine", r);
                    if (file.EyeLine.HasValue && file.EyeLowerLine.HasValue &&
                        file.EyeLowerLine.Value > file.EyeLine.Value - FaceMapFile.MinEyeBand + 1e-6f)
                    {
                        r.Errors.Add($"R18: 目の下の線（sizes.目.lowerLine）は、目の線（line）より {FaceMapFile.MinEyeBand} 以上下にしてください。");
                    }

                    // 目の開いていない素体（任意。true / false。無ければ false）
                    if (co.TryGetValue("noOpening", out JToken no))
                    {
                        if (no.Type == JTokenType.Boolean) file.NoEyeOpening = (bool)no;
                        else r.Warnings.Add("R18: 目の開いていない素体の印（sizes.目.noOpening）は true か false にしてください。無視しました。");
                    }
                }

                // 口の線（任意）。範囲外は警告にして無視する（口の線が無くても 1 段で写せるため）
                if (category == FaceMapFile.MouthCategory && co.TryGetValue("line", out JToken ml))
                {
                    bool isNumber = ml.Type == JTokenType.Float || ml.Type == JTokenType.Integer;
                    float v = isNumber ? (float)ml : float.NaN;
                    if (isNumber && !float.IsNaN(v) && v >= FaceMapFile.MinMouthLine && v <= FaceMapFile.MaxMouthLine) file.MouthLine = v;
                    else r.Warnings.Add($"R18: 口の線（sizes.口.line）は {FaceMapFile.MinMouthLine}〜{FaceMapFile.MaxMouthLine} の数値にしてください。無視しました。");
                }

                // 口の線の折れ線（任意。#25）。壊れていれば警告にして、line の水平線で写す
                if (category == FaceMapFile.MouthCategory && co.TryGetValue("linePoints", out JToken lpt))
                {
                    Vector2[] pts = ReadLinePoints(lpt, out string why);
                    if (pts != null) why = MouthLineShape.Check(pts, FaceMapFile.MinMouthLine, FaceMapFile.MaxMouthLine);
                    if (why == null && pts != null && !MouthLineShape.IsHorizontal(pts))
                    {
                        file.MouthLinePoints = pts;
                        file.MouthLine = MouthLineShape.Mean(pts, 0.5f);
                    }
                    else if (why != null)
                    {
                        r.Warnings.Add($"R18: 口の線の折れ線（sizes.口.linePoints）が正しくないので、line の高さの水平線で写します: {why}");
                    }
                }
            }

            AddGrouped(r.Errors, "R14: sizes に分類のサイズがありません: ", missingSize);
            AddGrouped(r.Errors, "R15: サイズ（w, h）が正の数値ではありません: ", badSize);
        }

        /// <summary>目の線の値（0.05〜0.95 の数値）。無ければ null、範囲外・数値でなければ R18 のエラーにして null。</summary>
        private static float? ReadEyeLine(JObject co, string key, Result r)
        {
            if (!co.TryGetValue(key, out JToken t)) return null;
            bool isNumber = t.Type == JTokenType.Float || t.Type == JTokenType.Integer;
            float v = isNumber ? (float)t : float.NaN;
            if (!isNumber || float.IsNaN(v) || v < FaceMapFile.MinEyeLine || v > FaceMapFile.MaxEyeLine)
            {
                r.Errors.Add($"R18: 目の線（sizes.目.{key}）は {FaceMapFile.MinEyeLine}〜{FaceMapFile.MaxEyeLine} の数値にしてください。");
                return null;
            }
            return v;
        }

        /// <summary>[[u, v], ...] を読む。形が違えば null と理由。範囲・並びの確認は MouthLineShape.Check。</summary>
        private static Vector2[] ReadLinePoints(JToken t, out string why)
        {
            why = null;
            if (t.Type != JTokenType.Array)
            {
                why = "配列ではありません。";
                return null;
            }
            var list = new List<Vector2>();
            foreach (JToken item in t)
            {
                if (!(item is JArray pair) || pair.Count != 2 || !IsNumber(pair[0]) || !IsNumber(pair[1]))
                {
                    why = "各点は [u, v] の 2 つの数値にしてください。";
                    return null;
                }
                list.Add(new Vector2((float)pair[0], (float)pair[1]));
            }
            return list.ToArray();
        }

        // ── 警告（領域の整合性） ──

        private static void AddRegionWarnings(FaceMapFile file, List<string> warnings)
        {
            var byLabel = new Dictionary<string, FaceMapPoint>(StringComparer.Ordinal);
            foreach (FaceMapPoint p in file.Points) byLabel[p.Label] = p;

            // W3: 矩形が UV からはみ出す
            var protruding = new List<string>();
            foreach (FaceMapPoint p in file.Points)
            {
                Rect rc = FaceMapFile.RegionRect(p.Uv, file.Sizes[FaceTemplate.CategoryOf(p.Label)]);
                if (rc.xMin < 0f || rc.yMin < 0f || rc.xMax > 1f || rc.yMax > 1f) protruding.Add(p.Label);
            }
            AddGrouped(warnings, "W3: 領域が UV 範囲（0〜1）からはみ出しています: ", protruding);

            // W6: 左右の整合性（左の x が右の x より小さいこと）
            var swapped = new List<string>();
            foreach (string category in new[] { "目", "頬" })
            {
                if (byLabel.TryGetValue(category + "_左", out FaceMapPoint l) &&
                    byLabel.TryGetValue(category + "_右", out FaceMapPoint rt) &&
                    l.X >= rt.X)
                    swapped.Add(category);
            }
            AddGrouped(warnings, "W6: 左右が逆になっている可能性があります（左は画像の左側）: ", swapped);

            // W7: 縦方向の整合性
            if (byLabel.TryGetValue("口_中央", out FaceMapPoint mouth))
            {
                foreach (string label in new[] { "目_左", "目_右", "鼻_中央" })
                {
                    if (byLabel.TryGetValue(label, out FaceMapPoint upper) && upper.Y <= mouth.Y)
                    {
                        warnings.Add($"W7: {label} が口より下にあります（上下が逆の可能性があります）。");
                        break;
                    }
                }
            }
            if (byLabel.TryGetValue("顎_中央", out FaceMapPoint chin) && byLabel.TryGetValue("口_中央", out FaceMapPoint m2) &&
                chin.Y >= m2.Y)
            {
                warnings.Add("W7: 顎が口より上にあります（上下が逆の可能性があります）。");
            }

            // W8: 領域同士の大きな重なり
            var overlapped = new List<string>();
            for (int i = 0; i < file.Points.Count; i++)
            {
                for (int j = i + 1; j < file.Points.Count; j++)
                {
                    FaceMapPoint a = file.Points[i];
                    FaceMapPoint b = file.Points[j];
                    Rect ra = FaceMapFile.RegionRect(a.Uv, file.Sizes[FaceTemplate.CategoryOf(a.Label)]);
                    Rect rb = FaceMapFile.RegionRect(b.Uv, file.Sizes[FaceTemplate.CategoryOf(b.Label)]);
                    if (OverlapRatio(ra, rb) > OverlapWarnRatio) overlapped.Add($"{a.Label} と {b.Label}");
                }
            }
            AddGrouped(warnings, "W8: 領域が大きく重なっています: ", overlapped);
        }

        /// <summary>重なり面積 / 小さい方の面積。</summary>
        private static float OverlapRatio(Rect a, Rect b)
        {
            float w = Mathf.Min(a.xMax, b.xMax) - Mathf.Max(a.xMin, b.xMin);
            float h = Mathf.Min(a.yMax, b.yMax) - Mathf.Max(a.yMin, b.yMin);
            if (w <= 0f || h <= 0f) return 0f;

            float smaller = Mathf.Min(a.width * a.height, b.width * b.height);
            return smaller <= 0f ? 0f : (w * h) / smaller;
        }

        // ── 補助 ──

        /// <summary>
        /// JToken.Parse と同等だが、日付らしい文字列を Date 型に変換しない
        /// （name / label / meta を文字列のまま扱い、上書き保存で書式が変わらないようにする）。
        /// </summary>
        /// <summary>
        /// JSON を読む。日付らしい文字列を日付として読み直さない（読み直すと書き出しで書式が変わる）。
        /// FaceMap の読み込みと、meta（FaceMapFile.MetaJson）を扱うところはすべてこれで読む。
        /// </summary>
        internal static JToken ParseJson(string text)
        {
            using (var reader = new JsonTextReader(new System.IO.StringReader(text)))
            {
                reader.DateParseHandling = DateParseHandling.None;
                JToken token = JToken.ReadFrom(reader);

                // JToken.Parse と同じく、末尾の余分な内容（コメント以外）は拒否する
                while (reader.Read())
                {
                    if (reader.TokenType != JsonToken.Comment)
                        throw new JsonReaderException("Additional text encountered after finished reading JSON content.");
                }
                return token;
            }
        }

        private static bool IsNumber(JToken t)
        {
            return t.Type == JTokenType.Integer || t.Type == JTokenType.Float;
        }

        private static bool ReadNumber(JObject po, string key, string at,
                                       List<string> notNumber, List<string> notFinite, out float value)
        {
            value = 0f;
            if (!po.TryGetValue(key, out JToken t) || !IsNumber(t))
            {
                notNumber.Add($"{at}.{key}");
                return false;
            }

            double d = (double)t;
            float f = (float)d;
            if (double.IsNaN(d) || double.IsInfinity(d) || float.IsInfinity(f))
            {
                notFinite.Add($"{at}.{key}");
                return false;
            }

            value = f;
            return true;
        }

        private static void AddGrouped(List<string> dst, string head, List<string> items, int maxListed = MaxListedItems)
        {
            if (items.Count == 0) return;

            string list = string.Join(", ", items.Take(maxListed));
            if (items.Count > maxListed)
                list += $" …他 {items.Count - maxListed} 件";
            dst.Add(head + list);
        }
    }
}
