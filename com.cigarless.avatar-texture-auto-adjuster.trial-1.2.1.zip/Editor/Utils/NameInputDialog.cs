// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/NameInputDialog.cs
using System;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 名前を 1 つ入力してもらう小さなモーダルダイアログ（FaceMap エディターの「別名保存」など）。
    /// 保存先のフォルダは呼び出し側で決め、ここでは名前だけを聞く（どこにでも保存できるファイルダイアログは使わない）。
    /// Enter で決定、Esc で取り消し。
    /// </summary>
    internal sealed class NameInputDialog : EditorWindow
    {
        private const string FieldName = "ATAA.NameInputDialog.Field";

        private string _message;
        private string _value;
        private string _okLabel;
        private Func<string, NameCheck> _check;
        private bool _ok;
        private bool _focused;

        /// <summary>入力中の名前の確かめ結果。Error があれば決定できない。Note は補足（上書きになる、など）。</summary>
        public struct NameCheck
        {
            public string Error;
            public string Note;
        }

        /// <summary>
        /// ダイアログを出して、決定されたら入力された名前を、取り消されたら null を返す（閉じるまで戻らない）。
        /// </summary>
        /// <param name="check">入力のたびに呼ぶ確かめ。null なら空でなければ決定できる。</param>
        public static string Show(string title, string message, string initial, string okLabel, Func<string, NameCheck> check = null)
        {
            var dialog = CreateInstance<NameInputDialog>();
            dialog.titleContent = new GUIContent(title);
            dialog._message = message;
            dialog._value = initial ?? "";
            dialog._okLabel = okLabel;
            dialog._check = check;

            var size = new Vector2(420f, 150f);
            Rect main = EditorGUIUtility.GetMainWindowPosition();
            dialog.position = new Rect(main.center - size * 0.5f, size);
            dialog.minSize = dialog.maxSize = size;
            dialog.ShowModalUtility();
            return dialog._ok ? dialog._value.Trim() : null;
        }

        private NameCheck Check(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return new NameCheck { Error = "名前を入れてください。" };
            return _check != null ? _check(value.Trim()) : default;
        }

        private void OnGUI()
        {
            Event e = Event.current;
            NameCheck check = Check(_value);
            bool canOk = check.Error == null;

            // Enter / Esc は、テキスト欄がキーを使う前に受け取る（日本語 IME の変換確定 Enter は通す）
            if (e.type == EventType.KeyDown && string.IsNullOrEmpty(Input.compositionString))
            {
                if ((e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter) && canOk)
                {
                    Finish(true);
                    e.Use();
                    return;
                }
                if (e.keyCode == KeyCode.Escape)
                {
                    Finish(false);
                    e.Use();
                    return;
                }
            }

            EditorGUILayout.Space(8f);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(10f);
                using (new EditorGUILayout.VerticalScope())
                {
                    GUILayout.Label(_message, EditorStyles.wordWrappedLabel);
                    EditorGUILayout.Space(4f);

                    GUI.SetNextControlName(FieldName);
                    _value = EditorGUILayout.TextField(_value);
                    if (!_focused)
                    {
                        _focused = true;
                        EditorGUI.FocusTextInControl(FieldName);
                    }

                    string line = check.Error ?? check.Note ?? " ";
                    GUILayout.Label(line, check.Error != null ? MakeFixGui.WarnText : MakeFixGui.Subtle);

                    GUILayout.FlexibleSpace();
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.FlexibleSpace();
                        if (GUILayout.Button("キャンセル", GUILayout.Width(90f))) Finish(false);
                        using (new EditorGUI.DisabledScope(!canOk))
                        {
                            if (GUILayout.Button(_okLabel, GUILayout.Width(90f))) Finish(true);
                        }
                    }
                    EditorGUILayout.Space(8f);
                }
                GUILayout.Space(10f);
            }
        }

        private void Finish(bool ok)
        {
            _ok = ok;
            Close();
            GUIUtility.ExitGUI();
        }
    }
}
