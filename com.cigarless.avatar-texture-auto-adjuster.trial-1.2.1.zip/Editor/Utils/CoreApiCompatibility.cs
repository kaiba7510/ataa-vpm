// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/CoreApiCompatibility.cs
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// UI ソース（Editor）と計算コア（Core DLL）の API バージョン整合を確認する純粋ヘルパー（docs~/コアとUIの分割_設計メモ.md §5）。
    /// 上書き更新で片方だけ古い版が残った場合に、起動時に明確な案内を出す。
    /// </summary>
    public static class CoreApiCompatibility
    {
        /// <summary>この UI ソースが想定する AtaaCore.ApiVersion。</summary>
        public const int ExpectedApiVersion = 2;

        public static bool IsCompatible() => IsCompatible(AtaaCore.ApiVersion);

        public static bool IsCompatible(int actualApiVersion) => actualApiVersion == ExpectedApiVersion;

        /// <summary>
        /// 整合していれば null、不一致ならユーザー向けの案内文を返す。
        /// </summary>
        public static string GetMismatchMessage() => GetMismatchMessage(AtaaCore.ApiVersion, InstalledPackage.IsVpm);

        public static string GetMismatchMessage(int actualApiVersion) => GetMismatchMessage(actualApiVersion, installedByVpm: false);

        /// <param name="installedByVpm">VCC（VPM）で Packages/ に入っているとき true。案内する直し方が変わる。</param>
        public static string GetMismatchMessage(int actualApiVersion, bool installedByVpm)
        {
            if (IsCompatible(actualApiVersion)) return null;
            string fix = installedByVpm
                ? "VCC でこのプロジェクトの「Avatar Texture Auto Adjuster」をいったん削除し、入れ直してください。\n"
                : $"{PackageLocation.LegacyRoot} フォルダを削除してから、新しい .unitypackage をインポートし直してください。\n";
            return $"ATAA のコア DLL（API v{actualApiVersion}）と UI スクリプト（API v{ExpectedApiVersion}）のバージョンが一致していません。\n" +
                   "古いファイルが残ったまま上書き更新された可能性があります。\n" +
                   fix +
                   "（作成した FaceMap・調整データは Assets/ATAA_Data に保存されているため消えません）";
        }
    }
}
