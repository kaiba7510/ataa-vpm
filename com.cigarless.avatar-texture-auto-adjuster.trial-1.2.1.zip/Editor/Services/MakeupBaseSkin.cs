// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Services/MakeupBaseSkin.cs
using UnityEditor;
using UnityEngine;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 肌色合わせ（統合仕様書 §6.6）で、肌の部分が透明な「重ねるだけ」のメイクに使う、メイク元の素体の肌色。
    /// メイクのテクスチャには肌が無いので、メイク元 FaceMap に記録された顔テクスチャ（meta.faceTexture）から推定する。
    /// 重ねるメイクは、作者がメイク元の肌の上で色を決めている。メイクの色に「対象の肌色 ÷ メイク元の肌色」を掛けて
    /// 対象に重ねると、メイク元の肌の上で見た色に同じ比を掛けたものになり、見え方がそろう。
    /// 読み込みはメインスレッド専用。顔テクスチャは小さく読んでキャッシュする（推定は 192×192 の格子で見るだけ）。
    /// </summary>
    internal static class MakeupBaseSkin
    {
        /// <summary>推定に使う読み込みの長辺。</summary>
        private const int ReadSize = 1024;

        private static Texture2D _cachedTex;
        private static Hash128 _cachedHash;
        private static bool _cachedLinear;
        private static FacePixels _cachedPixels;

        /// <summary>
        /// mask の肌色合わせに、メイク元の素体の肌色を設定する（推定できなければ何もしない）。
        /// mask をワーカースレッドに渡す前に呼ぶこと。linear は対象の顔テクスチャの色空間（メイクの読み込みと同じ）。
        /// </summary>
        public static void Assign(FaceMask mask, FaceMapMeta makeupMap, Texture2D makeupTexture, bool linear)
        {
            SkinToneMatch match = mask?.SkinTone;
            if (match == null) return;
            match.MakeupBaseSkin = null;

            Texture2D tex = Resolve(makeupMap);
            // メイクのテクスチャそのものなら、合成時にメイクから推定するので要らない
            if (tex == null || ReferenceEquals(tex, makeupTexture)) return;

            FacePixels px = Load(tex, linear);
            if (px != null && AtaaCore.TryEstimateSkinTone(px, match.MakeupParts, true, out Color skin))
                match.MakeupBaseSkin = skin;
        }

        /// <summary>メイク元 FaceMap に記録された顔テクスチャ（GUID で探す。見つからなければ null）。</summary>
        private static Texture2D Resolve(FaceMapMeta map)
        {
            if (map == null || string.IsNullOrEmpty(map.FaceTextureGuid)) return null;
            string path = AssetDatabase.GUIDToAssetPath(map.FaceTextureGuid);
            return string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }

        private static FacePixels Load(Texture2D tex, bool linear)
        {
            if (tex.width > AtaaCore.MaxTextureSize || tex.height > AtaaCore.MaxTextureSize) return null;

            string path = AssetDatabase.GetAssetPath(tex);
            Hash128 hash = string.IsNullOrEmpty(path) ? default : AssetDatabase.GetAssetDependencyHash(path);
            if (_cachedPixels != null && ReferenceEquals(tex, _cachedTex) && hash == _cachedHash && linear == _cachedLinear)
                return _cachedPixels;

            FaceMapPreview.FitSize(tex.width, tex.height, ReadSize, out int w, out int h);
            _cachedPixels = FaceTextureReader.Read(tex, w, h, linear);
            _cachedTex = tex;
            _cachedHash = hash;
            _cachedLinear = linear;
            return _cachedPixels;
        }
    }
}
