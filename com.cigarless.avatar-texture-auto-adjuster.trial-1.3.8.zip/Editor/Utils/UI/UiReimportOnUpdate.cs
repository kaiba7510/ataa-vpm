using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// VPM で版を上げた（下げた）あと、ツールの UI（Editor/Windows/UI の UXML・USS）を 1 回だけインポートし直す。
    /// 1.3.7 までの zip は全ファイルの更新日時が 1980-01-01 だったため、VCC で更新しても Unity が UXML を変わっていないと見て
    /// 古いインポート結果を使い続け、C# だけ新しくなって FaceMap エディターの画面が壊れた（「保存して完了」・口の線が反応しない）。
    /// インポートし直した版は Library に印として残す（Library を消せば Unity がすべて読み直すので、印も一緒に消えてよい）。
    /// </summary>
    [InitializeOnLoad]
    internal static class UiReimportOnUpdate
    {
        private const string MarkerPath = "Library/ATAA/ui-imported-version.txt";

        static UiReimportOnUpdate()
        {
            EditorApplication.delayCall += Run;
        }

        private static void Run()
        {
            try
            {
                var info = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(UiReimportOnUpdate).Assembly);
                if (info == null || !PackageLocation.IsVpmRoot(info.assetPath)) return; // .unitypackage 版は取り込みで読み直される

                string marker = File.Exists(MarkerPath) ? File.ReadAllText(MarkerPath) : null;
                if (!PackageLocation.NeedsUiReimport(info.version, marker)) return;

                string folder = info.assetPath.Replace('\\', '/').TrimEnd('/') + "/" + PackageLocation.UiFolder;
                if (AssetDatabase.IsValidFolder(folder))
                {
                    AssetDatabase.ImportAsset(folder,
                        ImportAssetOptions.ForceUpdate | ImportAssetOptions.ImportRecursive | ImportAssetOptions.ForceSynchronousImport);
                }

                Directory.CreateDirectory(Path.GetDirectoryName(MarkerPath));
                File.WriteAllText(MarkerPath, info.version.Trim());

                // 古い画面のまま開いているウィンドウを組み立て直す
                foreach (MyVrcToolFaceMapEditorWindow w in Resources.FindObjectsOfTypeAll<MyVrcToolFaceMapEditorWindow>()) w.RebuildUi();
                foreach (MakeFixWindow w in Resources.FindObjectsOfTypeAll<MakeFixWindow>()) w.RebuildUi();
            }
            catch (Exception ex)
            {
                // 読み直せなくてもツールは使える（UiAssets.EnsureFresh が UXML を個別に確かめる）
                Debug.LogWarning("[ATAA] UI のインポートし直しに失敗しました: " + ex.Message);
            }
        }
    }
}
