using System.Collections.Generic;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// ツールの置き場所。.unitypackage 版は Assets/Cigarless/AvatarTextureAutoAdjuster、
    /// VPM（VCC）版は Packages/&lt;パッケージ名&gt;（本リリースと体験版で名前が違う）。
    /// パッケージ名は tools~/release/build_release.py の VPM_PACKAGE_NAMES と同じにする。
    /// </summary>
    public static class PackageLocation
    {
        public const string PackageName = "com.cigarless.avatar-texture-auto-adjuster";
        public const string TrialPackageName = PackageName + ".trial";
        /// <summary>ショップのフォルダ。.unitypackage 版のツールと、ユーザーのデータ（ATAA_Data）を置く。</summary>
        public const string ShopRoot = "Assets/Cigarless";
        public const string LegacyRoot = ShopRoot + "/AvatarTextureAutoAdjuster";

        /// <summary>以前の版がユーザーのデータを置いていた場所（1.3.5 までは Assets 直下）。開いたときに今の場所へ移す。</summary>
        public static readonly string[] LegacyDataRoots = { "Assets/ATAA_Data" };
        public const string UiFolder = "Editor/Windows/UI";

        /// <summary>
        /// ツールのルートの候補を、試す順に返す。detectedRoot（実際に入っている場所。分からなければ null）を先頭に、
        /// 次に VPM の本リリース・体験版、最後に旧 Assets の場所。重複は除く。
        /// </summary>
        public static string[] CandidateRoots(string detectedRoot)
        {
            var roots = new List<string>();
            void Add(string root)
            {
                if (string.IsNullOrEmpty(root)) return;
                root = root.Replace('\\', '/').TrimEnd('/');
                if (root.Length > 0 && !roots.Contains(root)) roots.Add(root);
            }
            Add(detectedRoot);
            Add("Packages/" + PackageName);
            Add("Packages/" + TrialPackageName);
            Add(LegacyRoot);
            return roots.ToArray();
        }

        /// <summary>UI Toolkit の画面ファイル（例 MakeFixWindow.uxml）を探すパスの候補。</summary>
        public static string[] UiAssetCandidates(string fileName, string detectedRoot)
        {
            string[] roots = CandidateRoots(detectedRoot);
            var paths = new string[roots.Length];
            for (int i = 0; i < roots.Length; i++) paths[i] = roots[i] + "/" + UiFolder + "/" + fileName;
            return paths;
        }

        /// <summary>
        /// 以前の版が FaceMaps を置いていた場所の候補（以前のデータの場所、今のツールのルートの下、旧 Assets の場所の順）。
        /// VPM へ移るとき VCC はツールのファイルだけを消し、旧フォルダの FaceMaps は残すので、そこからも移す。
        /// </summary>
        public static string[] LegacyFaceMapFolders(string toolRoot)
        {
            var folders = new List<string>();
            var roots = new List<string>(LegacyDataRoots) { toolRoot, LegacyRoot };
            foreach (string root in roots)
            {
                if (string.IsNullOrEmpty(root)) continue;
                string path = root.Replace('\\', '/').TrimEnd('/') + "/FaceMaps";
                if (!folders.Contains(path)) folders.Add(path);
            }
            return folders.ToArray();
        }

        /// <summary>
        /// UI（UXML・USS）をインポートし直すか。installed は入っている版、marker は前にインポートし直した版（無ければ null）。
        /// 版が分からなければしない。前後の空白は無視する。
        /// </summary>
        public static bool NeedsUiReimport(string installed, string marker)
        {
            string v = installed?.Trim();
            return !string.IsNullOrEmpty(v) && v != marker?.Trim();
        }

        /// <summary>VPM（Packages/ の下）で入っているか。</summary>
        public static bool IsVpmRoot(string root) =>
            !string.IsNullOrEmpty(root) && root.Replace('\\', '/').StartsWith("Packages/");
    }
}
