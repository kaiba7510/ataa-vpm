# Avatar Texture Auto Adjuster (ATAA)

アバターの顔テクスチャ（メイク）を、別のアバターの顔に自動で合わせる Unity エディター拡張です。
目・鼻・口・頬の位置の違いに合わせてメイクを変形し、対象アバターの顔テクスチャに合成します。

## 動作環境

- Unity 2022.3（VRChat 推奨バージョン）
- Newtonsoft Json（`com.unity.nuget.newtonsoft-json`）。VRChat SDK を入れたプロジェクトには入っています。
- エディター専用です。アバターのアップロード・ビルドには含まれません。

## 導入

1. `.unitypackage` を Unity プロジェクトにインポートします。
2. `Assets/Cigarless/AvatarTextureAutoAdjuster/` ができます。
   フォルダは移動しても動きます。
3. 作った FaceMap・調整・合成したテクスチャは、ツールとは別の `Assets/ATAA_Data/FaceMaps/` に保存されます。
   ツールを入れ直す（古いフォルダを消してから新しい版を入れる）ときも、`ATAA_Data` は消さないでください。
   以前の版でツールのフォルダの中（`AvatarTextureAutoAdjuster/FaceMaps/`）に保存したものは、初めて開いたときに自動で移します。

## 使い方

作業の前に、プロジェクトのバックアップを取っておくことをおすすめします。

### 1. ウィンドウを開く

メニューの **Cigarless > ATAA** を開きます。左が「アバター管理」、中央がプレビュー、右が「フィッティング調整」です。

### 2. 対象アバターを準備する（左：アバター管理）

1. **アバター**: メイクを乗せたいアバターを、シーンからドラッグ＆ドロップするか一覧から選びます。
   （プロジェクトのプレハブには適用できません。シーン上のアバターを選んでください）
2. **顔メッシュ**: 顔の SkinnedMeshRenderer を選びます。通常は自動で選ばれます。行にマウスを乗せると、3D ビューにそのメッシュだけが映ります。
3. **アバター基準**: 顔の基準データ（FaceMap）です。まだ無いときは「アバター基準を自動生成」を押します。
   - 「要確認」や「目の線を合わせてください」と出たときは、FaceMap エディターで位置を確かめてください。
4. **顔テクスチャ**: 「候補から選ぶ」で、顔のマテリアルが使っているテクスチャを画像を見て選びます。

### 3. メイク元を選ぶ（右：フィッティング調整）

- **メイク基準**: メイクを作ったアバターの FaceMap を選びます。
  メイク元のアバターの FaceMap も、手順 2 と同じ方法で先に作っておいてください。
- **メイクテクスチャ**: メイク元の顔テクスチャ（またはメイクだけの透過画像）を選びます。

### 4. 確認と微調整

- 中央のプレビューで仕上がりを確認します。「3Dビュー」と「2D UV」を切り替えられます。
  - 3Dビュー: 右ドラッグで回転、中ドラッグで移動、ホイールでズーム、H キーで前髪などの装飾品を非表示
  - ビュー右下の「押している間：メイク前」（または C キー）を押している間は、メイク前の顔を表示します
- ずれが気になるときは、**調整するパーツ** を選んで位置・大きさを合わせます。
  2D UV 表示では、枠のドラッグで移動、四隅で拡大縮小もできます。
- **目の調整** で下まつ毛の幅などを、**仕上げ** でメイクの濃さを変えられます。
- 調整はアバターの組み合わせごとに保存され、次回も引き継がれます。アバター基準（FaceMap）は変わりません。
- 「調整するパーツ」の見出しにある「調整をすべてリセット」で、調整をやり直せます（メイクの濃さは変わりません）。

### 5. 適用する

右下の **メイク適用** を押すと、合成したテクスチャを作り、顔のマテリアルに適用します。
メイクを外したいときは「適用を解除」を押してください（Unity の Undo でも戻せます）。

## 合いにくい組み合わせ

- **口が小さく描かれたデフォルメ調のアバター**（線や小さな口で描かれた顔）に、口が大きく描かれたメイク元から写すと、唇の形が崩れやすくなります。
  メイク元の唇を大きく縮めて写すことになり、位置・大きさ・口の曲がりを調整しても、形を合わせきれないことがあります。
  - 口の大きさが顔に対して 3 倍以上違う組み合わせでは、プレビューの上に「口の大きさがメイク元と大きく違います」と注意が出ます。合成はそのまま行います。
  - プレビューで口元を拡大して確かめ、合わなければ注意の横の「口を合成しない」を押してください（アバターの元の口がそのまま残ります。「口」の「合成する」で戻せます）。

## FaceMap（顔の基準データ）について

- アバターごとの FaceMap は同梱していません。自動生成、または FaceMap エディターで、お使いのアバターごとに作成してください。
- 作成した FaceMap は `Assets/ATAA_Data/FaceMaps/` に、組み合わせごとの調整は `FaceMaps/Adjustments/` に保存されます。
- FaceMap は、アバターやメイク素材などの商品に同梱して配布できます。その場合は、商品ページに「本ツール用の FaceMap が含まれていること（ツール名と BOOTH の URL）」と「使うには本ツールが別途必要なこと」を必ず記載してください（`LICENSE.txt` の 3 を参照）。
- まばたきのブレンドシェイプが見つからず自動生成できないときは、FaceMap エディターの「自動作成」でブレンドシェイプを指定してください。

## 出力されるファイル

- 合成したテクスチャ・マテリアルは `FaceMaps/Generated/<アバター>/<メイク>/` に出力されます。
- 元のマテリアル・テクスチャは書き換えません。
- 生成したテクスチャには、元のアバター・テクスチャの利用規約が適用されます。
  メイク元のテクスチャを別のアバターに使ってよいか、事前にそれぞれの規約をご確認ください。

## 更新

- **通常の上書き更新**: 新しい版を同じ場所にインポートし直すと、上書きで更新できます。作成した FaceMap と調整は `Assets/ATAA_Data/` にあるため、そのまま残ります。
- **旧単一 DLL 版（オープンβなど）からの移行**: 以前の版（`Editor/AvatarTextureAutoAdjuster.Editor.dll` が入っていた版）が残ったまま新しい版を上書きすると、型が重複してコンパイルエラーになります。移行時は **`Assets/Cigarless/AvatarTextureAutoAdjuster` フォルダを一度削除してから**、新しい `.unitypackage` をインポートしてください（`Assets/ATAA_Data` は消さないでください）。
- 起動時に「コア DLL と UI スクリプトのバージョンが一致していません」と出た場合も、同様に `Assets/Cigarless/AvatarTextureAutoAdjuster` を削除して再インポートしてください。
- 変更点は `CHANGELOG.md` を見てください。

## 安全性・DLL・完全オフライン動作について

- **完全オフライン・エディタ専用**: 外部通信やテレメトリ送信は一切行いません。また、エディタ専用のためアバターのビルド・アップロードには一切含まれません。
- **UI・ファイル操作はソースコード同梱**: ウィンドウ UI・ファイル読み書き・アセット操作・マテリアル適用などはすべて読める C# ソースコード（`Editor/*.cs`）で同梱しています。
- **計算コアのみ DLL 化（穏健な名前難読化）**: 独自に開発した計算アルゴリズム保護のため、純粋な計算コア（`Core/AvatarTextureAutoAdjuster.Core.dll`）のみを DLL 化（ASCII 名のシンプルな難読化）しています。ウイルス対策ソフトの誤検知や不審な挙動の原因になりやすいパッカー・暗号化・`SuppressIldasm` 属性は使用していません。
- **外部 API 参照の検証可能**: コア DLL はネットワーク・ファイル I/O・プロセス起動・`UnityEditor` API 等を一切参照していません（リリースビルド時に .NET メタデータ解析で自動検査しています）。

### コア DLL の外部 API 参照（許可リストと確認手順）

`Core/AvatarTextureAutoAdjuster.Core.dll` が参照してよい外部 API は、次の範囲だけに限定しています。

- **許可している参照**:
  - `UnityEngine.CoreModule` の純粋な数学・色型のみ（`Vector2` / `Vector3` / `Vector3Int` / `Rect` / `Color` / `Color32` / `Mathf` 等）
  - `netstandard` の純粋計算・コレクション・並列計算・経過時間計測（`Stopwatch`）・コンパイラ生成の非実行メタデータ属性のみ
- **参照していないもの（自動検査で禁止）**:
  - 外部通信（`System.Net*`、`UnityEngine.Networking*`、`Application.OpenURL`）
  - ファイル・OS・プロセス（`System.IO.File*` / `Directory*` / `FileStream`、`System.Diagnostics.Process*`、`System.Environment*`）
  - 動的実行リフレクション（`Type.GetType`、`Assembly.Load*`、`MethodInfo.Invoke`、`Reflection.Emit`）
  - ネイティブ呼び出し（`DllImport` / `ImplMap`、`Marshal`、`NativeLibrary`）
  - エディタ・端末情報・永続化（`UnityEditor*`、`UnityEngine.Application*`、`UnityEngine.SystemInfo*`、`UnityEngine.PlayerPrefs*`）

#### 方法 1: Windows 標準の PowerShell で依存アセンブリを確認する（ツール導入・逆コンパイル不要）

Unity プロジェクトのルートで PowerShell を開き、次を実行します。

```powershell
$asm = [System.Reflection.Assembly]::ReflectionOnlyLoadFrom(
    (Resolve-Path "Assets/Cigarless/AvatarTextureAutoAdjuster/Core/AvatarTextureAutoAdjuster.Core.dll").Path
)
$asm.GetReferencedAssemblies() | ForEach-Object { $_.Name }
```

出力が `netstandard` と `UnityEngine.CoreModule` の 2 つだけであることを確認できます。

#### 方法 2: PowerShell 7（`pwsh`）で外部型参照・P/Invoke 一覧まで確認する（逆コンパイル不要）

PowerShell 7 が入っている環境では、.NET 標準の `System.Reflection.Metadata` で `AssemblyRef` / `TypeRef` / `ImplMap`（`DllImport`）をそのまま一覧できます。

```powershell
$dll = (Resolve-Path "Assets/Cigarless/AvatarTextureAutoAdjuster/Core/AvatarTextureAutoAdjuster.Core.dll").Path
$fs = [System.IO.File]::OpenRead($dll)
$pe = [System.Reflection.PortableExecutable.PEReader]::new($fs)
$md = $pe.GetMetadataReader()
"=== AssemblyRefs ==="
$md.AssemblyReferences | ForEach-Object { $md.GetString($md.GetAssemblyReference($_).Name) } | Sort-Object
"=== TypeRefs ==="
$md.TypeReferences | ForEach-Object {
    $tr = $md.GetTypeReference($_)
    "$($md.GetString($tr.Namespace)).$($md.GetString($tr.Name))"
} | Sort-Object -Unique
"=== ImplMaps (DllImport) ==="
$md.MethodDefinitions | ForEach-Object {
    $imp = $md.GetMethodDefinition($_).GetImport()
    if (-not $imp.Module.IsNil) { "$($md.GetString($md.GetModuleReference($imp.Module).Name))|$($md.GetString($imp.Name))" }
}
$pe.Dispose(); $fs.Dispose()
```

#### 方法 3: ILSpy で参照を確認する

1. ILSpy で `Core/AvatarTextureAutoAdjuster.Core.dll` を開きます。
2. アセンブリ直下の **References** を開き、`netstandard` と `UnityEngine.CoreModule` のみであることを確認します。

（※ `LICENSE.txt` の「4. プログラムの扱いと安全性確認」の通り、安全性確認のための依存アセンブリ・外部 API 参照メタデータの確認は許可されています。計算アルゴリズムの解析・抽出・再現は禁止です。）

## 利用規約

`LICENSE.txt` を見てください。

## 連絡先

不具合報告・ご質問は、BOOTH のメッセージ機能、または X の DM からお願いします。

- BOOTH: https://cigarless.booth.pm/
- X: [@Cigarless_VR](https://x.com/Cigarless_VR)

### 不具合報告のお願い

次の内容を書いて送っていただけると、原因を探しやすくなります。分かる範囲で大丈夫です。

```
・ツールのバージョン（CHANGELOG.md の一番上）:
・Unity のバージョン:
・対象アバター（とメイク元のアバター）の名前:
・どの手順で起きたか（例: アバター基準の自動生成、メイク適用）:
・画面に出たメッセージ（Console のエラーがあればその文面）:
・どうなったか / どうなってほしかったか:
```

- スクリーンショットを付けていただく場合は、アバターのテクスチャやモデルの規約に反しない範囲でお願いします。
- アバターのデータ（モデル・テクスチャ・FaceMap など）を送っていただく必要はありません。
