// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/State/MyVrcToolState.cs
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// フィッティング（メイク適用）画面の状態。
    /// 選択中の FaceMap はファイルパスで保持し、一覧の再走査後も FaceMapMeta を引き直せるようにする。
    /// </summary>
    public class MyVrcToolState
    {
        public GameObject TargetAvatar;

        /// <summary>
        /// 対象アバターの顔メッシュ（左ペインで選ぶ。3ペイン仕様 §3）。3D 顔ビューのピボット・装飾品の非表示で残すレンダラー・
        /// アバター基準の自動生成・顔テクスチャの候補に使う。null なら自動で選ぶ。
        /// </summary>
        public SkinnedMeshRenderer FaceRenderer;

        /// <summary>走査中の FaceMaps フォルダ（絶対パス。表示用）。</summary>
        public string FaceMapFolderPath;

        /// <summary>直近の走査結果（valid / invalid の両方）。</summary>
        public List<FaceMapMeta> FaceMaps = new List<FaceMapMeta>();
        public bool IsScanning;

        public string MakeupFaceMapPath;
        public string AvatarFaceMapPath;

        // ── 微調整（FaceMap の組み合わせごと） ──

        /// <summary>メイク元と対象の両方が選択済みで読み込める。</summary>
        public bool HasPair =>
            MakeupFaceMap != null && MakeupFaceMap.IsValid &&
            AvatarFaceMap != null && AvatarFaceMap.IsValid;

        /// <summary>現在の組み合わせを読み込み済みかを判定するキー。組み合わせが変わると差し替わる。</summary>
        public string PairKey;

        /// <summary>組み合わせの対応付け結果。読み込み前・失敗時は null。</summary>
        public FaceMapMatch PairMatch;

        /// <summary>組み合わせを読み込めなかった理由（読み込み中・正常時は null）。</summary>
        public string PairError;

        public FaceMapAdjustment Adjustment = new FaceMapAdjustment();
        public string AdjustmentPath;

        /// <summary>プレビュー用の顔テクスチャ（保存しない。見た目の確認だけに使う）。</summary>
        public Texture2D PreviewAvatarTexture;
        public Texture2D PreviewMakeupTexture;
        /// <summary>メイクの濃さの既定値（仕上げの「自動に戻す」で戻る値）。</summary>
        public const float DefaultPreviewMakeupOpacity = 0.7f;
        public float PreviewMakeupOpacity = DefaultPreviewMakeupOpacity;

        public string Warning = "";
        public MessageType WarningType = MessageType.Info;

        public FaceMapMeta MakeupFaceMap => Find(MakeupFaceMapPath);
        public FaceMapMeta AvatarFaceMap => Find(AvatarFaceMapPath);

        public bool IsReady =>
            TargetAvatar != null &&
            MakeupFaceMap != null && MakeupFaceMap.IsValid &&
            AvatarFaceMap != null && AvatarFaceMap.IsValid;

        public FaceMapMeta Find(string path)
        {
            if (string.IsNullOrEmpty(path) || FaceMaps == null) return null;
            return FaceMaps.Find(m => m.FilePath == path);
        }
    }
}
