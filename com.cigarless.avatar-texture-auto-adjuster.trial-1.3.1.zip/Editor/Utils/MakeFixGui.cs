// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/MakeFixGui.cs
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// メイクフィックス画面の見た目の部品（カード・見出し・ステップ番号・状態チップ・メッセージ行・主ボタン）。
    /// 色はエディターのスキン（Personal / Pro）に合わせる。絵文字は使わず、Unity 標準のアイコンと図形で表す。
    /// </summary>
    internal static class MakeFixGui
    {
        public enum StepState
        {
            Pending,
            Current,
            Done,
            Problem
        }

        // ── 色 ──

        private static bool Pro => EditorGUIUtility.isProSkin;

        public static Color Accent => Pro ? new Color(0.30f, 0.58f, 0.93f) : new Color(0.17f, 0.42f, 0.82f);
        public static Color Success => Pro ? new Color(0.33f, 0.72f, 0.42f) : new Color(0.20f, 0.58f, 0.30f);
        public static Color Warning => Pro ? new Color(0.95f, 0.68f, 0.22f) : new Color(0.78f, 0.49f, 0.04f);
        public static Color Danger => Pro ? new Color(0.90f, 0.36f, 0.33f) : new Color(0.75f, 0.20f, 0.18f);
        public static Color Muted => Pro ? new Color(0.50f, 0.50f, 0.50f) : new Color(0.52f, 0.52f, 0.52f);
        public static Color Text => Pro ? new Color(0.82f, 0.82f, 0.82f) : new Color(0.10f, 0.10f, 0.10f);
        public static Color SubText => Pro ? new Color(0.62f, 0.62f, 0.62f) : new Color(0.36f, 0.36f, 0.36f);
        public static Color Divider => Pro ? new Color(0f, 0f, 0f, 0.35f) : new Color(0f, 0f, 0f, 0.18f);
        public static Color RowHover => Pro ? new Color(1f, 1f, 1f, 0.05f) : new Color(0f, 0f, 0f, 0.05f);
        public static Color RowSelected => new Color(Accent.r, Accent.g, Accent.b, Pro ? 0.35f : 0.25f);

        private static Color PaneBg => Pro ? new Color(0.19f, 0.19f, 0.19f) : new Color(0.74f, 0.74f, 0.74f);
        private static Color CardBg => Pro ? new Color(0.245f, 0.245f, 0.245f) : new Color(0.86f, 0.86f, 0.86f);
        private static Color CardBorder => Pro ? new Color(0.14f, 0.14f, 0.14f) : new Color(0.62f, 0.62f, 0.62f);
        private static Color InsetBg => Pro ? new Color(0.20f, 0.20f, 0.20f) : new Color(0.80f, 0.80f, 0.80f);

        // ── スタイル（スキンが変わる・テクスチャが破棄されたら作り直す）──

        private static bool _stylesPro;
        private static Texture2D _paneTex, _cardTex, _insetTex;
        private static GUIStyle _pane, _card, _inset, _title, _subtle, _subtleWrap, _chip, _stepNum, _rowLabel, _rowSub,
            _primary, _secondary, _warnText, _paneTitle;
        private static readonly Dictionary<int, Texture2D> SolidTextures = new Dictionary<int, Texture2D>();

        public static GUIStyle Pane { get { Ensure(); return _pane; } }
        public static GUIStyle Card { get { Ensure(); return _card; } }
        public static GUIStyle Inset { get { Ensure(); return _inset; } }
        public static GUIStyle Title { get { Ensure(); return _title; } }
        public static GUIStyle Subtle { get { Ensure(); return _subtle; } }
        public static GUIStyle SubtleWrap { get { Ensure(); return _subtleWrap; } }
        public static GUIStyle WarnText { get { Ensure(); return _warnText; } }
        public static GUIStyle RowLabel { get { Ensure(); return _rowLabel; } }
        public static GUIStyle RowSub { get { Ensure(); return _rowSub; } }
        public static GUIStyle SecondaryButton { get { Ensure(); return _secondary; } }

        private static void Ensure()
        {
            if (_pane != null && _paneTex != null && _cardTex != null && _insetTex != null && _stylesPro == Pro) return;
            _stylesPro = Pro;

            _paneTex = MakeFramedTexture(PaneBg, PaneBg);
            _cardTex = MakeFramedTexture(CardBg, CardBorder);
            _insetTex = MakeFramedTexture(InsetBg, CardBorder);

            _pane = new GUIStyle
            {
                normal = { background = _paneTex },
                padding = new RectOffset(6, 6, 6, 6),
                margin = new RectOffset(0, 0, 0, 0)
            };
            _card = new GUIStyle
            {
                normal = { background = _cardTex },
                border = new RectOffset(1, 1, 1, 1),
                padding = new RectOffset(8, 8, 6, 8),
                margin = new RectOffset(0, 0, 0, 6)
            };
            _inset = new GUIStyle
            {
                normal = { background = _insetTex },
                border = new RectOffset(1, 1, 1, 1),
                padding = new RectOffset(2, 2, 2, 2),
                margin = new RectOffset(0, 0, 2, 2)
            };
            _paneTitle = new GUIStyle(EditorStyles.boldLabel) { fontSize = 13, normal = { textColor = Text } };
            _title = new GUIStyle(EditorStyles.boldLabel) { fontSize = 12, normal = { textColor = Text } };
            _subtle = new GUIStyle(EditorStyles.miniLabel) { normal = { textColor = SubText }, clipping = TextClipping.Clip };
            _subtleWrap = new GUIStyle(_subtle) { wordWrap = true };
            _warnText = new GUIStyle(EditorStyles.miniLabel) { normal = { textColor = Warning }, clipping = TextClipping.Clip };
            _chip = new GUIStyle(EditorStyles.miniBoldLabel)
            {
                alignment = TextAnchor.MiddleCenter,
                padding = new RectOffset(6, 6, 0, 0),
                normal = { textColor = Color.white }
            };
            _stepNum = new GUIStyle(EditorStyles.miniBoldLabel)
            {
                alignment = TextAnchor.MiddleCenter,
                padding = new RectOffset(0, 0, 0, 0),
                normal = { textColor = Color.white }
            };
            _rowLabel = new GUIStyle(EditorStyles.label) { clipping = TextClipping.Clip, padding = new RectOffset(4, 4, 1, 1) };
            _rowSub = new GUIStyle(_subtle) { alignment = TextAnchor.MiddleRight, padding = new RectOffset(4, 4, 1, 1) };

            _primary = new GUIStyle(GUI.skin.button)
            {
                fontSize = 13,
                fontStyle = FontStyle.Bold,
                fixedHeight = 34f,
                normal = { textColor = Color.white },
                hover = { textColor = Color.white },
                active = { textColor = Color.white },
                focused = { textColor = Color.white }
            };
            _secondary = new GUIStyle(GUI.skin.button) { fontSize = 12, fixedHeight = 34f };
        }

        /// <summary>中が bg、外周 1px が border の 3×3 テクスチャ（GUIStyle.border で 9 スライスにする）。</summary>
        private static Texture2D MakeFramedTexture(Color bg, Color border)
        {
            var tex = new Texture2D(3, 3, TextureFormat.RGBA32, false)
            {
                hideFlags = HideFlags.HideAndDontSave,
                filterMode = FilterMode.Point,
                wrapMode = TextureWrapMode.Clamp
            };
            var px = new Color[9];
            for (int i = 0; i < 9; i++) px[i] = i == 4 ? bg : border;
            tex.SetPixels(px);
            tex.Apply();
            return tex;
        }

        private static Texture2D Solid(Color c)
        {
            int key = ((int)(c.r * 255) << 24) | ((int)(c.g * 255) << 16) | ((int)(c.b * 255) << 8) | (int)(c.a * 255);
            if (SolidTextures.TryGetValue(key, out Texture2D t) && t != null) return t;
            t = MakeFramedTexture(c, c);
            SolidTextures[key] = t;
            return t;
        }

        // ── アイコン（Unity 標準）──

        private static GUIContent _warnIcon, _infoIcon, _errorIcon;

        public static Texture Icon(MessageType type)
        {
            switch (type)
            {
                case MessageType.Warning:
                    return (_warnIcon ??= EditorGUIUtility.IconContent("console.warnicon.sml")).image;
                case MessageType.Error:
                    return (_errorIcon ??= EditorGUIUtility.IconContent("console.erroricon.sml")).image;
                default:
                    return (_infoIcon ??= EditorGUIUtility.IconContent("console.infoicon.sml")).image;
            }
        }

        // ── ペイン・カード ──

        public static void PaneHeader(string title, string subtitle)
        {
            Ensure();
            GUILayout.Label(title, _paneTitle);
            if (!string.IsNullOrEmpty(subtitle)) GUILayout.Label(subtitle, _subtle);
            EditorGUILayout.Space(4);
        }

        /// <summary>カードを始める。step が 1 以上なら丸いステップ番号を、chip があれば右端に状態を出す。</summary>
        public static void BeginCard(string title, string tooltip = null, int step = 0, StepState state = StepState.Pending,
                                     string chip = null, Color? chipColor = null)
        {
            BeginCardWithHeader(title, tooltip, step, state);
            if (chip != null) Chip(chip, chipColor ?? Muted);
            EndCardHeader();
        }

        /// <summary>
        /// 見出しの右端にボタンなどを置くカード。BeginCard と同じ見出しを描き、行を開いたまま返す。
        /// 呼び出し側で右端の部品を描いてから EndCardHeader を呼ぶ。
        /// </summary>
        public static void BeginCardWithHeader(string title, string tooltip = null, int step = 0, StepState state = StepState.Pending)
        {
            Ensure();
            EditorGUILayout.BeginVertical(_card);
            EditorGUILayout.BeginHorizontal();
            if (step > 0)
            {
                Rect r = GUILayoutUtility.GetRect(18f, 18f, GUILayout.Width(18f), GUILayout.Height(18f));
                if (Event.current.type == EventType.Repaint) DrawStepBadge(r, step, state);
                GUILayout.Space(4f);
            }
            GUILayout.Label(new GUIContent(title, tooltip), _title, GUILayout.Height(18f));
            GUILayout.FlexibleSpace();
        }

        public static void EndCardHeader()
        {
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.Space(3);
        }

        public static void EndCard()
        {
            EditorGUILayout.EndVertical();
        }

        private static void DrawStepBadge(Rect r, int step, StepState state)
        {
            Color c;
            switch (state)
            {
                case StepState.Done: c = Success; break;
                case StepState.Current: c = Accent; break;
                case StepState.Problem: c = Warning; break;
                default: c = Muted; break;
            }
            DrawDisc(r, c);
            if (state == StepState.Done) DrawCheck(r, Color.white);
            else GUI.Label(r, step.ToString(), _stepNum);
        }

#if ATAA_DIAGNOSTICS
        private static GUIStyle _testBanner;

        /// <summary>
        /// オープンβだけ: ウィンドウ上部に出す赤い注意書き（ATAA ウィンドウ・FaceMap エディター共通）。
        /// 本リリースの DLL には文言ごと入らない（build_release.py の DIAGNOSTICS_IN_DLL で検査）。
        /// </summary>
        public static void TestBuildBanner()
        {
            if (_testBanner == null)
            {
                _testBanner = new GUIStyle(EditorStyles.boldLabel)
                {
                    alignment = TextAnchor.MiddleCenter,
                    wordWrap = true,
                    padding = new RectOffset(6, 6, 3, 3),
                };
            }
            _testBanner.normal.textColor = Pro ? new Color(1f, 0.42f, 0.42f) : new Color(0.8f, 0.05f, 0.05f);

            var content = new GUIContent("本バージョンはオープンβ版です。予期しない不具合が起きることがあります。" +
                                         "利用する前にプロジェクトのバックアップを取り、注意して使ってください。");
            Rect r = GUILayoutUtility.GetRect(content, _testBanner, GUILayout.ExpandWidth(true));
            if (Event.current.type == EventType.Repaint)
                EditorGUI.DrawRect(r, Pro ? new Color(0.45f, 0.08f, 0.08f, 0.35f) : new Color(1f, 0.85f, 0.85f, 1f));
            GUI.Label(r, content, _testBanner);
        }
#endif

        private static GUIStyle _trialBanner;

        /// <summary>
        /// 体験版だけ: ウィンドウ上部に出す青い案内（ATAA ウィンドウ・FaceMap エディター共通）。
        /// 呼ぶのは体験版（AtaaCore.Edition）のときだけ。
        /// </summary>
        public static void TrialBanner()
        {
            if (_trialBanner == null)
            {
                _trialBanner = new GUIStyle(EditorStyles.boldLabel)
                {
                    alignment = TextAnchor.MiddleCenter,
                    wordWrap = true,
                    padding = new RectOffset(6, 6, 3, 3),
                };
            }
            _trialBanner.normal.textColor = Pro ? new Color(0.55f, 0.78f, 1f) : new Color(0.05f, 0.3f, 0.7f);

            var content = new GUIContent(
                "体験版です。自動作成・調整・プレビューは製品版と同じように使えます（プレビューは通常 512・長押しで 2048 表示）。" +
                "メイク適用（テクスチャの書き出し）とファイルへの保存は製品版のみです。" +
                "作った FaceMap と調整はメモリに一時保存され、Unity を閉じると消えます。");
            Rect r = GUILayoutUtility.GetRect(content, _trialBanner, GUILayout.ExpandWidth(true));
            if (Event.current.type == EventType.Repaint)
                EditorGUI.DrawRect(r, Pro ? new Color(0.1f, 0.25f, 0.5f, 0.35f) : new Color(0.85f, 0.92f, 1f, 1f));
            GUI.Label(r, content, _trialBanner);
        }

        /// <summary>小さな色付きの状態ラベル（例: 準備完了・未選択）。</summary>
        public static void Chip(string text, Color color, string tooltip = null)
        {
            Ensure();
            var content = new GUIContent(text, tooltip);
            float w = _chip.CalcSize(content).x;
            Rect r = GUILayoutUtility.GetRect(w, 16f, GUILayout.Width(w), GUILayout.Height(16f));
            r.y += 1f;
            if (Event.current.type == EventType.Repaint)
            {
                DrawRounded(r, color);
                _chip.Draw(r, content, false, false, false, false);
            }
            if (!string.IsNullOrEmpty(tooltip)) GUI.Label(r, new GUIContent("", tooltip));
        }

        /// <summary>押せる Chip。マウスを乗せると少し明るくなり、カーソルが指の形になる。押されたら true。</summary>
        public static bool ChipButton(string text, Color color, string tooltip = null)
        {
            Ensure();
            var content = new GUIContent(text, tooltip);
            float w = _chip.CalcSize(content).x;
            Rect r = GUILayoutUtility.GetRect(w, 16f, GUILayout.Width(w), GUILayout.Height(16f));
            r.y += 1f;
            EditorGUIUtility.AddCursorRect(r, MouseCursor.Link);
            if (Event.current.type == EventType.Repaint)
            {
                bool hover = r.Contains(Event.current.mousePosition);
                DrawRounded(r, hover ? Color.Lerp(color, Color.white, 0.2f) : color);
                _chip.Draw(r, content, false, false, false, false);
            }
            return GUI.Button(r, new GUIContent("", tooltip), GUIStyle.none);
        }

        /// <summary>
        /// 「次: …」の 1 行（押せる）。行全体がボタンで、押されたら true。全文はツールチップ。
        /// </summary>
        public static bool NextStepLine(string text, string tooltip)
        {
            Ensure();
            var content = new GUIContent("次: " + text + "  ›", tooltip);
            Rect r = GUILayoutUtility.GetRect(content, _subtle, GUILayout.ExpandWidth(true), GUILayout.Height(18f));
            EditorGUIUtility.AddCursorRect(r, MouseCursor.Link);
            bool hover = r.Contains(Event.current.mousePosition);
            if (Event.current.type == EventType.Repaint)
            {
                if (hover) EditorGUI.DrawRect(r, RowHover);
                Texture icon = Icon(MessageType.Info);
                if (icon != null) GUI.DrawTexture(new Rect(r.x, r.y + 1f, 16f, 16f), icon, ScaleMode.ScaleToFit);
                Rect tr = new Rect(r.x + 18f, r.y, r.width - 18f, r.height);
                Color old = _subtle.normal.textColor;
                _subtle.normal.textColor = hover ? Text : SubText;
                _subtle.Draw(tr, new GUIContent(content.text), false, false, false, false);
                _subtle.normal.textColor = old;
            }
            return GUI.Button(r, new GUIContent("", tooltip), GUIStyle.none);
        }

        /// <summary>アイコン付きの 1 行。全文はツールチップ。</summary>
        public static void MessageLine(MessageType type, string text, string tooltip)
        {
            Ensure();
            EditorGUILayout.BeginHorizontal();
            MessageIcon(type);
            GUILayout.Label(new GUIContent(text, tooltip), type == MessageType.Warning || type == MessageType.Error ? _warnText : _subtle);
            EditorGUILayout.EndHorizontal();
        }

        public static void MessageIcon(MessageType type)
        {
            Rect r = GUILayoutUtility.GetRect(16f, 16f, GUILayout.Width(16f), GUILayout.Height(16f));
            Texture icon = Icon(type);
            if (icon != null && Event.current.type == EventType.Repaint) GUI.DrawTexture(r, icon, ScaleMode.ScaleToFit);
        }

        /// <summary>選べる 1 行（一覧の行）。選択中は強調色、マウスが乗ると薄く光る。クリックされたら true。</summary>
        public static bool SelectableRow(GUIContent content, string sub, bool selected)
        {
            Ensure();
            Rect r = GUILayoutUtility.GetRect(content, _rowLabel, GUILayout.Height(18f), GUILayout.ExpandWidth(true));
            bool clicked = GUI.Button(r, GUIContent.none, GUIStyle.none);
            if (Event.current.type == EventType.Repaint)
            {
                if (selected) EditorGUI.DrawRect(r, RowSelected);
                else if (r.Contains(Event.current.mousePosition)) EditorGUI.DrawRect(r, RowHover);
                if (selected) EditorGUI.DrawRect(new Rect(r.x, r.y, 2f, r.height), Accent);

                float subW = string.IsNullOrEmpty(sub) ? 0f : Mathf.Min(_rowSub.CalcSize(new GUIContent(sub)).x, r.width * 0.45f);
                _rowLabel.Draw(new Rect(r.x + 4f, r.y, r.width - subW - 4f, r.height), new GUIContent(content.text), false, false, false, false);
                if (subW > 0f) _rowSub.Draw(new Rect(r.xMax - subW, r.y, subW, r.height), sub, false, false, false, false);
            }
            if (!string.IsNullOrEmpty(content.tooltip)) GUI.Label(r, new GUIContent("", content.tooltip));
            return clicked;
        }

        /// <summary>色付きの大きな主ボタン（無効のときは色を付けない）。</summary>
        public static bool PrimaryButton(GUIContent content, Color color, params GUILayoutOption[] options)
        {
            Ensure();
            _primary.normal.background = GUI.enabled ? Solid(color) : null;
            _primary.hover.background = GUI.enabled ? Solid(Color.Lerp(color, Color.white, 0.15f)) : null;
            _primary.active.background = GUI.enabled ? Solid(Color.Lerp(color, Color.black, 0.15f)) : null;
            _primary.normal.textColor = GUI.enabled ? Color.white : SubText;
            GUIStyle style = GUI.enabled ? _primary : _secondary;
            return GUILayout.Button(content, style, options);
        }

        public static void HorizontalDivider(float spaceBefore = 4f, float spaceAfter = 4f)
        {
            EditorGUILayout.Space(spaceBefore);
            Rect r = GUILayoutUtility.GetRect(1f, 1f, GUILayout.ExpandWidth(true));
            if (Event.current.type == EventType.Repaint) EditorGUI.DrawRect(r, Divider);
            EditorGUILayout.Space(spaceAfter);
        }

        /// <summary>細い進み具合のバー（done / total）。</summary>
        public static void ProgressBar(int done, int total, Color color)
        {
            Rect r = GUILayoutUtility.GetRect(1f, 4f, GUILayout.ExpandWidth(true), GUILayout.Height(4f));
            if (Event.current.type != EventType.Repaint) return;
            EditorGUI.DrawRect(r, Divider);
            float t = total > 0 ? Mathf.Clamp01(done / (float)total) : 0f;
            if (t > 0f) EditorGUI.DrawRect(new Rect(r.x, r.y, r.width * t, r.height), color);
        }

        // ── 図形 ──

        /// <summary>角を 1px 落とした塗りつぶし（小さなチップ用）。</summary>
        public static void DrawRounded(Rect r, Color c)
        {
            EditorGUI.DrawRect(new Rect(r.x + 1f, r.y, r.width - 2f, r.height), c);
            EditorGUI.DrawRect(new Rect(r.x, r.y + 1f, 1f, r.height - 2f), c);
            EditorGUI.DrawRect(new Rect(r.xMax - 1f, r.y + 1f, 1f, r.height - 2f), c);
        }

        /// <summary>塗りつぶした円。</summary>
        public static void DrawDisc(Rect r, Color c)
        {
            Color old = Handles.color;
            Handles.color = c;
            Handles.DrawSolidDisc(r.center, Vector3.forward, Mathf.Min(r.width, r.height) * 0.5f);
            Handles.color = old;
        }

        /// <summary>チェックの印（2 本の線）。</summary>
        public static void DrawCheck(Rect r, Color c)
        {
            Color old = Handles.color;
            Handles.color = c;
            Vector2 a = new Vector2(r.x + r.width * 0.27f, r.y + r.height * 0.52f);
            Vector2 b = new Vector2(r.x + r.width * 0.44f, r.y + r.height * 0.70f);
            Vector2 d = new Vector2(r.x + r.width * 0.74f, r.y + r.height * 0.33f);
            Handles.DrawAAPolyLine(2.2f, a, b, d);
            Handles.color = old;
        }

        /// <summary>向き dir（画面上の上 = (0,1)）の塗りつぶした三角形。dir が 0 なら十字。</summary>
        public static void DrawArrow(Rect r, Vector2 dir, Color c)
        {
            Color old = Handles.color;
            Handles.color = c;
            Vector2 center = r.center;
            float s = Mathf.Min(r.width, r.height) * 0.22f;
            if (dir == Vector2.zero)
            {
                Handles.DrawAAPolyLine(1.6f, center + new Vector2(-s, 0f), center + new Vector2(s, 0f));
                Handles.DrawAAPolyLine(1.6f, center + new Vector2(0f, -s), center + new Vector2(0f, s));
            }
            else
            {
                // GUI 座標は y が下向き
                Vector2 f = new Vector2(dir.x, -dir.y).normalized;
                Vector2 side = new Vector2(-f.y, f.x);
                Vector3 tip = center + f * s;
                Vector3 l = center - f * s * 0.7f + side * s;
                Vector3 rr = center - f * s * 0.7f - side * s;
                Handles.DrawAAConvexPolygon(tip, l, rr);
            }
            Handles.color = old;
        }

        /// <summary>小さな丸い点（調整済み・表示中などの印）。</summary>
        public static void Dot(Rect r, Color c) => DrawDisc(r, c);
    }
}
