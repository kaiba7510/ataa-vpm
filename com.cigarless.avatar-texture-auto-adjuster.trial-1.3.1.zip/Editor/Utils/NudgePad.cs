// Assets/Cigarless/AvatarTextureAutoAdjuster/Editor/Utils/NudgePad.cs
using UnityEngine;
using UnityEditor;

namespace AvatarTextureAutoAdjuster.Editor
{
    /// <summary>
    /// 微調整 PAD（FaceMap 仕様 v0.4 §12.1、3ペイン仕様の ContinuousPad）。上下左右の十字ボタン・2 ボタンと移動量の選択。
    /// クリックで 1 ステップ動き、押したままドラッグすると移動量に応じて連続的に加減算する（ドラッグスクラブ）。
    /// 方向は画面上の見た目の方向（上向きの三角は v を増やす）。
    /// </summary>
    public static class NudgePad
    {
        public const string MakeFixStepKey = "ATAA.MakeFix.NudgeStep";
        public const string FaceMapEditorStepKey = "ATAA.FaceMapEditor.NudgeStep";

        public static readonly float[] Steps = { 0.001f, 0.005f, 0.01f, 0.05f };
        private static readonly string[] StepLabels = { "0.001", "0.005", "0.01", "0.05" };
        private const int DefaultStepIndex = 1;

        private const float ButtonSize = 22f;
        private const float Gap = 2f;


        private static GUIStyle _buttonStyle;

        // ── ドラッグスクラブ（ContinuousPad、3ペイン仕様 §3「ドラッグスクラブ操作」）──
        // ボタンは「クリックで 1 ステップの微動」に加えて、「押したままドラッグすると、移動量に応じて連続的に加減算」する。
        // 押し続けの自動連打はしない（クリック連打・長押しの負担を無くし、視線をプレビューに置いたまま手元の感覚で調整する）。

        /// <summary>ドラッグ 1 ピクセルあたりの変化量（ステップに対する比）。5 ピクセルで 1 ステップ。</summary>
        public const float ScrubPerPixel = 0.2f;

        /// <summary>1 イベントのドラッグ量の上限（ピクセル）。これを超える移動はマウスの回り込みとみなして捨てる。</summary>
        private const float MaxDragDelta = 150f;

        /// <summary>
        /// 十字ボタン（ドラッグスクラブ対応）と移動量の選択を 1 行に描く。
        /// クリックはその向きに 1 ステップ、どのボタンでも押したままドラッグするとマウスの動きに合わせて縦横に動く。
        /// 戻り値は UV の変化量（v は上向きが正）。
        /// </summary>
        public static Vector2 DrawScrubPad(string label, string stepPrefsKey, bool enabled, EditorWindow window)
        {
            EnsureStyle();
            float step = Steps[GetStepIndex(stepPrefsKey)];
            Vector2 result = Vector2.zero;

            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(new GUIContent(label, "クリックで 1 ステップ、押したままドラッグで連続して動かせます。"),
                EditorStyles.miniLabel, GUILayout.Width(EditorGUIUtility.labelWidth));

            float padSize = ButtonSize * 3f + Gap * 2f;
            Rect pad = GUILayoutUtility.GetRect(padSize, padSize, GUILayout.Width(padSize), GUILayout.Height(padSize));

            using (new EditorGUI.DisabledScope(!enabled))
            {
                float c = ButtonSize + Gap;
                result += Scrub2D(Cell(pad, 1, 0, c), "上へ", Vector2.up, step, window);
                result += Scrub2D(Cell(pad, 0, 1, c), "左へ", Vector2.left, step, window);
                result += Scrub2D(Cell(pad, 1, 1, c), "押したままドラッグで自由に動かす", Vector2.zero, step, window);
                result += Scrub2D(Cell(pad, 2, 1, c), "右へ", Vector2.right, step, window);
                result += Scrub2D(Cell(pad, 1, 2, c), "下へ", Vector2.down, step, window);
            }

            EditorGUILayout.BeginVertical();
            GUILayout.Space(ButtonSize + Gap);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("移動量", EditorStyles.miniLabel, GUILayout.Width(40f));
            int index = GetStepIndex(stepPrefsKey);
            int next = EditorGUILayout.Popup(index, StepLabels, GUILayout.Width(64f));
            if (next != index) EditorPrefs.SetInt(stepPrefsKey, next);
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndVertical();

            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            return result;
        }

        /// <summary>
        /// 2 つのボタン（ドラッグスクラブ対応）を 1 行に描く。クリックで ∓1 ステップ、どちらかを押したまま横にドラッグすると
        /// 右で増え・左で減る。戻り値は「ステップ数」（ステップの倍数。呼び出し側で量に直す）。
        /// </summary>
        public static float DrawScrubTwo(string label, string minusText, string plusText, string minusTip, string plusTip,
                                         bool enabled, EditorWindow window)
        {
            EnsureStyle();
            float steps = 0f;
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(new GUIContent(label, "クリックで 1 ステップ、押したまま左右にドラッグで連続して変えられます。"),
                EditorStyles.miniLabel, GUILayout.Width(EditorGUIUtility.labelWidth));

            float width = Mathf.Max(ButtonSize, _buttonStyle.CalcSize(new GUIContent(minusText)).x + 8f,
                                    _buttonStyle.CalcSize(new GUIContent(plusText)).x + 8f);
            Rect row = GUILayoutUtility.GetRect(width * 2f + Gap, ButtonSize,
                                                GUILayout.Width(width * 2f + Gap), GUILayout.Height(ButtonSize));
            using (new EditorGUI.DisabledScope(!enabled))
            {
                steps += Scrub1D(new Rect(row.x, row.y, width, ButtonSize), minusText, minusTip, -1f, window);
                steps += Scrub1D(new Rect(row.x + width + Gap, row.y, width, ButtonSize), plusText, plusTip, 1f, window);
            }

            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            return steps;
        }

        /// <summary>移動量の選択で選んでいるステップ（UV）。</summary>
        public static float CurrentStep(string stepPrefsKey) => Steps[GetStepIndex(stepPrefsKey)];

        /// <summary>十字の 1 ボタン。向きは文字ではなく三角形（中央は十字）で描く。tip はツールチップ。</summary>
        private static Vector2 Scrub2D(Rect r, string tip, Vector2 clickDir, float step, EditorWindow window)
        {
            // 上下のボタンは上下だけ、左右のボタンは左右だけ動く（中央のボタンは自由に動く）。カーソルも動く向きに合わせる
            MouseCursor cursor = clickDir == Vector2.zero ? MouseCursor.MoveArrow
                : Mathf.Abs(clickDir.y) > Mathf.Abs(clickDir.x) ? MouseCursor.ResizeVertical
                : MouseCursor.ResizeHorizontal;
            bool active = ScrubControl(r, new GUIContent("", tip), out bool pressed, out Vector2 drag, cursor);
            if (Event.current.type == EventType.Repaint)
            {
                Color c = EditorStyles.label.normal.textColor;
                if (!GUI.enabled) c.a *= 0.4f;
                MakeFixGui.DrawArrow(r, clickDir, c);
            }
            if (!active) return Vector2.zero;
            if (window != null) window.Repaint();
            Vector2 v = pressed ? clickDir * step : Vector2.zero;
            // 画面の下向きは v の負の向き
            Vector2 d = new Vector2(drag.x, -drag.y);
            if (clickDir != Vector2.zero) d = Vector2.Dot(d, clickDir) * clickDir;
            return v + d * (step * ScrubPerPixel);
        }

        private static float Scrub1D(Rect r, string text, string tip, float clickSign, EditorWindow window)
        {
            if (!ScrubControl(r, new GUIContent(text, tip), out bool pressed, out Vector2 drag)) return 0f;
            if (window != null) window.Repaint();
            return (pressed ? clickSign : 0f) + drag.x * ScrubPerPixel;
        }

        /// <summary>
        /// ドラッグスクラブのボタン。押している間 true。pressed は押し始めたイベントだけ true、
        /// drag はこのイベントでのマウスの移動量（ピクセル）。ドラッグ中はマウスが画面端で反対側へ回り込む。
        /// </summary>
        public static bool ScrubControl(Rect r, GUIContent content, out bool pressed, out Vector2 drag)
            => ScrubControl(r, content, out pressed, out drag, MouseCursor.SlideArrow);

        /// <summary>ScrubControl の、ボタンの上でのカーソルを指定する版。</summary>
        public static bool ScrubControl(Rect r, GUIContent content, out bool pressed, out Vector2 drag, MouseCursor cursor)
        {
            EnsureStyle();
            int id = GUIUtility.GetControlID(FocusType.Passive);
            string key = KeyOf(content);
            Event e = Event.current;
            pressed = false;
            drag = Vector2.zero;
            AdoptIfShifted(id, key);

            if (GUI.enabled) EditorGUIUtility.AddCursorRect(r, cursor);

            // ID がずれて、押したボタンの古い ID がこのボタンに当たっただけなら、押されていない扱い（押下は本来のボタンが引き継ぐ）
            if (IsForeignHold(id, key))
            {
                if (e.type == EventType.Repaint)
                {
                    _buttonStyle.Draw(r, content, r.Contains(e.mousePosition), false, false, false);
                    if (!string.IsNullOrEmpty(content.tooltip)) GUI.Label(r, new GUIContent("", content.tooltip));
                }
                return false;
            }

            // 押している間に、このボタンより前のコントロールが増減して ID がずれても、ボタンを離せば必ず解放する
            // （解放されないと hotControl が残り、ウィンドウのほかのボタン・PAD が効かなくなる）
            if (ReleaseIfStale(e, id)) return false;

            switch (e.GetTypeForControl(id))
            {
                case EventType.MouseDown:
                    if (GUI.enabled && e.button == 0 && r.Contains(e.mousePosition))
                    {
                        GUIUtility.hotControl = id;
                        _heldId = id;
                        _heldKey = key;
                        EditorGUIUtility.SetWantsMouseJumping(1);
                        pressed = true;
                        e.Use();
                    }
                    break;
                case EventType.MouseUp:
                    if (GUIUtility.hotControl == id)
                    {
                        GUIUtility.hotControl = 0;
                        _heldId = 0;
                        EditorGUIUtility.SetWantsMouseJumping(0);
                        e.Use();
                    }
                    break;
                case EventType.MouseDrag:
                    if (GUIUtility.hotControl == id)
                    {
                        // ペンタブレット（絶対座標）・リモートデスクトップなどでは、画面端の回り込み（マウスジャンプ）の後に
                        // 回り込んだ分の大きな移動量が届くことがあるので、1 イベントで飛びすぎた移動は捨てる
                        if (e.delta.sqrMagnitude <= MaxDragDelta * MaxDragDelta) drag = e.delta;
                        e.Use();
                    }
                    break;
                case EventType.Repaint:
                    _buttonStyle.Draw(r, content, r.Contains(e.mousePosition), GUIUtility.hotControl == id, false, false);
                    if (!string.IsNullOrEmpty(content.tooltip)) GUI.Label(r, new GUIContent("", content.tooltip));
                    break;
            }

            if (GUIUtility.hotControl == id && !GUI.enabled)
            {
                GUIUtility.hotControl = 0;
                _heldId = 0;
                EditorGUIUtility.SetWantsMouseJumping(0);
                pressed = false;
                drag = Vector2.zero;
            }
            return GUIUtility.hotControl == id || pressed;
        }

        // 押しているボタン（ScrubControl・HoldControl）の ID と、ボタンを見分けるキー（文字とツールチップ）。0 なら押していない
        private static int _heldId;
        private static string _heldKey;

        private static string KeyOf(GUIContent content) => content.text + "|" + content.tooltip;

        /// <summary>
        /// 押している間に、このボタンより前のコントロール（中央ペインの警告の行のボタンなど）が増減して ID がずれたとき、
        /// 同じキーのボタンが押下を引き継ぐ（ドラッグがそのまま続き、離せば解放される）。
        /// </summary>
        private static void AdoptIfShifted(int id, string key)
        {
            if (_heldId == 0 || _heldId == id || GUIUtility.hotControl != _heldId || key != _heldKey) return;
            GUIUtility.hotControl = id;
            _heldId = id;
        }

        /// <summary>
        /// このボタンの ID が押下中の ID と同じだが、押したのは別のボタン（文字・ツールチップが違う）か。
        /// 押している間に前のコントロール（中央ペインの警告の行のボタンなど）が増えて ID がずれると、押したボタンの古い ID が
        /// 前にある別のボタンに当たる。これを自分の押下とみなすと、押していないボタンが動く
        /// （左右の間隔を狭めると、位置 PAD の「上」が押された見た目になり、ドラッグで上下に動く、など）。
        /// 押下は、後で描かれる本来のボタンが AdoptIfShifted で引き継ぐ。
        /// </summary>
        private static bool IsForeignHold(int id, string key) =>
            _heldId != 0 && _heldId == id && GUIUtility.hotControl == id && key != _heldKey;

        /// <summary>
        /// 自分が押したボタンの ID（_heldId）がまだ hotControl なのに、このコントロールの ID と違う（途中で ID がずれた）とき、
        /// マウスを離したら解放する。解放したら true。
        /// </summary>
        private static bool ReleaseIfStale(Event e, int id)
        {
            if (_heldId == 0 || GUIUtility.hotControl != _heldId || _heldId == id) return false;
            if (e.rawType != EventType.MouseUp) return false;
            GUIUtility.hotControl = 0;
            _heldId = 0;
            EditorGUIUtility.SetWantsMouseJumping(0);
            e.Use();
            return true;
        }

        private static void EnsureStyle()
        {
            if (_buttonStyle == null)
            {
                _buttonStyle = new GUIStyle(GUI.skin.button)
                {
                    padding = new RectOffset(0, 0, 0, 0),
                    fontSize = 10,
                    alignment = TextAnchor.MiddleCenter
                };
            }
        }

        private static int GetStepIndex(string key)
        {
            int i = EditorPrefs.GetInt(key, DefaultStepIndex);
            return i >= 0 && i < Steps.Length ? i : DefaultStepIndex;
        }

        private static Rect Cell(Rect pad, int col, int row, float pitch)
        {
            return new Rect(pad.x + col * pitch, pad.y + row * pitch, ButtonSize, ButtonSize);
        }

        /// <summary>
        /// 押している間だけ true を返すボタン（IMGUI の hotControl で押下を追う）。
        /// pressed は、このイベントで押し始めたときだけ true。押している間に無効になったら離した扱いにする。
        /// style が null なら GUI.skin.button で描く。
        /// </summary>
        public static bool HoldControl(Rect r, GUIContent content, GUIStyle style, out bool pressed)
        {
            if (style == null) style = GUI.skin.button;
            int id = GUIUtility.GetControlID(FocusType.Passive);
            string key = KeyOf(content);
            Event e = Event.current;
            pressed = false;
            AdoptIfShifted(id, key);
            if (IsForeignHold(id, key))
            {
                if (e.type == EventType.Repaint)
                {
                    style.Draw(r, content, r.Contains(e.mousePosition), false, false, false);
                    if (!string.IsNullOrEmpty(content.tooltip)) GUI.Label(r, new GUIContent("", content.tooltip));
                }
                return false;
            }
            if (ReleaseIfStale(e, id)) return false;

            switch (e.GetTypeForControl(id))
            {
                case EventType.MouseDown:
                    if (GUI.enabled && e.button == 0 && r.Contains(e.mousePosition))
                    {
                        GUIUtility.hotControl = id;
                        _heldId = id;
                        _heldKey = key;
                        pressed = true;
                        e.Use();
                    }
                    break;
                case EventType.MouseUp:
                    if (GUIUtility.hotControl == id)
                    {
                        GUIUtility.hotControl = 0;
                        _heldId = 0;
                        e.Use();
                    }
                    break;
                case EventType.MouseDrag:
                    if (GUIUtility.hotControl == id) e.Use();
                    break;
                case EventType.Repaint:
                    bool active = GUIUtility.hotControl == id;
                    style.Draw(r, content, r.Contains(e.mousePosition), active, false, false);
                    if (!string.IsNullOrEmpty(content.tooltip)) GUI.Label(r, new GUIContent("", content.tooltip));
                    break;
            }

            if (GUIUtility.hotControl == id && !GUI.enabled)
            {
                // 押している間に無効になった（選択解除など）
                GUIUtility.hotControl = 0;
                _heldId = 0;
                pressed = false;
            }
            return GUIUtility.hotControl == id;
        }
    }
}
