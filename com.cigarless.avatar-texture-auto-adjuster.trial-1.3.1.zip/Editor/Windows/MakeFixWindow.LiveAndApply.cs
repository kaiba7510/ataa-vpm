using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── ライブプレビューの同期（§13.6）──

        /// <summary>表示する条件を満たしていれば付け（同じなら何もしない）、満たさなければ外す。</summary>
        private void SyncLive()
        {
            if (_live == null) return;
            bool wasAttached = _live.IsAttached;
            SyncLiveCore();
            if (wasAttached != _live.IsAttached) _orbit?.MarkDirty();
        }

        private void SyncLiveCore()
        {
            bool can = LiveEnabled && _liveOk && !_applying && _showPreview
                       && !EditorApplication.isPlayingOrWillChangePlaymode;
            Texture activeOutput = ActivePreviewOutput;
            bool ready = activeOutput != null;
            // 比較（メイク前）は「調整を表示」・準備チェックに関係なく出す。
            // OFF でも、適用済みならアバターのマテリアルはメイク後なので、メイク前を一時的に表示しないと比べられない
            GameObject avatar = _state.TargetAvatar;
            bool canCompare = _comparing && _showPreview && !_applying
                              && avatar != null && !EditorUtility.IsPersistent(avatar)
                              && !EditorApplication.isPlayingOrWillChangePlaymode;

            int shown = 0;
            if (canCompare)
            {
                // 比較中は、最初の顔テクスチャを表示する（適用済みでも、メイク前の見た目にする）
                shown = _live.Show(_state.TargetAvatar, _state.PreviewAvatarTexture, _state.PreviewAvatarTexture);
            }
            else if (can && ready && !_comparing)
            {
                shown = _live.Show(_state.TargetAvatar, _state.PreviewAvatarTexture, activeOutput);
            }
            else
            {
                _live.Detach();
            }

            // ON なのに表示できていないときの理由（ツールバーの状態表示のツールチップ）
            _liveReason =
                !LiveEnabled ? null
                : EditorApplication.isPlayingOrWillChangePlaymode ? "再生中は表示しません。"
                : _applying ? "適用中です。"
                : !_showPreview ? "メイク元とアバター基準の組み合わせがまだ選ばれていない（または使えない）ため、表示できません。"
                : !_liveOk ? "準備チェックに終わっていない項目があるため、表示できません（左のアバター管理の項目を確かめてください）。"
                : !_comparing && !ready ? "プレビューを作成中です。"
                : shown == 0 ? "シーンのアバターに、顔テクスチャを使うマテリアルが見つからないため、表示できません。"
                : null;
        }

        // 「調整を表示」が ON なのに表示できていない理由。表示できている・OFF なら null
        private string _liveReason;

        /// <summary>
        /// 「調整を表示」の横の状態表示。今シーンのアバターに何が出ているかを、色の点と短い文で示す
        /// （緑: 調整中のメイクを表示中 / 橙: 比較中・ON なのに表示できていない / 灰: OFF で元の見た目）。
        /// </summary>
        private void DrawLiveStatus()
        {
            bool attached = _live != null && _live.IsAttached;
            string text;
            string tip;
            Color color;
            if (attached && _comparing)
            {
                text = "比較中（メイク前）";
                tip = "「比較」を押している間は、シーンのアバターにメイク前の顔テクスチャを表示しています。";
                color = MakeFixGui.Warning;
            }
            else if (attached)
            {
                text = "シーンに表示中";
                tip = "調整中のメイクを、シーンのアバター（と 3D 顔ビュー）に表示しています。まだ適用・保存はされていません。";
                color = MakeFixGui.Success;
            }
            else if (LiveEnabled)
            {
                text = "表示できていません";
                tip = _liveReason ?? "表示の準備をしています。";
                color = MakeFixGui.Warning;
            }
            else
            {
                text = "シーンは元のまま";
                tip = "「調整を表示」が OFF のため、シーンのアバターは元の見た目です。";
                color = MakeFixGui.Muted;
            }

            Rect r = GUILayoutUtility.GetRect(112f, 18f, GUILayout.Width(112f), GUILayout.ExpandHeight(true));
            if (Event.current.type != EventType.Repaint) return;
            MakeFixGui.Dot(new Rect(r.x + 4f, r.center.y - 3.5f, 7f, 7f), color);
            GUI.Label(new Rect(r.x + 14f, r.y, r.width - 14f, r.height), new GUIContent(text, tip), EditorStyles.miniLabel);
        }

        /// <summary>
        /// メイクを適用する。await の続きは EditorMainThreadContext（EditorApplication.update で回る）で受け取る。
        /// Unity 標準の同期コンテキストはエディターのアイドル中に回らないことがあり、適用が「適用中...」のまま終わらなかった。
        /// </summary>
        private void ApplyMakeup()
        {
            using (EditorMainThreadContext.Instance.Enter())
            {
                ApplyMakeupCore();
            }
        }

        private async void ApplyMakeupCore()
        {
            // 適用の前に外し、終わったら付け直す（適用後の複製マテリアルのスロットにも同じ規則で付ける）
            _applying = true;
            _live?.Detach();
            // 適用を始めた時点の結果を覚える（適用中に調整を変えたら「適用後に変更あり」になる）。
            // 一時データ（ドラフト）が適用中に実ファイルへ昇格した場合だけはパスを昇格後に揃える。
            int startRevision = _outputRevision;
            string startMakeupPath = _state.MakeupFaceMapPath;
            string startAvatarPath = _state.AvatarFaceMapPath;
            bool startMakeupDraft = FaceMapStorage.IsDraft(startMakeupPath);
            bool startAvatarDraft = FaceMapStorage.IsDraft(startAvatarPath);
            int startMakeupTexId = _state.PreviewMakeupTexture != null ? _state.PreviewMakeupTexture.GetInstanceID() : 0;
            int startAvatarTexId = _state.PreviewAvatarTexture != null ? _state.PreviewAvatarTexture.GetInstanceID() : 0;
            int startOpacityKey = Mathf.RoundToInt(_state.PreviewMakeupOpacity * 1000f);
            int avatarId = _state.TargetAvatar != null ? _state.TargetAvatar.GetInstanceID() : 0;
            string generated = null;
            try
            {
                generated = await _toolService.ApplyMakeupAsync();
                if (generated != null)
                {
                    string appliedMakeupPath = MakeFixUnsavedGuard.ResolveAppliedPath(startMakeupPath, _state.MakeupFaceMapPath, startMakeupDraft);
                    string appliedAvatarPath = MakeFixUnsavedGuard.ResolveAppliedPath(startAvatarPath, _state.AvatarFaceMapPath, startAvatarDraft);
                    _appliedFingerprint = FormatOutputFingerprint(
                        startRevision, appliedMakeupPath, appliedAvatarPath,
                        startMakeupTexId, startAvatarTexId, startOpacityKey);
                    _appliedAvatarId = avatarId;
                    _appliedTexturePath = generated;
                }
            }
            finally
            {
                _applying = false;
                // 適用の待ち中にウィンドウが閉じられたら、破棄済みのウィンドウからプレビューを付け直さない
                if (this != null)
                {
                    _slotsDirty = true;
                    SyncLive();
                    if (generated != null) Notify("メイクを適用しました");
                    // 閉じる前の確認で「保存」を選んだ: 適用できたら閉じる（できなければ開いたまま、理由を見せる）
                    if (_closeAfterApply)
                    {
                        _closeAfterApply = false;
                        if (generated != null)
                        {
                            hasUnsavedChanges = false;
                            EditorApplication.delayCall += () => { if (this != null) Close(); };
                        }
                    }
                    // アバター切り替え前の確認で「適用して切り替え」を選んだ: 適用できたら切り替える
                    if (_switchAfterApply)
                    {
                        bool hadTarget = !ReferenceEquals(_pendingSwitchAvatar, null);
                        GameObject nextAvatar = _pendingSwitchAvatar;
                        _switchAfterApply = false;
                        _pendingSwitchAvatar = null;
                        if (generated != null && (!hadTarget || nextAvatar != null))
                        {
                            _state.TargetAvatar = nextAvatar;
                            GUI.FocusControl(null);
                        }
                    }
                    // UI Toolkit の表示（ボタン・状態表示・準備チェック）は MarkUiDirty で作り直す
                    MarkUiDirty();
                    Repaint();
                }
            }
        }

        /// <summary>
        /// 適用を解除。マテリアルを元に戻し、戻せたら「調整を表示」を OFF にして、シーンと 3D 顔ビューを元の見た目にする（§13.6）。
        /// ON のままだと、元のマテリアルのスロットにすぐ調整中のメイクが付け直され、見た目が何も変わらず「解除できない」ように見えた。
        /// </summary>
        private void RevertMakeup()
        {
            // 複製マテリアルのスロットに付けた一時表示を外してから戻す
            _live?.Detach();
            int reverted = _toolService.RevertMakeup();
            if (reverted > 0 && LiveEnabled)
            {
                LiveEnabled = false;
                _state.Warning += "\n「調整を表示」を OFF にしました（シーンは元の見た目です）。ON に戻すと、調整中のメイクをまた表示します。";
            }
            if (reverted > 0) Notify("適用を解除しました（元の見た目）");
            _appliedFingerprint = null;
            _appliedTexturePath = null;
            _slotsDirty = true;
            SyncLive();
            Repaint();
        }

        /// <summary>生成したテクスチャを Project ウィンドウで選択し、押せたことをこのウィンドウにも知らせる。</summary>
        private void LocateAppliedTexture()
        {
            var asset = string.IsNullOrEmpty(_appliedTexturePath)
                ? null
                : AssetDatabase.LoadAssetAtPath<Texture2D>(_appliedTexturePath);
            if (asset != null)
            {
                EditorGUIUtility.PingObject(asset);
                Selection.activeObject = asset;
            }
            ShowNotification(new GUIContent(MakeFixLocateFeedback.Message(_appliedTexturePath, asset != null)), 2.5);
        }

        // ── 適用の状態 ──

        /// <summary>プレビューを作り直す印を付ける。結果が変わったので、適用済みとの比較用の番号も進める。</summary>
        private void InvalidatePreview()
        {
            _previewDirty = true;
            _outputRevision++;
            MarkUiDirty();
        }

        /// <summary>適用したときと今とで、結果が同じかを比べるための指紋（調整・組み合わせ・テクスチャ・メイクの濃さ）。</summary>
        private string OutputFingerprint()
        {
            Texture2D makeupTex = _state.PreviewMakeupTexture;
            Texture2D avatarTex = _state.PreviewAvatarTexture;
            return FormatOutputFingerprint(
                _outputRevision,
                _state.MakeupFaceMapPath ?? "",
                _state.AvatarFaceMapPath ?? "",
                makeupTex != null ? makeupTex.GetInstanceID() : 0,
                avatarTex != null ? avatarTex.GetInstanceID() : 0,
                Mathf.RoundToInt(_state.PreviewMakeupOpacity * 1000f));
        }

        private static string FormatOutputFingerprint(
            int revision, string makeupPath, string avatarPath, int makeupTexId, int avatarTexId, int opacityKey)
        {
            return string.Join("|", revision, makeupPath ?? "", avatarPath ?? "", makeupTexId, avatarTexId, opacityKey);
        }

        /// <summary>
        /// 対象アバターの適用の状態。このウィンドウを開く前に適用したもの（どの調整で適用したか分からない）は「適用済み」とみなす。
        /// </summary>
        private ApplyState CurrentApplyState()
        {
            if (!_hasAppliedSlots) return ApplyState.None;
            int avatarId = _state.TargetAvatar != null ? _state.TargetAvatar.GetInstanceID() : 0;
            if (_appliedFingerprint == null || avatarId != _appliedAvatarId) return ApplyState.Current;
            return _appliedFingerprint == OutputFingerprint() ? ApplyState.Current : ApplyState.Stale;
        }

        /// <summary>適用バーの「次にやること」の位置に出す 1 行（体験版。製品版は DrawApplyStatusBanner）。</summary>
        private void DrawApplyStateLine()
        {
            MakeFixGui.MessageLine(MessageType.Info, "体験版はプレビューで確かめるところまでです",
                "プレビューは一時的な表示で、アバターのマテリアルは変わりません。\n" +
                "合成したテクスチャの書き出しと、顔のマテリアルへの適用は製品版で行えます。");
        }
        /// <summary>
        /// 適用ボタンのすぐ上に出す、適用の状態の大きな帯（未適用・適用済み・調整の変更は未反映）。
        /// ビューの左上のバッジだけでは、適用・解除したことに気付きにくかったため。
        /// </summary>
        private void DrawApplyStatusBanner()
        {
            ApplyState state = CurrentApplyState();
            bool known = _appliedTexturePath != null;
            bool previewing = _live != null && _live.IsAttached && !_comparing;
            string title, sub, tip;
            Color color;
            switch (state)
            {
                case ApplyState.Current:
                    title = "メイク適用済み";
                    sub = known ? System.IO.Path.GetFileName(_appliedTexturePath) : "このウィンドウを開く前に適用したメイク";
                    tip = "アバターの顔のマテリアルは、メイクを合成したものに差し替わっています。\n" +
                          (known ? _appliedTexturePath + "\n" : "") + "元に戻すのは「適用を解除」です。";
                    color = MakeFixGui.Success;
                    break;
                case ApplyState.Stale:
                    title = "適用済み・調整の変更は未反映";
                    sub = "「メイク適用」で今の調整を反映します";
                    tip = "アバターに適用されているのは、前に適用したときの結果です。" +
                          (previewing ? "\nシーンに映っているのは調整中の結果（プレビュー）です。" : "");
                    color = MakeFixGui.Warning;
                    break;
                default:
                    title = "未適用";
                    sub = previewing
                        ? "シーンの表示はプレビューです（閉じると元に戻ります）"
                        : "アバターにメイクは適用されていません";
                    tip = "アバターのマテリアルはまだ変わっていません。\n" +
                          "「メイク適用」を押すと、合成したテクスチャを作り（FaceMaps/Generated）、顔のマテリアルを差し替えます。";
                    color = previewing ? MakeFixGui.Accent : MakeFixGui.Muted;
                    break;
            }

            Rect r = GUILayoutUtility.GetRect(1f, 40f, GUILayout.ExpandWidth(true), GUILayout.Height(40f));
            bool showLocate = state == ApplyState.Current && known;
            float buttonW = showLocate ? 72f : 0f;
            if (Event.current.type == EventType.Repaint)
            {
                MakeFixGui.DrawRounded(r, new Color(color.r, color.g, color.b, EditorGUIUtility.isProSkin ? 0.22f : 0.16f));
                EditorGUI.DrawRect(new Rect(r.x, r.y, 4f, r.height), color);
                MakeFixGui.Dot(new Rect(r.x + 12f, r.y + 9f, 10f, 10f), color);
            }
            BannerTitleStyle.normal.textColor = MakeFixGui.Text;
            BannerSubStyle.normal.textColor = MakeFixGui.SubText;
            float textW = r.width - 30f - buttonW - 6f;
            GUI.Label(new Rect(r.x + 28f, r.y + 3f, textW, 18f), new GUIContent(title, tip), BannerTitleStyle);
            GUI.Label(new Rect(r.x + 28f, r.y + 21f, textW, 16f), new GUIContent(sub, tip), BannerSubStyle);

            if (showLocate &&
                GUI.Button(new Rect(r.xMax - buttonW - 6f, r.center.y - 9f, buttonW, 18f),
                    new GUIContent("場所を表示", "生成したテクスチャを Project ウィンドウで選択します。"), EditorStyles.miniButton))
            {
                LocateAppliedTexture();
            }
        }

        private static GUIStyle _bannerTitleStyle;
        private static GUIStyle BannerTitleStyle => _bannerTitleStyle ?? (_bannerTitleStyle =
            new GUIStyle(EditorStyles.boldLabel) { fontSize = 13, alignment = TextAnchor.MiddleLeft, clipping = TextClipping.Clip });

        private static GUIStyle _bannerSubStyle;
        private static GUIStyle BannerSubStyle => _bannerSubStyle ?? (_bannerSubStyle =
            new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleLeft, clipping = TextClipping.Clip });

        // ── 閉じる前の確認 ──
        // 「調整を表示」で映しているのは一時的な表示なので、ウィンドウを閉じると消える。未適用（または変更が未反映）のまま
        // 閉じようとしたら、Unity の「未保存の変更」の確認（FaceMap エディターと同じ仕組み）で知らせる。
        // 「保存」はメイク適用。適用は非同期なので、その場では閉じず（base.SaveChanges を呼ばない）、適用が済んだら閉じる。

        [System.NonSerialized] private bool _closeAfterApply;
        [System.NonSerialized] private bool _switchAfterApply;
        [System.NonSerialized] private GameObject _pendingSwitchAvatar;

        private bool ShouldConfirmAvatarSwitch(GameObject nextAvatar)
        {
            ApplyState state = CurrentApplyState();
            return MakeFixUnsavedGuard.ShouldConfirmAvatarSwitch(
                isTrial: AtaaCore.Edition == CoreEdition.Trial,
                applying: _applying,
                isPlaying: EditorApplication.isPlayingOrWillChangePlaymode,
                hasCurrentAvatar: _state.TargetAvatar != null,
                isDifferentAvatar: !ReferenceEquals(nextAvatar, _state.TargetAvatar),
                allOk: _allOk,
                liveAttached: _live != null && _live.IsAttached,
                isCurrentApplied: state == ApplyState.Current);
        }

        /// <summary>閉じる前に確認するか（hasUnsavedChanges）と、その文面を今の状態に合わせる。OnGUI の最初に呼ぶ。</summary>
        private void UpdateUnsavedState()
        {
            ApplyState state = CurrentApplyState();
            bool unsaved = MakeFixUnsavedGuard.IsUnsaved(
                isTrial: AtaaCore.Edition == CoreEdition.Trial,
                applying: _applying,
                allOk: _allOk,
                liveAttached: _live != null && _live.IsAttached,
                isCurrentApplied: state == ApplyState.Current);
            if (unsaved)
                saveChangesMessage = MakeFixUnsavedGuard.CloseDialogMessage(state == ApplyState.Stale);
            hasUnsavedChanges = unsaved;
        }

        /// <summary>このウィンドウと Scene ビューに、大きな通知を数秒出す（適用・解除したことを見落とさないように）。</summary>
        private void Notify(string message)
        {
            var content = new GUIContent(message);
            ShowNotification(content, 2.5);
            SceneView.lastActiveSceneView?.ShowNotification(content, 2.5);
        }

        public override void SaveChanges()
        {
            // base を呼ばない（hasUnsavedChanges が残る）ので、ウィンドウは閉じない。適用が済んだら ApplyMakeup が閉じる
            if (_applying || !_allOk || EditorApplication.isPlayingOrWillChangePlaymode) return;
            _switchAfterApply = false;
            _pendingSwitchAvatar = null;
            _closeAfterApply = true;
            ApplyMakeup();
        }

        /// <summary>
        /// ビューの左上に出す状態のバッジ。いまビューに映っているものが、プレビュー（未適用）・適用済み・元の見た目のどれかを示す。
        /// </summary>
        /// <param name="showingResult">このビューに調整中の結果が映っているか（3D: ライブプレビュー中、2D: 「結果」表示）。</param>
        /// <returns>バッジの下端の y（その下に別の表示を置くため）。</returns>
        private float DrawViewStateBadge(Rect area, bool showingResult)
        {
            ApplyState apply = CurrentApplyState();
            string text, tip;
            Color color;
            if (_comparing && _showPreview)
            {
                text = "比較中：メイク前";
                tip = "「比較」を押している間は、メイク前の顔テクスチャを表示しています。";
                color = MakeFixGui.Warning;
            }
            else if (showingResult)
            {
                switch (apply)
                {
                    case ApplyState.Current:
                        text = "適用済み";
                        tip = "アバターにメイクが適用されています。映っているのは調整中の結果で、適用した内容と同じです。";
                        color = MakeFixGui.Success;
                        break;
                    case ApplyState.Stale:
                        text = "プレビュー中（変更は未適用）";
                        tip = "適用した後に調整を変えました。映っているのは調整中の結果で、アバターにはまだ反映されていません。\n" +
                              "「メイク適用」で反映します。";
                        color = MakeFixGui.Warning;
                        break;
                    default:
                        if (Core.AtaaCore.Edition == Core.CoreEdition.Trial)
                        {
                            MakeFixTrialPreview.StatusInfo info =
                                MakeFixTrialPreview.StatusPill(IsTrialHighResActive, TrialHighOutputReady);
                            text = info.Text;
                            tip = info.Tooltip;
                        }
                        else
                        {
                            text = "プレビュー中（未適用）";
                            tip = "調整中の結果を一時的に表示しています。アバターのマテリアルはまだ変わっていません。\n" +
                                  "調整が終わったら、右下の「メイク適用」で確定します。";
                        }
                        color = MakeFixGui.Accent;
                        break;
                }
            }
            else
            {
                string why = !LiveEnabled ? "「調整を表示」が OFF のため、調整中の結果は映していません。"
                    : _liveReason ?? "調整中の結果はまだ映せません。";
                switch (apply)
                {
                    case ApplyState.Current:
                        text = "適用済み";
                        tip = why + "\n映っているのは、アバターに適用したメイクです。";
                        color = MakeFixGui.Success;
                        break;
                    case ApplyState.Stale:
                        text = "適用済み（調整の変更は未反映）";
                        tip = why + "\n映っているのは前に適用したメイクです。調整の変更は「メイク適用」で反映します。";
                        color = MakeFixGui.Warning;
                        break;
                    default:
                        text = "元の見た目";
                        tip = why + "\nアバターにはメイクが適用されていません。";
                        color = MakeFixGui.Muted;
                        break;
                }
            }

            var content = new GUIContent(text, tip);
            GUIStyle style = BadgeStyle;
            Vector2 size = style.CalcSize(new GUIContent(text));
            var r = new Rect(area.x + 8f, area.y + 8f, size.x + 26f, 24f);
            if (Event.current.type == EventType.Repaint)
            {
                MakeFixGui.DrawRounded(r, new Color(0f, 0f, 0f, 0.6f));
                MakeFixGui.DrawRounded(new Rect(r.x, r.y, 4f, r.height), color);
                MakeFixGui.Dot(new Rect(r.x + 10f, r.center.y - 4f, 8f, 8f), color);
            }
            GUI.Label(new Rect(r.x + 22f, r.y, r.width - 22f, r.height), content, style);
            return r.yMax;
        }

        private static GUIStyle _badgeStyle;
        private static GUIStyle BadgeStyle => _badgeStyle ?? (_badgeStyle = new GUIStyle(EditorStyles.whiteBoldLabel)
        {
            alignment = TextAnchor.MiddleLeft,
            normal = { textColor = Color.white }
        });
    }
}
