using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MyVrcToolFaceMapEditorWindow
    {
        // ── 左: テクスチャビュー（描画と操作は IMGUIContainer、上に重ねる案内は UI Toolkit）──

        private const string ShowAxisPrefsKey = "ATAA.FaceMapEditor.ShowAxis";

        /// <summary>上と左の U/V 定規の太さ。テクスチャはその内側に描く。</summary>
        private const float RulerSize = 24f;

        private static readonly float[] RulerTicks = { 0f, 0.25f, 0.5f, 0.75f, 1f };

        private IMGUIContainer _viewImgui;
        private VisualElement _stage;
        private VisualElement _dropCard;
        private VisualElement _guideU, _guideV;
        private VisualElement _rulerU, _rulerV;
        private readonly List<Label> _ticksU = new List<Label>();
        private readonly List<Label> _ticksV = new List<Label>();
        private Label _lblZoom;
        private Toggle _toggleAxis;
        private VisualElement _selChip, _selChipDot;
        private Label _lblSelName, _lblSelUv;
        private bool _rulersDirty = true;

        private Rect _areaRect;
        private Rect _texRect;

        // ── テクスチャビューの拡大・移動 ──
        private const float MinZoom = 1f;
        private const float MaxZoom = 8f;
        private const float ZoomStep = 1.15f;
        private float _zoom = 1f;
        private Vector2 _pan;
        private bool _panning;
        private Texture2D _zoomTexture;

        /// <summary>対称軸（中心線とつまみ）を表示するか。表示だけの設定で、FaceMap には保存しない。</summary>
        private bool _showAxis = true;

        private static GUIStyle _labelStyle;
        private static GUIStyle _attrStyle;
        private static GUIStyle _tipStyle;

        private void BindViewportUi()
        {
            _stage = _root.Q<VisualElement>("fm-stage");
            _viewImgui = _root.Q<IMGUIContainer>("fm-view-imgui");
            _viewImgui.onGUIHandler = OnViewGUI;
            _viewImgui.focusable = true;
            _viewImgui.RegisterCallback<PointerLeaveEvent>(_ =>
            {
                if (!_vm.IsHovering) return;
                _vm.IsHovering = false;
                _hoverDirty = true;
                _viewImgui.MarkDirtyRepaint();
            });
            _dropCard = _root.Q<VisualElement>("drop-card");
            _guideU = _root.Q<VisualElement>("guide-u");
            _guideV = _root.Q<VisualElement>("guide-v");
            _rulerU = _root.Q<VisualElement>("ruler-u");
            _rulerV = _root.Q<VisualElement>("ruler-v");
            _lblZoom = _root.Q<Label>("lbl-zoom");
            _lblZoom.tooltip = "倍率（全体表示が 100%）。ホイールで拡大・縮小します。";
            _toggleAxis = _root.Q<Toggle>("toggle-axis");
            _toggleAxis.tooltip = "左右対称の中心線（とつまみ）をテクスチャに重ねて表示します。表示だけの設定です。";
            _selChip = _root.Q<VisualElement>("sel-chip");
            _selChipDot = _root.Q<VisualElement>("sel-chip-dot");
            _lblSelName = _root.Q<Label>("lbl-sel-name");
            _lblSelUv = _root.Q<Label>("lbl-sel-uv");

            _ticksU.Clear();
            _ticksV.Clear();
            foreach (float t in RulerTicks)
            {
                bool center = Mathf.Approximately(t, 0.5f);
                var u = new Label(center ? "0.50 [CENTER]" : t.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture))
                    { pickingMode = PickingMode.Ignore };
                u.AddToClassList("fm-ruler-tick");
                u.AddToClassList("fm-ruler-tick--u");
                if (center) u.AddToClassList("fm-ruler-tick--center");
                _rulerU.Add(u);
                _ticksU.Add(u);

                var v = new Label(t.ToString(t == 0.25f || t == 0.75f ? "0.00" : "0.0", System.Globalization.CultureInfo.InvariantCulture))
                    { pickingMode = PickingMode.Ignore };
                v.AddToClassList("fm-ruler-tick");
                v.AddToClassList("fm-ruler-tick--v");
                if (center) v.AddToClassList("fm-ruler-tick--center");
                _rulerV.Add(v);
                _ticksV.Add(v);
            }

            _root.Q<Button>("btn-fit").clicked += () =>
            {
                ResetZoom();
                MarkUiDirty();
            };
            _toggleAxis.SetValueWithoutNotify(_showAxis);
            _toggleAxis.RegisterValueChangedCallback(evt =>
            {
                _showAxis = evt.newValue;
                EditorPrefs.SetBool(ShowAxisPrefsKey, _showAxis);
                MarkUiDirty();
            });

            _root.Q<Button>("btn-pick-texture").clicked += PickTextureFromFile;
            _root.Q<Button>("btn-card-load").clicked += () =>
            {
                _vm.Load();
                MarkUiDirty();
            };

            // テクスチャのドラッグ＆ドロップ（背景表示のみ。FaceMap には保存されない）。ドロップカードの上でも、テクスチャの上でも受ける
            _stage.RegisterCallback<DragUpdatedEvent>(_ =>
            {
                bool ok = DraggedTexture() != null || MakeupTextureImporter.FindDraggedImagePath(DragAndDrop.paths) != null;
                DragAndDrop.visualMode = ok ? DragAndDropVisualMode.Copy : DragAndDropVisualMode.Rejected;
                _dropCard.EnableInClassList("fm-drop-card--hover", ok);
            });
            _stage.RegisterCallback<DragLeaveEvent>(_ => _dropCard.RemoveFromClassList("fm-drop-card--hover"));
            _stage.RegisterCallback<DragExitedEvent>(_ => _dropCard.RemoveFromClassList("fm-drop-card--hover"));
            _stage.RegisterCallback<DragPerformEvent>(_ =>
            {
                _dropCard.RemoveFromClassList("fm-drop-card--hover");
                Texture2D dropped = DraggedTexture();
                if (dropped != null)
                {
                    DragAndDrop.AcceptDrag();
                    SetTexture(dropped);
                    return;
                }
                string filePath = MakeupTextureImporter.FindDraggedImagePath(DragAndDrop.paths);
                if (filePath != null)
                {
                    DragAndDrop.AcceptDrag();
                    ApplyImportedTexture(MakeupTextureImporter.ImportOrLoad(filePath));
                }
            });

            _stage.RegisterCallback<GeometryChangedEvent>(_ => _rulersDirty = true);
        }

        private static Texture2D DraggedTexture()
        {
            foreach (Object obj in DragAndDrop.objectReferences)
            {
                if (obj is Texture2D tex) return tex;
            }
            return null;
        }

        private void SetTexture(Texture2D tex, bool isTransient = false)
        {
            if (_transientTexture != null && !ReferenceEquals(_transientTexture, tex))
                DisposeTransientTexture();
            if (isTransient) _transientTexture = tex;

            _vm.State.Texture = tex;
            ResetZoom();
            _viewImgui.Focus();
            MarkUiDirty();
        }

        private void ApplyImportedTexture(MakeupTextureImporter.LoadResult result)
        {
            if (result.Canceled) return;
            if (!string.IsNullOrEmpty(result.Error) || result.Texture == null)
            {
                _vm.State.Warning = result.Error ?? "画像を読み込めませんでした。";
                _vm.State.WarningType = MessageType.Warning;
                MarkUiDirty();
                return;
            }
            SetTexture(result.Texture, result.IsTransient);
            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                if (result.IsTransient)
                {
                    _vm.State.Warning = "外部の顔画像をプレビュー用に読み込みました（ファイル保存なし）。";
                    _vm.State.WarningType = MessageType.Info;
                }
            }
            else if (result.Imported)
            {
                _vm.State.Warning = "メイク画像をインポートしました: " + result.AssetPath;
                _vm.State.WarningType = MessageType.Info;
            }
        }

        /// <summary>ドロップカードの［テクスチャを選択］。プロジェクト内外の画像ファイルを選ぶ（外部は自動インポート／体験版はメモリ読込）。</summary>
        private void PickTextureFromFile()
        {
            ApplyImportedTexture(MakeupTextureImporter.OpenFileDialog("顔テクスチャを選択"));
        }

        private void RefreshViewportUi()
        {
            _dropCard.EnableInClassList("hidden", !FaceMapEditorUi.ShowDropCard(_hasTexture));
            _lblZoom.text = FaceMapEditorUi.ZoomText(_zoom);
            _toggleAxis.SetValueWithoutNotify(_showAxis);

            int sel = _vm.SelectedPoint;
            bool hasSel = sel >= 0 && sel < _vm.State.Points.Count;
            _selChip.EnableInClassList("hidden", !hasSel);
            if (hasSel)
            {
                FaceMapPoint p = _vm.State.Points[sel];
                _lblSelName.text = FaceIllustrationPalette.ShortName(p.Label);
                _lblSelUv.text = FaceMapEditorUi.UvText(p.Uv);
                _selChipDot.style.backgroundColor = FaceMapTextureRenderer.GetLabelColor(p.Label);
            }
            UpdateRulers();
        }

        /// <summary>定規の目盛りと中央のガイドを、いまのテクスチャの位置（ズーム・パン込み）に合わせる。</summary>
        private void UpdateRulers()
        {
            _rulersDirty = false;
            if (_stage == null) return;
            Rect stage = _stage.contentRect;
            if (float.IsNaN(stage.width) || stage.width <= 0f) return;

            var clipU = new Rect(RulerSize, 0f, stage.width - RulerSize, stage.height);
            var clipV = new Rect(0f, RulerSize, stage.width, stage.height - RulerSize);
            for (int i = 0; i < RulerTicks.Length; i++)
            {
                float? x = FaceMapEditorUi.RulerX(RulerTicks[i], _texRect, clipU);
                _ticksU[i].EnableInClassList("hidden", !x.HasValue);
                if (x.HasValue)
                {
                    _ticksU[i].style.left = x.Value;
                    _ticksU[i].style.translate = new Translate(Length.Percent(RulerTicks[i] >= 1f ? -100f : RulerTicks[i] <= 0f ? 0f : -50f), 0f);
                }

                float? y = FaceMapEditorUi.RulerY(RulerTicks[i], _texRect, clipV);
                _ticksV[i].EnableInClassList("hidden", !y.HasValue);
                if (y.HasValue)
                {
                    // 左の定規は stage の上から RulerSize ずれている
                    _ticksV[i].style.top = y.Value - RulerSize;
                    _ticksV[i].style.translate = new Translate(0f, Length.Percent(RulerTicks[i] >= 1f ? 0f : RulerTicks[i] <= 0f ? -100f : -50f));
                }
            }

            // 中央のガイド（テクスチャが無いときだけ。テクスチャがあるときは対称軸の線が代わりになる）
            float? gx = FaceMapEditorUi.RulerX(0.5f, _texRect, clipU);
            float? gy = FaceMapEditorUi.RulerY(0.5f, _texRect, clipV);
            _guideU.EnableInClassList("hidden", _hasTexture || !gx.HasValue);
            _guideV.EnableInClassList("hidden", _hasTexture || !gy.HasValue);
            if (gx.HasValue) _guideU.style.left = gx.Value;
            if (gy.HasValue) _guideV.style.top = gy.Value;
        }

        private void RepaintView()
        {
            _viewImgui?.MarkDirtyRepaint();
            _uiDirty = true;
        }

        private void InitStyles()
        {
            if (_labelStyle == null)
            {
                _labelStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    alignment = TextAnchor.MiddleCenter,
                    normal = { textColor = Color.white }
                };
            }
            if (_attrStyle == null)
            {
                _attrStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    alignment = TextAnchor.UpperLeft,
                    normal = { textColor = Color.white }
                };
            }
            if (_tipStyle == null)
            {
                _tipStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    alignment = TextAnchor.MiddleLeft,
                    wordWrap = false,
                    padding = new RectOffset(6, 6, 3, 3),
                    normal = { textColor = Color.white }
                };
            }
        }

        /// <summary>テクスチャビューの IMGUI（描画とマウス操作）。座標は fm-stage と同じ（左上が原点）。</summary>
        private void OnViewGUI()
        {
            InitStyles();
            Event e = Event.current;
            if (e.type == EventType.Layout) UpdateTarget();

            Texture2D current = _vm.State.Texture;
            if (current != _zoomTexture)
            {
                // テクスチャを入れ替えたら 100% に戻す（§12.6）
                _zoomTexture = current;
                _zoom = 1f;
                _pan = Vector2.zero;
                _uiDirty = true;
            }

            Rect full = _viewImgui.contentRect;
            _areaRect = new Rect(RulerSize, RulerSize, Mathf.Max(1f, full.width - RulerSize), Mathf.Max(1f, full.height - RulerSize));
            Rect tex = TexRect(_areaRect);
            if (tex != _texRect)
            {
                _texRect = tex;
                _rulersDirty = true;
            }

            ProcessTextureViewEvents();

            if (e.type == EventType.Repaint)
            {
                int hoverIndex = (_vm.IsHovering && !_vm.IsDraggingControlPoint)
                    ? _vm.FindNearPoint(_vm.HoverUV, _texRect)
                    : -1;

                // 拡大中はビューの外にはみ出す部分を DrawPanel が切り取る（§12.6）
                FaceMapTextureRenderer.DrawPanel(
                    _areaRect, _texRect, _vm.State.Texture,
                    _vm.State.Points, _vm.State.Sizes,
                    _vm.SelectedPoint, hoverIndex,
                    _vm.HoverUV, _vm.IsHovering, _targetText,
                    _labelStyle, _attrStyle, _tipStyle,
                    _vm.PointerScale,
                    AxisVisible ? _vm.State.CenterX : null,
                    _vm.OverlayVisible ? _vm.OverlayAlpha : 0f,
                    _vm.ActiveCheckLabels(),
                    _vm.State.EyeLine, _vm.State.EyeLowerLine, _vm.State.MouthLine,
                    _vm.State.MouthLinePoints, _vm.State.EyeContourUpper, _vm.State.EyeContourLower);
            }

            if (e.type == EventType.Repaint && _vm.State.Texture != null) AddResizeCursorRects();
        }

        /// <summary>中心線を描き、つまみをつかめるか（左右対称が ON で中心が決まっていて、対称軸表示が ON）。</summary>
        private bool AxisVisible => _showAxis && _vm.MirrorActive;

        private Rect TexRect(Rect area)
        {
            Texture2D tex = _vm.State.Texture;
            Rect fit = tex != null && tex.height > 0 ? UVCoordinateConverter.FitRect(area, (float)tex.width / tex.height) : area;
            float w = fit.width * _zoom, h = fit.height * _zoom;
            Vector2 c = fit.center + _pan;
            return new Rect(c.x - w * 0.5f, c.y - h * 0.5f, w, h);
        }

        private void ResetZoom()
        {
            _zoom = 1f;
            _pan = Vector2.zero;
            RepaintView();
        }

        /// <summary>
        /// テクスチャビューのイベント。左クリック（配置・選択・移動・拡縮）と、中/右ドラッグ（パン）・ホイール（ズーム）を
        /// ボタンで厳密に分け、パンしようとして誤って配置する事故を防ぐ。
        /// </summary>
        private void ProcessTextureViewEvents()
        {
            Event e = Event.current;
            Texture2D tex = _vm.State.Texture;
            bool inView = _areaRect.Contains(e.mousePosition);

            switch (e.type)
            {
                case EventType.MouseMove:
                case EventType.MouseDrag:
                case EventType.MouseDown:
                case EventType.MouseUp:
                    bool hovering = tex != null && mouseOverWindow == this && inView && _texRect.Contains(e.mousePosition) && !_panning;
                    if (hovering != _vm.IsHovering) _hoverDirty = true;
                    _vm.IsHovering = hovering;
                    if (hovering)
                    {
                        _vm.HoverUV = UVCoordinateConverter.ScreenToUv(e.mousePosition, _texRect);
                        _hoverDirty = true;
                    }
                    break;
                case EventType.MouseLeaveWindow:
                    _vm.IsHovering = false;
                    _hoverDirty = true;
                    _viewImgui.MarkDirtyRepaint();
                    break;
            }

            if (e.type == EventType.MouseMove) _viewImgui.MarkDirtyRepaint();

            if (tex == null) return;

            // ── ズーム・パン（中/右ボタン・ホイール）──
            if (e.type == EventType.ScrollWheel && inView)
            {
                ZoomAt(e.mousePosition, e.delta.y < 0f ? ZoomStep : 1f / ZoomStep);
                e.Use();
                return;
            }
            if (e.type == EventType.MouseDown && (e.button == 1 || e.button == 2) && inView)
            {
                if (e.button == 2 && e.clickCount == 2) ResetZoom();
                else _panning = true;
                e.Use();
                return;
            }
            if (_panning)
            {
                if (e.type == EventType.MouseDrag)
                {
                    if (_zoom > MinZoom)
                    {
                        _pan = ClampPan(_pan + e.delta);
                        RepaintView();
                    }
                    e.Use();
                }
                else if (e.rawType == EventType.MouseUp && e.button != 0)
                {
                    _panning = false;
                    e.Use();
                }
                return;
            }

            // ── 左クリック: 配置・選択・移動・拡縮 ──
            if (e.type == EventType.MouseDown && e.button == 0 && inView)
            {
                if (_texRect.Contains(e.mousePosition))
                {
                    Vector2 uv = UVCoordinateConverter.ScreenToUv(e.mousePosition, _texRect);

                    // 入力欄のフォーカスを外す（このあと矢印キーで選択中の領域を動かせるように）
                    GUIUtility.keyboardControl = 0;
                    _viewImgui.Focus();

                    int sel = _vm.SelectedPoint;
                    bool hasSel = sel >= 0 && sel < _vm.State.Points.Count;
                    Vector2? handle = hasSel ? ResizeHandleAt(sel, e.mousePosition) : null;
                    // 優先順位: 四隅 → 目の線・口の線のつまみ（右辺の中点と重なりやすい）→ 辺の中点
                    bool onKnob = hasSel &&
                                  (IsOnEyeLineKnob(sel, e.mousePosition, _vm.State.EyeLine) ||
                                   IsOnEyeLineKnob(sel, e.mousePosition, _vm.State.EyeLowerLine) ||
                                   IsOnMouthLineKnob(sel, e.mousePosition));
                    // 目の輪郭の点のつまみ（目頭・目尻は辺の中点と重なりやすいので、四隅の次に見る）
                    EyeContourEditing.Handle contourHandle = default;
                    bool onContour = hasSel && TryGetEyeContourHandle(sel, e.mousePosition, out contourHandle);
                    if (handle.HasValue && (FaceMapResizeMath.IsCorner(handle.Value) || !(onKnob || onContour)))
                    {
                        _vm.StartResize(sel, handle.Value, e.shift, e.alt);
                    }
                    else if (onContour)
                    {
                        _vm.StartEyeContourDrag(sel, contourHandle.OnUpper, contourHandle.Index);
                    }
                    else if (sel >= 0 && sel < _vm.State.Points.Count && IsOnEyeLineKnob(sel, e.mousePosition, _vm.State.EyeLine))
                    {
                        _vm.StartEyeLineDrag(sel);
                    }
                    else if (sel >= 0 && sel < _vm.State.Points.Count && IsOnEyeLineKnob(sel, e.mousePosition, _vm.State.EyeLowerLine))
                    {
                        _vm.StartEyeLowerLineDrag(sel);
                    }
                    else if (sel >= 0 && sel < _vm.State.Points.Count && IsOnMouthLineKnob(sel, e.mousePosition))
                    {
                        _vm.StartMouthLineDrag(sel);
                    }
                    else
                    {
                        // 優先順位: 選択中のハンドル・目の線のつまみ → 最も近い中心点 → 中心線のつまみ → 案内中のパーツを置く → 枠の内側 → 選択解除
                        int nearIdx = _vm.FindNearPoint(uv, _texRect);
                        int regionIdx = _vm.FindRegionAt(uv);
                        if (nearIdx >= 0)
                        {
                            _vm.StartDrag(nearIdx, e.alt);
                        }
                        else if (AxisVisible &&
                                 FaceMapTextureRenderer.IsOnCenterKnob(_areaRect, _texRect, _vm.State.CenterX.Value, e.mousePosition, _vm.PointerScale))
                        {
                            _vm.StartCenterDrag();
                        }
                        else if (_vm.TargetEntry != null && (regionIdx < 0 || !string.IsNullOrEmpty(_vm.ArmedLabel) || _vm.WizardStep > 0))
                        {
                            _vm.TryPlaceTarget(uv, e.alt);
                        }
                        else if (regionIdx >= 0)
                        {
                            // 枠の内側をつかんで移動（中心がマウスへ飛ばない）
                            _vm.StartDrag(regionIdx, uv, e.alt);
                        }
                        else
                        {
                            _vm.ClearSelection();
                        }
                    }

                    GUI.FocusControl(null);
                    e.Use();
                    MarkUiDirty();
                }
            }
            else if (e.type == EventType.MouseDrag && e.button == 0 && _vm.IsDraggingControlPoint)
            {
                _vm.DragTo(UVCoordinateConverter.ScreenToUv(e.mousePosition, _texRect));
                e.Use();
                MarkUiDirty();
            }
            else if (e.rawType == EventType.MouseUp && e.button == 0 && _vm.IsDraggingControlPoint)
            {
                _vm.EndDrag();
                e.Use();
                MarkUiDirty();
            }
        }

        /// <summary>カーソル位置の UV が動かないように拡大・縮小する。</summary>
        private void ZoomAt(Vector2 mouse, float factor)
        {
            if (!ViewportMath.TryZoomAt(FitRect(), _texRect, _zoom, _pan, mouse, factor, out float zoom, out Vector2 pan)) return;

            _zoom = zoom;
            _pan = pan;
            _texRect = TexRect(_areaRect);
            _rulersDirty = true;
            RepaintView();
        }

        private Rect FitRect()
        {
            Texture2D tex = _vm.State.Texture;
            return tex != null && tex.height > 0 ? UVCoordinateConverter.FitRect(_areaRect, (float)tex.width / tex.height) : _areaRect;
        }

        private Vector2 ClampPan(Vector2 pan) => ViewportMath.ClampPan(FitRect(), _zoom, pan);

        /// <summary>選択中の目の、目の線（または目の下の線）のつまみの上か（v0.4 §4.2）。</summary>
        private bool IsOnEyeLineKnob(int index, Vector2 mouse, float? line)
        {
            FaceMapPoint p = _vm.State.Points[index];
            if (!line.HasValue || FaceTemplate.CategoryOf(p.Label) != FaceMapFile.EyeCategory) return false;
            return FaceMapTextureRenderer.IsOnEyeLineKnob(_texRect, p, _vm.Service.GetSize(FaceMapFile.EyeCategory),
                line.Value, mouse, _vm.PointerScale);
        }

        /// <summary>選択中の口の、口の線のつまみの上か。</summary>
        /// <summary>選択中の目の領域で、mouse の下にある目の輪郭の点のつまみ（無ければ false）。</summary>
        private bool TryGetEyeContourHandle(int index, Vector2 mouse, out EyeContourEditing.Handle handle)
        {
            handle = default;
            Vector2[] upper = _vm.State.EyeContourUpper, lower = _vm.State.EyeContourLower;
            if (upper == null || lower == null || index < 0 || index >= _vm.State.Points.Count) return false;
            FaceMapPoint p = _vm.State.Points[index];
            if (FaceTemplate.CategoryOf(p.Label) != FaceMapFile.EyeCategory) return false;
            Rect region = FaceMapTextureRenderer.RegionScreenRect(_texRect, p.Uv, _vm.Service.GetSize(FaceMapFile.EyeCategory));
            bool innerAtMax = EyeContourEditing.InnerAtMax(p.Label);
            EyeContourEditing.Handle[] handles = EyeContourEditing.Handles(upper, lower);
            var screen = new Vector2[handles.Length];
            for (int i = 0; i < handles.Length; i++)
                screen[i] = EyeContourEditing.LocalToScreen(region, EyeContourEditing.HandlePoint(upper, lower, handles[i]), innerAtMax);
            int hit = EyeContourEditing.HitHandle(screen, mouse, FaceMapTextureRenderer.ScaledHandleHitRadius(_vm.PointerScale));
            if (hit < 0) return false;
            handle = handles[hit];
            return true;
        }

        private bool IsOnMouthLineKnob(int index, Vector2 mouse)
        {
            FaceMapPoint p = _vm.State.Points[index];
            if (!_vm.State.MouthLine.HasValue || FaceTemplate.CategoryOf(p.Label) != FaceMapFile.MouthCategory) return false;
            return FaceMapTextureRenderer.IsOnEyeLineKnob(_texRect, p, _vm.Service.GetSize(FaceMapFile.MouthCategory),
                _vm.State.MouthLine.Value, mouse, _vm.PointerScale);
        }

        /// <summary>選択中の領域の、mouse の下にあるサイズ変更ハンドルの向き（四隅・辺の中点）。なければ null。</summary>
        private Vector2? ResizeHandleAt(int index, Vector2 mouse)
        {
            FaceMapPoint p = _vm.State.Points[index];
            string category = FaceTemplate.CategoryOf(p.Label);
            if (category == null) return null;

            return FaceMapTextureRenderer.HitResizeHandle(_texRect, p, _vm.Service.GetSize(category), mouse, _vm.PointerScale);
        }

        /// <summary>選択中の領域のハンドルの上に、動く向きのカーソルを出す。</summary>
        private void AddResizeCursorRects()
        {
            int sel = _vm.SelectedPoint;
            if (sel < 0 || sel >= _vm.State.Points.Count) return;
            FaceMapPoint p = _vm.State.Points[sel];
            string category = FaceTemplate.CategoryOf(p.Label);
            if (category == null) return;

            Rect region = FaceMapTextureRenderer.RegionScreenRect(_texRect, p.Uv, _vm.Service.GetSize(category));
            float r = FaceMapTextureRenderer.ScaledHandleHitRadius(_vm.PointerScale);
            foreach (Vector2 h in FaceMapTextureRenderer.HandlePositions(region))
                AddResizeCursorRect(h, r, p, category);
            foreach (Vector2 h in FaceMapTextureRenderer.EdgeHandlePositions(region))
                AddResizeCursorRect(h, r, p, category);
        }

        private void AddResizeCursorRect(Vector2 h, float r, FaceMapPoint p, string category)
        {
            // 小さい枠で重なるときも、実際につかむハンドルと同じ向きを出す
            Vector2? sign = FaceMapTextureRenderer.HitResizeHandle(_texRect, p, _vm.Service.GetSize(category), h, _vm.PointerScale);
            if (!sign.HasValue) return;
            var rect = Rect.MinMaxRect(h.x - r, h.y - r, h.x + r, h.y + r);
            rect = Rect.MinMaxRect(Mathf.Max(rect.xMin, _areaRect.xMin), Mathf.Max(rect.yMin, _areaRect.yMin),
                                   Mathf.Min(rect.xMax, _areaRect.xMax), Mathf.Min(rect.yMax, _areaRect.yMax));
            if (rect.width <= 0f || rect.height <= 0f) return;
            EditorGUIUtility.AddCursorRect(rect, FaceMapResizeMath.CursorFor(sign.Value));
        }
    }
}
