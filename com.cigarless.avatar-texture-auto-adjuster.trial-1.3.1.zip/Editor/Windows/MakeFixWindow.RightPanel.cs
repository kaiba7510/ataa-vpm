using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── 右ペイン: フィッティング調整（3ペイン仕様 §3）──

        private void DrawRightPanel()
        {
            // ExitGUI（ボタンで構造が変わるとき）を try/finally で包まない。
            // finally で EndVertical すると、Unity が「EndLayoutGroup: BeginLayoutGroup must be called first」を出す
            EditorGUILayout.BeginVertical(MakeFixGui.Pane, GUILayout.Width(RightPanelWidth), GUILayout.ExpandHeight(true));
            float oldLabelWidth = EditorGUIUtility.labelWidth;

            MakeFixGui.PaneHeader("フィッティング調整", "メイク元を選び、パーツごとに位置と大きさを合わせます");
            _rightScroll = EditorGUILayout.BeginScrollView(_rightScroll);

            DrawMakeupSource();

            if (!_showPreview)
            {
                // ⑥ まだ調整できないので、見出しと 1 行だけ
                MakeFixGui.BeginCard("調整", null, 6, MakeFixGui.StepState.Pending);
                MakeFixGui.MessageLine(MessageType.Info, "①〜⑤が揃うと、ここで調整できます", null);
                EndFocusCard(FocusCard.Parts);
            }
            else
            {
                FaceMapAdjustment adj = _state.Adjustment;

                DrawPartSelector(adj);
                DrawEditLayer(adj);

                if (_editTarget == FaceMapFile.EyeCategory)
                    DrawEyeSettings(adj);
                else if (_editTarget == FaceMapFile.MouthCategory)
                    DrawMouthSettings(adj);

                MakeFixGui.BeginCard("仕上げ", "メイクの濃さ・肌色と、メイクを乗せる範囲。");
                EditorGUIUtility.labelWidth = 100f;
                _state.PreviewMakeupOpacity = EditorGUILayout.Slider("メイクの濃さ", _state.PreviewMakeupOpacity, 0f, 1f);
                DrawSkinToneToggle(adj);
                EditorGUILayout.Space(2);
                DrawMaskSettings(adj);
                MakeFixGui.EndCard();
            }

            EditorGUILayout.EndScrollView();
            EditorGUIUtility.labelWidth = oldLabelWidth;

            DrawApplyBar();

            EditorGUILayout.EndVertical();
        }

        /// <summary>
        /// 右ペインの下端に固定した「メイク適用」「適用を解除」の大きなボタン（スクロールしても見失わない）。
        /// 上には準備の進み具合のバーと、次にやることの 1 行。「メイク適用」「適用を解除」はここだけに置く。
        /// </summary>
        /// <summary>済んだステップの数（①〜⑥。カードのステップ番号の緑と同じ判定）。</summary>
        private int CountDoneSteps()
        {
            bool avatar = ItemsOk(3);
            int n = 0;
            if (avatar) n++;                                   // ① アバター
            if (avatar && _state.FaceRenderer != null) n++;    // ② 顔メッシュ
            if (ItemsOk(2)) n++;                               // ③ アバター基準
            if (ItemsOk(4, 6)) n++;                            // ④ 顔テクスチャ
            if (ItemsOk(1, 5)) n++;                            // ⑤ メイク元
            if (_allOk) n++;                                   // ⑥ 調整（対応付け・合成するパーツ）
            return n;
        }

        private const int TotalSteps = 6;

        private void DrawApplyBar()
        {
            MakeFixGui.HorizontalDivider(2f, 4f);

            // 進み具合は、カードのステップ（①〜⑥）の数で数える（カードの番号と揃える）
            int done = _allOk ? TotalSteps : CountDoneSteps();
            ReadinessItem firstFailed = NextItem();

            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(new GUIContent(_allOk ? "準備完了" : $"ステップ  {done} / {TotalSteps}",
                "①アバター ②顔メッシュ ③アバター基準 ④顔テクスチャ ⑤メイク元 ⑥調整"), EditorStyles.miniBoldLabel);
            GUILayout.FlexibleSpace();
            if (_applying) GUILayout.Label("適用中...", MakeFixGui.Subtle);
            EditorGUILayout.EndHorizontal();
            MakeFixGui.ProgressBar(done, TotalSteps, _allOk ? MakeFixGui.Success : MakeFixGui.Accent);
            EditorGUILayout.Space(3);

            // 警告そのものは各カードに出す。ここは「次にやること」だけを、押すとそのカードへ移動する 1 行で
            if (!_allOk && firstFailed != null)
            {
                bool canFocus = CardFor(firstFailed) != FocusCard.None;
                string tip = firstFailed.Detail + (canFocus ? "\n押すとその項目へ移動します。" : "");
                if (MakeFixGui.NextStepLine(firstFailed.Message, tip) && canFocus)
                    FocusReadinessItem(firstFailed);
            }
            else if (_allOk && AtaaCore.Edition == CoreEdition.Trial)
            {
                DrawApplyStateLine();
            }

            EditorGUILayout.Space(2);
            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                // 体験版は適用できない。押せない理由をボタンとツールチップで示す
                using (new EditorGUI.DisabledScope(true))
                {
                    MakeFixGui.PrimaryButton(new GUIContent("メイク適用（製品版のみ）",
                        "体験版では、調整した結果をプレビューで確かめるところまで使えます。\n" +
                        "合成したテクスチャの書き出しと、顔のマテリアルへの適用は製品版で行えます。"), MakeFixGui.Success);
                }
                return;
            }

            // 適用済みかどうかは、ボタンのすぐ上に大きく出す（ビューのバッジだけでは気付きにくい）
            if (_state.TargetAvatar != null)
            {
                DrawApplyStatusBanner();
                EditorGUILayout.Space(3);
            }
            EditorGUILayout.BeginHorizontal();
            using (new EditorGUI.DisabledScope(!_allOk || _applying))
            {
                string tip = firstFailed != null ? firstFailed.Message : "合成したテクスチャを作り、顔のマテリアルに適用します。";
                if (MakeFixGui.PrimaryButton(new GUIContent(_applying ? "適用中..." : "メイク適用", tip), MakeFixGui.Success))
                {
                    ApplyMakeup();
                    GUIUtility.ExitGUI();
                }
            }
            using (new EditorGUI.DisabledScope(_state.TargetAvatar == null || _applying))
            {
                if (GUILayout.Button(new GUIContent("適用を解除",
                            "メイクを適用したマテリアルを外し、アバターを元のマテリアルに戻します。\n" +
                            "調整した値はそのまま残ります（調整を戻すのは「調整をすべてリセット」です）。"),
                        MakeFixGui.SecondaryButton, GUILayout.Width(96f)))
                {
                    RevertMakeup();
                    GUIUtility.ExitGUI();
                }
            }
            EditorGUILayout.EndHorizontal();
        }

        /// <summary>メイク元（メイク基準の FaceMap と顔テクスチャ）と、足りないものの 1 行表示。</summary>
        private void DrawMakeupSource()
        {
            // ⑤ 済んだかどうかはステップ番号の色で示す（「選択済み／未選択」の札は出さない）
            MakeFixGui.BeginCard("メイク元", "写したいメイクの FaceMap と、そのときの顔テクスチャ。", 5,
                StepStateOf(FocusCard.MakeupSource, ItemsOk(1, 5)));

            EditorGUIUtility.labelWidth = 96f;
            _state.MakeupFaceMapPath = DrawFaceMapPopup("メイク基準", _state.MakeupFaceMapPath);
            DrawNotesLine(_makeupNotes);
            EditorGUILayout.Space(2);
            EditorGUILayout.BeginHorizontal();
            _state.PreviewMakeupTexture = (Texture2D)EditorGUILayout.ObjectField(
                _state.PreviewMakeupTexture, typeof(Texture2D), false,
                GUILayout.Width(48f), GUILayout.Height(48f));
            EditorGUILayout.BeginVertical();
            GUILayout.Label(new GUIContent("メイクテクスチャ",
                "メイク元の FaceMap を作ったときの顔テクスチャ（またはメイクだけの透過画像）。"), MakeFixGui.Subtle);
            Texture2D makeupTex = _state.PreviewMakeupTexture;
            GUILayout.Label(makeupTex != null ? makeupTex.name : "未選択",
                makeupTex != null ? MakeFixGui.RowLabel : MakeFixGui.Subtle);
            GUILayout.Label(makeupTex != null ? $"{makeupTex.width} x {makeupTex.height}" : "ドラッグ＆ドロップ、またはクリックで選択",
                MakeFixGui.Subtle);
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();

            if (_validMaps.Count == 0 && !_state.IsScanning)
            {
                DrawWarnLine("使える FaceMap がありません",
                    AtaaCore.Edition == CoreEdition.Trial
                        ? "「FaceMap エディター」で作成し、「一時保存」を押してください（体験版はメモリに保存します）。"
                        : "「FaceMap エディター」で作成するか、FaceMaps フォルダに JSON を置いてください。",
                    "FaceMap エディター", () => MyVrcToolFaceMapEditorWindow.ShowWindow());
            }

            if (_invalidMaps.Count > 0)
            {
                EditorGUILayout.BeginHorizontal();
                MakeFixGui.MessageIcon(MessageType.Warning);
                GUILayout.Label($"読み込めない FaceMap が {_invalidMaps.Count} 個", MakeFixGui.WarnText);
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(_showInvalidDetail ? "閉じる" : "詳細", EditorStyles.miniButton, GUILayout.Width(50f)))
                {
                    _showInvalidDetail = !_showInvalidDetail;
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();

                if (_showInvalidDetail)
                {
                    foreach (FaceMapMeta m in _invalidMaps)
                    {
                        string errors = string.Join(" / ", m.Errors);
                        GUILayout.Label(new GUIContent($"  {m.FileName}: {errors}", errors), _statusStyle);
                    }
                }
            }

            // このカードで選ぶもの（1: メイク基準、5: メイクテクスチャ）だけを 1 行で（§13.7）。
            // 左ペインの項目はそれぞれのカードに出す（同じ警告を何か所にも出さない）
            ReadinessItem missing = FirstFailedOf(1, 5);
            if (missing != null) DrawProblemLine(missing);
            EndFocusCard(FocusCard.MakeupSource);
        }

        /// <summary>指定した番号の項目のうち、最初の ✗。</summary>
        private ReadinessItem FirstFailedOf(params int[] numbers)
        {
            foreach (ReadinessItem it in _readiness)
            {
                if (!it.Ok && System.Array.IndexOf(numbers, it.Number) >= 0) return it;
            }
            return null;
        }

        private static GUIStyle[] _partChipStyles, _partChipOffStyles;

        private static GUIStyle PartChipStyle(int index, int count, bool enabled)
        {
            if (_partChipStyles == null)
            {
                GUIStyle[] bases = { EditorStyles.miniButton, EditorStyles.miniButtonLeft, EditorStyles.miniButtonMid, EditorStyles.miniButtonRight };
                _partChipStyles = new GUIStyle[bases.Length];
                _partChipOffStyles = new GUIStyle[bases.Length];
                for (int i = 0; i < bases.Length; i++)
                {
                    _partChipStyles[i] = new GUIStyle(bases[i]) { fixedHeight = 22f, fontSize = 11 };
                    _partChipOffStyles[i] = new GUIStyle(_partChipStyles[i]);
                    _partChipOffStyles[i].normal.textColor = _partChipOffStyles[i].onNormal.textColor = MakeFixGui.Muted;
                    _partChipOffStyles[i].hover.textColor = _partChipOffStyles[i].onHover.textColor = MakeFixGui.Muted;
                }
            }
            int kind = count <= 1 ? 0 : index == 0 ? 1 : index == count - 1 ? 3 : 2;
            return enabled ? _partChipStyles[kind] : _partChipOffStyles[kind];
        }

        /// <summary>
        /// 調整対象パーツの選択（全体 / 目 / 鼻 / 口 / 頬 / 顎）と、選択中のパーツの合成 ON/OFF・状態。
        /// パーツはボタンの並び。調整済みのパーツは右上に点、合成しない（OFF）パーツは灰色の取り消し線で示す。
        /// </summary>
        private void DrawPartSelector(FaceMapAdjustment adj)
        {

            // 見出しの右端に「調整をすべてリセット」（⑥でした調整をまとめてやり直す。メイクの濃さは対象外）
            MakeFixGui.BeginCardWithHeader("調整するパーツ", "選んだパーツ（全体なら顔全体）の位置・大きさを下で調整します。", 6,
                StepStateOf(FocusCard.Parts, _allOk));
            using (new EditorGUI.DisabledScope(adj.IsIdentity || _previewDrag != PreviewDrag.None))
            {
                if (GUILayout.Button(new GUIContent("調整をすべてリセット",
                            "この組み合わせの調整をすべて自動の状態に戻します。\n" +
                            "対象: 全体・各パーツの位置・大きさ・回転・左右の間隔、合成する ON/OFF、目の調整、口の曲がり、合成範囲・肌色合わせ。\n" +
                            "メイクの濃さと、適用済みのマテリアルは変わりません（適用を外すのは「適用を解除」です）。"),
                        EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                {
                    if (EditorUtility.DisplayDialog("調整をすべてリセット",
                            "位置・大きさ・目や口の調整・合成範囲など、この組み合わせの調整をすべて自動の状態に戻しますか？\n（メイクの濃さは変わりません）",
                            "リセットする", "キャンセル"))
                    {
                        adj.Reset();
                        MarkAdjustmentChanged();
                    }
                    GUIUtility.ExitGUI();
                }
            }
            MakeFixGui.EndCardHeader();

            int count = _categories.Count + 1;
            Rect row = GUILayoutUtility.GetRect(10f, 22f, GUILayout.ExpandWidth(true), GUILayout.Height(22f));
            float w = row.width / count;
            for (int i = 0; i < count; i++)
            {
                string c = i == 0 ? null : _categories[i - 1];
                string name = c ?? AllTargetName;
                bool enabled = c == null || adj.IsEnabled(c);
                FaceMapTransform t = c == null ? adj.Global : adj.FindPart(c);
                bool adjusted = (t != null && !t.IsIdentity) || (c == FaceMapFile.EyeCategory && adj.HasEyeAdjustment) ||
                                (c == FaceMapFile.MouthCategory && adj.HasMouthAdjustment);
                bool selected = c == _editTarget;

                Rect r = new Rect(row.x + w * i, row.y, w, row.height);
                GUIStyle style = PartChipStyle(i, count, enabled);
                string tip = (enabled ? "" : "合成しない（OFF）") + (adjusted ? (enabled ? "" : "・") + "調整済み" : "");
                bool next = GUI.Toggle(r, selected, new GUIContent(name, tip), style);
                if (next && !selected && _previewDrag == PreviewDrag.None)
                {
                    _editTarget = c;
                    GUI.FocusControl(null); // 数値欄の編集中の値が別の対象に残らないように
                    // 下の欄の並びが変わるので、このイベントはここで終える（Layout とコントロール数がずれないように）
                    Repaint();
                    GUIUtility.ExitGUI();
                }

                if (Event.current.type == EventType.Repaint)
                {
                    if (adjusted) MakeFixGui.Dot(new Rect(r.xMax - 9f, r.y + 3f, 5f, 5f), MakeFixGui.Accent);
                    if (!enabled)
                    {
                        float tw = Mathf.Min(style.CalcSize(new GUIContent(name)).x, r.width - 6f);
                        EditorGUI.DrawRect(new Rect(r.center.x - tw * 0.5f, r.center.y, tw, 1f), MakeFixGui.Muted);
                    }
                }
            }

            // 選んだパーツの「合成する」。位置・大きさの「自動に戻す」は下の「位置・大きさ」カードの見出しにある
            if (_editTarget != null)
            {
                EditorGUILayout.Space(4);
                bool enabled = adj.IsEnabled(_editTarget);
                bool on = EditorGUILayout.ToggleLeft(new GUIContent("合成する", "OFF にすると、このパーツにはメイクを乗せません（灰色の取り消し線）。"),
                    enabled, GUILayout.Width(80f));
                if (on != enabled)
                {
                    adj.SetEnabled(_editTarget, on);
                    MarkAdjustmentChanged();
                }
            }
            EndFocusCard(FocusCard.Parts);
        }

        /// <summary>回転の 1 ステップ（度）。ドラッグでは 5 ピクセルで 1 ステップ。</summary>
        private const float RotationStep = 1f;

        /// <summary>選択中の対象の位置・拡大縮小（ドラッグスクラブ PAD・詳細の数値入力）。</summary>
        private void DrawEditLayer(FaceMapAdjustment adj)
        {
            // 見出しの右端: 編集中のパーツ名・調整済み・このカードの値（位置・大きさ・回転・左右の間隔）を戻す
            MakeFixGui.BeginCardWithHeader("位置・大きさ", "クリックで 1 ステップ、押したままドラッグで連続して動かせます。");
            MakeFixGui.Chip(EditTargetName, MakeFixGui.Accent);
            FaceMapTransform current = _editTarget == null ? adj.Global : adj.FindPart(_editTarget);
            bool layerAdjusted = current != null && !current.IsIdentity;
            if (layerAdjusted)
            {
                GUILayout.Space(2f);
                MakeFixGui.Chip("調整済み", MakeFixGui.Muted);
            }
            GUILayout.Space(4f);
            using (new EditorGUI.DisabledScope(!layerAdjusted || _previewDrag != PreviewDrag.None))
            {
                if (GUILayout.Button(new GUIContent("自動に戻す",
                            $"{EditTargetName}の位置・大きさ・回転・左右の間隔だけを、自動の状態に戻します。\n" +
                            "ほかのパーツ・目の調整・仕上げは変わりません（まとめて戻すのは「調整をすべてリセット」）。"),
                        EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                {
                    current.Reset();
                    MarkAdjustmentChanged();
                    GUIUtility.ExitGUI();
                }
            }
            MakeFixGui.EndCardHeader();

            FaceMapTransform layer = EditLayer(adj);
            EditorGUIUtility.labelWidth = 80f;
            bool canEdit = _previewDrag == PreviewDrag.None;
            Vector2 outer = OuterScale(adj);

            // 位置（ドラッグスクラブ）。プレビュー上の見た目でステップ分動くよう、全体の拡大縮小で割る
            Vector2 move = NudgePad.DrawScrubPad("位置", NudgePad.MakeFixStepKey, canEdit, this);
            if (move != Vector2.zero)
            {
                layer.Offset += new Vector2(move.x / outer.x, move.y / outer.y);
                MarkAdjustmentChanged();
                Repaint();
            }

            // 縦横のスケール。1 ステップで枠の大きさが「移動量」の UV だけ変わる
            Rect bounds = AtaaCore.GetAvatarBounds(_state.PairMatch, _editTarget);
            float step = NudgePad.CurrentStep(NudgePad.MakeFixStepKey);
            float sx = NudgePad.DrawScrubTwo("横幅", "－", "＋", "横に縮める", "横に広げる", canEdit, this);
            float sy = NudgePad.DrawScrubTwo("高さ", "－", "＋", "縦に縮める", "縦に広げる", canEdit, this);
            if (sx != 0f || sy != 0f)
            {
                layer.Scale += new Vector2(
                    sx * step / Mathf.Max(bounds.width * outer.x, 1e-3f),
                    sy * step / Mathf.Max(bounds.height * outer.y, 1e-3f));
                layer.ClampScale();
                MarkAdjustmentChanged();
                Repaint();
            }

            // 回転（§4.7）。パーツのまわりだけの変形の中で回すので、TPS の制御点は動かさない（補正の影響を受けない）。
            // 1 ステップ = RotationStep 度。左右ペアのパーツは左右対称に傾く
            bool canRotate = canEdit && adj.LocalPartAdjust;
            const string rotateOffTip = "下の「パーツのまわりだけ動かす」が ON のときだけ回せます";
            float rot = NudgePad.DrawScrubTwo($"回転 {layer.Rotation:0.#}°", "↻", "↺",
                adj.LocalPartAdjust ? "時計回りに回す" : rotateOffTip,
                adj.LocalPartAdjust ? "反時計回りに回す" : rotateOffTip,
                canRotate, this);
            if (rot != 0f)
            {
                layer.Rotation += rot * RotationStep;
                layer.ClampScale();
                MarkAdjustmentChanged();
                Repaint();
            }

            // 変形のしかた（回転できるかどうかもこれで決まるので、回転のすぐ下に置く）
            using (new EditorGUI.DisabledScope(!canEdit))
            {
                bool localPart = EditorGUILayout.ToggleLeft(
                    new GUIContent("パーツのまわりだけ動かす（全パーツ共通）",
                        "ON: パーツの位置・大きさの調整は、そのパーツのまわりだけを動かします（口を動かしても目元は動きません）。回転も使えます。\n" +
                        "OFF: 従来どおり、顔全体の変形を作り直します（離れたところも少しずつ動きます）。回転は使えません。"),
                    adj.LocalPartAdjust);
                if (localPart != adj.LocalPartAdjust)
                {
                    adj.LocalPartAdjust = localPart;
                    MarkAdjustmentChanged();
                }
            }

            if (IsPairCategory(_editTarget))
                DrawPairGap(adj, layer);
            else if (IsCenterCategory(_editTarget))
                DrawCenterAlign(adj, layer);

            // 数値入力は詳細に隠す
            _detailFoldout = EditorGUILayout.Foldout(_detailFoldout, "詳細（数値）", true);
            if (_detailFoldout)
            {
                EditorGUI.BeginChangeCheck();
                Vector2 offset = EditorGUILayout.Vector2Field("位置のずれ", layer.Offset);
                Vector2 scale = EditorGUILayout.Vector2Field("拡大縮小", layer.Scale);
                float rotation = layer.Rotation;
                using (new EditorGUI.DisabledScope(!canRotate))
                {
                    rotation = EditorGUILayout.FloatField(
                        new GUIContent("回転 (°)", adj.LocalPartAdjust ? "パーツの回転角（度）。" : rotateOffTip),
                        layer.Rotation);
                }
                if (EditorGUI.EndChangeCheck())
                {
                    layer.Offset = offset;
                    layer.Scale = scale;
                    layer.Rotation = rotation;
                    layer.ClampScale();
                    MarkAdjustmentChanged();
                }

                if (IsPairCategory(_editTarget))
                {
                    float? minGap = AtaaCore.MinGap(_state.PairMatch, adj, _editTarget);
                    using (new EditorGUI.DisabledScope(!minGap.HasValue || !canEdit))
                    {
                        EditorGUI.BeginChangeCheck();
                        float gap = EditorGUILayout.FloatField(
                            new GUIContent("間隔の変化", "左右の中心の間隔をどれだけ変えたか（UV）。正で広がる。"),
                            layer.Gap);
                        if (EditorGUI.EndChangeCheck() && minGap.HasValue) SetGap(layer, gap, minGap.Value);
                    }
                }
            }

            EditorGUILayout.Space(2);
            GUILayout.Label(new GUIContent("2D UV 表示では枠のドラッグで移動、四隅で拡大縮小（Shift で縦横比固定）もできます。",
                    "ホイールで拡大、中ボタンか Alt + ドラッグで表示を移動できます。"),
                MakeFixGui.SubtleWrap);

            MakeFixGui.EndCard();
        }

        /// <summary>
        /// 口パーツ専用: 口の曲がり・口の折れ（^ / v）。値は .adjust.json（この組み合わせの調整）にだけ保存し、FaceMap には書き戻さない。
        /// </summary>
        private void DrawMouthSettings(FaceMapAdjustment adj)
        {
            MakeFixGui.BeginCardWithHeader("口の調整", MakeFixMouthUi.CardTooltip);
            if (adj.HasMouthAdjustment)
            {
                MakeFixGui.Chip("調整済み", MakeFixGui.Muted);
                GUILayout.Space(4f);
            }
            using (new EditorGUI.DisabledScope(!adj.HasMouthAdjustment))
            {
                if (GUILayout.Button(new GUIContent("自動に戻す", MakeFixMouthUi.ResetAllTooltip),
                        EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                {
                    adj.ResetMouth();
                    MarkAdjustmentChanged("口の調整を自動に戻す");
                    GUIUtility.ExitGUI();
                }
            }
            MakeFixGui.EndCardHeader();

            EditorGUIUtility.labelWidth = 110f;
            EditorGUI.BeginChangeCheck();
            float bend = EditorGUILayout.Slider(
                new GUIContent(MakeFixMouthUi.BendLabel, MakeFixMouthUi.BendTooltip),
                adj.MouthBend, -FaceMapAdjustment.MaxMouthBend, FaceMapAdjustment.MaxMouthBend);
            if (EditorGUI.EndChangeCheck())
            {
                adj.MouthBend = bend;
                adj.ClampMouth();
                MarkAdjustmentChanged();
            }

            bool canFold = AtaaCore.CanFoldMouth(_state.PairMatch);
            using (new EditorGUI.DisabledScope(!canFold))
            {
                EditorGUI.BeginChangeCheck();
                float fold = EditorGUILayout.Slider(
                    new GUIContent(MakeFixMouthUi.FoldLabel, MakeFixMouthUi.FoldTooltip),
                    adj.MouthFold, -FaceMapAdjustment.MaxMouthFold, FaceMapAdjustment.MaxMouthFold);
                if (EditorGUI.EndChangeCheck())
                {
                    adj.MouthFold = fold;
                    adj.ClampMouth();
                    MarkAdjustmentChanged();
                }
            }
            if (!canFold)
                EditorGUILayout.LabelField(MakeFixMouthUi.FoldUnavailableText,
                                           EditorStyles.wordWrappedMiniLabel);

            MakeFixGui.EndCard();
        }

        /// <summary>
        /// 目パーツ専用: 下まつ毛幅・目尻フレア・アイライン高（・下まぶた線）。
        /// 値は .adjust.json（この組み合わせの調整）にだけ保存し、アバター基準（FaceMap）には書き戻さない。
        /// </summary>
        private void DrawEyeSettings(FaceMapAdjustment adj)
        {
            FaceMapMatch match = _state.PairMatch;

            // 見出しの右端に「調整済み」と「自動に戻す」（位置・大きさカードと同じ並び）
            MakeFixGui.BeginCardWithHeader("目の調整", "この組み合わせだけの調整です。アバター基準（FaceMap）は変わりません。");
            if (adj.HasEyeAdjustment)
            {
                MakeFixGui.Chip("調整済み", MakeFixGui.Muted);
                GUILayout.Space(4f);
            }
            using (new EditorGUI.DisabledScope(!adj.HasEyeAdjustment))
            {
                if (GUILayout.Button(new GUIContent("自動に戻す",
                            "このカードの目の調整（下まつ毛幅・目尻フレアなど）だけを自動の状態に戻します。目の線は FaceMap の値に戻ります。\n" +
                            "目の位置・大きさは変わりません（上の「位置・大きさ」の「自動に戻す」で戻します）。"),
                        EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                {
                    adj.ResetEye();
                    MarkAdjustmentChanged();
                    GUIUtility.ExitGUI();
                }
            }
            MakeFixGui.EndCardHeader();

            EditorGUIUtility.labelWidth = 90f;

            // 下まつ毛幅・目尻フレア: 目の下の肌の段（両方の FaceMap に目の下の線があるとき）だけに掛かる
            bool band = match != null && match.MakeupHasEyeLowerLine && match.AvatarHasEyeLowerLine;
            using (new EditorGUI.DisabledScope(!band))
            {
                EditorGUI.BeginChangeCheck();
                float width = EditorGUILayout.Slider(
                    new GUIContent("下まつ毛幅", "目頭を固定したまま、下まつ毛の横幅を目尻側へ伸び縮みさせます（1 = 変更なし）。"),
                    adj.LowerEyeWidthScale, FaceMapAdjustment.MinLowerEyeWidthScale, FaceMapAdjustment.MaxLowerEyeWidthScale);
                float flare = EditorGUILayout.Slider(
                    new GUIContent("目尻フレア", "目頭の位置は固定したまま、下まつ毛の目尻側ほど外側へ逃がします。"),
                    adj.LowerEyeOuterFlare, 0f, FaceMapAdjustment.MaxLowerEyeOuterFlare);
                if (EditorGUI.EndChangeCheck())
                {
                    adj.LowerEyeWidthScale = width;
                    adj.LowerEyeOuterFlare = flare;
                    adj.ClampEye();
                    MarkAdjustmentChanged();
                }
            }
            if (!band)
                GUILayout.Label("下まつ毛幅・目尻フレアは、目の下の線が両方の FaceMap にあるときに使えます。", MakeFixGui.SubtleWrap);

            // 目の線の高さ（目の領域の中の割合）。メイク元に線があるときだけ変形に使われる
            if (match != null && match.AvatarEyeLine.HasValue)
            {
                EditorGUI.BeginChangeCheck();
                float upper = EditorGUILayout.Slider(
                    new GUIContent("アイライン高", "目の枠の中で、目の線（上まつげの生え際）を置く高さ（下が 0、上が 1）。\n" +
                                                 "この組み合わせだけの調整で、FaceMap は変わりません。"),
                    match.AvatarEyeLine.Value, FaceMapFile.MinEyeLine, FaceMapFile.MaxEyeLine);
                float? lower = match.AvatarEyeLowerLine;
                if (lower.HasValue)
                {
                    lower = EditorGUILayout.Slider(
                        new GUIContent("下まぶた線", "目の枠の中で、目の下の線（下まつげの生え際）を置く高さ。"),
                        lower.Value, FaceMapFile.MinEyeLine, FaceMapFile.MaxEyeLine);
                }
                if (EditorGUI.EndChangeCheck())
                {
                    SetEyeLineOverrides(upper, lower);
                }
                if (!match.MakeupEyeLine.HasValue)
                    GUILayout.Label("メイク元の FaceMap に目の線が無いため、アイライン高は変形に使われません。", MakeFixGui.SubtleWrap);
                GUILayout.Label(new GUIContent("2D UV 表示では、目の枠の左右のつまみでも動かせます",
                        "右のつまみ = 目の線（上まつげの生え際）、左のつまみ = 目の下の線（下まつげの生え際）。\n" +
                        "この組み合わせの調整（.adjust.json）に保存され、対象の FaceMap は変わりません。"),
                    MakeFixGui.SubtleWrap);
            }
            else
            {
                GUILayout.Label("対象の FaceMap に目の線がありません（FaceMap エディターか、アバター基準の自動生成で付けられます）。",
                    MakeFixGui.SubtleWrap);
            }
            MakeFixGui.EndCard();
        }

        /// <summary>
        /// 左右の間隔（§7・§13.4）。目・頬の左右の領域の間隔だけを変える（大きさは変えない）。
        /// ドラッグスクラブ対応。プレビュー上の見た目でステップ分変わるよう全体の拡大縮小で割る。
        /// </summary>
        private void DrawPairGap(FaceMapAdjustment adj, FaceMapTransform layer)
        {
            float? minGap = AtaaCore.MinGap(_state.PairMatch, adj, _editTarget);
            float steps = NudgePad.DrawScrubTwo("左右の間隔", "→←", "←→",
                "左右の間隔を狭める（中央に寄せる）", "左右の間隔を広げる",
                minGap.HasValue && _previewDrag == PreviewDrag.None, this);
            if (steps != 0f && minGap.HasValue)
            {
                float step = NudgePad.CurrentStep(NudgePad.MakeFixStepKey);
                SetGap(layer, AtaaCore.NudgeGap(layer.Gap, minGap.Value, steps * step / OuterScale(adj).x), minGap.Value);
                Repaint();
            }
        }

        private void SetGap(FaceMapTransform layer, float gap, float minGap)
        {
            float next = AtaaCore.ClampGap(gap, minGap);
            if (Mathf.Approximately(next, layer.Gap)) return;
            layer.Gap = next;
            MarkAdjustmentChanged();
        }

        /// <summary>中心線に合わせる（§13.4）。鼻・口・顎の左右の位置を、対象アバターの FaceMap の中心線に合わせる。</summary>
        private void DrawCenterAlign(FaceMapAdjustment adj, FaceMapTransform layer)
        {
            float? centerX = _state.PairMatch?.AvatarCenterX;

            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("", GUILayout.Width(EditorGUIUtility.labelWidth));
            using (new EditorGUI.DisabledScope(!centerX.HasValue || _previewDrag != PreviewDrag.None))
            {
                string tip = centerX.HasValue
                    ? "左右の位置を、対象アバターの顔の中心線に合わせます。"
                    : "対象アバターの FaceMap に中心線（または鼻）がありません。";
                if (GUILayout.Button(new GUIContent("中心線に合わせる", tip), EditorStyles.miniButton, GUILayout.Width(110f)))
                {
                    GetEditBox(_state.PairMatch, adj, out Rect bounds, out Vector2 globalPivot, out Vector2 boxCenter, out _);
                    // 調整後の中心の x が中心線に来るような Offset（全体の調整の内側に戻して求める）
                    Vector2 inner = OuterInverse(adj, new Vector2(centerX.Value, boxCenter.y), globalPivot);
                    float offsetX = inner.x - bounds.center.x;
                    if (!Mathf.Approximately(offsetX, layer.Offset.x))
                    {
                        layer.Offset = new Vector2(offsetX, layer.Offset.y);
                        MarkAdjustmentChanged();
                    }
                }
            }
            EditorGUILayout.EndHorizontal();
        }

        /// <summary>合成範囲（既定で畳む。畳んでいても見出しに現在値）。</summary>
        private void DrawMaskSettings(FaceMapAdjustment adj)
        {
            string summary = $"合成範囲  広げ {adj.MaskMargin:0.###} / ぼかし {adj.MaskFeather:0.###}";
            _maskFoldout = EditorGUILayout.Foldout(_maskFoldout, summary, true);
            if (!_maskFoldout) return;

            EditorGUIUtility.labelWidth = 130f;
            EditorGUI.BeginChangeCheck();
            float margin = EditorGUILayout.Slider("広げ量", adj.MaskMargin, 0f, FaceMapAdjustment.MaxMaskExtent);
            float feather = EditorGUILayout.Slider("ぼかし", adj.MaskFeather, 0f, FaceMapAdjustment.MaxMaskExtent);
            float excludeFeather = EditorGUILayout.Slider(
                new GUIContent("OFF の境界のぼかし",
                    "「調整するパーツ」で「合成する」を OFF にしたパーツに効きます。\n" +
                    "そのパーツの枠の外側で、メイクを徐々に戻す幅。枠の内側は常に元のまま。"),
                adj.ExcludeFeather, 0f, FaceMapAdjustment.MaxMaskExtent);
            if (EditorGUI.EndChangeCheck())
            {
                adj.MaskMargin = margin;
                adj.MaskFeather = feather;
                adj.ExcludeFeather = excludeFeather;
                adj.ClampMask();
                MarkAdjustmentChanged();
            }
        }

        /// <summary>肌色を合わせる（仕上げ。メイクの濃さの下）。</summary>
        private void DrawSkinToneToggle(FaceMapAdjustment adj)
        {
            bool skinTone = EditorGUILayout.Toggle(
                new GUIContent("肌色を合わせる",
                    "メイクの色を「対象の肌色 ÷ メイク元の素体の肌色」の比で寄せてから重ねます（浮きを防ぐ）。\n" +
                    "肌ごと不透明に描かれたメイクは、メイクのテクスチャの肌から、肌の部分が透明な「重ねるだけ」のメイクは、" +
                    "メイク元 FaceMap に記録された顔テクスチャ（素体の肌）から、メイク元の肌色を測ります。\n" +
                    "重ねるだけのメイクで、メイク元 FaceMap に顔テクスチャが記録されていないときや、肌色がほぼ同じ組み合わせでは何も変わりません。"),
                adj.MatchSkinTone);
            if (skinTone != adj.MatchSkinTone)
            {
                adj.MatchSkinTone = skinTone;
                MarkAdjustmentChanged();
            }
        }

        /// <summary>
        /// 調整の変更を反映する。ボタン・スライダーを操作中（押し続け・ドラッグ中）は保存を後回しにし、
        /// 操作が終わったときに 1 回だけ保存する（FlushPendingSave）。元に戻す（Ctrl+Z）の履歴にも記録する。
        /// </summary>
        private void MarkAdjustmentChanged(string undoName = "調整を変更") => ApplyAdjustmentChange(true, undoName);

        private void ApplyAdjustmentChange(bool recordHistory, string undoName = null)
        {
            if (recordHistory) RecordHistory(undoName);
            AtaaCore.ApplyEyeLineOverrides(_state.PairMatch, _state.Adjustment);
            InvalidatePreview();
            _orbit?.MarkDirty();
            if (IsInteracting)
            {
                _pendingSave = true;
                return;
            }
            _pendingSave = false;
            _toolService.SaveAdjustment();
        }

        /// <summary>元に戻す（Ctrl+Z）の履歴に、今の調整とメイクの濃さを記録する。操作中の変更は 1 回にまとめる。</summary>
        private void RecordHistory(string undoName)
        {
            SyncHistoryBaseline();
            _history.Commit(undoName ?? "調整を変更", _state.PairKey, _state.Adjustment, _state.PreviewMakeupOpacity, IsInteracting);
        }

        /// <summary>組み合わせ・調整が差し替わっていたら（読み込み・切り替え）、履歴を消して今の状態を起点にする。</summary>
        private void SyncHistoryBaseline()
        {
            if (ReferenceEquals(_state.Adjustment, _historyAdjustment) && _state.PairKey == _historyPairKey) return;
            _historyAdjustment = _state.Adjustment;
            _historyPairKey = _state.PairKey;
            _history.Reset(_state.PairKey, _state.Adjustment, _state.PreviewMakeupOpacity);
        }

        /// <summary>後回しにした保存があれば保存する。</summary>
        private void FlushPendingSave()
        {
            _history.EndGesture();
            if (!_pendingSave) return;
            _pendingSave = false;
            _toolService?.SaveAdjustment();
        }

        private bool _pendingSave;

        private const string AllTargetName = "全体";

        private string EditTargetName => _editTarget ?? AllTargetName;

        /// <summary>いま編集している層（全体 or パーツ）。</summary>
        private FaceMapTransform EditLayer(FaceMapAdjustment adj)
        {
            return _editTarget == null ? adj.Global : adj.GetPart(_editTarget);
        }

        // 編集している層の外側に掛かる変換（パーツを編集中なら全体の調整、全体なら無し）

        private Vector2 OuterScale(FaceMapAdjustment adj) => _editTarget == null ? Vector2.one : adj.Global.Scale;

        private Vector2 OuterApply(FaceMapAdjustment adj, Vector2 p, Vector2 globalPivot) =>
            _editTarget == null ? p : adj.Global.Apply(p, globalPivot);

        private Vector2 OuterInverse(FaceMapAdjustment adj, Vector2 p, Vector2 globalPivot) =>
            _editTarget == null ? p : adj.Global.Inverse(p, globalPivot);

        /// <summary>編集している層の枠（調整後、UV）。baseBounds はその層の調整前の外接矩形。</summary>
        private void GetEditBox(FaceMapMatch match, FaceMapAdjustment adj,
                                out Rect baseBounds, out Vector2 globalPivot, out Vector2 boxCenter, out Vector2 boxSize)
        {
            baseBounds = AtaaCore.GetAvatarBounds(match, _editTarget);
            globalPivot = AtaaCore.GetAvatarBounds(match).center;
            FaceMapTransform layer = EditLayer(adj);
            boxCenter = OuterApply(adj, baseBounds.center + layer.Offset, globalPivot);
            boxSize = Vector2.Scale(Vector2.Scale(baseBounds.size, layer.Scale), OuterScale(adj))
                      + new Vector2(LayerGap(layer) * OuterScale(adj).x, 0f);
        }

        /// <summary>編集中の層の左右の間隔（左右ペアのパーツのときだけ。それ以外は 0）。</summary>
        private float LayerGap(FaceMapTransform layer) =>
            _editTarget != null && IsPairCategory(_editTarget) ? layer.Gap : 0f;

        private static bool IsPairCategory(string category) =>
            category != null && FaceMapMirror.IsPair(FaceMapMirror.PairLabel(category, true));

        private static bool IsCenterCategory(string category) =>
            category != null && FaceMapMirror.IsCenterPart(category + "_中央");
    }
}
