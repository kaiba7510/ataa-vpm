using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── 上部ツールバー（メイク適用など）と状態の行 ──

        // ── 準備の項目へ移動（「あと N 項目」「次: …」から）──

        /// <summary>準備の項目に対応するカード。</summary>
        private enum FocusCard
        {
            None,
            Avatar,
            AvatarFaceMap,
            AvatarTexture,
            MakeupSource,
            Parts
        }

        /// <summary>カードの位置（スクロールの中の座標。Repaint のたびに記録）。</summary>
        private readonly Dictionary<FocusCard, Rect> _cardRects = new Dictionary<FocusCard, Rect>();

        private FocusCard _flashCard;
        private double _flashUntil;
        private const double FlashSeconds = 1.2;

        private static FocusCard CardFor(ReadinessItem item)
        {
            switch (item.Number)
            {
                case 1: case 5: return FocusCard.MakeupSource;
                case 2: return FocusCard.AvatarFaceMap;
                case 3: return FocusCard.Avatar;
                case 4: case 6: return FocusCard.AvatarTexture;
                case 8: return FocusCard.Parts;
                default: return FocusCard.None; // 7（対応付け）は中央のビューに出る
            }
        }

        /// <summary>
        /// 画面のステップ順（①アバター → ③アバター基準 → ④顔テクスチャ → ⑤メイク元〔テクスチャ → 基準〕 → ⑥調整）に並べた準備の項目番号。
        /// 「次にやること」はこの順で最初の ✗（項目番号の順だと、まだ開いていないカードを指すことがある）。
        /// </summary>
        private static readonly int[] StepOrder = { 3, 2, 4, 6, 5, 1, 7, 8 };

        private ReadinessItem NextItem()
        {
            foreach (int n in StepOrder)
            {
                ReadinessItem it = FirstFailedOf(n);
                if (it != null) return it;
            }
            return null;
        }

        /// <summary>カードのステップ番号の色。済み → 緑、次にやるカード → 青、それ以外 → 灰色。</summary>
        private MakeFixGui.StepState StepStateOf(FocusCard card, bool done) =>
            done ? MakeFixGui.StepState.Done
            : card == _currentCard ? MakeFixGui.StepState.Current
            : MakeFixGui.StepState.Pending;

        /// <summary>指定した項目がすべて ✓ か。</summary>
        private bool ItemsOk(params int[] numbers)
        {
            foreach (ReadinessItem it in _readiness)
            {
                if (!it.Ok && System.Array.IndexOf(numbers, it.Number) >= 0) return false;
            }
            return true;
        }

        private static bool IsLeftCard(FocusCard card) =>
            card == FocusCard.Avatar || card == FocusCard.AvatarFaceMap || card == FocusCard.AvatarTexture;

        /// <summary>その項目のカードまでペインをスクロールし、少しのあいだ枠を光らせる。</summary>
        private void FocusReadinessItem(ReadinessItem item)
        {
            FocusCard card = CardFor(item);
            if (card == FocusCard.None) return;
            if (_cardRects.TryGetValue(card, out Rect r))
            {
                float y = Mathf.Max(0f, r.y - 4f);
                if (IsLeftCard(card)) _leftScroll.y = y;
                else _rightScroll.y = y;
            }
            _flashCard = card;
            _flashUntil = EditorApplication.timeSinceStartup + FlashSeconds;
            Repaint();
        }

        /// <summary>MakeFixGui.EndCard の代わり。カードの位置を記録し、移動先なら枠を光らせる。</summary>
        private void EndFocusCard(FocusCard card)
        {
            MakeFixGui.EndCard();
            if (Event.current.type != EventType.Repaint) return;

            Rect r = GUILayoutUtility.GetLastRect();
            _cardRects[card] = r;

            // 次にやるカードは、いつも青い 1px の枠
            if (card == _currentCard && !_allOk)
            {
                Color cc = MakeFixGui.Accent;
                cc.a = 0.8f;
                EditorGUI.DrawRect(new Rect(r.x, r.y, r.width, 1f), cc);
                EditorGUI.DrawRect(new Rect(r.x, r.yMax - 1f, r.width, 1f), cc);
                EditorGUI.DrawRect(new Rect(r.x, r.y, 1f, r.height), cc);
                EditorGUI.DrawRect(new Rect(r.xMax - 1f, r.y, 1f, r.height), cc);
            }

            if (_flashCard != card) return;
            double left = _flashUntil - EditorApplication.timeSinceStartup;
            if (left <= 0)
            {
                _flashCard = FocusCard.None;
                return;
            }
            // 2 回点滅してから消える
            float t = (float)(left / FlashSeconds);
            float a = Mathf.Abs(Mathf.Sin(t * Mathf.PI * 2f)) * Mathf.Clamp01(t * 3f);
            Color c = MakeFixGui.Accent;
            c.a = a;
            const float w = 2f;
            EditorGUI.DrawRect(new Rect(r.x, r.y, r.width, w), c);
            EditorGUI.DrawRect(new Rect(r.x, r.yMax - w, r.width, w), c);
            EditorGUI.DrawRect(new Rect(r.x, r.y, w, r.height), c);
            EditorGUI.DrawRect(new Rect(r.xMax - w, r.y, w, r.height), c);
            Repaint();
        }

        private void DrawTopToolbar()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);

            // 準備の状態。足りないときは押すと、最初に足りない項目のカードへ移動して光らせる。
            // 「メイク適用」「適用を解除」は右ペイン下端だけに置く（同じボタンを 2 か所に出さない）
            ReadinessItem firstFailed = NextItem();
            if (_allOk)
            {
                MakeFixGui.Chip("準備完了", MakeFixGui.Success, "メイクを適用できます（右下の「メイク適用」）。");
            }
            else
            {
                int remaining = Mathf.Max(1, TotalSteps - CountDoneSteps());
                string tip = firstFailed != null ? $"次: {firstFailed.Message}\n押すとその項目へ移動します。" : null;
                if (MakeFixGui.ChipButton($"あと {remaining} ステップ  ›", MakeFixGui.Warning, tip) && firstFailed != null)
                    FocusReadinessItem(firstFailed);
            }

            GUILayout.FlexibleSpace();

            using (new EditorGUI.DisabledScope(_state.TargetAvatar == null || SceneView.lastActiveSceneView == null))
            {
                if (GUILayout.Button(new GUIContent("Scene で顔を映す", "Scene ビューのカメラを顔の正面に向けます。"),
                        EditorStyles.toolbarButton, GUILayout.Width(100f)))
                {
                    LiveFacePreview.FrameFace(_state.TargetAvatar, _state.PreviewAvatarTexture);
                }
            }
            if (GUILayout.Button("FaceMap エディター", EditorStyles.toolbarButton, GUILayout.Width(110f)))
                MyVrcToolFaceMapEditorWindow.ShowWindow();
#if ATAA_DIAGNOSTICS
            // オープンβだけ（本リリースの DLL にはこのボタンもコードも入らない）
            using (new EditorGUI.DisabledScope(_state.TargetAvatar == null || _applying))
            {
                if (GUILayout.Button(new GUIContent("診断", "（オープンβ用）対象アバターの自動生成の入力と結果を調べ、一覧を出します。"),
                        EditorStyles.toolbarButton, GUILayout.Width(40f)))
                {
                    RunDiagnostics();
                    GUIUtility.ExitGUI();
                }
            }
#endif
            if (GUILayout.Button(new GUIContent("更新", "FaceMaps フォルダとシーンのアバターを読み直します。"), EditorStyles.toolbarButton, GUILayout.Width(40f)))
            {
                _avatarsDirty = true;
                _faceCandidatesDirty = true;
                RequestRefresh();
            }

            EditorGUILayout.EndHorizontal();
        }

        /// <summary>状態の行（1 行。全文はツールチップ）。</summary>
        private void DrawStatusLine()
        {
            string status = MakeFixReadiness.FirstLine(_state.Warning);
            if (_preview.IsBusy || _applying) status = string.IsNullOrEmpty(status) ? "更新中…" : status + "   更新中…";
            GUIStyle style = _state.WarningType == MessageType.Warning || _state.WarningType == MessageType.Error
                ? MakeFixGui.WarnText
                : _statusStyle;
            EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
            // 種類に合わせたアイコン（メッセージが無いときは出さない。行の高さは変えない）
            Rect iconRect = GUILayoutUtility.GetRect(16f, 16f, GUILayout.Width(16f), GUILayout.Height(16f));
            if (!string.IsNullOrEmpty(status) && Event.current.type == EventType.Repaint)
            {
                Texture icon = MakeFixGui.Icon(_state.WarningType == MessageType.None ? MessageType.Info : _state.WarningType);
                if (icon != null) GUI.DrawTexture(iconRect, icon, ScaleMode.ScaleToFit);
            }
            GUILayout.Label(new GUIContent(string.IsNullOrEmpty(status) ? " " : status, _state.Warning), style);
            EditorGUILayout.EndHorizontal();
        }
    }
}
