using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── 問題の 1 行表示（§13.7）──

        private void DrawProblemLine(ReadinessItem item)
        {
            switch (item.Fix)
            {
                case ReadinessFix.PickAvatarTexture:
                    DrawWarnLine(item.Message, item.Detail, "候補から選ぶ",
                        _state.TargetAvatar != null ? (System.Action)(() => ShowAvatarTextureMenu(new Rect(Event.current.mousePosition, Vector2.zero))) : null);
                    break;
                case ReadinessFix.OpenFaceMapEditor:
                    DrawWarnLine(item.Message, item.Detail, "FaceMap エディター", () => MyVrcToolFaceMapEditorWindow.ShowWindow());
                    break;
                case ReadinessFix.EnableAllParts:
                    DrawWarnLine(item.Message, item.Detail, "すべて ON", EnableAllParts);
                    break;
                default:
                    DrawWarnLine(item.Message, item.Detail, null, null);
                    break;
            }
        }

        /// <summary>「警告アイコン メッセージ [ボタン]」の 1 行。fix が null ならボタンは無効（ボタン名も null なら出さない）。</summary>
        private void DrawWarnLine(string message, string detail, string buttonLabel, System.Action fix)
        {
            EditorGUILayout.BeginHorizontal();
            MakeFixGui.MessageIcon(MessageType.Warning);
            GUILayout.Label(new GUIContent(message, detail), MakeFixGui.WarnText);
            GUILayout.FlexibleSpace();
            if (buttonLabel != null)
            {
                using (new EditorGUI.DisabledScope(fix == null))
                {
                    if (GUILayout.Button(buttonLabel, EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                    {
                        fix?.Invoke();
                        GUIUtility.ExitGUI();
                    }
                }
            }
            EditorGUILayout.EndHorizontal();
        }

        /// <summary>
        /// メイク元と対象アバターの顔の系統（通常・デフォルメ寄り）が違うときのお知らせ（§11.20）。
        /// 目と口の位置関係が大きく違い、口の周り・目の下で崩れや折り返しが出やすいため、先に知らせる。
        /// </summary>
        private void DrawFaceStyleLine(FaceMapMatch match)
        {
            if (!IsCrossStyle(match, out string from, out string to, out string detail)) return;
            DrawInfoLine($"顔立ちの系統が違う組み合わせです（{from} → {to}）。口の周りなどが崩れやすくなります", detail);
        }

        /// <summary>メイク元か対象のどちらかが、デフォルメ寄りの顔立ちか。</summary>
        private static bool InvolvesDeformed(FaceMapMatch match) =>
            match != null &&
            ((match.MakeupProportion.HasValue && AtaaCore.IsDeformed(match.MakeupProportion.Value)) ||
             (match.AvatarProportion.HasValue && AtaaCore.IsDeformed(match.AvatarProportion.Value)));

        /// <summary>メイク元と対象の顔の系統が違うか。違えば、表示用の系統名と説明を返す。</summary>
        private static bool IsCrossStyle(FaceMapMatch match, out string from, out string to, out string detail)
        {
            from = to = detail = null;
            if (match == null || !match.MakeupProportion.HasValue || !match.AvatarProportion.HasValue) return false;
            bool makeupDeformed = AtaaCore.IsDeformed(match.MakeupProportion.Value);
            bool avatarDeformed = AtaaCore.IsDeformed(match.AvatarProportion.Value);
            if (makeupDeformed == avatarDeformed) return false;

            string Style(bool deformed) => deformed ? "デフォルメ寄り" : "通常";
            from = Style(makeupDeformed);
            to = Style(avatarDeformed);
            detail =
                $"メイク元は{from}（目と口の距離 ÷ 目の幅 {match.MakeupProportion.Value:0.00}）、" +
                $"対象は{to}（{match.AvatarProportion.Value:0.00}）の顔立ちです。\n" +
                "目と口の位置関係が大きく違うため、口の周りや目の下で、メイクの崩れや変形の折り返しが出ることがあります。\n" +
                "目安: " + AtaaCore.DeformedProportion.ToString("0.00") + " 未満をデフォルメ寄りとしています。";
            return true;
        }

        /// <summary>
        /// 変形の折り返し（DisplacementGrid）の 1 行。どれもテクスチャの生成・適用は止めない（合う・合わないは利用者が決める）。
        ///  - 裏返りが残り、顔立ちの系統が違う組み合わせ・どちらかがデフォルメ寄り: お知らせ
        ///    （顔の作りの違いでどうしても残るため。プレビューで判断してもらう）
        ///  - 裏返りが残り、どちらも通常の顔立ち: 調整で増えた分が目に見えるほどのときだけ警告（パーツの調整で直せる）。
        ///    調整なしでも残る分は、顔の組み合わせの違いで出るもので、利用者には直せないので警告にしない（DistortionNotice）
        ///  - 直せた（または潰れかけだけ残った）: お知らせ
        /// baseline は調整なしのときに残る裏返りの数（測れなければ null）。
        /// </summary>
        private void DrawDistortionLine(DistortionReport report, int? baseline, FaceMapMatch match)
        {
            const string canApply = "テクスチャの生成・適用はそのままできます。プレビューで見て、合う・合わないを決めてください。";
            // 数か所だけ（NegligibleInvertedCells 以下）残ったものは見た目にほぼ出ないので、警告にしない
            if (report.HasVisibleInversion)
            {
                string remain = "自動の補正で直しきれなかった折り返しが残っています（" + report.RemainingInvertedCells + " か所）。\n" +
                                canApply + "\n気になるときは、微調整でパーツの位置・大きさを変えると減ることがあります。";
                if (IsCrossStyle(match, out string from, out string to, out string styleDetail))
                {
                    DrawInfoLine($"顔立ちの系統が違う組み合わせ（{from} → {to}）のため、口の周りなどで補正しきれない箇所があります",
                        styleDetail + "\n" + remain);
                    return;
                }
                if (InvolvesDeformed(match))
                {
                    // デフォルメ寄りの顔は、口と目の下・頬が近くに並び、写し方の差が狭い範囲に集まるため残りやすい
                    DrawInfoLine("デフォルメ寄りの顔立ちのため、口の周りなどで補正しきれない箇所があります",
                        "デフォルメ寄りの顔は、口と目の下・頬が近くに並ぶため、変形の差が狭い範囲に集まり、折り返しが残りやすくなります。\n" + remain);
                    return;
                }
                if (DistortionNotice.HasVisibleIncrease(report.RemainingInvertedCells, baseline))
                {
                    int increase = DistortionNotice.Increase(report.RemainingInvertedCells, baseline);
                    DrawWarnLine("パーツの周りで変形が折り返しています",
                        "パーツを大きく動かしたり縮めたりしたため、メイク元の画像が裏返って写る部分があります。\n" +
                        "自動の補正では直しきれませんでした（調整で " + increase + " か所増えました）。" +
                        "パーツの位置・大きさを元に近づけるか、隣のパーツから離すと直ることがあります。\n" + canApply,
                        null, null);
                    return;
                }
                // 調整なしでも残る分だけ（増えていない）: 警告にせず、下のお知らせにする
            }

            string detail =
                "パーツを大きく動かしたり縮めたりしたため、パーツと周りの肌のつなぎ目で、メイク元の画像が裏返って写る部分がありました。\n" +
                "その部分だけを滑らかにならして直しています。パーツの中心部の写り方は変わりませんが、縁が少しずれることがあります。";
            if (report.RemainingInvertedCells > 0)
            {
                detail += report.HasVisibleInversion
                    ? $"\nこの顔の組み合わせでは、調整しなくても折り返しが {baseline ?? 0} か所残ります。" +
                      "調整で増えた分は少ないので、警告にはしていません。\n" + canApply
                    : $"\nごく小さな折り返しが {report.RemainingInvertedCells} か所残っていますが、見た目にはほぼ出ない大きさです。";
            }
            DrawInfoLine($"パーツの周りの歪みを自動で補正しました（縁のずれ 最大 {report.MaxLockShift * 100f:0.0}%）", detail);
        }

        /// <summary>目の下の線が片方（または両方）の FaceMap に無いときの 1 行。両方にある・目の領域が無いなら null。</summary>
        private static string MissingLowerLineNote(FaceMapMatch match, List<string> categories)
        {
            if (match == null || !categories.Contains(FaceMapFile.EyeCategory)) return null;
            if (match.MakeupHasEyeLowerLine && match.AvatarHasEyeLowerLine) return null;

            string who = !match.MakeupHasEyeLowerLine && !match.AvatarHasEyeLowerLine ? "メイク元と対象"
                : !match.MakeupHasEyeLowerLine ? "メイク元"
                : "対象";
            return $"{who}の FaceMap に目の下の線がありません（下まつげが潰れやすくなります）";
        }

        private void EnableAllParts()
        {
            foreach (string category in _categories) _state.Adjustment.SetEnabled(category, true);
            MarkAdjustmentChanged();
        }
    }
}
