using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        private void Draw2DView(Rect area)
        {
            if (_showPreview)
            {
                Rect texRect = PreviewTexRect(area);
                ProcessPreviewEvents(area, texRect);
                if (Event.current.type == EventType.Repaint) DrawPreview(area, PreviewTexRect(area));
                // 「結果」表示のときだけ（メイク前・メイク元・マスクは、それぞれの画像だと見て分かる）
                if (_comparing || _viewMode == FaceMapPreview.ViewMode.Result)
                    DrawViewStateBadge(area, true);
            }
            else if (Event.current.type == EventType.Repaint)
            {
                EditorGUI.DrawRect(area, new Color(0.17f, 0.17f, 0.17f));
                string text = _state.PairMatch == null && _state.PairError == null && _state.HasPair
                    ? "読み込み中..."
                    : "準備が揃うと、ここにプレビューが出ます";
                GUI.Label(area, text, _emptyViewStyle);
            }
        }

        private float TextureAspect()
        {
            Texture2D tex = _state.PreviewAvatarTexture;
            return tex != null && tex.height > 0 ? (float)tex.width / tex.height : 1f;
        }

        /// <summary>拡大率・表示位置を反映した、テクスチャのスクリーン上の矩形。</summary>
        private Rect PreviewTexRect(Rect area)
        {
            Rect fit = UVCoordinateConverter.FitRect(area, TextureAspect());
            float w = fit.width * _zoom, h = fit.height * _zoom;
            Vector2 c = fit.center + _pan;
            return new Rect(c.x - w * 0.5f, c.y - h * 0.5f, w, h);
        }

        private void ResetZoom()
        {
            _zoom = 1f;
            _pan = Vector2.zero;
            Repaint();
        }

        /// <summary>プレビューの依頼。値・テクスチャ・表示が変わったときだけ作り直す。ライブプレビューと共通。</summary>
        private void EnsurePreview()
        {
            // 作れない間は低解像度の要求を残さない（残すと OnEditorUpdate が毎フレーム Repaint し続ける）
            if (!_showPreview)
            {
                _requestedQuality = FaceMapPreview.Quality.Full;
                return;
            }

            bool texChanged = _preview.SetTextures(_state.PreviewAvatarTexture, _state.PreviewMakeupTexture);
            if (_state.PreviewAvatarTexture == null)
            {
                _requestedQuality = FaceMapPreview.Quality.Full;
                return;
            }
            bool opacityChanged = !Mathf.Approximately(_previewOpacity, _state.PreviewMakeupOpacity);
            bool pairChanged = _previewPairKey != _state.PairKey;

            FaceMapPreview.ViewMode view = _viewMode == FaceMapPreview.ViewMode.Makeup || _viewMode == FaceMapPreview.ViewMode.Mask
                ? _viewMode
                : FaceMapPreview.ViewMode.Result;
            bool viewChanged = view != FaceMapPreview.ViewMode.Result && view != _requestedView;

            // ドラッグ・スライダー操作中は低解像度、止まったらフル解像度（§13.5）
            FaceMapPreview.Quality quality = IsInteracting
                ? FaceMapPreview.Quality.Low
                : FaceMapPreview.Quality.Full;
            bool upgrade = quality == FaceMapPreview.Quality.Full && _requestedQuality == FaceMapPreview.Quality.Low;

            if (!_previewDirty && !texChanged && !opacityChanged && !pairChanged && !viewChanged && !upgrade &&
                (_preview.Output != null || _preview.IsBusy))
                return;

            _previewDirty = false;
            _previewPairKey = _state.PairKey;
            _previewOpacity = _state.PreviewMakeupOpacity;
            _previewError = null;

            BuildPreviewInputs(out AvatarDeformer deformer, out FaceMask mask);
            // 折り返しの警告は調整で増えた分だけで判断する（DistortionNotice）ので、Full のときは調整なしの結果も測る
            AvatarDeformer baselineDeformer = null;
            FaceMask baselineMask = null;
            if (quality == FaceMapPreview.Quality.Full && deformer != null) BuildBaselineInputs(out baselineDeformer, out baselineMask);
            _preview.Render(deformer, mask, _state.PreviewMakeupOpacity, quality, view, CurrentOutputKey, baselineDeformer, baselineMask);
            _requestedQuality = quality;
            _requestedView = view;
        }

        /// <summary>体験版の高画質長押しボタンが押されている間だけ、2048px（透かし入り）のプレビューを依頼する。</summary>
        private void EnsureTrialHighPreview()
        {
            if (!IsTrialHighResActive || _state.PreviewAvatarTexture == null) return;

            string key = CurrentTrialHighKey;
            if (TrialHighOutputReady || (_preview.IsTrialHighBusy && _requestedTrialHighKey == key)) return;

            BuildPreviewInputs(out AvatarDeformer deformer, out FaceMask mask);
            _preview.RenderTrialHigh(deformer, mask, _state.PreviewMakeupOpacity, key);
            _requestedTrialHighKey = key;
        }

        private void BuildPreviewInputs(out AvatarDeformer deformer, out FaceMask mask)
        {
            if (!AtaaCore.TryBuildDeformer(_state.PairMatch, _state.Adjustment,
                    out deformer, out string error))
            {
                _previewError = error;
                deformer = null;
            }

            mask = AtaaCore.BuildMask(_state.PairMatch, _state.Adjustment);
            // 重ねるだけのメイクの肌色合わせ用に、メイク元の素体の肌色を入れておく（適用と同じ。ToolService.ApplyMakeupAsync）
            _baseSkinLookup = MakeupBaseSkin.Assign(mask, _state.MakeupFaceMap, _state.PreviewMakeupTexture,
                FaceTextureReader.IsLinear(_state.PreviewAvatarTexture));
        }

        /// <summary>最後に作ったプレビューの入力で、メイク元の素体の肌色を取れたか（肌色合わせの状態表示に使う）。</summary>
        private BaseSkinLookup _baseSkinLookup;

        /// <summary>調整なし（既定値）の変形とマスク。作れなければどちらも null（基準なしとして扱う）。</summary>
        private void BuildBaselineInputs(out AvatarDeformer deformer, out FaceMask mask)
        {
            var none = new FaceMapAdjustment();
            if (!AtaaCore.TryBuildDeformer(_state.PairMatch, none, out deformer, out string _))
            {
                deformer = null;
                mask = null;
                return;
            }
            mask = AtaaCore.BuildMask(_state.PairMatch, none);
        }

        private void DrawPreview(Rect area, Rect texRect)
        {
            GUI.BeginClip(area);
            try
            {
                Rect local = new Rect(0f, 0f, area.width, area.height);
                Rect tex = new Rect(texRect.x - area.x, texRect.y - area.y, texRect.width, texRect.height);
                EditorGUI.DrawRect(local, new Color(0.12f, 0.12f, 0.12f));

                Texture image = PreviewImage();
                if (image != null) GUI.DrawTexture(tex, image, ScaleMode.StretchToFill);
                else EditorGUI.DrawRect(tex, new Color(0.17f, 0.17f, 0.17f));

                FaceMapMatch match = _state.PairMatch;
                FaceMapAdjustment adj = _state.Adjustment;

                // 調整後の、対象アバター側の各領域。OFF のパーツは灰色、編集中のパーツは太線
                AtaaCore.GetAdjustedRegions(match, adj, out Vector2[] centers, out Vector2[] sizes);
                for (int i = 0; i < centers.Length; i++)
                {
                    FaceMapRegionPair region = match.Regions[i];
                    Rect r = FaceMapTextureRenderer.RegionScreenRect(tex, centers[i], sizes[i]);
                    Color color = adj.IsEnabled(region.Category)
                        ? FaceMapTextureRenderer.GetLabelColor(region.Label)
                        : new Color(0.5f, 0.5f, 0.5f, 0.8f);
                    float thickness = _editTarget != null && region.Category == _editTarget ? 2f : 1f;
                    FaceMapTextureRenderer.DrawOutline(r, color, thickness);

                    // 目の線（v0.4 §4.2）。メイク元・対象の両方にあるときだけ、目の領域を上下 2 段で写す
                    // （上下の線を値で見分けると、同じ高さのとき下の線を上の線の条件で判定してしまうので、別々に描く）
                    DrawRegionLine(r, region.AvatarLine, region.MakeupLine.HasValue, color, region.AvatarLinePoints);
                    DrawRegionLine(r, region.AvatarLowerLine, region.MakeupLowerLine.HasValue, color, null);

                    // 目を調整の対象にしているときは、線のつまみ（ドラッグで対象の FaceMap の線を直す）
                    if (LineKnobsVisible && region.Category == FaceMapFile.EyeCategory) DrawLineKnobs(r, match, color);
                }

                // 編集中の対象（全体 or パーツ）の枠とハンドル（大きさは画面のピクセルで一定）
                GetEditBox(match, adj, out _, out _, out Vector2 boxCenter, out Vector2 boxSize);
                Rect box = FaceMapTextureRenderer.RegionScreenRect(tex, boxCenter, boxSize);
                FaceMapTextureRenderer.DrawOutline(box, Color.yellow, 2f);
                foreach (Vector2 h in FaceMapTextureRenderer.HandlePositions(box))
                {
                    const float hs = FaceMapTextureRenderer.HandleSize;
                    var hr = new Rect(h.x - hs * 0.5f, h.y - hs * 0.5f, hs, hs);
                    EditorGUI.DrawRect(new Rect(hr.x - 1, hr.y - 1, hr.width + 2, hr.height + 2), Color.black);
                    EditorGUI.DrawRect(hr, Color.white);
                }

                if (_preview.IsBusy)
                    GUI.Label(new Rect(6f, local.height - 24f, 120f, 16f), "更新中…", EditorStyles.whiteMiniLabel);
            }
            finally
            {
                GUI.EndClip();
            }
        }

        /// <summary>表示の切り替え（§13.5）に応じた画像。比較中はメイク前。</summary>
        private Texture PreviewImage()
        {
            Texture2D before = _state.PreviewAvatarTexture;
            if (_comparing) return before;

            switch (_viewMode)
            {
                case FaceMapPreview.ViewMode.Before:
                    return before;
                case FaceMapPreview.ViewMode.Makeup:
                case FaceMapPreview.ViewMode.Mask:
                    if (_preview.ViewOutput != null && _preview.ViewOutputMode == _viewMode) return _preview.ViewOutput;
                    return ActivePreviewOutput ?? before;
                default:
                    return ActivePreviewOutput ?? before;
            }
        }

        /// <summary>今の組み合わせの合成結果のキー（Render の tag）。</summary>
        private string CurrentOutputKey => MakeFixLiveOutput.Key(_state.MakeupFaceMapPath, _state.AvatarFaceMapPath);

        /// <summary>体験版の高画質長押し確認ボタンが有効に押されているか。</summary>
        private bool IsTrialHighResActive =>
            MakeFixTrialPreview.IsActive(AtaaCore.Edition, _showPreview, _trialHighResHeld, _comparing);

        /// <summary>今の調整・組み合わせ・テクスチャ・濃さに対応する高画質確認キャッシュのキー。</summary>
        private string CurrentTrialHighKey => OutputFingerprint();

        /// <summary>
        /// 合成結果が今の顔テクスチャ・組み合わせのものか。アバターを切り替えた直後に、前のアバターの基準で
        /// 合成した結果を新しいアバターに出さない（同じ顔テクスチャのアバター同士で、一瞬ずれて映っていた）。
        /// </summary>
        private bool PreviewOutputReady => MakeFixLiveOutput.IsReady(
            hasOutput: _preview.Output != null,
            sourceMatches: ReferenceEquals(_preview.AvatarSource, _state.PreviewAvatarTexture),
            outputKey: _preview.OutputTag,
            currentKey: CurrentOutputKey);

        /// <summary>体験版の高画質確認テクスチャ（2048px）が現在の状態と一致して準備できているか。</summary>
        private bool TrialHighOutputReady => MakeFixLiveOutput.IsReady(
            hasOutput: _preview.TrialHighOutput != null,
            sourceMatches: ReferenceEquals(_preview.AvatarSource, _state.PreviewAvatarTexture),
            outputKey: _preview.TrialHighOutputTag,
            currentKey: CurrentTrialHighKey);

        /// <summary>いま表示すべきプレビュー結果（体験版の高画質長押し中かつ準備済みなら 2048px、それ以外は通常プレビュー）。</summary>
        private Texture ActivePreviewOutput =>
            MakeFixTrialPreview.ShouldUseHighResTexture(IsTrialHighResActive, TrialHighOutputReady)
                ? _preview.TrialHighOutput
                : PreviewOutputReady ? _preview.Output : null;

        private int _previewDragControlId;

        private void CapturePreviewHotControl()
        {
            _previewDragControlId = GUIUtility.GetControlID(FocusType.Passive);
            GUIUtility.hotControl = _previewDragControlId;
        }

        private void ReleasePreviewHotControl()
        {
            if (_previewDragControlId != 0 && GUIUtility.hotControl == _previewDragControlId)
                GUIUtility.hotControl = 0;
            _previewDragControlId = 0;
        }

        private void ProcessPreviewEvents(Rect area, Rect texRect)
        {
            Event e = Event.current;
            if (_state.PairMatch == null || !_state.PairMatch.IsApplicable) return;

            // ── 拡大・移動 ──
            if (e.type == EventType.ScrollWheel && area.Contains(e.mousePosition))
            {
                ZoomAt(area, texRect, e.mousePosition, e.delta.y < 0f ? ZoomStep : 1f / ZoomStep);
                MarkUiDirty();
                e.Use();
                return;
            }

            bool panButton = e.button == 2 || (e.button == 0 && e.alt);
            if (e.type == EventType.MouseDown && panButton && area.Contains(e.mousePosition))
            {
                if (e.button == 2 && e.clickCount == 2)
                {
                    ResetZoom();
                }
                else
                {
                    _panning = true;
                    CapturePreviewHotControl();
                }
                e.Use();
                return;
            }
            if (_panning)
            {
                if (e.type == EventType.MouseDrag)
                {
                    if (_zoom > MinZoom) _pan = ClampPan(area, _pan + e.delta);
                    e.Use();
                    _viewportImgui?.MarkDirtyRepaint();
                }
                else if (e.rawType == EventType.MouseUp)
                {
                    _panning = false;
                    ReleasePreviewHotControl();
                    e.Use();
                }
                return;
            }

            // ── 目の線・目の下の線のつまみ（目を調整の対象にしているとき）──
            if (e.type == EventType.MouseDown && e.button == 0 && area.Contains(e.mousePosition) &&
                TryStartLineDrag(texRect, e.mousePosition))
            {
                CapturePreviewHotControl();
                e.Use();
                _viewportImgui?.MarkDirtyRepaint();
                return;
            }
            if (_previewDrag == PreviewDrag.EyeLine || _previewDrag == PreviewDrag.EyeLowerLine)
            {
                if (e.type == EventType.MouseDrag && e.button == 0)
                {
                    DragLine(texRect, e.mousePosition);
                    e.Use();
                    _viewportImgui?.MarkDirtyRepaint();
                }
                else if (e.rawType == EventType.MouseUp && e.button == 0)
                {
                    EndPreviewDrag();
                    e.Use();
                    _viewportImgui?.MarkDirtyRepaint();
                }
                return;
            }

            // ── 位置・拡大縮小のドラッグ ──
            FaceMapAdjustment adj = _state.Adjustment;
            FaceMapTransform layer = EditLayer(adj);
            GetEditBox(_state.PairMatch, adj, out Rect bounds, out Vector2 globalPivot,
                out Vector2 boxCenter, out Vector2 boxSize);
            Rect box = FaceMapTextureRenderer.RegionScreenRect(texRect, boxCenter, boxSize);
            Vector2 outer = OuterScale(adj);

            if (e.type == EventType.MouseDown && e.button == 0 && area.Contains(e.mousePosition))
            {
                Vector2[] handles = FaceMapTextureRenderer.HandlePositions(box);
                _previewDrag = PreviewDrag.None;

                for (int i = 0; i < handles.Length; i++)
                {
                    if (Vector2.Distance(handles[i], e.mousePosition) <= FaceMapTextureRenderer.HandleHitRadius)
                    {
                        // 反対側の角を固定して、マウス位置まで広げる
                        _dragFixedUv = ScreenToUvUnclamped(handles[handles.Length - 1 - i], texRect);
                        _previewDrag = PreviewDrag.Corner;
                        break;
                    }
                }

                if (_previewDrag == PreviewDrag.None && box.Contains(e.mousePosition))
                {
                    _dragStartMouseUv = ScreenToUvUnclamped(e.mousePosition, texRect);
                    _dragStartOffset = layer.Offset;
                    _previewDrag = PreviewDrag.Move;
                }

                if (_previewDrag != PreviewDrag.None)
                {
                    CapturePreviewHotControl();
                    e.Use();
                    _viewportImgui?.MarkDirtyRepaint();
                }
            }
            else if (e.type == EventType.MouseDrag && e.button == 0 && _previewDrag != PreviewDrag.None)
            {
                // 拡大中も画面上の見た目で動く（texRect が拡大を含むので、UV に直すと自動で 1/拡大率になる）
                Vector2 m = ScreenToUvUnclamped(e.mousePosition, texRect);

                if (_previewDrag == PreviewDrag.Move)
                {
                    // 画面上の移動量を、編集中の層の座標（全体の拡大縮小を掛ける前）に直す
                    Vector2 delta = m - _dragStartMouseUv;
                    layer.Offset = _dragStartOffset + new Vector2(delta.x / outer.x, delta.y / outer.y);
                }
                else
                {
                    Vector2 d = m - _dragFixedUv;
                    float gapWidth = LayerGap(layer) * outer.x;
                    var scale = new Vector2(
                        Mathf.Max(Mathf.Abs(d.x) - gapWidth, 1e-4f) / Mathf.Max(bounds.width * outer.x, 1e-4f),
                        Mathf.Abs(d.y) / Mathf.Max(bounds.height * outer.y, 1e-4f));
                    if (e.shift)
                    {
                        float uniform = Mathf.Max(scale.x, scale.y);
                        scale = new Vector2(uniform, uniform);
                    }
                    layer.Scale = scale;
                    layer.ClampScale();

                    // 固定した角からマウスの向きへ広がる
                    Vector2 size = Vector2.Scale(Vector2.Scale(bounds.size, layer.Scale), outer) + new Vector2(gapWidth, 0f);
                    Vector2 center = _dragFixedUv + new Vector2(
                        (d.x >= 0f ? 1f : -1f) * size.x * 0.5f,
                        (d.y >= 0f ? 1f : -1f) * size.y * 0.5f);
                    layer.Offset = OuterInverse(adj, center, globalPivot) - bounds.center;
                }

                InvalidatePreview();
                e.Use();
                Repaint();
            }
            else if (e.rawType == EventType.MouseUp && e.button == 0 && _previewDrag != PreviewDrag.None)
            {
                EndPreviewDrag();
                e.Use();
                Repaint();
            }
        }

        // ── 目の線・目の下の線の編集（この組み合わせの調整 .adjust.json に保存する。FaceMap は Read-Only）──

        /// <summary>線のつまみを出すか（目を調整の対象にしているとき）。</summary>
        private bool LineKnobsVisible => _editTarget == FaceMapFile.EyeCategory;

        /// <summary>
        /// 線のつまみの中心（スクリーン座標）。目の線は目の領域の右の外、目の下の線は左の外に置く
        /// （目の領域が薄い素体では 2 本の線が数ピクセルしか離れないため、左右に分ける）。
        /// </summary>
        private static Vector2 LineKnob(Rect regionScreen, float line, bool lower) =>
            new Vector2(lower ? regionScreen.xMin - LineKnobOffset : regionScreen.xMax + LineKnobOffset,
                FaceMapTextureRenderer.EyeLineScreenY(regionScreen, line));

        private bool TryStartLineDrag(Rect texRect, Vector2 mouse)
        {
            FaceMapMatch match = _state.PairMatch;
            if (!LineKnobsVisible || match == null) return false;

            AtaaCore.GetAdjustedRegions(match, _state.Adjustment, out Vector2[] centers, out Vector2[] sizes);
            for (int i = 0; i < centers.Length; i++)
            {
                if (match.Regions[i].Category != FaceMapFile.EyeCategory) continue;
                Rect r = FaceMapTextureRenderer.RegionScreenRect(texRect, centers[i], sizes[i]);

                if (match.AvatarEyeLowerLine.HasValue &&
                    Vector2.Distance(LineKnob(r, match.AvatarEyeLowerLine.Value, true), mouse) <= FaceMapTextureRenderer.HandleHitRadius)
                {
                    _previewDrag = PreviewDrag.EyeLowerLine;
                    _lineDragRegion = i;
                    return true;
                }
                if (match.AvatarEyeLine.HasValue &&
                    Vector2.Distance(LineKnob(r, match.AvatarEyeLine.Value, false), mouse) <= FaceMapTextureRenderer.HandleHitRadius)
                {
                    _previewDrag = PreviewDrag.EyeLine;
                    _lineDragRegion = i;
                    return true;
                }
            }
            return false;
        }

        /// <summary>ドラッグ中の線を、マウスの高さ（つかんだ目の領域の中での割合）に動かす。もう一方の線は動かさない。</summary>
        private void DragLine(Rect texRect, Vector2 mouse)
        {
            FaceMapMatch match = _state.PairMatch;
            if (match == null || !match.AvatarEyeLine.HasValue) return;

            AtaaCore.GetAdjustedRegions(match, _state.Adjustment, out Vector2[] centers, out Vector2[] sizes);
            if (_lineDragRegion < 0 || _lineDragRegion >= centers.Length) return;
            Rect r = FaceMapTextureRenderer.RegionScreenRect(texRect, centers[_lineDragRegion], sizes[_lineDragRegion]);
            if (r.height <= 1e-3f) return;

            float ratio = (r.yMax - mouse.y) / r.height;
            float line = match.AvatarEyeLine.Value;
            float? lower = match.AvatarEyeLowerLine;
            if (_previewDrag == PreviewDrag.EyeLine)
            {
                float min = lower.HasValue ? lower.Value + FaceMapFile.MinEyeBand : FaceMapFile.MinEyeLine;
                line = Mathf.Clamp(ratio, min, FaceMapFile.MaxEyeLine);
            }
            else if (lower.HasValue)
            {
                lower = Mathf.Clamp(ratio, FaceMapFile.MinEyeLine, line - FaceMapFile.MinEyeBand);
            }

            // ドラッグ中はメモリ上だけ。離したとき（EndPreviewDrag）に .adjust.json へ保存する
            SetEyeLineOverrides(line, lower, false);
        }

        /// <summary>
        /// 対象アバターの目の線・目の下の線を、この組み合わせの調整（上書き）として設定する。
        /// FaceMap の値と同じなら上書きを外す。save なら保存する（操作中は後回し）。FaceMap のファイルは変えない。
        /// </summary>
        private void SetEyeLineOverrides(float line, float? lower, bool save = true)
        {
            FaceMapMatch match = _state.PairMatch;
            if (match == null) return;
            FaceMapAdjustment adj = _state.Adjustment;

            AtaaCore.SetAvatarEyeLines(match, line, lower); // 決まり（範囲・線どうしの間隔）に収める
            adj.OverrideAvatarEyeLine = SameLine(match.AvatarEyeLine, match.FileAvatarEyeLine) ? null : match.AvatarEyeLine;
            adj.OverrideAvatarEyeLowerLine = SameLine(match.AvatarEyeLowerLine, match.FileAvatarEyeLowerLine) ? null : match.AvatarEyeLowerLine;

            if (save)
            {
                MarkAdjustmentChanged();
            }
            else
            {
                InvalidatePreview();
                _orbit?.MarkDirty();
            }
        }

        private static bool SameLine(float? a, float? b) =>
            a.HasValue == b.HasValue && (!a.HasValue || Mathf.Abs(a.Value - b.Value) < 1e-5f);

        /// <summary>領域の線（目の線・目の下の線・口の線）を 1 本描く。メイク元・対象の両方にあるときだけ。</summary>
        private static void DrawRegionLine(Rect regionScreen, float? avatarLine, bool makeupHasLine, Color color, Vector2[] points)
        {
            if (!avatarLine.HasValue || !makeupHasLine) return;
            var faded = new Color(color.r, color.g, color.b, 0.6f);
            if (!MouthLineShape.IsHorizontal(points))
            {
                // 口の線の折れ線（#25）
                FaceMapTextureRenderer.DrawMouthPolyline(regionScreen, points, avatarLine.Value, faded, false, 0f);
                return;
            }
            float ly = Mathf.Round(FaceMapTextureRenderer.EyeLineScreenY(regionScreen, avatarLine.Value));
            EditorGUI.DrawRect(new Rect(regionScreen.xMin, ly, regionScreen.width, 1f), new Color(color.r, color.g, color.b, 0.6f));
        }

        /// <summary>プレビューに、対象アバターの目の線・目の下の線とそのつまみを描く（regionScreen はクリップ内の座標）。</summary>
        private void DrawLineKnobs(Rect regionScreen, FaceMapMatch match, Color color)
        {
            if (_lineLabelLeft == null)
            {
                _lineLabelLeft = new GUIStyle(EditorStyles.whiteMiniLabel) { alignment = TextAnchor.MiddleLeft };
                _lineLabelRight = new GUIStyle(EditorStyles.whiteMiniLabel) { alignment = TextAnchor.MiddleRight };
            }

            for (int k = 0; k < 2; k++)
            {
                bool lower = k == 1;
                float? line = lower ? match.AvatarEyeLowerLine : match.AvatarEyeLine;
                if (!line.HasValue) continue;

                // メイク元に同じ線が無いと変形には使われない（薄く描く）
                bool used = lower ? match.MakeupEyeLowerLine.HasValue : match.MakeupEyeLine.HasValue;
                bool dragging = _previewDrag == (lower ? PreviewDrag.EyeLowerLine : PreviewDrag.EyeLine);
                Vector2 knob = LineKnob(regionScreen, line.Value, lower);
                float y = Mathf.Round(knob.y);

                // 枠からつまみまでの引き出し線
                float x0 = lower ? knob.x : regionScreen.xMax;
                float x1 = lower ? regionScreen.xMin : knob.x;
                EditorGUI.DrawRect(new Rect(x0, y, x1 - x0, 1f), new Color(color.r, color.g, color.b, used ? 0.9f : 0.4f));
                if (!used)
                    EditorGUI.DrawRect(new Rect(regionScreen.xMin, y, regionScreen.width, 1f), new Color(color.r, color.g, color.b, 0.3f));

                const float hs = FaceMapTextureRenderer.HandleSize;
                var hr = new Rect(knob.x - hs * 0.5f, y - hs * 0.5f, hs, hs);
                EditorGUI.DrawRect(new Rect(hr.x - 1, hr.y - 1, hr.width + 2, hr.height + 2), Color.black);
                EditorGUI.DrawRect(hr, dragging ? Color.yellow : used ? color : new Color(0.7f, 0.7f, 0.7f));

                string text = lower ? "目の下の線" : "目の線";
                if (lower) GUI.Label(new Rect(hr.xMin - 64f, y - 8f, 60f, 16f), text, _lineLabelRight);
                else GUI.Label(new Rect(hr.xMax + 4f, y - 8f, 60f, 16f), text, _lineLabelLeft);
            }
        }

        private static GUIStyle _lineLabelLeft;
        private static GUIStyle _lineLabelRight;

        /// <summary>
        /// 警告の「線を置く」。この組み合わせの調整として目の下の線を置き（目の線が無ければ目の線も）、目を調整の対象にして
        /// つまみをドラッグできるようにする。目の線があれば、そのすぐ下（最小の間隔）に置く（自動作成と同じ）。
        /// </summary>
        private void PlaceAvatarLowerLine()
        {
            FaceMapMatch match = _state.PairMatch;
            if (match == null) return;

            float line, lower;
            if (match.AvatarEyeLine.HasValue)
            {
                line = Mathf.Max(match.AvatarEyeLine.Value, FaceMapFile.MinEyeLine + FaceMapFile.MinEyeBand);
                lower = line - FaceMapFile.MinEyeBand;
            }
            else
            {
                line = FaceMapEditorViewModel.DefaultEyeLine;
                lower = line - FaceMapEditorViewModel.DefaultEyeLowerGap;
            }

            _editTarget = FaceMapFile.EyeCategory;
            _viewMode = FaceMapPreview.ViewMode.Result;
            _centerMode = CenterMode.Uv2D; // つまみをドラッグできる 2D UV 表示にする
            SetEyeLineOverrides(line, lower);
        }

        /// <summary>カーソル位置の UV が動かないように拡大・縮小する。</summary>
        private void ZoomAt(Rect area, Rect texRect, Vector2 mouse, float factor)
        {
            float next = Mathf.Clamp(_zoom * factor, MinZoom, MaxZoom);
            if (Mathf.Approximately(next, _zoom)) return;

            Vector2 uv = ScreenToUvUnclamped(mouse, texRect);
            Rect fit = UVCoordinateConverter.FitRect(area, TextureAspect());
            float w = fit.width * next, h = fit.height * next;
            var topLeft = new Vector2(mouse.x - uv.x * w, mouse.y - (1f - uv.y) * h);
            Vector2 center = topLeft + new Vector2(w * 0.5f, h * 0.5f);

            _zoom = next;
            _pan = _zoom <= MinZoom ? Vector2.zero : ClampPan(area, center - fit.center);
            Repaint();
        }

        /// <summary>テクスチャが表示欄から完全に外れないよう、移動量を収める。</summary>
        private Vector2 ClampPan(Rect area, Vector2 pan)
        {
            Rect fit = UVCoordinateConverter.FitRect(area, TextureAspect());
            float mx = fit.width * _zoom * 0.5f, my = fit.height * _zoom * 0.5f;
            return new Vector2(Mathf.Clamp(pan.x, -mx, mx), Mathf.Clamp(pan.y, -my, my));
        }

        /// <summary>範囲外も含めた UV（UVCoordinateConverter.ScreenToUv は 0〜1 にクランプする）。</summary>
        private static Vector2 ScreenToUvUnclamped(Vector2 screen, Rect rect)
        {
            return new Vector2(
                (screen.x - rect.x) / rect.width,
                1f - (screen.y - rect.y) / rect.height);
        }
    }
}
