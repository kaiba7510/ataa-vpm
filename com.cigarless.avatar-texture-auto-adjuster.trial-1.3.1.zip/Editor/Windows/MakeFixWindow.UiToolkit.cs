using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── UI Toolkit ルート・共通状態 ──

        private bool _uiBuilt;
        private bool _uiDirty = true;
        private bool _uiInteracting;
        private bool _suppressUiEvents;
        private double _lastPeriodicSync;

        private VisualElement _root;
        private Button _btnReadinessPill;
        private Label _lblBreadcrumbAvatar;
        private Label _lblBrandTier;
        private VisualElement _headerBanner;
        private Label _lblHeaderBannerText;
        private Button _btnFrameScene;
        private Button _btnFaceMapEditor;
        private Button _btnDiagnostics;
        private Button _btnRefresh;

        private VisualElement _statusBarDot;
        private Label _lblGlobalStatus;
        private Label _lblStatusBusy;

        private readonly Dictionary<FocusCard, VisualElement> _cardElements = new Dictionary<FocusCard, VisualElement>();
        private IVisualElementScheduledItem _flashTimer;

        /// <summary>プレビュー・スライダー・スクラブ操作中か（低解像度プレビュー＆保存遅延の判定）。</summary>
        private bool IsInteracting => MakeFixInteraction.IsInteracting(
            previewDragging: _previewDrag != PreviewDrag.None,
            panning: _panning,
            orbitDragging: _orbit != null && _orbit.IsDragging,
            uiScrubbing: _uiInteracting);

        private void CreateGUI()
        {
            _uiBuilt = false;
            rootVisualElement.Clear();

            string apiMismatch = CoreApiCompatibility.GetMismatchMessage();
            if (apiMismatch != null)
            {
                Debug.LogError("[ATAA] " + apiMismatch);
                var err = new Label(apiMismatch);
                err.style.whiteSpace = WhiteSpace.Normal;
                err.style.paddingLeft = 12;
                err.style.paddingRight = 12;
                err.style.paddingTop = 12;
                rootVisualElement.Add(err);
                return;
            }

            VisualTreeAsset uxml = UiAssets.Load<VisualTreeAsset>("MakeFixWindow", ".uxml");
            StyleSheet uss = UiAssets.Load<StyleSheet>("MakeFixWindow", ".uss");

            if (uss != null) rootVisualElement.styleSheets.Add(uss);
            if (uxml != null)
            {
                uxml.CloneTree(rootVisualElement);
            }
            else
            {
                var err = new Label("MakeFixWindow.uxml が見つかりませんでした。");
                err.style.paddingLeft = 12;
                err.style.paddingTop = 12;
                rootVisualElement.Add(err);
                return;
            }

            _root = rootVisualElement.Q<VisualElement>("ataa-root");
            rootVisualElement.focusable = true;
            _cardElements.Clear();

            BindHeaderUi();
            BindLeftUi();
            BindCenterUi();
            BindRightUi();
            BindStatusBarUi();
            BindGlobalHotkeys();
            StartAttentionBlink();

            _uiBuilt = true;
            _uiDirty = true;
            if (_state.FaceMaps == null || _state.FaceMaps.Count == 0)
                RequestRefresh();
            SyncAndRefreshUi();
        }

        internal void MarkUiDirty()
        {
            _uiDirty = true;
            _viewportImgui?.MarkDirtyRepaint();
        }

        private bool _lastSceneViewAvailable;

        private void TickUiToolkit()
        {
            _preview.Poll();

            if (_pendingSave && !IsInteracting) FlushPendingSave();
            if (!IsInteracting) _history.EndGesture(); // ドラッグなどが終わったら、次の変更は元に戻すの別の 1 回

            if (_requestedQuality == FaceMapPreview.Quality.Low && !IsInteracting)
            {
                _uiDirty = true;
            }

            if (!_uiBuilt) return;

            TickAutoSetup();

            if (_uiDirty)
            {
                SyncAndRefreshUi();
                return;
            }

            // アイドル時・バックグラウンド時は負荷をかけない。フォーカス中だけ SceneView の有無を軽く監視
            if (focusedWindow == this)
            {
                double now = EditorApplication.timeSinceStartup;
                if (now - _lastPeriodicSync >= 1.0)
                {
                    _lastPeriodicSync = now;
                    bool hasScene = SceneView.lastActiveSceneView != null;
                    if (hasScene != _lastSceneViewAvailable)
                    {
                        _lastSceneViewAvailable = hasScene;
                        _btnFrameScene?.SetEnabled(_state.TargetAvatar != null && hasScene);
                    }
                }
            }
        }

        private void SyncAndRefreshUi()
        {
            if (!_uiBuilt) return;
            _uiDirty = false;

            // アバターの切り替え（アバター基準・顔テクスチャの選び直し）を先に反映してから組み合わせを読み直す。
            // 逆だと、切り替えたフレームに新しい顔テクスチャを前のアバターの基準で合成してしまい、一瞬ずれて映っていた
            SyncAvatarSelection();
            if (_previewDrag == PreviewDrag.None)
                _ = _toolService.RefreshPairAsync();

            SyncTextureMemory();
            SyncFaceTextureHint();
            UpdateSnapshot();
            EnsurePreview();
            EnsureTrialHighPreview();
            SyncLive();
            SyncOrbitTarget();

            if (!(AtaaCore.Edition == CoreEdition.Trial)) UpdateUnsavedState();

            _suppressUiEvents = true;
            try
            {
                RefreshHeaderUi();
                RefreshLeftUi();
                RefreshCenterUi();
                RefreshRightUi();
                RefreshStatusBarUi();
            }
            finally
            {
                _suppressUiEvents = false;
            }

            _viewportImgui?.MarkDirtyRepaint();
        }

        // ── Header ──

        private void BindHeaderUi()
        {
            _btnReadinessPill = _root.Q<Button>("readiness-pill");
            _lblBreadcrumbAvatar = _root.Q<Label>("breadcrumb-avatar");
            _lblBrandTier = _root.Q<Label>("brand-tier");
            _headerBanner = _root.Q<VisualElement>("header-banner");
            _lblHeaderBannerText = _root.Q<Label>("header-banner-text");
            _btnFrameScene = _root.Q<Button>("btn-frame-scene");
            _btnFaceMapEditor = _root.Q<Button>("btn-facemap-editor");
            _btnDiagnostics = _root.Q<Button>("btn-diagnostics");
            _btnRefresh = _root.Q<Button>("btn-refresh");

            if (AtaaCore.Edition == CoreEdition.Trial)
            {
                if (_lblBrandTier != null) _lblBrandTier.text = "Trial";
                if (_headerBanner != null)
                {
                    _headerBanner.RemoveFromClassList("hidden");
                    _lblHeaderBannerText.text = "体験版: プレビューでの確認まで利用できます（書き出し・適用は製品版）";
                }
            }
#if ATAA_DIAGNOSTICS
            else
            {
                if (_lblBrandTier != null) _lblBrandTier.text = "Open β";
                if (_headerBanner != null)
                {
                    _headerBanner.RemoveFromClassList("hidden");
                    _lblHeaderBannerText.text = "オープンβ稼働中: 実行前にプロジェクトのバックアップを推奨します";
                }
                _btnDiagnostics?.RemoveFromClassList("hidden");
            }
#endif

            _btnReadinessPill.clicked += () =>
            {
                if (_allOk) return;
                ReadinessItem firstFailed = NextItem();
                if (firstFailed != null) FocusCardUi(CardFor(firstFailed));
            };

            _btnFrameScene.tooltip = "Scene ビューのカメラを顔の正面に向けます。";
            _btnFrameScene.clicked += () =>
            {
                if (_state.TargetAvatar != null)
                    LiveFacePreview.FrameFace(_state.TargetAvatar, _state.PreviewAvatarTexture);
            };

            _btnFaceMapEditor.clicked += () => MyVrcToolFaceMapEditorWindow.ShowWindow();

#if ATAA_DIAGNOSTICS
            _btnDiagnostics.tooltip = "（オープンβ用）対象アバターの自動生成の入力と結果を調べ、一覧を出します。";
            _btnDiagnostics.clicked += () => RunDiagnostics();
#endif

            _btnRefresh.tooltip = "FaceMaps フォルダとシーンのアバターを読み直します。";
            _btnRefresh.clicked += TriggerRefreshAll;
        }

        private void TriggerRefreshAll()
        {
            _avatarsDirty = true;
            _faceCandidatesDirty = true;
            _slotsDirty = true;
            RequestRefresh();
            MarkUiDirty();
        }

        private void RefreshHeaderUi()
        {
            ReadinessItem firstFailed = NextItem();
            if (_allOk)
            {
                _btnReadinessPill.text = "準備完了";
                _btnReadinessPill.tooltip = "メイクを適用できます（右下の「メイク適用」）。";
                _btnReadinessPill.AddToClassList("status-pill--ok");
                _btnReadinessPill.RemoveFromClassList("status-pill--warn");
            }
            else
            {
                int remaining = Mathf.Max(1, TotalSteps - CountDoneSteps());
                _btnReadinessPill.text = $"あと {remaining} ステップ ›";
                _btnReadinessPill.tooltip = firstFailed != null
                    ? $"次: {firstFailed.Message}\n押すとその項目へ移動します。"
                    : "";
                _btnReadinessPill.RemoveFromClassList("status-pill--ok");
                _btnReadinessPill.AddToClassList("status-pill--warn");
            }

            _lblBreadcrumbAvatar.text = _state.TargetAvatar != null ? _state.TargetAvatar.name : "未選択";
            _btnFrameScene.SetEnabled(_state.TargetAvatar != null && SceneView.lastActiveSceneView != null);
#if ATAA_DIAGNOSTICS
            _btnDiagnostics.SetEnabled(_state.TargetAvatar != null && !_applying);
#endif
        }

        // ── Bottom Global Status Bar ──

        private void BindStatusBarUi()
        {
            _statusBarDot = _root.Q<VisualElement>("status-bar-dot");
            _lblGlobalStatus = _root.Q<Label>("lbl-global-status");
            _lblStatusBusy = _root.Q<Label>("lbl-status-busy");
        }

        private void RefreshStatusBarUi()
        {
            string status = MakeFixReadiness.FirstLine(_state.Warning);
            bool busy = _preview.IsBusy || _applying;
            if (string.IsNullOrEmpty(status)) status = _allOk ? "準備完了" : "アバターとメイク元を選択してください";
            _lblGlobalStatus.text = status;
            _lblGlobalStatus.tooltip = _state.Warning ?? "";

            _statusBarDot.RemoveFromClassList("status-bar-dot--warn");
            _statusBarDot.RemoveFromClassList("status-bar-dot--error");
            if (_state.WarningType == MessageType.Error) _statusBarDot.AddToClassList("status-bar-dot--error");
            else if (_state.WarningType == MessageType.Warning) _statusBarDot.AddToClassList("status-bar-dot--warn");

            string analyzing = AutoProgressText;
            _lblStatusBusy.text = _applying ? "Applying..."
                : _preview.IsBusy ? "Rendering..."
                : analyzing.Length > 0 ? analyzing
                : "Ready";
        }

        // ── Focus & Flash Card ──

        private void FocusCardUi(FocusCard card)
        {
            if (card == FocusCard.None || !_cardElements.TryGetValue(card, out VisualElement el)) return;
            ScrollView sv = IsLeftCard(card) ? _leftScrollView : _rightScrollView;
            if (card != FocusCard.Avatar && IsLeftCard(card) && _manualCards != null && _manualCards.ClassListContains("hidden"))
            {
                // 「あと N ステップ」で②〜④へ飛んだときは、折りたたまれていても開く
                _manualCardsOpen = true;
                _manualCards.RemoveFromClassList("hidden");
                MarkUiDirty();
                rootVisualElement.schedule.Execute(() => sv?.ScrollTo(el)).StartingIn(30);
            }
            else
            {
                sv?.ScrollTo(el);
            }

            _flashTimer?.Pause();
            foreach (VisualElement v in _cardElements.Values) v.RemoveFromClassList("section-card--flash");
            el.AddToClassList("section-card--flash");
            _flashTimer = rootVisualElement.schedule.Execute(() => el.RemoveFromClassList("section-card--flash")).StartingIn(1100);
        }

        private void ApplyCardHighlight(FocusCard card, VisualElement el)
        {
            if (el == null) return;
            bool isCurrent = card == _currentCard && !_allOk;
            el.EnableInClassList("section-card--current", isCurrent);
        }

        // ── 設定待ちの点滅 ──

        private const string BlinkClass = "attention-bright";

        /// <summary>手順が止まっている間、設定が必要なカードと手順の丸を点滅させる。</summary>
        private void StartAttentionBlink()
        {
            rootVisualElement.schedule.Execute(() =>
            {
                bool busy = _preview.IsBusy || _applying;
                bool bright = MakeFixAttentionBlink.IsBright(EditorApplication.timeSinceStartup);
                foreach (var kv in _cardElements)
                {
                    VisualElement card = kv.Value;
                    bool blink = MakeFixAttentionBlink.ShouldBlink(kv.Key == _currentCard, _allOk, busy);
                    card.EnableInClassList(BlinkClass, blink && bright);
                    VisualElement dot = card.Q(className: "step-dot");
                    dot?.EnableInClassList(BlinkClass, blink && bright && dot.ClassListContains("step-dot--current"));
                }
            }).Every(150);
        }

        private static void SetStepDot(VisualElement dot, MakeFixGui.StepState state)
        {
            if (dot == null) return;
            dot.RemoveFromClassList("step-dot--ok");
            dot.RemoveFromClassList("step-dot--current");
            dot.RemoveFromClassList("step-dot--warn");
            dot.RemoveFromClassList("step-dot--pending");
            switch (state)
            {
                case MakeFixGui.StepState.Done: dot.AddToClassList("step-dot--ok"); break;
                case MakeFixGui.StepState.Current: dot.AddToClassList("step-dot--current"); break;
                case MakeFixGui.StepState.Problem: dot.AddToClassList("step-dot--warn"); break;
                default: dot.AddToClassList("step-dot--pending"); break;
            }
        }

        // ── Global Hotkeys (C / H) ──

        private void BindGlobalHotkeys()
        {
            rootVisualElement.RegisterCallback<KeyDownEvent>(OnRootKeyDown, TrickleDown.TrickleDown);
            rootVisualElement.RegisterCallback<KeyUpEvent>(OnRootKeyUp, TrickleDown.TrickleDown);
        }

        private bool IsTextInputFocused()
        {
            Focusable focused = rootVisualElement.focusController?.focusedElement;
            return focused is TextInputBaseField<string> || focused is TextInputBaseField<float> ||
                   focused is TextInputBaseField<int> || EditorGUIUtility.editingTextField;
        }

        private bool IsFieldFocused(VisualElement field)
        {
            if (field == null) return false;
            VisualElement focused = rootVisualElement.focusController?.focusedElement as VisualElement;
            while (focused != null)
            {
                if (focused == field) return true;
                focused = focused.parent;
            }
            return false;
        }

        private void OnRootKeyDown(KeyDownEvent evt)
        {
            if (evt.ctrlKey || evt.commandKey || evt.altKey || evt.shiftKey) return;
            if (IsTextInputFocused()) return;
            if (!_centerFocused && !_pointerOverViewport) return;

            if (evt.keyCode == KeyCode.C && _showPreview)
            {
                if (!_compareKeyHeld)
                {
                    _compareKeyHeld = true;
                    UpdateComparing();
                    MarkUiDirty();
                }
                evt.StopPropagation();
                return;
            }

            if (evt.keyCode == KeyCode.H && _centerMode == CenterMode.View3D)
            {
                SetHideDecorations(!(_orbit != null && _orbit.HideDecorations));
                MarkUiDirty();
                evt.StopPropagation();
            }
        }

        private void OnRootKeyUp(KeyUpEvent evt)
        {
            if (evt.keyCode == KeyCode.C && _compareKeyHeld)
            {
                _compareKeyHeld = false;
                UpdateComparing();
                MarkUiDirty();
                evt.StopPropagation();
            }
        }

        // ── Pointer-Capture Drag Scrub Helpers (NudgePad equivalent for UI Toolkit) ──

        private void BindScrub2D(VisualElement el, Vector2 clickDir, string activeClass, Func<bool> canEdit, Action<Vector2> onDelta,
                                 Func<string> disabledReason = null)
        {
            UiScrub.Bind2D(el, clickDir, activeClass, canEdit, () => NudgePad.CurrentStep(NudgePad.MakeFixStepKey),
                (d, _) => onDelta(d), OnScrubHeld);
            UiScrub.BindHoverTooltip(el, () => UiScrub.HoverHint2D(clickDir, canEdit(), disabledReason?.Invoke()));
        }

        private void BindScrub1D(VisualElement el, float clickSign, string activeClass, Func<bool> canEdit, Action<float> onSteps,
                                 Func<string> disabledReason = null)
        {
            UiScrub.Bind1D(el, clickSign, activeClass, canEdit, (s, _) => onSteps(s), OnScrubHeld);
            UiScrub.BindHoverTooltip(el, () => UiScrub.HoverHint1D(canEdit(), disabledReason?.Invoke()));
        }

        private void OnScrubHeld(bool held)
        {
            _uiInteracting = held;
            if (held) return;
            FlushPendingSave();
            MarkUiDirty();
        }

        private void RegisterSliderInteraction(Slider slider)
        {
            slider.RegisterCallback<PointerDownEvent>(_ => { _uiInteracting = true; }, TrickleDown.TrickleDown);
            slider.RegisterCallback<PointerUpEvent>(_ =>
            {
                _uiInteracting = false;
                FlushPendingSave();
                MarkUiDirty();
            }, TrickleDown.TrickleDown);
            slider.RegisterCallback<PointerCaptureOutEvent>(_ =>
            {
                _uiInteracting = false;
                FlushPendingSave();
                MarkUiDirty();
            });
        }
    }
}
