using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using AvatarTextureAutoAdjuster.Core;

namespace AvatarTextureAutoAdjuster.Editor
{
    public partial class MakeFixWindow
    {
        // ── プレビュー（§13.5）──

        // ── 中央ペイン: 3D 顔ビュー / 2D UV（3ペイン仕様 §3）──

        private void DrawCenterPane()
        {
            EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));

            DrawCenterToolbar();

            // 変形・マスクの問題（§13.7）。選ぶものが揃っているときだけ
            if (_setupOk)
            {
                // 6（顔テクスチャを使っていない）は左の「顔テクスチャ」カードに出す
                ReadinessItem problem = MakeFixReadiness.FirstFailed(_readiness, 7, 8);
                if (problem != null) DrawProblemLine(problem);
                else if (!string.IsNullOrEmpty(_previewError)) DrawWarnLine(MakeFixReadiness.FirstLine(_previewError), _previewError, null, null);
                else if (!string.IsNullOrEmpty(_preview.LastError))
                    DrawWarnLine("プレビューを作れませんでした", _preview.LastError, null, null);
                else if (_preview.Output != null && _preview.Distortion.HasFold)
                    DrawDistortionLine(_preview.Distortion, _preview.BaselineDistortion?.RemainingInvertedCells, _state.PairMatch);
                else
                    DrawFaceStyleLine(_state.PairMatch);

                // 目の下の線が片方に無い組み合わせ（下まつげが潰れやすい）。ほかの 1 行とは別に常に出す
                if (_lowerLineNote != null)
                {
                    const string why =
                        "目の下の線（下まつげの生え際）がメイク元・対象の両方にあるときだけ、" +
                        "目の下の肌（下まつげ・涙袋）を横と同じ倍率で写します（下まつ毛幅・目尻フレアもこの段に掛かります）。\n" +
                        "片方でも無いと、目の線より下をまとめて 1 段で写すため、下まつげが縦に潰れることがあります。\n";
                    if (_lowerLineAvatarMissing)
                    {
                        // 対象側は、この画面で置いてそのままドラッグで直せる（この組み合わせの調整に保存。FaceMap は変えない）
                        DrawWarnLine(_lowerLineNote,
                            why + "「線を置く」で、目の線のすぐ下に置きます（この組み合わせの調整 .adjust.json に保存され、FaceMap は変わりません）。\n" +
                            "置いた後は、2D UV 表示で目の枠の左のつまみを上下にドラッグして、下まつげの生え際に合わせてください。",
                            "線を置く", PlaceAvatarLowerLine);
                    }
                    else
                    {
                        DrawWarnLine(_lowerLineNote,
                            why + "FaceMap エディターで、メイク元の FaceMap の目の領域に「目の下の線」を置いてください。",
                            "FaceMap エディター", () => MyVrcToolFaceMapEditorWindow.ShowWindow());
                    }
                }

                // 口の大きさがメイク元と大きく違う組み合わせ（口が小さく描かれたデフォルメ調のアバターなど）。
                // 合成は止めず、崩れやすいことを伝えて、使うかどうかはプレビューを見て決めてもらう。ほかの 1 行とは別に常に出す
                FaceMapAdjustment pairAdj = _state.Adjustment;
                if (pairAdj != null && pairAdj.IsEnabled(FaceMapFile.MouthCategory) && AtaaCore.IsExtremeMouthScale(_state.PairMatch))
                {
                    DrawWarnLine(
                        $"口の大きさがメイク元と大きく違います（顔に対して約 {AtaaCore.RelativeMouthScale(_state.PairMatch):0.#} 倍）。唇が崩れることがあります",
                        "口が小さく描かれたデフォルメ調のアバターなどでは、メイク元の唇を大きく縮めて写すため、" +
                        "位置・大きさ・口の曲がりを調整しても形を合わせきれないことがあります。\n" +
                        "合成はそのまま行います。プレビューで口元を拡大して確かめ、合わなければ口を合成しない（アバターの元の口を残す）にしてください。\n" +
                        "目安: 口の幅の倍率が、目の幅の倍率の " + AtaaCore.DeformedMouthScale.ToString("0.#") + " 倍以上（または 1/" +
                        AtaaCore.DeformedMouthScale.ToString("0.#") + " 以下）。",
                        "口を合成しない", () =>
                        {
                            pairAdj.SetEnabled(FaceMapFile.MouthCategory, false);
                            MarkAdjustmentChanged();
                        });
                }

                // メイク元が目の開いていない素体（Lapwing など）。目の開いた部分は対象の元の目を残す（§4.6）
                if (_keepsAvatarEye)
                {
                    DrawInfoLine("メイク元は目の開いていない素体のため、目の開いた部分は対象の元の目を残します",
                        "メイク元の顔テクスチャには目の開いた部分（白目・瞳）が無く、上下のまぶたの縁が UV 上でほぼ重なっています。\n" +
                        "そのまま写すと細い帯が縦に大きく引き伸ばされるため、対象の目の下の線〜目の線の間にはメイクを乗せません。\n" +
                        "上まつげ・目の下の肌は、これまでどおり写します。メイク元の FaceMap の分類は FaceMap エディターの目の欄で変えられます。");
                }
            }

            Rect area = GUILayoutUtility.GetRect(GUIContent.none, GUIStyle.none,
                GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));

            if (Event.current.type != EventType.Layout)
            {
                _centerRect = area;
                Event e = Event.current;
                // 中央ビューをクリックしたらフォーカスを持つ（H キーの切り替えの対象にする）
                if (e.type == EventType.MouseDown)
                {
                    _centerFocused = area.Contains(e.mousePosition);
                    if (_centerFocused) GUI.FocusControl(null);
                }

                // 比較ボタンはビューの上に重ねるので、押したことをビューの操作（2D のドラッグなど）より先に受け取る
                HandleCompareInput(area);
                if (_centerMode == CenterMode.View3D) Draw3DView(area);
                else Draw2DView(area);
                DrawCompareOverlay(area);
            }

            EditorGUILayout.EndVertical();
        }

        // ── 比較（押している間だけメイク前）──
        private bool _compareMouseHeld;
        private bool _compareKeyHeld;
        private static readonly GUIContent CompareHitContent =
            new GUIContent("ATAA.CompareOverlay", "押している間（または C キーを押している間）だけ、最初の顔テクスチャ（メイク前）を表示します。");
        private static GUIStyle _invisibleStyle;
        private static GUIStyle _compareLabelStyle;
        private static GUIStyle _compareKeyStyle;

        /// <summary>ビューの右下の比較ボタンの矩形（下端の説明バーの上）。</summary>
        private Rect CompareButtonRect(Rect area)
        {
            const float w = 168f, h = 36f;
            float bottom = area.yMax - 22f;
            return new Rect(area.xMax - w - 10f, bottom - h - 10f, w, h);
        }

        /// <summary>比較ボタンを押しているかを受け取る（描くのは DrawCompareOverlay。ここでは見えないボタン）。</summary>
        private void HandleCompareInput(Rect area)
        {
            bool held = false;
            if (_showPreview)
            {
                if (_invisibleStyle == null) _invisibleStyle = new GUIStyle { normal = { textColor = Color.clear } };
                held = NudgePad.HoldControl(CompareButtonRect(area), CompareHitContent, _invisibleStyle, out _);
            }
            if (held != _compareMouseHeld || (_comparing && !_showPreview))
            {
                _compareMouseHeld = held;
                UpdateComparing();
            }
        }

        /// <summary>ビューの右下に重ねる、半透明の大きな「比較」ボタン。</summary>
        private void DrawCompareOverlay(Rect area)
        {
            if (!_showPreview || Event.current.type != EventType.Repaint) return;
            // 明るいボタンに濃い文字（暗い背景・明るい肌のどちらの上でも読めるように、薄い縁も付ける）
            var ink = new Color(0.12f, 0.12f, 0.12f);
            if (_compareLabelStyle == null)
            {
                _compareLabelStyle = new GUIStyle(EditorStyles.boldLabel) { alignment = TextAnchor.MiddleLeft, fontSize = 12 };
                _compareKeyStyle = new GUIStyle(EditorStyles.miniBoldLabel) { alignment = TextAnchor.MiddleCenter };
            }
            _compareLabelStyle.normal.textColor = ink;
            _compareKeyStyle.normal.textColor = ink;

            Rect r = CompareButtonRect(area);
            bool hover = r.Contains(Event.current.mousePosition);
            Color bg = _comparing ? MakeFixGui.Warning : new Color(1f, 1f, 1f, hover ? 0.95f : 0.82f);
            MakeFixGui.DrawRounded(new Rect(r.x - 1f, r.y - 1f, r.width + 2f, r.height + 2f), new Color(0f, 0f, 0f, 0.3f));
            MakeFixGui.DrawRounded(r, bg);
            GUI.Label(new Rect(r.x + 12f, r.y, r.width - 44f, r.height),
                _comparing ? "メイク前を表示中" : "押している間：メイク前", _compareLabelStyle);

            // キーの案内（C）
            var key = new Rect(r.xMax - 30f, r.center.y - 9f, 20f, 18f);
            MakeFixGui.DrawRounded(key, new Color(0f, 0f, 0f, 0.12f));
            GUI.Label(key, "C", _compareKeyStyle);
            EditorGUIUtility.AddCursorRect(r, MouseCursor.Link);
        }

        /// <summary>マウス・C キーのどちらかで押していれば比較中にする。</summary>
        private void UpdateComparing()
        {
            bool next = _showPreview && (_compareMouseHeld || _compareKeyHeld);
            if (next == _comparing) return;
            _comparing = next;
            SyncLive();
            _orbit?.MarkDirty();
            Repaint();
        }

        /// <summary>上部ツールバー: [3Dビュー | 2D UV]・[装飾品: 表示/非表示]・[補助ライト: ON/OFF]・[正面リセット]。2D UV の表示切替は 2 行目。比較はビュー右下（DrawCompareOverlay）。</summary>
        private void DrawCenterToolbar()
        {
            bool modeChanged = false;
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);

            int mode = GUILayout.Toolbar((int)_centerMode, CenterModeLabels, EditorStyles.toolbarButton, GUILayout.Width(122f));
            if (mode != (int)_centerMode)
            {
                _centerMode = (CenterMode)mode;
                EditorPrefs.SetInt(CenterModeKey, mode);
                if (_orbit != null) _orbit.SoloRenderer = _centerMode == CenterMode.View3D ? _hoveredFaceRenderer : null;
                // 2D UV のドラッグ・表示移動は 2D の処理の中でしか終わらないので、切り替えたら終える
                // （残ると 3D 表示で PAD が無効のまま・プレビューが低解像度のまま、になる）
                _panning = false;
                if (_previewDrag != PreviewDrag.None) EndPreviewDrag();
                _orbit?.MarkDirty();
                modeChanged = true;
            }

            if (_centerMode == CenterMode.View3D)
            {
                GUILayout.Space(4f);
                bool hide = _orbit != null && _orbit.HideDecorations;
                bool nextHide = GUILayout.Toggle(hide,
                    new GUIContent(hide ? "装飾品: 非表示" : "装飾品: 表示",
                        "前髪・メガネなどを一時的に隠して、顔メッシュだけを映します（H キー）。シーンには保存されません。"),
                    EditorStyles.toolbarButton, GUILayout.Width(88f));
                if (nextHide != hide) SetHideDecorations(nextHide);

                bool aux = _orbit != null && _orbit.AuxiliaryLight;
                bool nextAux = GUILayout.Toggle(aux,
                    new GUIContent(aux ? "補助ライト: ON" : "補助ライト: OFF", "カメラに追従するライトで照らします（暗いワールドでも発色と境界を確認できます）。"),
                    EditorStyles.toolbarButton, GUILayout.Width(86f));
                if (nextAux != aux && _orbit != null)
                {
                    _orbit.AuxiliaryLight = nextAux;
                    EditorPrefs.SetBool(AuxLightKey, nextAux);
                }

                string bgLabel = ViewportBackground.Label(_orbit != null ? _orbit.Background : ViewportBackground.Default);
                if (GUILayout.Button(new GUIContent(bgLabel, BackgroundTooltip), EditorStyles.toolbarButton, GUILayout.Width(96f)))
                    CycleBackground();

                using (new EditorGUI.DisabledScope(_orbit == null || !_orbit.HasTarget))
                {
                    if (GUILayout.Button(new GUIContent("正面リセット", "カメラを顔の正面・既定の距離に戻します。"), EditorStyles.toolbarButton, GUILayout.Width(68f)))
                        _orbit.ResetToFront();
                }
            }

            GUILayout.FlexibleSpace();

            // ライブプレビュー（§13.6）。OFF にすると、シーンと 3D 顔ビューは元の見た目になる
            EditorGUI.BeginChangeCheck();
            bool liveOn = LiveEnabled;
            bool live = GUILayout.Toggle(liveOn,
                new GUIContent(liveOn ? "調整を表示: ON" : "調整を表示: OFF",
                    "調整中の結果を、シーン上のアバター（と 3D 顔ビュー）に一時的に表示します（保存されません）。" +
                    "OFF にすると、シーンのアバターは元の見た目に戻ります。\n" +
                    "2D UV ビューでは、この画面の表示は変わりません（シーンのアバターだけが切り替わります）。"),
                EditorStyles.toolbarButton, GUILayout.Width(92f));
            if (EditorGUI.EndChangeCheck())
            {
                LiveEnabled = live;
                SyncLive();
                Repaint();
            }
            // 3D 顔ビューはシーンと同じものを映すので、状態はビューのバッジで示す。2D UV ではシーンの状態をここに出す
            if (_centerMode != CenterMode.View3D) DrawLiveStatus();
            // 「比較」はビューの右下に大きく出す（DrawCompareOverlay）

            EditorGUILayout.EndHorizontal();

            if (modeChanged)
            {
                Repaint();
                GUIUtility.ExitGUI();
            }

            // 2D UV 専用の表示切替・ズーム操作は 2 行目に分け、最小幅でも右ペインを押し出さないようにする
            if (_centerMode == CenterMode.Uv2D)
            {
                EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
                using (new EditorGUI.DisabledScope(!_showPreview))
                {
                    int next = GUILayout.Toolbar((int)_viewMode, ViewModeLabels, EditorStyles.toolbarButton, GUILayout.Width(220f));
                    if (next != (int)_viewMode) _viewMode = (FaceMapPreview.ViewMode)next;
                    GUILayout.Space(6f);
                    GUILayout.Label($"{Mathf.RoundToInt(_zoom * 100f)}%", EditorStyles.miniLabel, GUILayout.Width(40f));
                    if (GUILayout.Button("全体表示", EditorStyles.toolbarButton, GUILayout.Width(60f))) ResetZoom();
                }
                GUILayout.FlexibleSpace();
                EditorGUILayout.EndHorizontal();
            }
        }

        private const string BackgroundTooltip =
            "3D ビューの背景を切り替えます（暗い → 中間 → 明るい → チェッカー）。どれも色みの無いグレーなので、肌の色の見え方は変わりません。";

        private void CycleBackground()
        {
            if (_orbit == null) return;
            _orbit.Background = ViewportBackground.Next(_orbit.Background);
            EditorPrefs.SetInt(BackgroundKey, (int)_orbit.Background);
            _viewportImgui?.MarkDirtyRepaint();
            Repaint();
        }

        private void SetHideDecorations(bool hide)
        {
            if (_orbit == null) return;
            _orbit.HideDecorations = hide;
            EditorPrefs.SetBool(HideDecorationsKey, hide);
            Repaint();
        }

        /// <summary>
        /// ホットキー: 中央ビューにフォーカスがある（クリックした・マウスが上にある）とき、H で「装飾品: 表示/非表示」を切り替える。
        /// 数値欄などに入力中は奪わない。
        /// </summary>
        private void HandleHotkeys()
        {
            Event e = Event.current;

            // C: 押している間だけ比較（3D・2D のどちらでも）。離したらいつでも戻す
            if (e.keyCode == KeyCode.C)
            {
                if (e.type == EventType.KeyUp && _compareKeyHeld)
                {
                    _compareKeyHeld = false;
                    UpdateComparing();
                    e.Use();
                    return;
                }
                if (e.type == EventType.KeyDown && !e.control && !e.command && !e.alt && !e.shift && _showPreview
                    && !EditorGUIUtility.editingTextField && GUIUtility.keyboardControl == 0
                    && (_centerFocused || _centerRect.Contains(e.mousePosition)))
                {
                    if (!_compareKeyHeld) // キーの自動リピートでは何もしない
                    {
                        _compareKeyHeld = true;
                        UpdateComparing();
                    }
                    e.Use();
                    return;
                }
            }

            if (e.type != EventType.KeyDown || e.keyCode != KeyCode.H) return;
            if (e.control || e.command || e.alt || e.shift) return;
            if (_centerMode != CenterMode.View3D || EditorGUIUtility.editingTextField || GUIUtility.keyboardControl != 0) return;
            if (!_centerFocused && !_centerRect.Contains(e.mousePosition)) return;

            SetHideDecorations(!(_orbit != null && _orbit.HideDecorations));
            e.Use();
        }

        /// <summary>3D 顔ビューに映すアバター・顔メッシュ・残すレンダラー（顔のスロット）を渡す。</summary>
        private void SyncOrbitTarget()
        {
            if (_orbit == null) return;
            GameObject avatar = _state.TargetAvatar;
            if (avatar != null && EditorUtility.IsPersistent(avatar)) avatar = null; // プロジェクトのプレハブは映せない
            _orbit.SetTarget(avatar, _state.FaceRenderer, _faceSlotRenderers);
        }

        private void Draw3DView(Rect area)
        {
            if (_orbit == null || !_orbit.HasTarget)
            {
                if (Event.current.type == EventType.Repaint)
                {
                    EditorGUI.DrawRect(area, new Color(0.17f, 0.17f, 0.17f));
                    GUI.Label(area, "左のアバター管理でシーン上のアバターを選ぶと、顔がここに映ります", _emptyViewStyle);
                }
                return;
            }

            if (_orbit.HandleInput(area)) Repaint();

            if (Event.current.type == EventType.Repaint)
            {
                _orbit.Draw(area);

                // 何が映っているか（プレビュー・適用済み・元の見た目）は左上のバッジで示す。下のバーは操作の説明だけ
                var bar = new Rect(area.x, area.yMax - 22f, area.width, 22f);
                EditorGUI.DrawRect(bar, new Color(0f, 0f, 0f, 0.45f));
                GUI.Label(new Rect(area.x + 8f, bar.y + 3f, area.width - 14f, 16f),
                    "右ドラッグ: 回転　中ドラッグ: 移動　ホイール: ズーム　H: 装飾品　C: 比較", EditorStyles.whiteMiniLabel);
            }

            bool liveShown = _live != null && _live.IsAttached;
            float y = DrawViewStateBadge(area, liveShown);
            if (Event.current.type == EventType.Repaint && _orbit.SoloRenderer != null)
                GUI.Label(new Rect(area.x + 10f, y + 4f, area.width - 20f, 16f),
                    $"メッシュの候補を表示中: {_orbit.SoloRenderer.name}（一覧から外すと戻ります）", EditorStyles.whiteMiniLabel);
            else if (Event.current.type == EventType.Repaint && _orbit.HideDecorations)
                GUI.Label(new Rect(area.x + 10f, y + 4f, 200f, 16f), "装飾品: 非表示", EditorStyles.whiteMiniLabel);
        }
    }
}
